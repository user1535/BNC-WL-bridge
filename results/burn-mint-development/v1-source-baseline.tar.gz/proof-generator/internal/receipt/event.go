package receipt

import (
	"errors"
	"github.com/ethereum/go-ethereum/accounts/abi"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/core/types"
	"github.com/ethereum/go-ethereum/crypto"
	"math/big"
)

type Event struct {
	Sender           common.Address
	Recipient        common.Address
	Amount           *big.Int
	Nonce            uint64
	DestinationChain uint64
}

func DecodeBridgeEvent(log types.Log, action string, sourceChain uint64, sourceToken, destinationToken common.Address) (*Event, error) {
	if action != "lock" && action != "burn" {
		return nil, errors.New("unsupported bridge event action")
	}
	if (sourceChain != 31337 && sourceChain != 31338) || sourceToken == (common.Address{}) || destinationToken == (common.Address{}) {
		return nil, errors.New("unsupported local event domain")
	}
	if log.Address != sourceToken || len(log.Topics) != 4 || len(log.Data) != 96 {
		return nil, errors.New("malformed bridge event")
	}
	signature := "Locked(bytes32,address,address,uint256,uint64,uint256)"
	if action == "burn" {
		signature = "Burned(bytes32,address,address,uint256,uint64,uint256)"
	}
	if log.Removed || log.Topics[0] != crypto.Keccak256Hash([]byte(signature)) {
		return nil, errors.New("removed event or unexpected bridge topic")
	}
	for _, topic := range log.Topics[2:] {
		for _, b := range topic.Bytes()[:12] {
			if b != 0 {
				return nil, errors.New("invalid address topic")
			}
		}
	}
	sender := common.BytesToAddress(log.Topics[2].Bytes()[12:])
	recipient := common.BytesToAddress(log.Topics[3].Bytes()[12:])
	if sender == (common.Address{}) || sender != recipient {
		return nil, errors.New("bridge event recipient does not own source lock")
	}
	amount := new(big.Int).SetBytes(log.Data[:32])
	if amount.Sign() <= 0 {
		return nil, errors.New("zero bridge amount")
	}
	if new(big.Int).SetBytes(log.Data[32:64]).BitLen() > 64 || new(big.Int).SetBytes(log.Data[64:96]).BitLen() > 64 {
		return nil, errors.New("event nonce or chain ID exceeds uint64")
	}
	nonce := new(big.Int).SetBytes(log.Data[32:64]).Uint64()
	destinationChain := new(big.Int).SetBytes(log.Data[64:96]).Uint64()
	if (sourceChain == 31337 && destinationChain != 31338) || (sourceChain == 31338 && destinationChain != 31337) {
		return nil, errors.New("unexpected destination chain")
	}
	bytes32, _ := abi.NewType("bytes32", "", nil)
	uint256, _ := abi.NewType("uint256", "", nil)
	address, _ := abi.NewType("address", "", nil)
	uint64Type, _ := abi.NewType("uint64", "", nil)
	args := abi.Arguments{}
	values := []interface{}{}
	if action == "lock" {
		args = abi.Arguments{{Type: bytes32}, {Type: uint256}, {Type: address}, {Type: address}, {Type: address}, {Type: address}, {Type: uint256}, {Type: uint64Type}, {Type: uint256}}
		values = []interface{}{crypto.Keccak256Hash([]byte("WORLDLAND_BNB_BRIDGE_LOCK_V2")), new(big.Int).SetUint64(sourceChain),
			sourceToken, destinationToken, sender, recipient, amount, nonce, new(big.Int).SetUint64(destinationChain)}
	} else {
		args = abi.Arguments{{Type: bytes32}, {Type: uint256}, {Type: address}, {Type: uint256}, {Type: address},
			{Type: address}, {Type: address}, {Type: uint256}, {Type: uint64Type}, {Type: uint256}}
		values = []interface{}{crypto.Keccak256Hash([]byte("WORLDLAND_BNB_BRIDGE_BURN_V1")), new(big.Int).SetUint64(sourceChain),
			sourceToken, new(big.Int).SetUint64(destinationChain), destinationToken,
			sender, recipient, amount, nonce, new(big.Int).SetUint64(destinationChain)}
	}
	packed, err := args.Pack(values...)
	if err != nil {
		return nil, err
	}
	if crypto.Keccak256Hash(packed) != log.Topics[1] {
		return nil, errors.New("bridge event ID mismatch")
	}
	return &Event{Sender: sender, Recipient: recipient, Amount: amount, Nonce: nonce, DestinationChain: destinationChain}, nil
}
