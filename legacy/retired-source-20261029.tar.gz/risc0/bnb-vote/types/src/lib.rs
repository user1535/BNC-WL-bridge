#![no_std]
extern crate alloc;

use alloc::vec::Vec;
use bls12_381::{
    hash_to_curve::{ExpandMsgXmd, HashToCurve},
    multi_miller_loop, G1Affine, G1Projective, G2Affine, G2Prepared, G2Projective, Gt,
};
use bridge_native_header_binding::{validate_header, Profile};
use bridge_native_header_types::{
    hash, journal as native_journal, word, NativeBatch, NativeHeader,
};
use serde::{Deserialize, Serialize};

pub const HEADER_BINDING: &str = "bnb-vote-native-rlp-supplied-epoch";
pub const JOURNAL_BYTES: usize = 352;
pub const DST: &[u8] = b"BLS_SIG_BLS12381G2_XMD:SHA-256_SSWU_RO_POP_";
type Checked<T> = Result<T, &'static str>;

#[derive(Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct BnbVoteInput {
    pub batch: NativeBatch,
    pub epoch: NativeHeader,
}

struct Item<'a> {
    list: bool,
    value: &'a [u8],
    encoded: &'a [u8],
}
fn item(data: &[u8]) -> Checked<Item<'_>> {
    let p = *data.first().ok_or("empty RLP")?;
    if p < 0x80 {
        return Ok(Item {
            list: false,
            value: &data[..1],
            encoded: &data[..1],
        });
    }
    let list = p >= 0xc0;
    let n = usize::from(p - if list { 0xc0 } else { 0x80 });
    let (offset, len) = if n <= 55 {
        (1, n)
    } else {
        let encoded = data.get(1..1 + n - 55).ok_or("truncated RLP length")?;
        if encoded.first() == Some(&0) {
            return Err("noncanonical RLP length");
        }
        let mut len = 0usize;
        for b in encoded {
            len = len
                .checked_mul(256)
                .and_then(|a| a.checked_add(*b as usize))
                .ok_or("RLP length overflow")?;
        }
        if len < 56 {
            return Err("noncanonical long RLP");
        }
        (1 + encoded.len(), len)
    };
    let end = offset.checked_add(len).ok_or("RLP length overflow")?;
    let value = data.get(offset..end).ok_or("truncated RLP")?;
    if !list && len == 1 && value[0] < 0x80 {
        return Err("noncanonical RLP scalar");
    }
    Ok(Item {
        list,
        value,
        encoded: &data[..end],
    })
}
fn list(raw: &[u8], maximum: usize) -> Checked<Vec<Item<'_>>> {
    let outer = item(raw)?;
    if !outer.list || outer.encoded.len() != raw.len() {
        return Err("one exact list required");
    }
    let mut result = Vec::new();
    let mut rest = outer.value;
    while !rest.is_empty() {
        if result.len() >= maximum {
            return Err("list field cap");
        }
        let next = item(rest)?;
        rest = &rest[next.encoded.len()..];
        result.push(next);
    }
    Ok(result)
}
fn scalar<'a>(v: &Item<'a>) -> Checked<&'a [u8]> {
    if v.list {
        return Err("scalar required");
    }
    Ok(v.value)
}
fn integer(v: &Item<'_>) -> Checked<u64> {
    let value = scalar(v)?;
    if value.len() > 8 || value.first() == Some(&0) {
        return Err("uint64 canonicality");
    }
    Ok(value.iter().fold(0, |n, b| n * 256 + *b as u64))
}
fn nonzero32(v: &Item<'_>) -> Checked<[u8; 32]> {
    let a: [u8; 32] = scalar(v)?.try_into().map_err(|_| "hash width")?;
    if a == [0; 32] {
        return Err("zero hash");
    }
    Ok(a)
}
fn extra(raw: &[u8]) -> Checked<&[u8]> {
    let fields = list(raw, 21)?;
    if fields.len() < 15 {
        return Err("header fields");
    }
    scalar(&fields[12])
}
struct Vote<'a> {
    bitmap: u64,
    signature: &'a [u8],
    data_hash: [u8; 32],
    source_number: u64,
    source_hash: [u8; 32],
    target_number: u64,
    target_hash: [u8; 32],
}
fn vote(raw: &[u8]) -> Checked<Vote<'_>> {
    if raw.is_empty() || raw.len() > 512 {
        return Err("vote size");
    }
    let fields = list(raw, 4)?;
    if fields.len() != 4 {
        return Err("vote fields");
    }
    let bitmap = integer(&fields[0])?;
    let signature = scalar(&fields[1])?;
    if bitmap == 0 || signature.len() != 96 || signature.iter().all(|b| *b == 0) {
        return Err("bitmap/signature");
    }
    let data = list(fields[2].encoded, 4)?;
    if data.len() != 4 || scalar(&fields[3])?.len() > 256 {
        return Err("vote data/extra");
    }
    let source_number = integer(&data[0])?;
    let target_number = integer(&data[2])?;
    if source_number >= target_number {
        return Err("source/target range");
    }
    Ok(Vote {
        bitmap,
        signature,
        data_hash: hash(fields[2].encoded),
        source_number,
        target_number,
        source_hash: nonzero32(&data[1])?,
        target_hash: nonzero32(&data[3])?,
    })
}
fn epoch_keys(epoch: &NativeHeader) -> Checked<Vec<G1Affine>> {
    if epoch.worldland_optional_mask != 0 {
        return Err("foreign epoch mask");
    }
    validate_header(
        Profile::BnbV178,
        56,
        &epoch.canonical_rlp,
        epoch.number,
        &epoch.block_hash,
        &epoch.parent_hash,
        &epoch.receipt_root,
    )?;
    let raw = extra(&epoch.canonical_rlp)?;
    if raw.len() < 167 {
        return Err("epoch layout");
    }
    let count = raw[32] as usize;
    let end = 33 + count * 68;
    if count == 0 || count > 64 || end + 1 + 65 > raw.len() || raw[end] == 0 {
        return Err("epoch count/turn");
    }
    let optional = &raw[end + 1..raw.len() - 65];
    if !optional.is_empty() {
        vote(optional)?;
    } // schema only; not the optional signature's pairing
    let mut keys = Vec::new();
    let mut previous = [0u8; 20];
    let mut compressed_keys = Vec::new();
    for i in 0..count {
        let start = 33 + i * 68;
        let address: [u8; 20] = raw[start..start + 20].try_into().unwrap();
        if address == [0; 20] || (i > 0 && address <= previous) {
            return Err("epoch address order");
        }
        previous = address;
        let compressed: [u8; 48] = raw[start + 20..start + 68].try_into().unwrap();
        if compressed_keys.contains(&compressed) {
            return Err("duplicate BLS key");
        }
        let key = Option::<G1Affine>::from(G1Affine::from_compressed(&compressed))
            .ok_or("BLS key subgroup/canonicality")?;
        if bool::from(key.is_identity()) {
            return Err("BLS key infinity");
        }
        compressed_keys.push(compressed);
        keys.push(key);
    }
    Ok(keys)
}

/// Native bytes + supplied epoch slots + all-key subgroup/quorum + POP-domain
/// BLS mathematics. No PoP registration, active epoch, ECDSA, fork/finality.
pub fn journal(input: &BnbVoteInput) -> Checked<[u8; JOURNAL_BYTES]> {
    if input.batch.chain_id != 56 || input.batch.headers.len() != 3 {
        return Err("one adjacent BNB vote witness required");
    }
    let native = native_journal(&input.batch)?;
    let source = &input.batch.headers[0];
    let target = &input.batch.headers[1];
    let attesting = &input.batch.headers[2];
    let payload = extra(&attesting.canonical_rlp)?;
    if payload.len() < 32 + 65 {
        return Err("attesting layout");
    }
    let v = vote(&payload[32..payload.len() - 65])?;
    if v.source_number != source.number
        || v.source_hash != source.block_hash
        || v.target_number != target.number
        || v.target_hash != target.block_hash
    {
        return Err("signed raw source/target mismatch");
    }
    let keys = epoch_keys(&input.epoch)?;
    if keys.len() < 64 && v.bitmap >> keys.len() != 0 {
        return Err("bitmap outside supplied keys");
    }
    let votes = v.bitmap.count_ones() as usize;
    if votes < (keys.len() * 2 + 2) / 3 {
        return Err("quorum");
    }
    let compressed: [u8; 96] = v.signature.try_into().unwrap();
    let signature = Option::<G2Affine>::from(G2Affine::from_compressed(&compressed))
        .ok_or("signature subgroup/canonicality")?;
    if bool::from(signature.is_identity()) {
        return Err("signature infinity");
    }
    let mut aggregate = G1Projective::identity();
    for (index, key) in keys.iter().enumerate() {
        if v.bitmap & (1u64 << index) != 0 {
            aggregate += key;
        }
    }
    if bool::from(aggregate.is_identity()) {
        return Err("aggregate key infinity");
    }
    let message =
        <G2Projective as HashToCurve<ExpandMsgXmd<sha2::Sha256>>>::hash_to_curve(v.data_hash, DST);
    let h = G2Prepared::from(G2Affine::from(message));
    let sig = G2Prepared::from(signature);
    let aggregate = G1Affine::from(aggregate);
    let negative_generator = -G1Affine::generator();
    if multi_miller_loop(&[(&aggregate, &h), (&negative_generator, &sig)]).final_exponentiation()
        != Gt::identity()
    {
        return Err("BLS pairing mismatch");
    }
    let mut output = [0u8; JOURNAL_BYTES];
    output[..224].copy_from_slice(&native);
    output[224..256].copy_from_slice(&input.epoch.block_hash);
    output[256..288].copy_from_slice(&v.data_hash);
    output[288..320].copy_from_slice(&word(v.bitmap));
    output[320..352].copy_from_slice(&word(keys.len() as u64));
    Ok(output)
}

#[cfg(test)]
mod tests {
    use super::*;
    fn input(text: &str) -> BnbVoteInput {
        serde_json::from_str(text).unwrap()
    }
    fn bytes(text: &str) -> Vec<u8> {
        let text = text.strip_prefix("0x").unwrap();
        (0..text.len())
            .step_by(2)
            .map(|i| u8::from_str_radix(&text[i..i + 2], 16).unwrap())
            .collect()
    }
    #[test]
    fn actual_two_independent_blst_evm_fixtures() {
        for text in [
            include_str!("../fixtures/parent.json"),
            include_str!("../fixtures/latest.json"),
        ] {
            let v = input(text);
            let j = journal(&v).unwrap();
            assert_eq!(&j[..32], &word(56));
            assert_eq!(&j[96..128], &word(3));
            assert_eq!(&j[320..352], &word(21));
        }
    }
    #[test]
    fn wrong_native_header_and_domain_fail_before_pairing() {
        let original = input(include_str!("../fixtures/parent.json"));
        let mut v = original.clone();
        v.batch.chain_id = 103;
        assert!(journal(&v).is_err());
        let mut v = original.clone();
        v.batch.headers[1].receipt_root[0] ^= 1;
        assert!(journal(&v).is_err());
        let mut v = original.clone();
        v.batch.headers.swap(0, 1);
        assert!(journal(&v).is_err());
        let mut v = original.clone();
        v.epoch.block_hash[0] ^= 1;
        assert!(journal(&v).is_err());
        let mut v = original;
        v.batch.headers.pop();
        assert!(journal(&v).is_err());
    }

    fn replace_raw(header: &mut NativeHeader, needle: &[u8], replacement: &[u8]) {
        assert_eq!(needle.len(), replacement.len());
        let positions: Vec<usize> = header
            .canonical_rlp
            .windows(needle.len())
            .enumerate()
            .filter(|(_, b)| *b == needle)
            .map(|(i, _)| i)
            .collect();
        assert_eq!(positions.len(), 1);
        let i = positions[0];
        header.canonical_rlp[i..i + needle.len()].copy_from_slice(replacement);
        header.block_hash = hash(&header.canonical_rlp);
    }
    #[test]
    fn valid_public_other_signature_and_nonparticipant_infinity_reject() {
        let original = input(include_str!("../fixtures/parent.json"));
        let other = input(include_str!("../fixtures/latest.json"));
        let payload = extra(&original.batch.headers[2].canonical_rlp).unwrap();
        let original_vote = vote(&payload[32..payload.len() - 65]).unwrap();
        let sig = original_vote.signature.to_vec();
        let bitmap = original_vote.bitmap;
        let payload = extra(&other.batch.headers[2].canonical_rlp).unwrap();
        let other_vote = vote(&payload[32..payload.len() - 65]).unwrap();
        let mut changed = original.clone();
        replace_raw(&mut changed.batch.headers[2], &sig, other_vote.signature);
        assert!(matches!(journal(&changed), Err("BLS pairing mismatch")));
        let raw = extra(&original.epoch.canonical_rlp).unwrap();
        let nonparticipant = (0..raw[32] as usize)
            .find(|i| bitmap & (1u64 << i) == 0)
            .unwrap();
        let compressed = raw[33 + nonparticipant * 68 + 20..33 + nonparticipant * 68 + 68].to_vec();
        let mut infinity = [0u8; 48];
        infinity[0] = 0xc0;
        let mut changed = original;
        replace_raw(&mut changed.epoch, &compressed, &infinity);
        assert!(matches!(journal(&changed), Err("BLS key infinity")));
    }
    #[test]
    fn epoch_optional_wire_matches_independent_go_oracle37() {
        let oracle: serde_json::Value =
            serde_json::from_str(include_str!("../fixtures/epoch-vote-schema-oracle.json"))
                .unwrap();
        let original = input(include_str!("../fixtures/parent.json"));
        let rows = oracle["vectors"].as_array().unwrap();
        assert_eq!(rows.len(), 37);
        for row in rows {
            let mut epoch = original.epoch.clone();
            epoch.canonical_rlp = bytes(row["epochRaw"].as_str().unwrap());
            epoch.block_hash = bytes(row["epochHash"].as_str().unwrap())
                .try_into()
                .unwrap();
            assert_eq!(
                epoch_keys(&epoch).is_ok(),
                row["goAccepted"].as_bool().unwrap(),
                "{}",
                row["name"]
            );
        }
    }
}
