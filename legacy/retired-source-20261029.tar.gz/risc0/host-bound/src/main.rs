#[cfg(not(feature = "strict-header"))]
compile_error!("bound host requires strict-header serialization");
include!("../../host/src/main.rs");
