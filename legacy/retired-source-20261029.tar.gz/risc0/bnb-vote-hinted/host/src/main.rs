use bridge_bnb_vote_hinted_methods::{
    BRIDGE_BNB_VOTE_HINTED_GUEST_ELF as ELF, BRIDGE_BNB_VOTE_HINTED_GUEST_ID as IMAGE,
};
use bridge_bnb_vote_hinted_types::{journal, BnbVoteInput, HEADER_BINDING, JOURNAL_BYTES};
use risc0_zkvm::{default_executor, sha::Digest, ExecutorEnv, InnerReceipt, Receipt};
use serde_json::json;
use std::{env, error::Error, fs, io::Read, time::Instant};
mod profile;
#[cfg(feature = "segment-cache")]
#[path = "../../../host/src/segment_cache.rs"]
mod segment_cache;

fn hex(b: &[u8]) -> String {
    format!(
        "0x{}",
        b.iter().map(|x| format!("{x:02x}")).collect::<String>()
    )
}
fn read(path: &str, limit: u64) -> Result<Vec<u8>, Box<dyn Error>> {
    let mut data = Vec::new();
    fs::File::open(path)?
        .take(limit + 1)
        .read_to_end(&mut data)?;
    if data.len() as u64 > limit {
        return Err("artifact size limit".into());
    }
    Ok(data)
}
fn crypto_mode() -> Result<(), Box<dyn Error>> {
    if env::var("RISC0_DEV_MODE").is_ok_and(|v| v != "0" && !v.is_empty()) {
        return Err("RISC0_DEV_MODE forbidden".into());
    }
    Ok(())
}
fn execution(input: &BnbVoteInput) -> Result<ExecutorEnv<'static>, Box<dyn Error>> {
    let segment: u32 = env::var("BRIDGE_RISC0_SEGMENT_PO2")
        .unwrap_or_else(|_| "18".into())
        .parse()?;
    if !(16..=19).contains(&segment) {
        return Err("vote execution segment bound16..19".into());
    }
    let mut builder = ExecutorEnv::builder();
    builder
        .segment_limit_po2(segment)
        .session_limit(Some(1 << 27))
        .write(input)?;
    Ok(builder.build()?)
}
fn checked(receipt: &Receipt) -> Result<serde_json::Value, Box<dyn Error>> {
    crypto_mode()?;
    if !matches!(
        receipt.inner,
        InnerReceipt::Composite(_) | InnerReceipt::Groth16(_)
    ) {
        return Err("only cryptographic receipts".into());
    }
    receipt.verify(IMAGE)?;
    if receipt.journal.bytes.len() != JOURNAL_BYTES
        || receipt.journal.bytes[..32] != bridge_native_header_types_word56()
    {
        return Err("vote journal shape/domain".into());
    }
    let (kind, seal) = match &receipt.inner {
        InnerReceipt::Groth16(inner) => {
            if inner.seal.len() != 256 {
                return Err("seal length".into());
            }
            let mut seal = inner.verifier_parameters.as_bytes()[..4].to_vec();
            seal.extend_from_slice(&inner.seal);
            ("groth16", Some(hex(&seal)))
        }
        _ => ("composite", None),
    };
    Ok(
        json!({"verified":true,"imageId":hex(Digest::from(IMAGE).as_bytes()),"headerBinding":HEADER_BINDING,
        "journal":hex(&receipt.journal.bytes),"receiptKind":kind,"seal":seal,"evmCompatible":seal.is_some(),
        "suppliedEpochBlsMathVerified":true,"sourceChainId":56,"chainAuthenticated":false,"realAssetDeploymentAllowed":false,
        "snapshotAuthenticated":false,"finalityVerified":false,"evmAcceptanceMeasured":false}),
    )
}
fn bridge_native_header_types_word56() -> [u8; 32] {
    let mut b = [0; 32];
    b[31] = 56;
    b
}
fn main() -> Result<(), Box<dyn Error>> {
    let args: Vec<String> = env::args().collect();
    #[cfg(feature = "segment-cache")]
    if segment_cache::is_command(&args) {
        crypto_mode()?;
        if args.len() < 4 { return Err("segment cache arguments".into()); }
        let input: BnbVoteInput = serde_json::from_slice(&segment_cache::read_regular(
            std::path::Path::new(&args[2]), 64 * 1024)?)?;
        let expected = journal(&input)?;
        segment_cache::command(&args, &input, ELF, IMAGE, HEADER_BINDING, &expected)?;
        return Ok(());
    }
    if profile::command(&args)? {
        return Ok(());
    }
    if args.len() == 2 && args[1] == "--image-id" {
        println!("{}", hex(Digest::from(IMAGE).as_bytes()));
        return Ok(());
    }
    if args.len() == 2 && args[1] == "--header-binding" {
        println!("{HEADER_BINDING}");
        return Ok(());
    }
    if args.len() == 3 && args[1] == "--verify-receipt" {
        let receipt: Receipt = serde_json::from_slice(&read(&args[2], 64 * 1024 * 1024)?)?;
        println!("{}", checked(&receipt)?);
        return Ok(());
    }
    if args.len() == 3 && args[1] == "--execute-input" {
        crypto_mode()?;
        let input: BnbVoteInput = serde_json::from_slice(&read(&args[2], 64 * 1024)?)?;
        if input.batch.headers.len() > 3 {
            return Err("vote input resource cap".into());
        }
        let started = Instant::now();
        let result = default_executor().execute(execution(&input)?, ELF)?;
        let expected = journal(&input)?;
        if result.journal.bytes != expected {
            return Err("host/guest vote journal mismatch".into());
        }
        println!(
            "{}",
            json!({"imageId":hex(Digest::from(IMAGE).as_bytes()),"headerBinding":HEADER_BINDING,
            "journal":hex(&expected),"sourceChainId":56,"nativeHeadersBound":3,"suppliedEpochBlsMathVerified":true,
            "executeMs":started.elapsed().as_millis(),"executionCycles":result.cycles(),"executionSegments":result.segments.len(),
            "guestExecuted":true,"proofGenerated":false,"evmAcceptanceMeasured":false,"snapshotAuthenticated":false,
            "ecdsaSealVerified":false,"finalityVerified":false,"chainAuthenticated":false,"realAssetDeploymentAllowed":false})
        );
        return Ok(());
    }
    Err("usage: --image-id | --header-binding | --execute-input <saved-json> | --verify-receipt <saved-json> | --prove-profile <input> <new-directory> | --resume-profile <input> <saved-receipt> <new-directory>; use bounded runner for proving".into())
}

#[cfg(test)]
mod tests {
    use super::*;
    use risc0_zkvm::{FakeReceipt, MaybePruned};
    #[test]
    fn fake_cannot_claim_bls_math() {
        let r = Receipt::new(
            InnerReceipt::Fake(FakeReceipt::new(MaybePruned::Pruned(Digest::ZERO))),
            vec![0; JOURNAL_BYTES],
        );
        assert!(checked(&r)
            .unwrap_err()
            .to_string()
            .contains("cryptographic"));
    }
}
