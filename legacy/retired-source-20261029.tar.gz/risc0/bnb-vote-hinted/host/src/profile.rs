//! Separate public BLS predicate. Preserve verified phases; no asset authority.
use super::*;
use risc0_zkvm::{default_prover, sha::Digestible, ProverOpts};
use std::{io::Write, path::Path};

fn verify_phase(
    receipt: &Receipt,
    kind: &str,
    expected: &[u8],
    claim: Digest,
) -> Result<(), Box<dyn Error>> {
    crypto_mode()?;
    let actual = match &receipt.inner {
        InnerReceipt::Composite(c) if !c.segments.is_empty() => "composite",
        InnerReceipt::Succinct(_) => "succinct",
        InnerReceipt::Groth16(_) => "groth16",
        _ => return Err("cryptographic phase receipt required".into()),
    };
    if actual != kind {
        return Err("requested phase differs".into());
    }
    // SDK verification resolves every attached accelerator assumption.
    // An empty assumption list is not required; unresolved ones are rejected.
    receipt.verify(IMAGE)?;
    if expected.len() != JOURNAL_BYTES
        || receipt.journal.bytes != expected
        || receipt.claim()?.digest() != claim
    {
        return Err("phase image/journal/claim mismatch".into());
    }
    Ok(())
}

fn save_receipt(path: &Path, receipt: &Receipt) -> Result<usize, Box<dyn Error>> {
    let encoded = serde_json::to_vec(receipt)?;
    if encoded.len() > 64 * 1024 * 1024 {
        return Err("phase artifact exceeds64MiB".into());
    }
    let mut file = fs::OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(path)?;
    file.write_all(&encoded)?;
    Ok(encoded.len())
}

pub(super) fn command(args: &[String]) -> Result<bool, Box<dyn Error>> {
    let resume = match args.get(1).map(String::as_str) {
        Some("--prove-profile") => false,
        Some("--resume-profile") => true,
        _ => return Ok(false),
    };
    if args.len() != if resume { 5 } else { 4 } {
        return Err("profile argument count".into());
    }
    crypto_mode()?;
    let input: BnbVoteInput = serde_json::from_slice(&read(&args[2], 64 * 1024)?)?;
    // The independent, unpatched host implementation validates the supplied
    // input before expensive proving. Only the guest receipt is a zk proof.
    let expected = journal(&input)?;
    let reused = if resume {
        let receipt: Receipt = serde_json::from_slice(&read(&args[3], 64 * 1024 * 1024)?)?;
        let kind = match &receipt.inner {
            InnerReceipt::Composite(_) => "composite",
            InnerReceipt::Succinct(_) => "succinct",
            _ => return Err("resume needs a saved actual composite or succinct".into()),
        };
        let claim = receipt.claim()?.digest();
        verify_phase(&receipt, kind, &expected, claim)?;
        Some((receipt, kind))
    } else {
        None
    };
    let directory = Path::new(&args[if resume { 4 } else { 3 }]);
    fs::create_dir(directory)?; // Never replace a previous attempt or phase.
    let start = Instant::now();
    let prover = default_prover();
    let (mut receipt, first, mut duration, stats) = if let Some((receipt, kind)) = reused {
        (receipt, kind, 0, None)
    } else {
        let timer = Instant::now();
        let info = prover.prove_with_opts(execution(&input)?, ELF, &ProverOpts::composite())?;
        (
            info.receipt,
            "composite",
            timer.elapsed().as_millis(),
            Some(info.stats),
        )
    };
    let claim = receipt.claim()?.digest();
    let mut phases = Vec::new();
    for kind in if first == "composite" {
        vec!["composite", "succinct", "groth16"]
    } else {
        vec!["succinct", "groth16"]
    } {
        if kind != first {
            let timer = Instant::now();
            receipt = prover.compress(
                &if kind == "succinct" {
                    ProverOpts::succinct()
                } else {
                    ProverOpts::groth16()
                },
                &receipt,
            )?;
            duration = timer.elapsed().as_millis();
        }
        let timer = Instant::now();
        verify_phase(&receipt, kind, &expected, claim)?;
        let verification = timer.elapsed().as_millis();
        let bytes = save_receipt(&directory.join(format!("{kind}.json")), &receipt)?;
        phases.push(json!({"receiptKind":kind,"durationMs":duration,"verificationMs":verification,
            "cryptographicallyVerified":true,"claimDigest":hex(claim.as_bytes()),"journalMatches":true,
            "receiptBytes":bytes,"reused":resume && kind==first}));
        fs::write(
            directory.join("phases.json"),
            serde_json::to_vec_pretty(&phases)?,
        )?;
    }
    let mut output = checked(&receipt)?;
    output["phases"] = json!(phases);
    output["profileTotalMs"] = json!(start.elapsed().as_millis());
    output["sessionStats"] = json!(stats);
    output["freshCompositeGenerated"] = json!(!resume);
    output["fullGenerationWallMeasured"] = json!(!resume);
    output["hostInputJournalMatched"] = json!(true);
    output["resumedFromKind"] = if resume {
        json!(first)
    } else {
        serde_json::Value::Null
    };
    fs::write(
        directory.join("verified.json"),
        serde_json::to_vec_pretty(&output)?,
    )?;
    println!("{output}");
    Ok(true)
}

#[cfg(test)]
mod tests {
    use super::*;
    use risc0_zkvm::{FakeReceipt, MaybePruned};
    #[test]
    fn fake_cannot_be_a_profile_phase_or_resume() {
        let r = Receipt::new(
            InnerReceipt::Fake(FakeReceipt::new(MaybePruned::Pruned(Digest::ZERO))),
            vec![0; JOURNAL_BYTES],
        );
        for kind in ["composite", "succinct", "groth16"] {
            assert!(verify_phase(&r, kind, &r.journal.bytes, Digest::ZERO).is_err());
        }
    }
}
