#![no_main]
use bridge_bnb_vote_hinted_types::{journal, BnbVoteInput};
use risc0_zkvm::guest::env;
risc0_zkvm::guest::entry!(main);
fn main() {
    let input: BnbVoteInput = env::read();
    let bytes = journal(&input).expect("supplied epoch BLS/native binding failed");
    env::commit_slice(&bytes);
}
