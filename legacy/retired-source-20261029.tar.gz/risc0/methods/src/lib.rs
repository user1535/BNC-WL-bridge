include!(concat!(env!("OUT_DIR"), "/methods.rs"));
pub const HEADER_BINDING: &str = "minimal-link";
