#[cfg(feature = "strict-header")]
compile_error!("accelerated experiment supports minimal relation only");
include!("../../host/src/main.rs");

#[cfg(test)]
mod compatibility {
    #[cfg(feature = "profile-prover")]
    #[test]
    fn profile_checks_actual_groth16_and_rejects_changed_kind_claim_or_journal() {
        use risc0_zkvm::{
            sha::{Digest, Digestible},
            Receipt,
        };
        let path = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../../results/accelerated-four-groth16/receipt.json");
        let receipt: Receipt = serde_json::from_slice(&std::fs::read(path).unwrap()).unwrap();
        let journal = &receipt.journal.bytes;
        let claim = receipt.claim().unwrap().digest();
        let check = crate::proof_profile::verify_stage;
        check(&receipt, "groth16", journal, claim).unwrap();
        assert!(check(&receipt, "succinct", journal, claim).is_err());
        assert!(check(&receipt, "groth16", journal, Digest::ZERO).is_err());
        let mut changed_journal = journal.clone();
        changed_journal[0] ^= 1;
        assert!(check(&receipt, "groth16", &changed_journal, claim).is_err());
        let mut changed_receipt = receipt.clone();
        changed_receipt.journal.bytes[0] ^= 1;
        assert!(check(&changed_receipt, "groth16", &changed_journal, claim).is_err());
    }

    #[test]
    fn pinned_sdk_still_verifies_original_local_receipts() {
        use risc0_zkvm::{sha::Digest, Receipt};
        for directory in ["local-risc0-current", "local-risc0-bound-pinned"] {
            let path = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
                .join("../../results")
                .join(directory)
                .join("lock-header.json");
            let package: serde_json::Value =
                serde_json::from_slice(&std::fs::read(path).unwrap()).unwrap();
            let receipt: Receipt = serde_json::from_value(package["proofReceipt"].clone()).unwrap();
            let image = package["imageId"]
                .as_str()
                .unwrap()
                .trim_start_matches("0x");
            let mut bytes = [0u8; 32];
            for (i, byte) in bytes.iter_mut().enumerate() {
                *byte = u8::from_str_radix(&image[2 * i..2 * i + 2], 16).unwrap();
            }
            receipt.verify(Digest::from_bytes(bytes)).unwrap();
            let mut changed = receipt.clone();
            changed.journal.bytes[0] ^= 1;
            assert!(changed.verify(Digest::from_bytes(bytes)).is_err());
        }
    }
}
