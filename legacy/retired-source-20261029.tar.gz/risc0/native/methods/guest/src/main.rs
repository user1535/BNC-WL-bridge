#![no_main]
#![no_std]
use bridge_native_header_types::{journal, NativeBatch};
use risc0_zkvm::guest::env;
risc0_zkvm::guest::entry!(main);

fn main() {
    let batch: NativeBatch = env::read();
    let bytes = journal(&batch).expect("native serialization binding failed");
    env::commit_slice(&bytes);
}
