#![no_std]
extern crate alloc;
use alloc::vec::Vec;
use bridge_native_header_binding::{validate_header, Profile};
use serde::{Deserialize, Serialize};
use tiny_keccak::{Hasher, Keccak};

pub const HEADER_BINDING: &str = "native-rlp";
pub const MAX_HEADERS: usize = 4;

#[derive(Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct NativeHeader {
    pub number: u64,
    pub block_hash: [u8; 32],
    pub parent_hash: [u8; 32],
    pub receipt_root: [u8; 32],
    pub canonical_rlp: Vec<u8>,
    pub worldland_optional_mask: u8,
}

#[derive(Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct NativeBatch {
    pub chain_id: u64,
    pub anchor_hash: [u8; 32],
    pub headers: Vec<NativeHeader>,
}

pub fn hash(data: &[u8]) -> [u8; 32] {
    let mut out = [0u8; 32];
    let mut k = Keccak::v256();
    k.update(data);
    k.finalize(&mut out);
    out
}

pub fn word(value: u64) -> [u8; 32] {
    let mut out = [0; 32];
    out[24..].copy_from_slice(&value.to_be_bytes());
    out
}

/// A distinct native guest binds these bytes, but authenticates neither the
/// supplied anchor nor source consensus/finality. Never changes a local image.
pub fn journal(input: &NativeBatch) -> Result<[u8; 224], &'static str> {
    if !matches!(input.chain_id, 103 | 56)
        || input.headers.is_empty()
        || input.headers.len() > MAX_HEADERS
    {
        return Err("native chain or batch size");
    }
    if input.anchor_hash == [0; 32] || input.headers[0].parent_hash != input.anchor_hash {
        return Err("anchor mismatch");
    }
    let mut prior = input.anchor_hash;
    let mut level = Vec::new();
    for (i, h) in input.headers.iter().enumerate() {
        let profile = if input.chain_id == 103 {
            Profile::WorldLandV113 {
                optional_mask: h.worldland_optional_mask,
            }
        } else {
            if h.worldland_optional_mask != 0 {
                return Err("BNB forbids WorldLand mask");
            }
            Profile::BnbV178
        };
        validate_header(
            profile,
            input.chain_id,
            &h.canonical_rlp,
            h.number,
            &h.block_hash,
            &h.parent_hash,
            &h.receipt_root,
        )?;
        if h.block_hash == [0; 32] || h.receipt_root == [0; 32] || h.parent_hash != prior {
            return Err("native header continuity");
        }
        if i > 0 && input.headers[i - 1].number.checked_add(1) != Some(h.number) {
            return Err("native number discontinuity/overflow");
        }
        let mut leaf = [0u8; 160];
        leaf[..32].copy_from_slice(&word(input.chain_id));
        leaf[32..64].copy_from_slice(&word(h.number));
        leaf[64..96].copy_from_slice(&h.block_hash);
        leaf[96..128].copy_from_slice(&h.parent_hash);
        leaf[128..].copy_from_slice(&h.receipt_root);
        level.push(hash(&leaf));
        prior = h.block_hash;
    }
    while level.len() > 1 {
        let mut next = Vec::new();
        for pair in level.chunks(2) {
            let mut data = [0u8; 64];
            data[..32].copy_from_slice(&pair[0]);
            data[32..].copy_from_slice(if pair.len() == 2 { &pair[1] } else { &pair[0] });
            next.push(hash(&data));
        }
        level = next;
    }
    let mut out = [0u8; 224];
    out[..32].copy_from_slice(&word(input.chain_id));
    out[32..64].copy_from_slice(&word(input.headers[0].number));
    out[64..96].copy_from_slice(&word(input.headers.last().unwrap().number));
    out[96..128].copy_from_slice(&word(input.headers.len() as u64));
    out[128..160].copy_from_slice(&input.anchor_hash);
    out[160..192].copy_from_slice(&prior);
    out[192..].copy_from_slice(&level[0]);
    Ok(out)
}

#[cfg(test)]
mod tests {
    use super::*;
    fn decode(s: &str) -> Vec<u8> {
        let s = s.strip_prefix("0x").unwrap();
        (0..s.len())
            .step_by(2)
            .map(|i| u8::from_str_radix(&s[i..i + 2], 16).unwrap())
            .collect()
    }
    fn fixture(wl: bool) -> NativeBatch {
        let rows = if wl {
            [
                include_str!("../../../native-binding/fixtures/worldland-parent.json"),
                include_str!("../../../native-binding/fixtures/worldland-latest.json"),
            ]
        } else {
            [
                include_str!("../../../native-binding/fixtures/bnb-parent.json"),
                include_str!("../../../native-binding/fixtures/bnb-latest.json"),
            ]
        };
        let headers: Vec<NativeHeader> = rows
            .into_iter()
            .map(|s| {
                let v: serde_json::Value = serde_json::from_str(s).unwrap();
                NativeHeader {
                    number: v["blockNumber"].as_u64().unwrap(),
                    block_hash: decode(v["recomputedHash"].as_str().unwrap())
                        .try_into()
                        .unwrap(),
                    parent_hash: decode(v["parentHash"].as_str().unwrap())
                        .try_into()
                        .unwrap(),
                    receipt_root: decode(v["receiptRoot"].as_str().unwrap())
                        .try_into()
                        .unwrap(),
                    canonical_rlp: decode(v["headerRlp"].as_str().unwrap()),
                    worldland_optional_mask: v["worldlandOptionalMask"].as_u64().unwrap() as u8,
                }
            })
            .collect();
        NativeBatch {
            chain_id: if wl { 103 } else { 56 },
            anchor_hash: headers[0].parent_hash,
            headers,
        }
    }
    #[test]
    fn actual_pairs_commitment_and_independent_single_leaf() {
        for wl in [true, false] {
            let batch = fixture(wl);
            let public = journal(&batch).unwrap();
            assert_eq!(&public[..32], &word(batch.chain_id));
            assert_eq!(&public[96..128], &word(2));
            let mut single = batch.clone();
            single.headers.truncate(1);
            let j = journal(&single).unwrap();
            let h = &single.headers[0];
            let mut bytes = Vec::new();
            bytes.extend_from_slice(&word(single.chain_id));
            bytes.extend_from_slice(&word(h.number));
            bytes.extend_from_slice(&h.block_hash);
            bytes.extend_from_slice(&h.parent_hash);
            bytes.extend_from_slice(&h.receipt_root);
            assert_eq!(&j[192..], &hash(&bytes));
        }
    }
    #[test]
    fn context_continuity_profile_and_size_reject() {
        for wl in [true, false] {
            for variant in 0..7 {
                let mut b = fixture(wl);
                match variant {
                    0 => b.chain_id = 31337,
                    1 => b.anchor_hash = [1; 32],
                    2 => b.headers.reverse(),
                    3 => b.headers.clear(),
                    4 => b.headers[1].number += 1,
                    5 => b.headers[0].receipt_root[0] ^= 1,
                    6 => {
                        while b.headers.len() <= MAX_HEADERS {
                            b.headers.push(b.headers[0].clone());
                        }
                    }
                    _ => unreachable!(),
                };
                assert!(journal(&b).is_err());
            }
        }
        let mut b = fixture(false);
        b.headers[0].worldland_optional_mask = 1;
        assert!(journal(&b).is_err());
        let json = serde_json::to_string(&b).unwrap();
        assert!(serde_json::from_str::<NativeBatch>(&json.replace(
            "\"chain_id\":56",
            "\"chain_id\":56,\"chainAuthenticated\":true"
        ))
        .is_err());
    }
}
