use bridge_native_header_methods::{
    BRIDGE_NATIVE_HEADER_GUEST_ELF as ELF, BRIDGE_NATIVE_HEADER_GUEST_ID as IMAGE,
};
use bridge_native_header_types::{journal, NativeBatch, HEADER_BINDING, MAX_HEADERS};
use risc0_zkvm::{
    default_executor, default_prover,
    sha::{Digest, Digestible},
    ExecutorEnv, Groth16Receipt, Groth16ReceiptVerifierParameters, InnerReceipt, ProverOpts,
    Receipt,
};
use serde_json::json;
use std::{env, error::Error, fs, io::Read, path::Path, time::Instant};

fn hex(bytes: &[u8]) -> String {
    format!(
        "0x{}",
        bytes.iter().map(|b| format!("{b:02x}")).collect::<String>()
    )
}
fn read_limited(path: &str, limit: u64) -> Result<Vec<u8>, Box<dyn Error>> {
    let mut bytes = Vec::new();
    fs::File::open(path)?
        .take(limit + 1)
        .read_to_end(&mut bytes)?;
    if bytes.len() as u64 > limit {
        return Err("artifact size limit".into());
    }
    Ok(bytes)
}
fn crypto_mode() -> Result<(), Box<dyn Error>> {
    if env::var("RISC0_DEV_MODE").is_ok_and(|v| v != "0" && !v.is_empty()) {
        return Err("RISC0_DEV_MODE forbidden".into());
    }
    Ok(())
}
fn segment(value: Option<&str>) -> Result<u32, Box<dyn Error>> {
    let n = value.unwrap_or("18").parse()?;
    if !(16..=20).contains(&n) {
        return Err("segment po2 must be 16..20".into());
    }
    Ok(n)
}
fn execution(input: &NativeBatch) -> Result<ExecutorEnv<'static>, Box<dyn Error>> {
    let n = segment(env::var("BRIDGE_RISC0_SEGMENT_PO2").ok().as_deref())?;
    let mut builder = ExecutorEnv::builder();
    builder.segment_limit_po2(n).write(input)?;
    Ok(builder.build()?)
}
fn checked_receipt(receipt: &Receipt) -> Result<serde_json::Value, Box<dyn Error>> {
    crypto_mode()?;
    if !matches!(
        receipt.inner,
        InnerReceipt::Composite(_) | InnerReceipt::Groth16(_)
    ) {
        return Err("only cryptographic composite/Groth16 receipts".into());
    }
    receipt.verify(IMAGE)?;
    if receipt.journal.bytes.len() != 224 {
        return Err("native journal length".into());
    }
    let (kind, seal) = match &receipt.inner {
        InnerReceipt::Groth16(inner) => {
            if inner.seal.len() != 256 {
                return Err("Groth16 seal length".into());
            }
            let mut bytes = inner.verifier_parameters.as_bytes()[..4].to_vec();
            bytes.extend_from_slice(&inner.seal);
            ("groth16", Some(hex(&bytes)))
        }
        _ => ("composite", None),
    };
    let chain_word = &receipt.journal.bytes[..32];
    if chain_word[..24] != [0u8; 24] {
        return Err("noncanonical native chain word".into());
    }
    let chain = u64::from_be_bytes(chain_word[24..].try_into()?);
    let profile = match chain {
        103 => "worldland-v1.1.3",
        56 => "bnb-v1.7.8",
        _ => return Err("unsupported native source chain".into()),
    };
    Ok(
        json!({"headerBinding":HEADER_BINDING,"encodingProfile":profile,"sourceChainId":chain,
        "imageId":hex(Digest::from(IMAGE).as_bytes()),"journal":hex(&receipt.journal.bytes),"receiptKind":kind,
        "verified":true,"evmCompatible":seal.is_some(),"seal":seal,"verifierParameters":hex(receipt.inner.verifier_parameters().as_bytes()),
        "hashBindingVerified":true,"chainAuthenticated":false,"realAssetDeploymentAllowed":false,"evmAcceptanceMeasured":false}),
    )
}
fn main() -> Result<(), Box<dyn Error>> {
    let args: Vec<String> = env::args().collect();
    if args.len() == 2 && args[1] == "--image-id" {
        println!("{}", hex(Digest::from(IMAGE).as_bytes()));
        return Ok(());
    }
    if args.len() == 2 && args[1] == "--header-binding" {
        println!("{HEADER_BINDING}");
        return Ok(());
    }
    if args.len() == 3 && args[1] == "--verify-receipt" {
        let receipt: Receipt = serde_json::from_slice(&read_limited(&args[2], 64 * 1024 * 1024)?)?;
        println!("{}", checked_receipt(&receipt)?);
        return Ok(());
    }
    if args.len() == 8
        && args[1] == "--wrap-groth16"
        && args[2] == "--composite"
        && args[4] == "--proof-json"
        && args[6] == "--receipt-output"
    {
        crypto_mode()?;
        if Path::new(&args[7]).exists() {
            return Err("receipt output already exists".into());
        }
        let composite: Receipt =
            serde_json::from_slice(&read_limited(&args[3], 64 * 1024 * 1024)?)?;
        let checked = checked_receipt(&composite)?;
        if checked["receiptKind"] != "composite" {
            return Err("genuine native composite receipt required".into());
        }
        // Use the SDK's official gnark point encoding and parameter digest. A
        // claimed match is insufficient: verify the assembled pairing proof
        // against the compiled guest image/journal before exporting any bytes.
        let json: risc0_groth16::ProofJson =
            serde_json::from_slice(&read_limited(&args[5], 64 * 1024)?)?;
        let seal: risc0_groth16::Seal = json.try_into()?;
        let parameters = Groth16ReceiptVerifierParameters::default().digest();
        let groth = Groth16Receipt::new(seal.to_vec(), composite.claim()?, parameters);
        let receipt = Receipt::new(
            InnerReceipt::Groth16(groth),
            composite.journal.bytes.clone(),
        );
        let summary = checked_receipt(&receipt)?;
        let mut out = fs::OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(&args[7])?;
        serde_json::to_writer(&mut out, &receipt)?;
        println!("{summary}");
        return Ok(());
    }
    if args.len() == 3 && args[1] == "--execute-input" {
        let input: NativeBatch = serde_json::from_slice(&read_limited(&args[2], 64 * 1024)?)?;
        // Semantic validation runs inside the guest so negative execution tests
        // exercise the compiled predicate rather than a host shortcut.
        if input.headers.len() > MAX_HEADERS {
            return Err("input header resource cap".into());
        }
        crypto_mode()?;
        let started = Instant::now();
        let result = default_executor().execute(execution(&input)?, ELF)?;
        let expected = journal(&input)?;
        if result.journal.bytes != expected {
            return Err("guest/host journal mismatch".into());
        }
        println!(
            "{}",
            json!({"imageId":hex(Digest::from(IMAGE).as_bytes()),"headerBinding":HEADER_BINDING,
            "journal":hex(&expected),"sourceChainId":input.chain_id,"headerCount":input.headers.len(),"executeMs":started.elapsed().as_millis(),
            "guestExecuted":true,"proofGenerated":false,"chainAuthenticated":false,"realAssetDeploymentAllowed":false})
        );
        return Ok(());
    }
    if args.len() == 8
        && args[1] == "--prove-receipt"
        && args[2] == "--input"
        && args[4] == "--receipt-output"
        && args[6] == "--receipt-kind"
    {
        crypto_mode()?;
        if Path::new(&args[5]).exists() {
            return Err("receipt output already exists".into());
        }
        let input: NativeBatch = serde_json::from_slice(&read_limited(&args[3], 64 * 1024)?)?;
        if input.headers.len() != 1 {
            return Err("native CPU proof export is initially limited to one header".into());
        }
        let expected = journal(&input)?;
        let opts = match args[7].as_str() {
            "composite" => ProverOpts::composite(),
            "groth16" => ProverOpts::groth16(),
            _ => return Err("unsupported receipt kind".into()),
        };
        let start = Instant::now();
        let proof = default_prover().prove_with_opts(execution(&input)?, ELF, &opts)?;
        let mut checked = checked_receipt(&proof.receipt)?;
        if proof.receipt.journal.bytes != expected || checked["receiptKind"] != args[7] {
            return Err("proof journal/kind mismatch".into());
        }
        let mut out = fs::OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(&args[5])?;
        serde_json::to_writer(&mut out, &proof.receipt)?;
        checked["proveMs"] = json!(start.elapsed().as_millis());
        println!("{checked}");
        return Ok(());
    }
    Err("usage: --image-id | --header-binding | --execute-input <json> | --verify-receipt <json> | --prove-receipt --input <json> --receipt-output <new-json> --receipt-kind composite|groth16".into())
}
#[cfg(test)]
mod tests {
    use super::*;
    use risc0_zkvm::{FakeReceipt, MaybePruned};
    #[test]
    fn unbounded_segments_reject() {
        assert_eq!(segment(None).unwrap(), 18);
        for x in ["15", "21", "-1", ""] {
            assert!(segment(Some(x)).is_err());
        }
    }
    #[test]
    fn fake_receipt_cannot_claim_native_binding() {
        let r = Receipt::new(
            InnerReceipt::Fake(FakeReceipt::new(MaybePruned::Pruned(Digest::ZERO))),
            vec![0; 224],
        );
        assert!(checked_receipt(&r)
            .unwrap_err()
            .to_string()
            .contains("cryptographic"));
    }
}
