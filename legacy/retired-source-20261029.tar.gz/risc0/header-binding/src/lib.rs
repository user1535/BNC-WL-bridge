#![no_std]
extern crate alloc;
use alloc::vec::Vec;
use tiny_keccak::{Hasher, Keccak};

type Checked<T> = Result<T, &'static str>;

// Only Ethereum-shaped local headers. This is serialization binding, not consensus.
fn item(data: &[u8]) -> Checked<(bool, &[u8], usize)> {
    let prefix = *data.first().ok_or("empty RLP item")?;
    if prefix < 0x80 {
        return Ok((false, &data[..1], 1));
    }
    let list = prefix >= 0xc0;
    let base = if list { 0xc0 } else { 0x80 };
    let code = usize::from(prefix - base);
    let (offset, len) = if code <= 55 {
        (1, code)
    } else {
        let n = code - 55;
        let encoded = data.get(1..1 + n).ok_or("truncated RLP length")?;
        if encoded[0] == 0 {
            return Err("leading zero RLP length");
        }
        let mut len = 0usize;
        for byte in encoded {
            len = len
                .checked_mul(256)
                .and_then(|v| v.checked_add(*byte as usize))
                .ok_or("RLP length overflow")?;
        }
        if len < 56 {
            return Err("noncanonical long RLP");
        }
        (1 + n, len)
    };
    let end = offset.checked_add(len).ok_or("RLP item overflow")?;
    let payload = data.get(offset..end).ok_or("truncated RLP payload")?;
    if !list && len == 1 && payload[0] < 0x80 {
        return Err("noncanonical short RLP");
    }
    Ok((list, payload, end))
}

fn integer(data: &[u8], maximum: usize) -> Checked<()> {
    if data.len() > maximum || data.first() == Some(&0) {
        return Err("noncanonical or oversized integer");
    }
    Ok(())
}

fn uint64(data: &[u8]) -> Checked<u64> {
    integer(data, 8)?;
    Ok(data
        .iter()
        .fold(0, |value, byte| value * 256 + *byte as u64))
}

pub fn validate_header(
    raw: &[u8],
    number: u64,
    block_hash: &[u8; 32],
    parent: &[u8; 32],
    receipt_root: &[u8; 32],
) -> Checked<()> {
    if raw.is_empty() || raw.len() > 2048 {
        return Err("local header size limit");
    }
    let (list, payload, consumed) = item(raw)?;
    if !list || consumed != raw.len() {
        return Err("header must be exactly one RLP list");
    }
    let mut fields = Vec::new();
    let mut remaining = payload;
    while !remaining.is_empty() {
        if fields.len() >= 21 {
            return Err("unknown header fields");
        }
        let (list, value, used) = item(remaining)?;
        if list {
            return Err("header field must be scalar");
        }
        fields.push(value);
        remaining = &remaining[used..];
    }
    if !matches!(fields.len(), 15 | 16 | 17 | 20 | 21) {
        return Err("unsupported local fork field count");
    }
    for (index, width) in [
        (0, 32),
        (1, 32),
        (2, 20),
        (3, 32),
        (4, 32),
        (5, 32),
        (6, 256),
        (13, 32),
        (14, 8),
    ] {
        if fields[index].len() != width {
            return Err("wrong header field width");
        }
    }
    integer(fields[7], 32)?;
    let encoded_number = uint64(fields[8])?;
    let gas_limit = uint64(fields[9])?;
    let gas_used = uint64(fields[10])?;
    uint64(fields[11])?;
    if gas_used > gas_limit || fields[12].len() > 32 {
        return Err("unsupported local gas/extra fields");
    }
    if fields.len() >= 16 {
        integer(fields[15], 32)?;
    }
    if fields.len() >= 17 && fields[16].len() != 32 {
        return Err("withdrawals root width");
    }
    if fields.len() >= 20 {
        uint64(fields[17])?;
        uint64(fields[18])?;
        if fields[19].len() != 32 {
            return Err("beacon root width");
        }
    }
    if fields.len() == 21 && fields[20].len() != 32 {
        return Err("requests hash width");
    }
    let mut computed = [0u8; 32];
    let mut keccak = Keccak::v256();
    keccak.update(raw);
    keccak.finalize(&mut computed);
    if &computed != block_hash
        || fields[0] != parent
        || fields[5] != receipt_root
        || encoded_number != number
    {
        return Err("hash/parent/receipt-root/number binding mismatch");
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use alloc::vec;
    fn decode(value: &str) -> Vec<u8> {
        let s = value.strip_prefix("0x").unwrap();
        (0..s.len())
            .step_by(2)
            .map(|i| u8::from_str_radix(&s[i..i + 2], 16).unwrap())
            .collect()
    }
    fn hash(data: &[u8]) -> [u8; 32] {
        let mut out = [0u8; 32];
        let mut k = Keccak::v256();
        k.update(data);
        k.finalize(&mut out);
        out
    }
    fn fixture() -> (Vec<u8>, [u8; 32], [u8; 32], [u8; 32]) {
        let p: serde_json::Value =
            serde_json::from_str(include_str!("../fixtures/anvil-prague.json")).unwrap();
        let raw = decode(p["headerRlp"].as_str().unwrap());
        let (_, mut remaining, _) = item(&raw).unwrap();
        let (_, parent, used) = item(remaining).unwrap();
        let parent: [u8; 32] = parent.try_into().unwrap();
        remaining = &remaining[used..];
        for _ in 1..5 {
            let (_, _, used) = item(remaining).unwrap();
            remaining = &remaining[used..];
        }
        let (_, root, _) = item(remaining).unwrap();
        let root: [u8; 32] = root.try_into().unwrap();
        let expected = decode(p["recomputedHash"].as_str().unwrap())
            .try_into()
            .unwrap();
        (raw, expected, parent, root)
    }
    #[test]
    fn prague_fixture_and_all_public_bindings() {
        let (raw, block, parent, root) = fixture();
        assert!(validate_header(&raw, 22, &block, &parent, &root).is_ok());
        assert!(validate_header(&raw, 23, &block, &parent, &root).is_err());
        assert!(validate_header(&raw, 22, &[1; 32], &parent, &root).is_err());
        assert!(validate_header(&raw, 22, &block, &[1; 32], &root).is_err());
        assert!(validate_header(&raw, 22, &block, &parent, &[1; 32]).is_err());
    }
    #[test]
    fn malformed_rlp_and_truncations_never_validate() {
        let (raw, block, parent, root) = fixture();
        for end in 0..raw.len() {
            assert!(validate_header(&raw[..end], 22, &block, &parent, &root).is_err());
        }
        for index in 0..raw.len() {
            let mut altered = raw.clone();
            altered[index] ^= 1;
            assert!(validate_header(&altered, 22, &block, &parent, &root).is_err());
        }
        let mut trailing = raw;
        trailing.push(0x80);
        assert!(validate_header(&trailing, 22, &block, &parent, &root).is_err());
        for invalid in [
            vec![0xf8, 0],
            vec![0xf8, 1, 0x80],
            vec![0xf9, 0, 56],
            vec![0xff; 64],
        ] {
            assert!(validate_header(&invalid, 0, &hash(&invalid), &parent, &root).is_err());
        }
        assert!(item(&[0x81, 1]).is_err());
        assert!(integer(&[0, 1], 32).is_err());
        assert!(integer(&[0; 33], 32).is_err());
    }

    fn encoded(payload: &[u8], list: bool) -> Vec<u8> {
        if !list && payload.len() == 1 && payload[0] < 0x80 {
            return payload.to_vec();
        }
        let base = if list { 0xc0 } else { 0x80 };
        let mut out = Vec::new();
        if payload.len() < 56 {
            out.push(base + payload.len() as u8);
        } else {
            let bytes = (payload.len() as u64).to_be_bytes();
            let first = bytes.iter().position(|b| *b != 0).unwrap();
            out.push(base + 55 + (8 - first) as u8);
            out.extend_from_slice(&bytes[first..]);
        }
        out.extend_from_slice(payload);
        out
    }

    #[test]
    fn malformed_fields_rejected_even_with_matching_hash() {
        let (raw, _, parent, root) = fixture();
        let (_, mut remaining, _) = item(&raw).unwrap();
        let mut fields = Vec::new();
        while !remaining.is_empty() {
            let (_, value, used) = item(remaining).unwrap();
            fields.push(value.to_vec());
            remaining = &remaining[used..];
        }
        for variant in 0..7 {
            let mut altered = fields.clone();
            match variant {
                0 => altered[8].insert(0, 0),
                1 => {
                    altered[5].pop();
                }
                2 => altered[12] = vec![1; 33],
                3 => altered[10] = vec![0xff; 8],
                4 => altered.truncate(18),
                5 => altered.push(vec![1]),
                6 => altered[15] = vec![1; 33],
                _ => unreachable!(),
            }
            let payload: Vec<u8> = altered
                .iter()
                .flat_map(|field| encoded(field, false))
                .collect();
            let raw = encoded(&payload, true);
            assert!(
                validate_header(&raw, 22, &hash(&raw), &parent, &root).is_err(),
                "variant {variant}"
            );
        }
    }
}
