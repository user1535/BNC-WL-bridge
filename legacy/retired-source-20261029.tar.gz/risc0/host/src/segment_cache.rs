//! Local, immutable SDK segment/Keccak cache. A partial proof has no asset authority.
use anyhow::{bail, ensure, Context, Result};
use risc0_zkvm::{
    sha::{Digest, Digestible, Impl, Sha256},
    ApiClient, Asset, AssetRequest, CompositeReceipt, CompositeReceiptVerifierParameters,
    CoprocessorCallback, ExecutorEnv, ExitCode, InnerAssumptionReceipt, InnerReceipt,
    ProveKeccakRequest, ProverOpts, Receipt, ReceiptClaim, SegmentReceipt, SuccinctReceipt,
    SuccinctReceiptVerifierParameters, Unknown, VerifierContext,
};
use serde::{Deserialize, Serialize};
use serde_json::json;
use std::{
    cell::RefCell,
    env, fs,
    io::{Read, Write},
    os::unix::fs::OpenOptionsExt,
    path::{Component, Path, PathBuf},
    rc::Rc,
    time::Instant,
};

const CAP: usize = 64 * 1024 * 1024;
const MAX_UNITS: usize = 4096;

#[path = "compression_cache.rs"]
mod compression;

fn hex(bytes: &[u8]) -> String {
    bytes.iter().map(|x| format!("{x:02x}")).collect()
}
fn sha(bytes: &[u8]) -> String {
    hex(Impl::hash_bytes(bytes).as_bytes())
}

// O_NONBLOCK prevents FIFO replacement from hanging before fstat; O_NOFOLLOW
// rejects the final symlink. Parent components are checked separately.
pub fn read_regular(path: &Path, cap: usize) -> Result<Vec<u8>> {
    safe_parents(path)?;
    let mut file = fs::OpenOptions::new()
        .read(true)
        .custom_flags(libc::O_NOFOLLOW | libc::O_NONBLOCK)
        .open(path)?;
    let meta = file.metadata()?;
    ensure!(
        meta.is_file() && meta.len() <= cap as u64,
        "regular artifact and size cap required"
    );
    let mut data = Vec::new();
    Read::by_ref(&mut file)
        .take(cap as u64 + 1)
        .read_to_end(&mut data)?;
    ensure!(
        data.len() <= cap && data.len() as u64 == meta.len(),
        "artifact changed/oversized"
    );
    Ok(data)
}

fn safe_parents(path: &Path) -> Result<()> {
    let absolute = if path.is_absolute() {
        path.to_path_buf()
    } else {
        env::current_dir()?.join(path)
    };
    let mut current = PathBuf::new();
    for component in absolute.components() {
        ensure!(
            !matches!(component, Component::ParentDir),
            "parent path forbidden"
        );
        current.push(component);
        if current == absolute {
            break;
        }
        ensure!(
            fs::symlink_metadata(&current)?.is_dir(),
            "parent must be a real directory"
        );
    }
    Ok(())
}

// Commit only complete, verified JSON. A killed writer leaves a .pending file;
// that file is never used as a receipt. hard_link cannot replace a prior file.
fn save(path: &Path, bytes: &[u8]) -> Result<()> {
    ensure!(bytes.len() <= CAP, "artifact exceeds64MiB");
    safe_parents(path)?;
    let pending = path.with_extension(format!("pending-{}", std::process::id()));
    let mut file = fs::OpenOptions::new()
        .write(true)
        .create_new(true)
        .custom_flags(libc::O_NOFOLLOW)
        .open(&pending)?;
    file.write_all(bytes)?;
    file.sync_all()?;
    fs::hard_link(&pending, path)?;
    fs::remove_file(pending)?;
    fs::File::open(path.parent().context("artifact parent")?)?.sync_all()?;
    Ok(())
}
fn save_json<T: Serialize>(path: &Path, value: &T) -> Result<()> {
    save(path, &serde_json::to_vec(value)?)
}

#[derive(Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct Artifact {
    name: String,
    sha256: String,
    bytes: usize,
}
impl Artifact {
    fn record(root: &Path, name: String, bytes: &[u8]) -> Result<Self> {
        save(&root.join(&name), bytes)?;
        Ok(Self {
            name,
            sha256: sha(bytes),
            bytes: bytes.len(),
        })
    }
    fn load(&self, root: &Path) -> Result<Vec<u8>> {
        let path = Path::new(&self.name);
        ensure!(
            path.components().count() == 1
                && matches!(path.components().next(), Some(Component::Normal(_))),
            "cache artifact basename required"
        );
        let bytes = read_regular(&root.join(path), CAP)?;
        ensure!(
            bytes.len() == self.bytes && sha(&bytes) == self.sha256,
            "artifact hash/length mismatch"
        );
        Ok(bytes)
    }
}

#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct Trace {
    artifact: Artifact,
    po2: u32,
    cycles: u32,
}

#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct Manifest {
    schema: u32,
    sdk: String,
    binding: String,
    image: String,
    elf_sha256: String,
    host_sha256: String,
    server_sha256: String,
    input_sha256: String,
    segment_po2: u32,
    keccak_po2: u32,
    threads: usize,
    session_cycle_limit: u64,
    journal: Vec<u8>,
    claim: ReceiptClaim,
    traces: Vec<Trace>,
    keccaks: Vec<Artifact>,
}

struct Collector {
    root: PathBuf,
    requests: Vec<Artifact>,
}
impl CoprocessorCallback for Collector {
    fn prove_keccak(&mut self, request: ProveKeccakRequest) -> Result<()> {
        ensure!(self.requests.len() < MAX_UNITS, "Keccak request count cap");
        let name = format!("keccak-request-{:04}.json", self.requests.len());
        self.requests.push(Artifact::record(
            &self.root,
            name,
            &serde_json::to_vec(&request)?,
        )?);
        Ok(())
    }
}

// SDK raw traces can differ across repeated executions. Re-execute
// to check segment metrics, Keccak transcripts and the full claim. Stored raw
// bytes retain their hashes, and an external preparation pin binds the manifest.
struct TranscriptChecker {
    expected: Vec<Artifact>,
    next: usize,
}
impl CoprocessorCallback for TranscriptChecker {
    fn prove_keccak(&mut self, request: ProveKeccakRequest) -> Result<()> {
        let expected = self
            .expected
            .get(self.next)
            .context("unexpected Keccak request")?;
        let bytes = serde_json::to_vec(&request)?;
        ensure!(
            bytes.len() == expected.bytes && sha(&bytes) == expected.sha256,
            "reexecuted Keccak transcript mismatch"
        );
        self.next += 1;
        Ok(())
    }
}

fn recheck_execution<T: Serialize>(
    client: &ApiClient,
    manifest: &Manifest,
    input: &T,
    elf: &[u8],
) -> Result<()> {
    let checker = Rc::new(RefCell::new(TranscriptChecker {
        expected: manifest.keccaks.clone(),
        next: 0,
    }));
    let mut builder = ExecutorEnv::builder();
    builder
        .segment_limit_po2(manifest.segment_po2)
        .session_limit(Some(manifest.session_cycle_limit))
        .keccak_max_po2(manifest.keccak_po2)?
        .coprocessor_callback_ref(checker.clone())
        .write(input)?;
    let mut next = 0;
    let session = client.execute(
        &builder.build()?,
        Asset::Inline(elf.to_vec().into()),
        AssetRequest::Inline,
        |info, asset| {
            let expected = manifest.traces.get(next).context("unexpected segment")?;
            let bytes = asset.as_bytes()?;
            ensure!(
                bytes.len() <= CAP
                    && bytes.len() == expected.artifact.bytes
                    && info.po2 == expected.po2
                    && info.cycles == expected.cycles,
                "reexecuted segment transcript/order/cycles mismatch"
            );
            next += 1;
            Ok(())
        },
    )?;
    ensure!(
        next == manifest.traces.len()
            && checker.borrow().next == manifest.keccaks.len()
            && session.exit_code == ExitCode::Halted(0)
            && session.journal.bytes == manifest.journal
            && session
                .receipt_claim
                .context("missing complete session claim")?
                .digest()
                == manifest.claim.digest(),
        "reexecuted full session mismatch"
    );
    Ok(())
}

pub fn is_command(args: &[String]) -> bool {
    matches!(
        args.get(1).map(String::as_str),
        Some("--segments-prepare" | "--segments-prove" | "--segments-audit"
            | "--compression-prepare" | "--compression-prove" | "--compression-audit")
    )
}

fn sdk_mode() -> Result<()> {
    ensure!(
        env::var("RISC0_DEV_MODE").is_ok_and(|s| s == "0"),
        "RISC0_DEV_MODE=0 required"
    );
    ensure!(
        env::var("RISC0_PROVER").is_ok_and(|s| s == "ipc"),
        "pinned local IPC prover required"
    );
    Ok(())
}

struct Budget {
    max: usize,
    new: usize,
    reused: usize,
}
impl Budget {
    fn available(&mut self, path: &Path) -> Result<bool> {
        match fs::symlink_metadata(path) {
            Ok(meta) => {
                ensure!(meta.is_file(), "cached proof must be a regular file");
                self.reused += 1;
                Ok(true)
            }
            Err(err) if err.kind() == std::io::ErrorKind::NotFound => {
                if self.new == self.max {
                    return Ok(false);
                }
                self.new += 1;
                Ok(true)
            }
            Err(err) => Err(err.into()),
        }
    }
}

fn succinct_context(root: Digest) -> VerifierContext {
    let mut params = SuccinctReceiptVerifierParameters::default();
    params.control_root = root;
    params.inner_control_root = None;
    VerifierContext::default().with_succinct_verifier_parameters(params)
}

fn verify_segment(
    r: &SegmentReceipt,
    index: usize,
    previous: Option<&SegmentReceipt>,
    image: Digest,
) -> Result<()> {
    r.verify_integrity_with_context(&VerifierContext::default())?;
    ensure!(r.index as usize == index, "segment index mismatch");
    let expected = if let Some(prior) = previous {
        prior.claim.post.digest()
    } else {
        image
    };
    ensure!(
        r.claim.pre.digest() == expected,
        "ordered segment prestate mismatch"
    );
    if let Some(prior) = previous {
        ensure!(
            prior.claim.exit_code == ExitCode::SystemSplit && prior.claim.output.is_none(),
            "non-final segment must split without output"
        );
    }
    Ok(())
}

// Mirror the SDK MMR peak shape, using the public union RPC. Cached unions
// are bound to both child assumptions; all are checked again by the composite.
fn merge(
    client: &ApiClient,
    root: &Path,
    a: SuccinctReceipt<Unknown>,
    a_root: Digest,
    b: SuccinctReceipt<Unknown>,
    b_root: Digest,
    budget: &mut Budget,
) -> Result<Option<SuccinctReceipt<Unknown>>> {
    use risc0_zkvm::{Assumption, UnionClaim};
    let da = Assumption {
        claim: a.claim.digest(),
        control_root: a_root,
    }
    .digest();
    let db = Assumption {
        claim: b.claim.digest(),
        control_root: b_root,
    }
    .digest();
    let (left, right) = if da <= db { (da, db) } else { (db, da) };
    let expected = UnionClaim { left, right }.digest();
    let path = root.join(format!("union-{}.json", hex(expected.as_bytes())));
    if !budget.available(&path)? {
        return Ok(None);
    }
    let r: SuccinctReceipt<Unknown> = if path.exists() {
        serde_json::from_slice(&read_regular(&path, CAP)?)?
    } else {
        let r = client
            .union(
                &ProverOpts::succinct(),
                a.try_into()?,
                b.try_into()?,
                AssetRequest::Inline,
            )?
            .into_unknown();
        r.verify_integrity()?;
        ensure!(r.claim.digest() == expected, "union claim mismatch");
        save_json(&path, &r)?;
        r
    };
    r.verify_integrity()?;
    ensure!(
        r.claim.digest() == expected,
        "cached union child claims mismatch"
    );
    Ok(Some(r))
}

fn prove(
    client: &ApiClient,
    root: &Path,
    manifest: &Manifest,
    budget: &mut Budget,
    persist: bool,
) -> Result<Option<Receipt>> {
    let mut segments: Vec<SegmentReceipt> = Vec::new();
    let mut image_bytes = [0u8; 32];
    ensure!(manifest.image.len() == 64, "image hex width");
    for (i, byte) in image_bytes.iter_mut().enumerate() {
        *byte = u8::from_str_radix(&manifest.image[i * 2..i * 2 + 2], 16)?;
    }
    let image = Digest::from_bytes(image_bytes);
    for (i, trace) in manifest.traces.iter().enumerate() {
        let trace_bytes = trace.artifact.load(root)?;
        let path = root.join(format!("segment-receipt-{i:04}.json"));
        if !budget.available(&path)? {
            return Ok(None);
        }
        let r = if path.exists() {
            serde_json::from_slice(&read_regular(&path, CAP)?)?
        } else {
            eprintln!("proving segment {i}/{}", manifest.traces.len());
            let r = client.prove_segment(
                &ProverOpts::composite(),
                Asset::Inline(trace_bytes.into()),
                AssetRequest::Inline,
            )?;
            verify_segment(&r, i, segments.last(), image)?;
            save_json(&path, &r)?;
            r
        };
        verify_segment(&r, i, segments.last(), image)?;
        segments.push(r);
    }
    let mut peaks: Vec<(u32, SuccinctReceipt<Unknown>, Digest)> = Vec::new();
    let union_root = SuccinctReceiptVerifierParameters::default().control_root;
    for (i, artifact) in manifest.keccaks.iter().enumerate() {
        let request: ProveKeccakRequest = serde_json::from_slice(&artifact.load(root)?)?;
        ensure!(
            (14..=manifest.keccak_po2 as usize).contains(&request.po2),
            "Keccak po2 bound"
        );
        let context = succinct_context(request.control_root);
        let path = root.join(format!("keccak-receipt-{i:04}.json"));
        if !budget.available(&path)? {
            return Ok(None);
        }
        let r: SuccinctReceipt<Unknown> = if path.exists() {
            serde_json::from_slice(&read_regular(&path, CAP)?)?
        } else {
            eprintln!("proving Keccak {i}/{}", manifest.keccaks.len());
            let r = client.prove_keccak(request.clone(), AssetRequest::Inline)?;
            r.verify_integrity_with_context(&context)?;
            ensure!(
                r.claim.digest() == request.claim_digest,
                "Keccak transcript claim mismatch"
            );
            save_json(&path, &r)?;
            r
        };
        r.verify_integrity_with_context(&context)?;
        ensure!(
            r.claim.digest() == request.claim_digest,
            "cached Keccak claim mismatch"
        );
        let (mut height, mut item, mut control) = (0, r, request.control_root);
        while peaks.last().is_some_and(|p| p.0 == height) {
            let (_, prior, prior_root) = peaks.pop().unwrap();
            item = match merge(client, root, item, control, prior, prior_root, budget)? {
                Some(r) => r,
                None => return Ok(None),
            };
            height += 1;
            control = union_root;
        }
        peaks.push((height, item, control));
    }
    let mut assumptions = Vec::new();
    if !peaks.is_empty() {
        let (_, mut item, mut control) = peaks.remove(0);
        for (_, next, next_root) in peaks {
            item = match merge(client, root, item, control, next, next_root, budget)? {
                Some(r) => r,
                None => return Ok(None),
            };
            control = union_root;
        }
        assumptions.push(InnerAssumptionReceipt::Succinct(item));
    }
    // Execute with a capture callback leaves accelerator assumptions unresolved
    // in the session claim. Match that conditional claim before resolution.
    let conditional = ReceiptClaim {
        pre: segments.first().context("first segment")?.claim.pre.clone(),
        post: segments.last().context("last segment")?.claim.post.clone(),
        exit_code: segments.last().unwrap().claim.exit_code,
        input: segments.first().unwrap().claim.input.clone(),
        output: segments.last().unwrap().claim.output.clone(),
    };
    ensure!(
        conditional.digest() == manifest.claim.digest(),
        "conditional session claim mismatch"
    );
    // CompositeReceipt is non_exhaustive. Its public serde representation is
    // used to construct it, with trusted default verifier parameters.
    let composite: CompositeReceipt = serde_json::from_value(json!({
        "segments": segments, "assumption_receipts": assumptions,
        "verifier_parameters": CompositeReceiptVerifierParameters::default().digest(),
    }))?;
    let receipt = Receipt::new(InnerReceipt::Composite(composite), manifest.journal.clone());
    receipt.verify(image)?; // Every accelerator assumption must have a verified receipt.
                            // Only after SDK verification, compare the claim with resolved assumptions,
                            // following CompositeReceipt::claim. Never suppress unresolved assumptions.
    let mut resolved = manifest.claim.clone();
    let mut output = resolved.output.as_value()?.clone();
    if let Some(output) = output.as_mut() {
        output.assumptions = Vec::<risc0_zkvm::Assumption>::new().into();
    }
    resolved.output = output.into();
    ensure!(
        receipt.claim()?.digest() == resolved.digest(),
        "resolved session claim mismatch"
    );
    let path = root.join("composite.json");
    if path.exists() {
        let cached: Receipt = serde_json::from_slice(&read_regular(&path, CAP)?)?;
        ensure!(
            matches!(cached.inner, InnerReceipt::Composite(_)),
            "cached receipt kind"
        );
        cached.verify(image)?;
        ensure!(
            cached.journal.bytes == manifest.journal
                && cached.claim()?.digest() == resolved.digest(),
            "cached composite journal/claim mismatch"
        );
    } else if persist {
        save_json(&path, &receipt)?;
    }
    Ok(Some(receipt))
}

pub fn command<T: Serialize>(
    args: &[String],
    input: &T,
    elf: &[u8],
    image: [u32; 8],
    binding: &str,
    expected: &[u8],
) -> Result<()> {
    if args[1].starts_with("--compression-") {
        return compression::command(args, input, elf, image, binding, expected);
    }
    sdk_mode()?;
    let prepare = args[1] == "--segments-prepare";
    let audit = args[1] == "--segments-audit";
    ensure!(args.len() == if prepare || audit { 4 } else { 5 },
            "usage: --segments-prepare|--segments-audit <input> <cache>; --segments-prove <input> <cache> <max-new-units>");
    let max = if prepare || audit {
        0
    } else {
        args[4].parse::<usize>()?
    };
    ensure!(max <= MAX_UNITS, "new proof units cap4096");
    let input_bytes = read_regular(Path::new(&args[2]), 64 * 1024)?;
    ensure!(
        serde_json::to_value(input)? == serde_json::from_slice::<serde_json::Value>(&input_bytes)?,
        "input changed or contains unrecognized fields"
    );
    let segment_po2 = env::var("BRIDGE_RISC0_SEGMENT_PO2")?.parse::<u32>()?;
    ensure!((16..=19).contains(&segment_po2), "segment po2 bound16..19");
    let keccak_po2: u32 = match env::var("BRIDGE_RISC0_KECCAK_PO2") {
        Ok(value) => value.parse()?,
        Err(env::VarError::NotPresent) => 16,
        Err(error) => return Err(error.into()),
    };
    ensure!((14..=16).contains(&keccak_po2), "Keccak max po2 bound14..16");
    let threads = env::var("RAYON_NUM_THREADS")?.parse::<usize>()?;
    ensure!((1..=12).contains(&threads), "SDK thread bound1..12");
    let host_sha = sha(&read_regular(&env::current_exe()?, 256 * 1024 * 1024)?);
    let server = PathBuf::from(env::var("RISC0_SERVER_PATH")?);
    let server_sha = sha(&read_regular(&server, 256 * 1024 * 1024)?);
    let root = Path::new(&args[3]);
    safe_parents(root)?;
    if prepare {
        fs::create_dir(root)?;
    }
    ensure!(
        fs::symlink_metadata(root)?.is_dir(),
        "real cache directory required"
    );
    let lock_path = root.join("cache.lock");
    let lock = fs::OpenOptions::new()
        .read(true)
        .write(true)
        .create(true)
        .truncate(false)
        .custom_flags(libc::O_NOFOLLOW | libc::O_NONBLOCK)
        .open(&lock_path)?;
    ensure!(lock.metadata()?.is_file(), "cache lock regular file");
    lock.try_lock().context("cache already in use")?;
    let client = ApiClient::from_env()?;
    let image_hex = hex(Digest::from(image).as_bytes());
    let started = Instant::now();
    let manifest_path = root.join("manifest.json");
    if prepare {
        let raw = root.join("sdk-traces");
        fs::create_dir(&raw)?;
        let collector = Rc::new(RefCell::new(Collector {
            root: root.to_path_buf(),
            requests: Vec::new(),
        }));
        let mut builder = ExecutorEnv::builder();
        builder
            .segment_limit_po2(segment_po2)
            .session_limit(Some(1 << 27))
            .keccak_max_po2(keccak_po2)?
            .coprocessor_callback_ref(collector.clone())
            .write(input)?;
        let mut traces = Vec::new();
        let session = client.execute(
            &builder.build()?,
            Asset::Inline(elf.to_vec().into()),
            AssetRequest::Path(raw.clone()),
            |info, asset| {
                ensure!(traces.len() < MAX_UNITS, "segment count cap4096");
                let path = match asset {
                    Asset::Path(path) => path,
                    _ => bail!("file segment required"),
                };
                ensure!(
                    path.parent() == Some(raw.as_path()),
                    "SDK trace outside owned directory"
                );
                let bytes = read_regular(&path, CAP)?;
                let artifact = Artifact::record(
                    root,
                    format!("segment-trace-{:04}.bin", traces.len()),
                    &bytes,
                )?;
                traces.push(Trace {
                    artifact,
                    po2: info.po2,
                    cycles: info.cycles,
                });
                Ok(())
            },
        )?;
        ensure!(
            session.exit_code == ExitCode::Halted(0)
                && session.journal.bytes == expected
                && !traces.is_empty()
                && session.segments.len() == traces.len(),
            "session exit/journal/segments mismatch"
        );
        let manifest = Manifest {
            schema: 1,
            sdk: "3.0.5".into(),
            binding: binding.into(),
            image: image_hex.clone(),
            elf_sha256: sha(elf),
            host_sha256: host_sha.clone(),
            server_sha256: server_sha.clone(),
            input_sha256: sha(&input_bytes),
            segment_po2,
            keccak_po2,
            threads,
            session_cycle_limit: 1 << 27,
            journal: expected.to_vec(),
            claim: session
                .receipt_claim
                .context("complete session claim required")?,
            traces,
            keccaks: collector.borrow().requests.clone(),
        };
        save_json(&manifest_path, &manifest)?;
    }
    let manifest_bytes = read_regular(&manifest_path, CAP)?;
    if !prepare {
        ensure!(
            env::var("BRIDGE_RISC0_CACHE_MANIFEST_SHA256")
                .context("external preparation manifest pin required")?
                == sha(&manifest_bytes),
            "preparation manifest pin mismatch"
        );
    }
    let manifest: Manifest = serde_json::from_slice(&manifest_bytes)?;
    ensure!(
        manifest.schema == 1
            && manifest.sdk == "3.0.5"
            && manifest.binding == binding
            && manifest.image == image_hex
            && manifest.elf_sha256 == sha(elf)
            && manifest.host_sha256 == host_sha
            && manifest.server_sha256 == server_sha
            && manifest.input_sha256 == sha(&input_bytes)
            && manifest.journal == expected
            && manifest.segment_po2 == segment_po2
            && manifest.keccak_po2 == keccak_po2
            && manifest.threads == threads
            && manifest.session_cycle_limit == 1 << 27,
        "cache schema/input/image/ELF/host/SDK/settings/journal mismatch"
    );
    ensure!(
        !manifest.traces.is_empty()
            && manifest.traces.len() <= MAX_UNITS
            && manifest.keccaks.len() <= MAX_UNITS,
        "manifest count bounds"
    );
    for (index, trace) in manifest.traces.iter().enumerate() {
        ensure!(
            trace.artifact.name == format!("segment-trace-{index:04}.bin"),
            "segment trace basename/order mismatch"
        );
        ensure!(
            (16..=segment_po2).contains(&trace.po2) && trace.cycles <= 1 << trace.po2,
            "trace po2/cycle bounds"
        );
        trace.artifact.load(root)?;
    }
    for (index, request) in manifest.keccaks.iter().enumerate() {
        ensure!(
            request.name == format!("keccak-request-{index:04}.json"),
            "Keccak basename/order mismatch"
        );
        request.load(root)?;
    }
    if !prepare {
        recheck_execution(&client, &manifest, input, elf)?;
    }
    let mut budget = Budget {
        max,
        new: 0,
        reused: 0,
    };
    let receipt = if prepare {
        None
    } else {
        prove(&client, root, &manifest, &mut budget, !audit)?
    };
    println!(
        "{}",
        json!({"status": if prepare { "PREPARED" } else if receipt.is_some() { "PASS" } else { "PARTIAL" },
        "imageId": format!("0x{image_hex}"), "headerBinding": binding, "journal": format!("0x{}", hex(expected)),
        "manifestSHA256": sha(&manifest_bytes), "segmentCount": manifest.traces.len(), "keccakRequestCount": manifest.keccaks.len(),
        "newVerifiedUnits": budget.new, "reusedVerifiedUnits": budget.reused,
        "invocationWallSeconds": started.elapsed().as_secs_f64(), "receiptKind": receipt.as_ref().map(|_| "composite"),
        "fullReceiptVerified": receipt.is_some(), "executionTranscriptsRechecked": !prepare, "fullGenerationWallMeasured": false,
        "evmCompatible": false, "evmAcceptanceMeasured": false,
        "chainAuthenticated": false, "realAssetDeploymentAllowed": false})
    );
    Ok(())
}
