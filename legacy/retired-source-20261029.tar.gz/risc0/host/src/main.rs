use bridge_header_methods::{
    BRIDGE_HEADER_GUEST_ELF as GUEST_ELF, BRIDGE_HEADER_GUEST_ID as GUEST_ID,
};
use risc0_zkvm::{
    default_executor, default_prover, sha::Digest, ExecutorEnv, InnerReceipt, ProverOpts, Receipt,
};
use serde::{Deserialize, Serialize};
use std::env;
use std::error::Error;
use std::fs;
use std::time::Instant;
use tiny_keccak::{Hasher, Keccak};

#[cfg(feature = "profile-prover")]
mod proof_profile;

#[cfg(feature = "segment-cache")]
mod segment_cache;

#[derive(Serialize, Deserialize)]
struct MinimalHeader {
    number: u64,
    block_hash: [u8; 32],
    parent_hash: [u8; 32],
    receipt_root: [u8; 32],
    #[cfg(feature = "strict-header")]
    canonical_rlp: Vec<u8>,
}

#[derive(Serialize, Deserialize)]
struct HeaderBatch {
    chain_id: u64,
    anchor_hash: [u8; 32],
    headers: Vec<MinimalHeader>,
}

#[derive(Serialize)]
struct ResultRow {
    chain_id: u64,
    receipt_kind: String,
    batch_size: usize,
    start_block: u64,
    end_block: u64,
    execute_ms: u128,
    prove_ms: u128,
    total_ms: u128,
    proof_bytes: usize,
    journal_bytes: usize,
    headers_per_second: f64,
    end_to_end_headers_per_second: f64,
    segment_limit_po2: u32,
    verified: bool,
    synthetic_input: bool,
}

fn parse_segment_limit(value: Option<&str>) -> Result<u32, Box<dyn Error>> {
    // SDK 3.0.5 defaults to 20. Smaller measured configurations are opt-in;
    // do not allow this host to silently request a larger memory budget.
    let limit = value.unwrap_or("20").parse::<u32>()?;
    if !(16..=20).contains(&limit) {
        return Err("BRIDGE_RISC0_SEGMENT_PO2 must be within 16..20".into());
    }
    Ok(limit)
}

fn segment_limit() -> Result<u32, Box<dyn Error>> {
    parse_segment_limit(env::var("BRIDGE_RISC0_SEGMENT_PO2").ok().as_deref())
}

fn execution_env(input: &HeaderBatch) -> Result<ExecutorEnv<'static>, Box<dyn Error>> {
    let mut builder = ExecutorEnv::builder();
    builder.segment_limit_po2(segment_limit()?).write(input)?;
    Ok(builder.build()?)
}

fn hash(data: &[u8]) -> [u8; 32] {
    let mut output = [0u8; 32];
    let mut hasher = Keccak::v256();
    hasher.update(data);
    hasher.finalize(&mut output);
    output
}

fn fixture(chain_id: u64, size: usize) -> HeaderBatch {
    let anchor = [7u8; 32];
    let mut prior = anchor;
    let mut headers = Vec::with_capacity(size);
    for i in 0..size {
        let number = 1000 + i as u64;
        let mut block_data = [0u8; 40];
        block_data[..32].copy_from_slice(&prior);
        block_data[32..].copy_from_slice(&number.to_be_bytes());
        let block_hash = hash(&block_data);
        let receipt_root = hash(&number.to_be_bytes());
        headers.push(MinimalHeader {
            number,
            block_hash,
            parent_hash: prior,
            receipt_root,
            #[cfg(feature = "strict-header")]
            canonical_rlp: Vec::new(),
        });
        prior = block_hash;
    }
    HeaderBatch {
        chain_id,
        anchor_hash: anchor,
        headers,
    }
}

#[derive(Serialize)]
struct VerifiedReceipt {
    header_binding: &'static str,
    image_id: String,
    journal: String,
    receipt_kind: &'static str,
    verified: bool,
    evm_compatible: bool,
    chain_authenticated: bool,
    seal: Option<String>,
    verifier_parameters: String,
}

fn hex(data: &[u8]) -> String {
    let value: String = data.iter().map(|byte| format!("{byte:02x}")).collect();
    format!("0x{value}")
}

fn verified_receipt(receipt: &Receipt) -> Result<VerifiedReceipt, Box<dyn Error>> {
    require_cryptographic_mode()?;
    // Never accept a development Fake receipt, even when RISC0_DEV_MODE is enabled.
    if !matches!(
        receipt.inner,
        InnerReceipt::Composite(_) | InnerReceipt::Groth16(_)
    ) {
        return Err(
            "only cryptographic composite or Groth16 receipts are supported by the local receipt path".into(),
        );
    }
    receipt.verify(GUEST_ID)?;
    if receipt.journal.bytes.len() != 224 {
        return Err("unexpected header journal size".into());
    }
    let (receipt_kind, seal) = match &receipt.inner {
        InnerReceipt::Groth16(inner) => {
            if inner.seal.len() != 256 {
                return Err("unexpected Groth16 seal length".into());
            }
            let mut encoded = inner.verifier_parameters.as_bytes()[..4].to_vec();
            encoded.extend_from_slice(&inner.seal);
            ("groth16", Some(hex(&encoded)))
        }
        _ => ("composite", None),
    };
    Ok(VerifiedReceipt {
        header_binding: bridge_header_methods::HEADER_BINDING,
        image_id: hex(Digest::from(GUEST_ID).as_bytes()),
        journal: hex(&receipt.journal.bytes),
        receipt_kind,
        verified: true,
        evm_compatible: seal.is_some(),
        chain_authenticated: false,
        seal,
        verifier_parameters: hex(receipt.inner.verifier_parameters().as_bytes()),
    })
}

fn require_cryptographic_mode() -> Result<(), Box<dyn Error>> {
    if env::var("RISC0_DEV_MODE").is_ok_and(|value| value != "0" && !value.is_empty()) {
        return Err(
            "RISC0_DEV_MODE is forbidden for cryptographic receipt export and verification".into(),
        );
    }
    Ok(())
}

fn receipt_command(args: &[String]) -> Result<bool, Box<dyn Error>> {
    if args.len() == 2 && args[1] == "--header-binding" {
        println!("{}", bridge_header_methods::HEADER_BINDING);
        return Ok(true);
    }
    if args.len() == 2 && args[1] == "--image-id" {
        println!("{}", hex(Digest::from(GUEST_ID).as_bytes()));
        return Ok(true);
    }
    if args.len() == 3 && args[1] == "--verify-receipt" {
        let receipt: Receipt = serde_json::from_slice(&fs::read(&args[2])?)?;
        println!("{}", serde_json::to_string(&verified_receipt(&receipt)?)?);
        return Ok(true);
    }
    if (args.len() == 6 || args.len() == 8)
        && args[1] == "--prove-receipt"
        && args[2] == "--input"
        && args[4] == "--receipt-output"
    {
        require_cryptographic_mode()?;
        let input: HeaderBatch = serde_json::from_slice(&fs::read(&args[3])?)?;
        if bridge_header_methods::HEADER_BINDING == "canonical-rlp" && input.headers.len() > 1 {
            return Err("strict RLP proving is limited to one header until its larger memory budget is measured".into());
        }
        if !matches!(input.chain_id, 31337 | 31338)
            || input.headers.is_empty()
            || input.headers.len() > 4
        {
            return Err(
                "receipt export requires local chain ID 31337/31338 and 1..4 headers (measured host memory budget)".into(),
            );
        }
        let proving_env = execution_env(&input)?;
        let opts = if args.len() == 8 {
            if args[6] != "--receipt-kind" {
                return Err("expected --receipt-kind composite|groth16".into());
            }
            match args[7].as_str() {
                "composite" => ProverOpts::composite(),
                "groth16" => ProverOpts::groth16(),
                _ => return Err("unsupported receipt kind".into()),
            }
        } else {
            ProverOpts::composite()
        };
        let proof = default_prover().prove_with_opts(proving_env, GUEST_ELF, &opts)?;
        let summary = verified_receipt(&proof.receipt)?;
        // Refuse to overwrite another caller's artifact.
        let mut output = fs::OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(&args[5])?;
        serde_json::to_writer(&mut output, &proof.receipt)?;
        println!("{}", serde_json::to_string(&summary)?);
        return Ok(true);
    }
    Ok(false)
}

fn main() -> Result<(), Box<dyn Error>> {
    let args: Vec<String> = env::args().collect();
    #[cfg(feature = "profile-prover")]
    if proof_profile::command(&args)? {
        return Ok(());
    }
    #[cfg(feature = "segment-cache")]
    if segment_cache::is_command(&args) {
        require_cryptographic_mode()?;
        if args.len() < 4 { return Err("segment cache arguments".into()); }
        let input: HeaderBatch = serde_json::from_slice(&segment_cache::read_regular(
            std::path::Path::new(&args[2]), 64 * 1024)?)?;
        let cap: usize = match env::var("BRIDGE_RISC0_DIAGNOSTIC_MAX_HEADERS") {
            Ok(value) => value.parse()?,
            Err(env::VarError::NotPresent) => 4,
            Err(error) => return Err(error.into()),
        };
        if !matches!(cap, 4 | 8 | 16 | 32 | 64 | 128)
            || (cap != 4 && bridge_header_methods::HEADER_BINDING != "minimal-link") {
            return Err("segment cache larger diagnostic needs explicit minimal-link cap4/8/16/32/64/128".into());
        }
        if !matches!(input.chain_id, 31337 | 31338) || input.headers.is_empty()
            || input.headers.len() > cap { return Err("segment cache local witness exceeds explicit diagnostic cap".into()); }
        let expected = default_executor().execute(execution_env(&input)?, GUEST_ELF)?.journal.bytes;
        segment_cache::command(&args, &input, GUEST_ELF, GUEST_ID,
            bridge_header_methods::HEADER_BINDING, &expected)?;
        return Ok(());
    }
    if receipt_command(&args)? {
        return Ok(());
    }
    let journal_only = args.len() == 4 && args[1] == "--journal-only" && args[2] == "--input";
    let (input, synthetic_input) = if journal_only {
        (
            serde_json::from_slice::<HeaderBatch>(&fs::read(&args[3])?)?,
            false,
        )
    } else if args.len() == 3 && args[1] == "--input" {
        (
            serde_json::from_slice::<HeaderBatch>(&fs::read(&args[2])?)?,
            false,
        )
    } else if args.len() == 3 {
        let chain_id: u64 = args[1].parse()?;
        let size: usize = args[2].parse()?;
        if chain_id == 0 || size == 0 || size > 4096 {
            return Err("invalid chain ID or batch size".into());
        }
        (fixture(chain_id, size), true)
    } else {
        return Err(
            "usage: bridge-header-benchmark <chain-id> <batch-size> | --input <json> | --journal-only --input <json>".into(),
        );
    };
    if input.chain_id == 0 || input.headers.is_empty() || input.headers.len() > 4096 {
        return Err("invalid input batch".into());
    }
    let chain_id = input.chain_id;
    let size = input.headers.len();
    if !journal_only && bridge_header_methods::HEADER_BINDING == "canonical-rlp" && size > 1 {
        return Err("strict RLP proving currently supports one header".into());
    }
    if !journal_only {
        require_cryptographic_mode()?;
    }
    let execution_env = execution_env(&input)?;
    let start = Instant::now();
    let execution = default_executor().execute(execution_env, GUEST_ELF)?;
    let execute_ms = start.elapsed().as_millis();
    if execution.journal.bytes.len() != 224 {
        return Err("unexpected journal size".into());
    }
    if journal_only {
        let journal_hex: String = execution
            .journal
            .bytes
            .iter()
            .map(|b| format!("{b:02x}"))
            .collect();
        println!("0x{journal_hex}");
        return Ok(());
    }
    let proving_env = crate::execution_env(&input)?;
    let receipt_kind = env::var("RISC0_RECEIPT_KIND").unwrap_or_else(|_| "composite".to_string());
    let opts = match receipt_kind.as_str() {
        "composite" => ProverOpts::composite(),
        "groth16" => ProverOpts::groth16(),
        _ => return Err("RISC0_RECEIPT_KIND must be composite or groth16".into()),
    };
    let start = Instant::now();
    let proof = default_prover().prove_with_opts(proving_env, GUEST_ELF, &opts)?;
    let prove_ms = start.elapsed().as_millis();
    verified_receipt(&proof.receipt)?;
    if proof.receipt.journal.bytes != execution.journal.bytes {
        return Err("execute/prove journal mismatch".into());
    }
    let row = ResultRow {
        chain_id,
        receipt_kind,
        batch_size: size,
        start_block: input.headers[0].number,
        end_block: input.headers[size - 1].number,
        execute_ms,
        prove_ms,
        total_ms: execute_ms + prove_ms,
        proof_bytes: proof.receipt.seal_size(),
        journal_bytes: proof.receipt.journal.bytes.len(),
        headers_per_second: size as f64 / (prove_ms as f64 / 1000.0),
        end_to_end_headers_per_second: size as f64 / ((execute_ms + prove_ms) as f64 / 1000.0),
        segment_limit_po2: segment_limit()?,
        verified: true,
        synthetic_input,
    };
    println!("{}", serde_json::to_string(&row)?);
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use risc0_zkvm::{FakeReceipt, MaybePruned};

    #[test]
    fn segment_limit_defaults_and_rejects_unbounded_memory_settings() {
        assert_eq!(parse_segment_limit(None).unwrap(), 20);
        assert_eq!(parse_segment_limit(Some("18")).unwrap(), 18);
        for invalid in ["", "15", "21", "-1", "invalid"] {
            assert!(parse_segment_limit(Some(invalid)).is_err());
        }
    }

    #[test]
    fn fake_receipt_cannot_be_exported_as_verified_proof() {
        let receipt = Receipt::new(
            InnerReceipt::Fake(FakeReceipt::new(MaybePruned::Pruned(Digest::ZERO))),
            vec![0u8; 224],
        );
        let err = verified_receipt(&receipt)
            .err()
            .expect("fake receipt must be rejected");
        assert!(err.to_string().contains("cryptographic composite"));
    }
}
