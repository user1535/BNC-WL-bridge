//! Verified public SDK lift/join/resolve checkpoints for an existing composite.
//! Every resumed node is bound to the pinned input composite and expected claim.
use super::*;

#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct CompressionManifest {
    schema: u32,
    sdk: String,
    binding: String,
    image: String,
    elf_sha256: String,
    host_sha256: String,
    server_sha256: String,
    input_sha256: String,
    threads: usize,
    composite: Artifact,
    resolved_claim: String,
    journal: Vec<u8>,
    segments: usize,
    assumptions: usize,
}

// Reading or generating a node always performs SDK integrity verification.
// The expected claim comes from the already fully verified pinned composite,
// never from a cached node's untrusted metadata.
fn node<F>(
    root: &Path,
    name: String,
    expected: &ReceiptClaim,
    budget: &mut Budget,
    make: F,
) -> Result<Option<SuccinctReceipt<ReceiptClaim>>>
where
    F: FnOnce() -> Result<SuccinctReceipt<ReceiptClaim>>,
{
    let path = root.join(name);
    if !budget.available(&path)? {
        return Ok(None);
    }
    let exists = path.exists();
    let receipt: SuccinctReceipt<ReceiptClaim> = if exists {
        serde_json::from_slice(&read_regular(&path, CAP)?)?
    } else {
        eprintln!("proving recursion node {}", path.file_name().unwrap().to_string_lossy());
        make()?
    };
    receipt.verify_integrity()?;
    ensure!(receipt.claim.digest() == expected.digest(), "recursion node claim mismatch");
    if !exists {
        save_json(&path, &receipt)?;
    }
    Ok(Some(receipt))
}

fn compress(
    client: &ApiClient,
    root: &Path,
    source: &Receipt,
    image: Digest,
    budget: &mut Budget,
    persist: bool,
) -> Result<Option<Receipt>> {
    let composite = match &source.inner {
        InnerReceipt::Composite(c) => c,
        _ => bail!("verified nonempty composite required"),
    };
    let opts = ProverOpts::succinct();
    let mut span: Option<SuccinctReceipt<ReceiptClaim>> = None;
    let mut expected: Option<ReceiptClaim> = None;
    for (i, segment) in composite.segments.iter().enumerate() {
        let lifted = match node(root, format!("lift-{i:04}.json"), &segment.claim, budget, || {
            client.lift(&opts, segment.clone().try_into()?, AssetRequest::Inline)
        })? {
            Some(r) => r,
            None => return Ok(None),
        };
        if let Some(left) = span {
            let prior = expected.as_ref().context("previous span claim")?;
            ensure!(prior.post.digest() == segment.claim.pre.digest()
                && prior.exit_code == ExitCode::SystemSplit && prior.output.is_none(),
                "recursion span continuity mismatch");
            let next = prior.join(&segment.claim);
            let joined = match node(root, format!("join-0000-{i:04}.json"), &next, budget, || {
                client.join(&opts, left.try_into()?, lifted.try_into()?, AssetRequest::Inline)
            })? {
                Some(r) => r,
                None => return Ok(None),
            };
            span = Some(joined);
            expected = Some(next);
        } else {
            span = Some(lifted);
            expected = Some(segment.claim.clone());
        }
    }
    let mut conditional = span.context("empty composite")?;
    let mut claim = expected.context("missing conditional claim")?;
    for (i, assumption) in composite.assumption_receipts.iter().enumerate() {
        // This cache supports the exact accelerator receipts used by the
        // segment cache. Other kinds fail explicitly, without dropping them.
        let assumption = match assumption {
            InnerAssumptionReceipt::Succinct(r) => r,
            _ => bail!("compression cache requires succinct assumptions"),
        };
        let resolved = claim.resolve(&assumption.claim)?;
        conditional = match node(root, format!("resolve-{i:04}.json"), &resolved, budget, || {
            client.resolve(&opts, conditional.try_into()?, assumption.clone().try_into()?, AssetRequest::Inline)
        })? {
            Some(r) => r,
            None => return Ok(None),
        };
        claim = resolved;
    }
    let receipt = Receipt::new(InnerReceipt::Succinct(conditional), source.journal.bytes.clone());
    receipt.verify(image)?;
    ensure!(receipt.claim()?.digest() == source.claim()?.digest(), "resolved full claim mismatch");
    let final_path = root.join("succinct.json");
    if final_path.exists() {
        let saved: Receipt = serde_json::from_slice(&read_regular(&final_path, CAP)?)?;
        ensure!(matches!(saved.inner, InnerReceipt::Succinct(_)), "final succinct kind mismatch");
        saved.verify(image)?;
        ensure!(saved.claim()?.digest() == source.claim()?.digest()
            && saved.journal.bytes == source.journal.bytes, "saved succinct journal/claim mismatch");
    } else if persist {
        save_json(&final_path, &receipt)?;
    }
    Ok(Some(receipt))
}

pub(super) fn command<T: Serialize>(
    args: &[String], input: &T, elf: &[u8], image: [u32; 8], binding: &str, expected: &[u8],
) -> Result<()> {
    sdk_mode()?;
    let prepare = args[1] == "--compression-prepare";
    let audit = args[1] == "--compression-audit";
    ensure!(args.len() == if audit { 4 } else { 5 }, "compression argument count");
    let max = if prepare || audit { 0 } else { args[4].parse::<usize>()? };
    ensure!(max <= MAX_UNITS, "recursion units cap4096");
    let raw_input = read_regular(Path::new(&args[2]), 64 * 1024)?;
    ensure!(serde_json::to_value(input)? == serde_json::from_slice::<serde_json::Value>(&raw_input)?,
        "input changed or contains unrecognized fields");
    let threads: usize = env::var("RAYON_NUM_THREADS")?.parse()?;
    ensure!((1..=12).contains(&threads), "SDK thread bound1..12");
    let image = Digest::from(image);
    let host_sha = sha(&read_regular(&env::current_exe()?, 256 * 1024 * 1024)?);
    let server_sha = sha(&read_regular(Path::new(&env::var("RISC0_SERVER_PATH")?), 256 * 1024 * 1024)?);
    let root = Path::new(&args[if prepare { 4 } else { 3 }]);
    safe_parents(root)?;
    if prepare { fs::create_dir(root)?; }
    ensure!(fs::symlink_metadata(root)?.is_dir(), "real compression cache directory required");
    let lock = fs::OpenOptions::new().read(true).write(true).create(true).truncate(false)
        .custom_flags(libc::O_NOFOLLOW | libc::O_NONBLOCK).open(root.join("cache.lock"))?;
    ensure!(lock.metadata()?.is_file(), "cache lock regular file");
    lock.try_lock().context("compression cache already in use")?;
    let start = Instant::now();
    let manifest_path = root.join("manifest.json");
    if prepare {
        let bytes = read_regular(Path::new(&args[3]), CAP)?;
        let receipt: Receipt = serde_json::from_slice(&bytes)?;
        receipt.verify(image)?;
        ensure!(receipt.journal.bytes == expected, "composite input journal mismatch");
        let c = match &receipt.inner {
            InnerReceipt::Composite(c) if !c.segments.is_empty() => c,
            _ => bail!("verified nonempty composite required"),
        };
        ensure!(c.segments.len() <= MAX_UNITS && c.assumption_receipts.len() <= MAX_UNITS,
            "compression count bound4096");
        ensure!(c.assumption_receipts.iter().all(|r| matches!(r, InnerAssumptionReceipt::Succinct(_))),
            "compression cache requires succinct assumptions");
        let manifest = CompressionManifest {
            schema: 1, sdk: "3.0.5".into(), binding: binding.into(), image: hex(image.as_bytes()),
            elf_sha256: sha(elf), host_sha256: host_sha.clone(), server_sha256: server_sha.clone(),
            input_sha256: sha(&raw_input), threads,
            composite: Artifact::record(root, "composite.json".into(), &bytes)?,
            resolved_claim: hex(receipt.claim()?.digest().as_bytes()), journal: expected.to_vec(),
            segments: c.segments.len(), assumptions: c.assumption_receipts.len(),
        };
        save_json(&manifest_path, &manifest)?;
    }
    let raw_manifest = read_regular(&manifest_path, CAP)?;
    if !prepare {
        ensure!(env::var("BRIDGE_RISC0_CACHE_MANIFEST_SHA256")
            .context("external preparation manifest pin required")? == sha(&raw_manifest),
            "preparation manifest pin mismatch");
    }
    let m: CompressionManifest = serde_json::from_slice(&raw_manifest)?;
    ensure!(m.schema == 1 && m.sdk == "3.0.5" && m.binding == binding
        && m.image == hex(image.as_bytes()) && m.elf_sha256 == sha(elf)
        && m.host_sha256 == host_sha && m.server_sha256 == server_sha
        && m.input_sha256 == sha(&raw_input) && m.threads == threads && m.journal == expected
        && m.composite.name == "composite.json", "compression schema/input/image/ELF/host/SDK/settings mismatch");
    let source: Receipt = serde_json::from_slice(&m.composite.load(root)?)?;
    source.verify(image)?;
    ensure!(source.journal.bytes == expected && hex(source.claim()?.digest().as_bytes()) == m.resolved_claim,
        "source composite full journal/claim mismatch");
    match &source.inner {
        InnerReceipt::Composite(c) => ensure!(!c.segments.is_empty() && c.segments.len() == m.segments
            && c.assumption_receipts.len() == m.assumptions, "compression count mismatch"),
        _ => bail!("verified nonempty composite required"),
    }
    let mut budget = Budget { max, new: 0, reused: 0 };
    let receipt = if prepare { None } else {
        compress(&ApiClient::from_env()?, root, &source, image, &mut budget, !audit)?
    };
    println!("{}", json!({"status":if prepare {"PREPARED"} else if receipt.is_some() {"PASS"} else {"PARTIAL"},
        "imageId":format!("0x{}",m.image), "headerBinding":binding, "manifestSHA256":sha(&raw_manifest),
        "journal":format!("0x{}",hex(expected)), "segmentCount":m.segments, "assumptionCount":m.assumptions,
        "newVerifiedUnits":budget.new,"reusedVerifiedUnits":budget.reused,
        "fullReceiptVerified":receipt.is_some(),"receiptKind":receipt.as_ref().map(|_|"succinct"),
        "invocationWallSeconds":start.elapsed().as_secs_f64(),"fullGenerationWallMeasured":false,
        "evmCompatible":false,"evmAcceptanceMeasured":false,"chainAuthenticated":false,"realAssetDeploymentAllowed":false}));
    Ok(())
}
