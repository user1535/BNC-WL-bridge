//! Opt-in SDK phase measurements; intermediate STARKs are never EVM proofs.
use super::*;
use risc0_zkvm::sha::Digestible;
use std::path::Path;

const ARTIFACT_CAP: usize = 64 * 1024 * 1024;

#[derive(Serialize)]
struct Phase {
    phase: &'static str,
    duration_ms: u128,
    verification_ms: u128,
    receipt_kind: &'static str,
    cryptographically_verified: bool,
    claim_digest: String,
    journal_matches: bool,
    receipt_bytes: usize,
}

#[derive(Serialize)]
struct Profile {
    #[serde(flatten)]
    proof: VerifiedReceipt,
    phases: Vec<Phase>,
    profile_total_ms: u128,
    fresh_composite_generated: bool,
    session_stats: risc0_zkvm::SessionStats,
    composite_segments: usize,
    composite_assumptions: usize,
    diagnostic_max_headers: usize,
}

pub(super) fn verify_stage(
    receipt: &Receipt,
    kind: &str,
    journal: &[u8],
    claim: Digest,
) -> Result<(), Box<dyn Error>> {
    require_cryptographic_mode()?;
    let actual = match &receipt.inner {
        InnerReceipt::Composite(_) => "composite",
        InnerReceipt::Succinct(_) => "succinct",
        InnerReceipt::Groth16(_) => "groth16",
        _ => return Err("fake receipt forbidden in phase profile".into()),
    };
    if actual != kind {
        return Err("SDK did not produce the requested phase receipt kind".into());
    }
    receipt.verify(GUEST_ID)?;
    if receipt.journal.bytes.len() != 224
        || receipt.journal.bytes != journal
        || receipt.claim()?.digest() != claim
    {
        return Err("profile phase image/claim/journal mismatch".into());
    }
    Ok(())
}

fn save_receipt(path: &Path, receipt: &Receipt) -> Result<usize, Box<dyn Error>> {
    let encoded = serde_json::to_vec(receipt)?;
    if encoded.len() > ARTIFACT_CAP {
        return Err("phase receipt exceeds 64MiB artifact cap".into());
    }
    let mut output = fs::OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(path)?;
    use std::io::Write;
    output.write_all(&encoded)?;
    Ok(encoded.len())
}

#[derive(Serialize)]
struct ResumedProfile {
    #[serde(flatten)]
    proof: VerifiedReceipt,
    phases: Vec<Phase>,
    profile_total_ms: u128,
    fresh_composite_generated: bool,
    resumed_from_kind: &'static str,
    reused_receipt_cryptographically_verified: bool,
    input_journal_reexecuted_and_matched: bool,
    full_generation_wall_measured: bool,
    diagnostic_max_headers: usize,
}

fn resume(args: &[String]) -> Result<(), Box<dyn Error>> {
    if !matches!(args.len(), 8 | 10)
        || args[2] != "--input"
        || args[4] != "--receipt-input"
        || args[6] != "--receipt-output"
    {
        return Err("usage: --resume-profile-receipt --input <json> --receipt-input <saved-composite-or-succinct> --receipt-output <new-json> [--diagnostic-max-headers 4|8|16|32|64|128]".into());
    }
    require_cryptographic_mode()?;
    let cap = if args.len() == 10 {
        if args[8] != "--diagnostic-max-headers" {
            return Err("expected diagnostic batch cap".into());
        }
        args[9].parse::<usize>()?
    } else {
        4
    };
    if !matches!(cap, 4 | 8 | 16 | 32 | 64 | 128)
        || (cap != 4 && bridge_header_methods::HEADER_BINDING != "minimal-link")
    {
        return Err("unsupported resume cap; minimal default4/strict1 remain unchanged".into());
    }
    if fs::metadata(&args[3])?.len() > 64 * 1024
        || fs::metadata(&args[5])?.len() > ARTIFACT_CAP as u64
    {
        return Err("resume input/receipt exceeds bounded artifact cap".into());
    }
    let input_bytes = fs::read(&args[3])?;
    let receipt_bytes = fs::read(&args[5])?;
    if input_bytes.len() > 64 * 1024 || receipt_bytes.len() > ARTIFACT_CAP {
        return Err("resume input/receipt exceeds bounded artifact cap".into());
    }
    let input: HeaderBatch = serde_json::from_slice(&input_bytes)?;
    let input_cap = if bridge_header_methods::HEADER_BINDING == "canonical-rlp" {
        1
    } else {
        cap
    };
    if !matches!(input.chain_id, 31337 | 31338)
        || input.headers.is_empty()
        || input.headers.len() > input_cap
    {
        return Err("resume requires local input within explicit export/diagnostic cap".into());
    }
    let mut receipt: Receipt = serde_json::from_slice(&receipt_bytes)?;
    let reused = match &receipt.inner {
        InnerReceipt::Composite(_) => "composite",
        InnerReceipt::Succinct(_) => "succinct",
        _ => return Err("resume requires an actual saved composite or succinct receipt".into()),
    };
    let expected_claim = receipt.claim()?.digest();
    // Verify before executing caller input or invoking any prover/compressor.
    verify_stage(&receipt, reused, &receipt.journal.bytes, expected_claim)?;
    let total_start = Instant::now();
    let execution = default_executor().execute(execution_env(&input)?, GUEST_ELF)?;
    let expected_journal = execution.journal.bytes;
    verify_stage(&receipt, reused, &expected_journal, expected_claim)?;
    let output = Path::new(&args[7]);
    if output.exists() {
        return Err("refuse to replace a receipt artifact".into());
    }
    let directory = output
        .parent()
        .unwrap_or_else(|| Path::new("."))
        .join("phases");
    fs::create_dir(&directory)?;
    let mut phases = Vec::new();
    let prover = default_prover();
    for kind in if reused == "composite" {
        vec!["composite", "succinct", "groth16"]
    } else {
        vec!["succinct", "groth16"]
    } {
        let started = Instant::now();
        let name = if kind == reused {
            "reused_verified_receipt"
        } else if kind == "succinct" {
            "composite_to_succinct"
        } else {
            "succinct_to_groth16"
        };
        let duration_ms = if kind == reused {
            0
        } else {
            let opts = if kind == "succinct" {
                ProverOpts::succinct()
            } else {
                ProverOpts::groth16()
            };
            receipt = prover.compress(&opts, &receipt)?;
            started.elapsed().as_millis()
        };
        let started = Instant::now();
        verify_stage(&receipt, kind, &expected_journal, expected_claim)?;
        let verification_ms = started.elapsed().as_millis();
        let receipt_bytes = save_receipt(&directory.join(format!("{kind}.json")), &receipt)?;
        phases.push(Phase {
            phase: name,
            duration_ms,
            verification_ms,
            receipt_kind: kind,
            cryptographically_verified: true,
            claim_digest: hex(expected_claim.as_bytes()),
            journal_matches: true,
            receipt_bytes,
        });
        fs::write(
            directory.join("timings.json"),
            serde_json::to_vec_pretty(&phases)?,
        )?;
    }
    let summary = ResumedProfile {
        proof: verified_receipt(&receipt)?,
        phases,
        profile_total_ms: total_start.elapsed().as_millis(),
        fresh_composite_generated: false,
        resumed_from_kind: reused,
        reused_receipt_cryptographically_verified: true,
        input_journal_reexecuted_and_matched: true,
        full_generation_wall_measured: false,
        diagnostic_max_headers: cap,
    };
    save_receipt(output, &receipt)?;
    println!("{}", serde_json::to_string(&summary)?);
    Ok(())
}

pub(super) fn command(args: &[String]) -> Result<bool, Box<dyn Error>> {
    if args.get(1).map(String::as_str) == Some("--resume-profile-receipt") {
        resume(args)?;
        return Ok(true);
    }
    if args.get(1).map(String::as_str) != Some("--profile-receipt") {
        return Ok(false);
    }
    if !matches!(args.len(), 6 | 8) || args[2] != "--input" || args[4] != "--receipt-output" {
        return Err("usage: --profile-receipt --input <json> --receipt-output <new-json> [--diagnostic-max-headers 4|8|16|32|64|128]".into());
    }
    let diagnostic_max_headers: usize = if args.len() == 8 {
        if args[6] != "--diagnostic-max-headers" {
            return Err("expected diagnostic batch cap".into());
        }
        args[7].parse()?
    } else {
        4
    };
    if !matches!(diagnostic_max_headers, 4 | 8 | 16 | 32 | 64 | 128) {
        return Err(
            "diagnostic batch cap must be4/8/16/32/64/128; larger sizes require explicit bounded experiment".into(),
        );
    }
    if diagnostic_max_headers != 4 && bridge_header_methods::HEADER_BINDING != "minimal-link" {
        return Err(
            "larger diagnostic batch requires minimal-link; strict export cap remains1".into(),
        );
    }
    require_cryptographic_mode()?;
    if fs::metadata(&args[3])?.len() > 64 * 1024 {
        return Err("profile input exceeds 64KiB".into());
    }
    let input_bytes = fs::read(&args[3])?;
    if input_bytes.len() > 64 * 1024 {
        return Err("profile input exceeds 64KiB".into());
    }
    let input: HeaderBatch = serde_json::from_slice(&input_bytes)?;
    let cap = if bridge_header_methods::HEADER_BINDING == "canonical-rlp" {
        1
    } else {
        diagnostic_max_headers
    };
    if !matches!(input.chain_id, 31337 | 31338)
        || input.headers.is_empty()
        || input.headers.len() > cap
    {
        return Err(
            "profile requires local source31337/31338 within measured minimal4/strict1 export cap"
                .into(),
        );
    }
    let output = Path::new(&args[5]);
    if output.exists() {
        return Err("refuse to replace a receipt artifact".into());
    }
    let directory = output
        .parent()
        .unwrap_or_else(|| Path::new("."))
        .join("phases");
    fs::create_dir(&directory)?;
    let total_start = Instant::now();
    let prover = default_prover();
    let started = Instant::now();
    let proof =
        prover.prove_with_opts(execution_env(&input)?, GUEST_ELF, &ProverOpts::composite())?;
    let mut duration_ms = started.elapsed().as_millis();
    let mut receipt = proof.receipt;
    let (composite_segments, composite_assumptions) = match &receipt.inner {
        InnerReceipt::Composite(inner) => (inner.segments.len(), inner.assumption_receipts.len()),
        _ => return Err("actual composite required before SDK compression".into()),
    };
    let expected_journal = receipt.journal.bytes.clone();
    let expected_claim = receipt.claim()?.digest();
    let mut phases = Vec::new();
    for (name, kind) in [
        ("execute_and_composite", "composite"),
        ("composite_to_succinct", "succinct"),
        ("succinct_to_groth16", "groth16"),
    ] {
        if kind != "composite" {
            let started = Instant::now();
            let opts = if kind == "succinct" {
                ProverOpts::succinct()
            } else {
                ProverOpts::groth16()
            };
            receipt = prover.compress(&opts, &receipt)?;
            duration_ms = started.elapsed().as_millis();
        }
        let started = Instant::now();
        verify_stage(&receipt, kind, &expected_journal, expected_claim)?;
        let verification_ms = started.elapsed().as_millis();
        let receipt_bytes = save_receipt(&directory.join(format!("{kind}.json")), &receipt)?;
        phases.push(Phase {
            phase: name,
            duration_ms,
            verification_ms,
            receipt_kind: kind,
            cryptographically_verified: true,
            claim_digest: hex(expected_claim.as_bytes()),
            journal_matches: true,
            receipt_bytes,
        });
        // Preserve successfully verified phases when later compression fails or is cancelled.
        fs::write(
            directory.join("timings.json"),
            serde_json::to_vec_pretty(&phases)?,
        )?;
    }
    let summary = Profile {
        proof: verified_receipt(&receipt)?,
        phases,
        profile_total_ms: total_start.elapsed().as_millis(),
        fresh_composite_generated: true,
        session_stats: proof.stats,
        composite_segments,
        composite_assumptions,
        diagnostic_max_headers,
    };
    save_receipt(output, &receipt)?;
    println!("{}", serde_json::to_string(&summary)?);
    Ok(true)
}

#[cfg(test)]
mod tests {
    use super::*;
    use risc0_zkvm::{FakeReceipt, MaybePruned};

    #[test]
    fn fake_compression_cannot_be_recorded_as_a_real_phase() {
        let receipt = Receipt::new(
            InnerReceipt::Fake(FakeReceipt::new(MaybePruned::Pruned(Digest::ZERO))),
            vec![0; 224],
        );
        assert!(verify_stage(&receipt, "groth16", &receipt.journal.bytes, Digest::ZERO).is_err());
    }
}
