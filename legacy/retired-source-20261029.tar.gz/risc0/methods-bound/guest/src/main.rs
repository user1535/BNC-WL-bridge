#![no_main]
#![no_std]

extern crate alloc;
use alloc::vec::Vec;
use risc0_zkvm::guest::env;
use serde::{Deserialize, Serialize};
use tiny_keccak::{Hasher, Keccak};

risc0_zkvm::guest::entry!(main);

#[derive(Serialize, Deserialize)]
struct MinimalHeader {
    number: u64,
    block_hash: [u8; 32],
    parent_hash: [u8; 32],
    receipt_root: [u8; 32],
    canonical_rlp: Vec<u8>,
}

#[derive(Serialize, Deserialize)]
struct HeaderBatch {
    chain_id: u64,
    anchor_hash: [u8; 32],
    headers: Vec<MinimalHeader>,
}

fn hash(data: &[u8]) -> [u8; 32] {
    let mut out = [0u8; 32];
    let mut hasher = Keccak::v256();
    hasher.update(data);
    hasher.finalize(&mut out);
    out
}

fn word_u64(value: u64) -> [u8; 32] {
    let mut out = [0u8; 32];
    out[24..].copy_from_slice(&value.to_be_bytes());
    out
}

fn leaf(chain_id: u64, header: &MinimalHeader) -> [u8; 32] {
    let mut data = [0u8; 160];
    data[..32].copy_from_slice(&word_u64(chain_id));
    data[32..64].copy_from_slice(&word_u64(header.number));
    data[64..96].copy_from_slice(&header.block_hash);
    data[96..128].copy_from_slice(&header.parent_hash);
    data[128..160].copy_from_slice(&header.receipt_root);
    hash(&data)
}

fn batch_root(chain_id: u64, headers: &[MinimalHeader]) -> [u8; 32] {
    let mut level: Vec<[u8; 32]> = headers.iter().map(|h| leaf(chain_id, h)).collect();
    while level.len() > 1 {
        let mut next = Vec::new();
        for pair in level.chunks(2) {
            let right = if pair.len() == 2 { pair[1] } else { pair[0] };
            let mut data = [0u8; 64];
            data[..32].copy_from_slice(&pair[0]);
            data[32..].copy_from_slice(&right);
            next.push(hash(&data));
        }
        level = next;
    }
    level[0]
}

fn main() {
    let input: HeaderBatch = env::read();
    assert!(matches!(input.chain_id, 31337 | 31338));
    assert!(!input.headers.is_empty());
    assert!(input.headers.len() <= 4);
    let first = &input.headers[0];
    assert_eq!(first.parent_hash, input.anchor_hash);
    for (i, header) in input.headers.iter().enumerate() {
        bridge_header_binding::validate_header(
            &header.canonical_rlp,
            header.number,
            &header.block_hash,
            &header.parent_hash,
            &header.receipt_root,
        )
        .expect("canonical header binding failed");
        assert!(header.block_hash != [0u8; 32]);
        assert!(header.receipt_root != [0u8; 32]);
        if i > 0 {
            let prior = &input.headers[i - 1];
            assert_eq!(
                header.number,
                prior.number.checked_add(1).expect("block number overflow")
            );
            assert_eq!(header.parent_hash, prior.block_hash);
        }
    }
    let last = &input.headers[input.headers.len() - 1];
    let root = batch_root(input.chain_id, &input.headers);
    let mut journal = [0u8; 224];
    journal[..32].copy_from_slice(&word_u64(input.chain_id));
    journal[32..64].copy_from_slice(&word_u64(first.number));
    journal[64..96].copy_from_slice(&word_u64(last.number));
    journal[96..128].copy_from_slice(&input.anchor_hash);
    journal[128..160].copy_from_slice(&last.block_hash);
    journal[160..192].copy_from_slice(&root);
    journal[192..224].copy_from_slice(&word_u64(input.headers.len() as u64));
    env::commit_slice(&journal);
}
