#![no_std]
extern crate alloc;
use alloc::vec::Vec;
use tiny_keccak::{Hasher, Keccak};

type Checked<T> = Result<T, &'static str>;

/// Serialization profiles only: no fork activation, work, signatures or finality.
#[derive(Clone, Copy)]
pub enum Profile {
    WorldLandV113 { optional_mask: u8 },
    BnbV178,
}

fn item(data: &[u8]) -> Checked<(bool, &[u8], usize)> {
    let prefix = *data.first().ok_or("empty RLP")?;
    if prefix < 0x80 {
        return Ok((false, &data[..1], 1));
    }
    let list = prefix >= 0xc0;
    let base = if list { 0xc0 } else { 0x80 };
    let code = usize::from(prefix - base);
    let (offset, len) = if code <= 55 {
        (1, code)
    } else {
        let n = code - 55;
        let encoded = data.get(1..1 + n).ok_or("truncated length")?;
        if encoded[0] == 0 {
            return Err("leading zero length");
        }
        let mut len = 0usize;
        for b in encoded {
            len = len
                .checked_mul(256)
                .and_then(|v| v.checked_add(*b as usize))
                .ok_or("length overflow")?;
        }
        if len < 56 {
            return Err("noncanonical long RLP");
        }
        (1 + n, len)
    };
    let end = offset.checked_add(len).ok_or("length overflow")?;
    let value = data.get(offset..end).ok_or("truncated RLP")?;
    if !list && len == 1 && value[0] < 0x80 {
        return Err("noncanonical short RLP");
    }
    Ok((list, value, end))
}

fn integer(value: &[u8], maximum: usize) -> Checked<u64> {
    if value.len() > maximum || value.first() == Some(&0) {
        return Err("integer width/canonicality");
    }
    if maximum > 8 {
        return Ok(0);
    }
    Ok(value.iter().fold(0, |a, b| a * 256 + *b as u64))
}

/// Binds actual native raw RLP to public fields. WL independently omitted
/// optional fields require an explicit shape witness; its mask is not finality.
pub fn validate_header(
    profile: Profile,
    chain_id: u64,
    raw: &[u8],
    number: u64,
    block_hash: &[u8; 32],
    parent: &[u8; 32],
    receipt_root: &[u8; 32],
) -> Checked<()> {
    let expected_chain = match profile {
        Profile::WorldLandV113 { .. } => 103,
        Profile::BnbV178 => 56,
    };
    if chain_id != expected_chain {
        return Err("profile chain mismatch");
    }
    if raw.is_empty() || raw.len() > 8192 {
        return Err("diagnostic header size limit");
    }
    let (list, mut rest, consumed) = item(raw)?;
    if !list || consumed != raw.len() {
        return Err("one exact RLP list required");
    }
    let mut fields = Vec::new();
    while !rest.is_empty() {
        if fields.len() >= 21 {
            return Err("unknown field count");
        }
        let (list, value, used) = item(rest)?;
        if list {
            return Err("scalar header fields required");
        }
        fields.push(value);
        rest = &rest[used..];
    }
    if fields.len() < 15 {
        return Err("missing base fields");
    }
    for (i, n) in [
        (0, 32),
        (1, 32),
        (2, 20),
        (3, 32),
        (4, 32),
        (5, 32),
        (6, 256),
        (13, 32),
        (14, 8),
    ] {
        if fields[i].len() != n {
            return Err("base field width");
        }
    }
    integer(fields[7], 32)?;
    let encoded_number = integer(fields[8], 8)?;
    let limit = integer(fields[9], 8)?;
    let used = integer(fields[10], 8)?;
    integer(fields[11], 8)?;
    if used > limit || fields[12].len() > 4096 {
        return Err("gas/resource bounds");
    }
    match profile {
        Profile::WorldLandV113 { optional_mask } => {
            if optional_mask > 7 || fields.len() != 15 + optional_mask.count_ones() as usize {
                return Err("WorldLand optional shape");
            }
            let mut i = 15;
            if optional_mask & 1 != 0 {
                integer(fields[i], 32)?;
                i += 1;
            }
            if optional_mask & 2 != 0 {
                if fields[i].len() > 4096 {
                    return Err("codeword resource bound");
                }
                i += 1;
            }
            if optional_mask & 4 != 0 && integer(fields[i], 8)? == 0 {
                return Err("zero codelength must be omitted");
            }
        }
        Profile::BnbV178 => {
            if fields.len() > 21 {
                return Err("BNB optional shape");
            }
            if fields.len() > 15 {
                integer(fields[15], 32)?;
            }
            for i in [16, 19, 20] {
                if i < fields.len() && !matches!(fields[i].len(), 0 | 32) {
                    return Err("BNB optional root width");
                }
            }
            for i in [17, 18] {
                if i < fields.len() {
                    integer(fields[i], 8)?;
                }
            }
        }
    }
    let mut computed = [0u8; 32];
    let mut k = Keccak::v256();
    k.update(raw);
    k.finalize(&mut computed);
    if &computed != block_hash
        || fields[0] != parent
        || fields[5] != receipt_root
        || encoded_number != number
    {
        return Err("hash/parent/number/receipt binding mismatch");
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use alloc::vec;
    fn hex(s: &str) -> Vec<u8> {
        let s = s.strip_prefix("0x").unwrap();
        (0..s.len())
            .step_by(2)
            .map(|i| u8::from_str_radix(&s[i..i + 2], 16).unwrap())
            .collect()
    }
    #[test]
    fn actual_four_native_headers_and_mutations() {
        for (wl, text) in [
            (true, include_str!("../fixtures/worldland-parent.json")),
            (true, include_str!("../fixtures/worldland-latest.json")),
            (false, include_str!("../fixtures/bnb-parent.json")),
            (false, include_str!("../fixtures/bnb-latest.json")),
        ] {
            let v: serde_json::Value = serde_json::from_str(text).unwrap();
            let profile = if wl {
                Profile::WorldLandV113 {
                    optional_mask: v["worldlandOptionalMask"].as_u64().unwrap() as u8,
                }
            } else {
                Profile::BnbV178
            };
            let raw = hex(v["headerRlp"].as_str().unwrap());
            let number = v["blockNumber"].as_u64().unwrap();
            let chain = v["chainId"].as_u64().unwrap();
            let block = hex(v["recomputedHash"].as_str().unwrap())
                .try_into()
                .unwrap();
            let parent = hex(v["parentHash"].as_str().unwrap()).try_into().unwrap();
            let root = hex(v["receiptRoot"].as_str().unwrap()).try_into().unwrap();
            assert!(validate_header(profile, chain, &raw, number, &block, &parent, &root).is_ok());
            for (c, n, b, p, r) in [
                (chain + 1, number, block, parent, root),
                (chain, number + 1, block, parent, root),
                (chain, number, [1; 32], parent, root),
                (chain, number, block, [1; 32], root),
                (chain, number, block, parent, [1; 32]),
            ] {
                assert!(validate_header(profile, c, &raw, n, &b, &p, &r).is_err());
            }
            for end in 0..raw.len() {
                assert!(validate_header(
                    profile,
                    chain,
                    &raw[..end],
                    number,
                    &block,
                    &parent,
                    &root
                )
                .is_err());
            }
            for i in 0..raw.len() {
                let mut bad = raw.clone();
                bad[i] ^= 1;
                assert!(
                    validate_header(profile, chain, &bad, number, &block, &parent, &root).is_err()
                );
            }
            let mut bad = raw.clone();
            bad.push(0x80);
            assert!(validate_header(profile, chain, &bad, number, &block, &parent, &root).is_err());
            if wl {
                assert!(validate_header(
                    Profile::WorldLandV113 { optional_mask: 0 },
                    chain,
                    &raw,
                    number,
                    &block,
                    &parent,
                    &root
                )
                .is_err());
            }
        }
    }
    #[test]
    fn canonical_rlp_integer_and_resource_guards() {
        assert!(item(&[0x81, 1]).is_err());
        assert!(item(&[0xf8, 1, 0x80]).is_err());
        assert!(item(&[0xf9, 0, 56]).is_err());
        assert!(integer(&[0], 8).is_err());
        assert!(integer(&[1; 9], 8).is_err());
        assert!(validate_header(
            Profile::BnbV178,
            56,
            &[0xff; 8193],
            0,
            &[0; 32],
            &[0; 32],
            &[0; 32]
        )
        .is_err());
    }

    #[test]
    fn pinned_generated_encoder_76_synthetic_oracles() {
        let file: serde_json::Value = serde_json::from_str(include_str!(
            "../../../proof-generator/internal/chain/testdata/native-header-fixtures.json"
        ))
        .unwrap();
        let rows = file["fixtures"].as_array().unwrap();
        assert_eq!(rows.len(), 76);
        for row in rows {
            let rpc = &row["rpc"];
            let wl = row["profile"] == "worldland-v1.1.3";
            let mut mask = 0;
            if !rpc["baseFeePerGas"].is_null() {
                mask |= 1;
            }
            if !rpc["codeword"].is_null() {
                mask |= 2;
            }
            if rpc["codelength"]
                .as_str()
                .is_some_and(|s| u64::from_str_radix(&s[2..], 16).unwrap() != 0)
            {
                mask |= 4;
            }
            let profile = if wl {
                Profile::WorldLandV113 {
                    optional_mask: mask,
                }
            } else {
                Profile::BnbV178
            };
            let number = u64::from_str_radix(&rpc["number"].as_str().unwrap()[2..], 16).unwrap();
            let block = hex(row["hash"].as_str().unwrap()).try_into().unwrap();
            let parent = hex(rpc["parentHash"].as_str().unwrap()).try_into().unwrap();
            let root = hex(rpc["receiptsRoot"].as_str().unwrap())
                .try_into()
                .unwrap();
            assert!(
                validate_header(
                    profile,
                    if wl { 103 } else { 56 },
                    &hex(row["rlp"].as_str().unwrap()),
                    number,
                    &block,
                    &parent,
                    &root
                )
                .is_ok(),
                "{}",
                row["name"]
            );
        }
    }

    fn encoded(payload: &[u8], list: bool) -> Vec<u8> {
        if !list && payload.len() == 1 && payload[0] < 0x80 {
            return payload.to_vec();
        }
        let base = if list { 0xc0 } else { 0x80 };
        let mut out = Vec::new();
        if payload.len() < 56 {
            out.push(base + payload.len() as u8);
        } else {
            let bytes = (payload.len() as u64).to_be_bytes();
            let first = bytes.iter().position(|b| *b != 0).unwrap();
            out.push(base + 55 + (8 - first) as u8);
            out.extend_from_slice(&bytes[first..]);
        }
        out.extend_from_slice(payload);
        out
    }

    #[test]
    fn malformed_native_fields_reject_even_when_hash_matches() {
        let v: serde_json::Value =
            serde_json::from_str(include_str!("../fixtures/bnb-parent.json")).unwrap();
        let bytes = hex(v["headerRlp"].as_str().unwrap());
        let (_, mut rest, _) = item(&bytes).unwrap();
        let mut fields = Vec::new();
        while !rest.is_empty() {
            let (_, field, used) = item(rest).unwrap();
            fields.push(field.to_vec());
            rest = &rest[used..];
        }
        let parent = hex(v["parentHash"].as_str().unwrap()).try_into().unwrap();
        let root = hex(v["receiptRoot"].as_str().unwrap()).try_into().unwrap();
        for variant in 0..7 {
            let mut changed = fields.clone();
            match variant {
                0 => changed[8].insert(0, 0),
                1 => {
                    changed[1].pop();
                }
                2 => changed[10] = vec![0xff; 8],
                3 => changed[12] = vec![1; 4097],
                4 => changed.truncate(14),
                5 => changed[15] = vec![1; 33],
                6 => changed[16] = vec![1; 31],
                _ => unreachable!(),
            }
            let payload: Vec<u8> = changed.iter().flat_map(|f| encoded(f, false)).collect();
            let raw = encoded(&payload, true);
            let mut hash = [0; 32];
            let mut k = Keccak::v256();
            k.update(&raw);
            k.finalize(&mut hash);
            assert!(
                validate_header(
                    Profile::BnbV178,
                    56,
                    &raw,
                    v["blockNumber"].as_u64().unwrap(),
                    &hash,
                    &parent,
                    &root
                )
                .is_err(),
                "variant {variant}"
            );
        }
    }
}
