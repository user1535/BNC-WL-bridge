include!(concat!(env!("OUT_DIR"), "/methods.rs"));
pub const BRIDGE_HEADER_GUEST_ELF: &[u8] = BRIDGE_HEADER_ACCELERATED_GUEST_ELF;
pub const BRIDGE_HEADER_GUEST_ID: [u32; 8] = BRIDGE_HEADER_ACCELERATED_GUEST_ID;
pub const HEADER_BINDING: &str = "minimal-link";
