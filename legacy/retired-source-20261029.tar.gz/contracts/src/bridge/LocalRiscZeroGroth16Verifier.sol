// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {ControlID} from "../risc0/groth16/ControlID.sol";
import {RiscZeroGroth16Verifier} from "../risc0/groth16/RiscZeroGroth16Verifier.sol";

/// @notice Cryptographic RISC Zero verifier pinned to the v3 circuit parameters, for local tests.
contract LocalRiscZeroGroth16Verifier is RiscZeroGroth16Verifier {
    constructor() RiscZeroGroth16Verifier(ControlID.CONTROL_ROOT, ControlID.BN254_CONTROL_ID) {
        require(block.chainid == 31337 || block.chainid == 31338, "local chains only");
    }
}
