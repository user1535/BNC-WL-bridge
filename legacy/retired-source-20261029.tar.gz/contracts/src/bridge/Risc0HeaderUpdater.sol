// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IHeaderSource} from "../interfaces/IHeaderSource.sol";

// Signature from the official RISC Zero Ethereum verifier interface.
// https://github.com/risc0/risc0-ethereum/blob/main/contracts/src/IRiscZeroVerifier.sol
interface IRiscZeroVerifier {
    function verify(bytes calldata seal, bytes32 imageId, bytes32 journalDigest) external view;
}

/// @notice Local-only updater for proving the minimal header relation.
/// @dev The initial anchor is supplied by the deployer; the guest does not authenticate consensus or finality.
contract Risc0HeaderUpdater is IHeaderSource {
    struct MinimalHeader {
        uint64 number;
        bytes32 blockHash;
        bytes32 parentHash;
        bytes32 receiptRoot;
    }

    struct HeaderRecord {
        bytes32 blockHash;
        bytes32 receiptRoot;
    }

    struct BatchCommitment {
        uint256 start;
        uint256 end;
        uint256 count;
        bytes32 anchor;
        bytes32 endHash;
        bytes32 root;
    }

    uint256 public immutable sourceChainId;
    IRiscZeroVerifier public immutable verifier;
    bytes32 public immutable guestImageId;
    uint256 public latestBlock;
    bytes32 public latestHash;
    mapping(uint256 => HeaderRecord) public headers;

    event HeaderBatchAccepted(uint256 indexed sourceChainId, uint256 startBlock, uint256 endBlock, bytes32 batchRoot);
    error InvalidConfiguration();
    error InvalidBatch();
    error InvalidJournal();
    error UnknownHeader();

    constructor(
        uint256 sourceChainId_,
        IRiscZeroVerifier verifier_,
        bytes32 guestImageId_,
        uint256 initialBlock_,
        bytes32 initialHash_
    ) {
        if (
            !((block.chainid == 31338 && sourceChainId_ == 31337)
                    || (block.chainid == 31337 && sourceChainId_ == 31338)) || address(verifier_).code.length == 0
                || guestImageId_ == bytes32(0) || initialHash_ == bytes32(0) || initialBlock_ >= type(uint64).max
        ) revert InvalidConfiguration();
        sourceChainId = sourceChainId_;
        verifier = verifier_;
        guestImageId = guestImageId_;
        latestBlock = initialBlock_;
        latestHash = initialHash_;
    }

    function submitHeaderProof(bytes calldata seal, bytes calldata journal, bytes calldata batchData) external {
        MinimalHeader[] memory batch = abi.decode(batchData, (MinimalHeader[]));
        if (batch.length == 0 || batch.length > 128 || journal.length != 224) revert InvalidBatch();
        BatchCommitment memory commitment;
        commitment.start = latestBlock + 1;
        commitment.end = commitment.start + batch.length - 1;
        commitment.count = batch.length;
        commitment.anchor = latestHash;
        (commitment.root, commitment.endHash) = _computeBatchRoot(batch, commitment.start, commitment.anchor);
        _validateJournal(journal, commitment);

        // Real RISC Zero verification is required here; local tests use a clearly named mock verifier.
        verifier.verify(seal, guestImageId, sha256(journal));
        for (uint256 i = 0; i < batch.length; i++) {
            headers[commitment.start + i] = HeaderRecord(batch[i].blockHash, batch[i].receiptRoot);
        }
        latestBlock = commitment.end;
        latestHash = commitment.endHash;
        emit HeaderBatchAccepted(sourceChainId, commitment.start, commitment.end, commitment.root);
    }

    function _computeBatchRoot(MinimalHeader[] memory batch, uint256 start, bytes32 anchor)
        private
        view
        returns (bytes32 root, bytes32 endHash)
    {
        bytes32[] memory level = new bytes32[](batch.length);
        bytes32 prior = anchor;
        for (uint256 i = 0; i < batch.length; i++) {
            MinimalHeader memory header = batch[i];
            if (
                uint256(header.number) != start + i || header.parentHash != prior || header.blockHash == bytes32(0)
                    || header.receiptRoot == bytes32(0)
            ) revert InvalidBatch();
            level[i] = keccak256(
                abi.encode(
                    sourceChainId, uint256(header.number), header.blockHash, header.parentHash, header.receiptRoot
                )
            );
            prior = header.blockHash;
        }
        uint256 count = level.length;
        while (count > 1) {
            uint256 nextCount = (count + 1) / 2;
            for (uint256 i = 0; i < nextCount; i++) {
                bytes32 left = level[2 * i];
                bytes32 right = 2 * i + 1 < count ? level[2 * i + 1] : left;
                level[i] = keccak256(abi.encodePacked(left, right));
            }
            count = nextCount;
        }
        return (level[0], prior);
    }

    function _validateJournal(bytes calldata journal, BatchCommitment memory expected) private view {
        if (
            abi.decode(journal[0:32], (uint256)) != sourceChainId
                || abi.decode(journal[32:64], (uint256)) != expected.start
                || abi.decode(journal[64:96], (uint256)) != expected.end
                || abi.decode(journal[96:128], (bytes32)) != expected.anchor
                || abi.decode(journal[128:160], (bytes32)) != expected.endHash
                || abi.decode(journal[160:192], (bytes32)) != expected.root
                || abi.decode(journal[192:224], (uint256)) != expected.count
        ) revert InvalidJournal();
    }

    function isBlockCovered(uint256 sourceChainId_, uint256 blockNumber, bytes32 blockHash)
        external
        view
        returns (bool)
    {
        return sourceChainId_ == sourceChainId && blockHash != bytes32(0) && headers[blockNumber].blockHash == blockHash;
    }

    function getReceiptRoot(uint256 sourceChainId_, uint256 blockNumber, bytes32 blockHash)
        external
        view
        returns (bytes32 receiptRoot)
    {
        HeaderRecord memory header = headers[blockNumber];
        if (sourceChainId_ != sourceChainId || blockHash == bytes32(0) || header.blockHash != blockHash) {
            revert UnknownHeader();
        }
        return header.receiptRoot;
    }
}
