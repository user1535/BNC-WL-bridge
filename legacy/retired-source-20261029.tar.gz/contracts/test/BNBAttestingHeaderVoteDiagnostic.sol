// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {BNBRawHeaderVoteDiagnostic} from "./BNBRawHeaderVoteDiagnostic.sol";
import {RLPReader} from "../src/bridge/lib/RLPReader.sol";
import {BNBVoteWireDiagnostic} from "./BNBVoteWireDiagnostic.sol";

/// @dev Local stateless diagnostic under an explicit post-Luban non-epoch
/// layout assumption. Not a fork selector, authenticated snapshot or finality
/// verifier. Only the adjacent source/target/attesting fixtures are supported.
contract BNBAttestingHeaderVoteDiagnostic is BNBRawHeaderVoteDiagnostic {
    bytes private constant HALF_P =
        hex"0d0088f51cbff34d258dd3db21a5d66bb23ba5c279c2895fb39869507b587b120f55ffff58a9ffffdcff7fffffffd555";

    function _slice(bytes memory data, uint256 offset, uint256 length) internal pure returns (bytes memory out) {
        if (offset + length > data.length) revert InvalidWitness();
        out = new bytes(length);
        for (uint256 i; i < length; ++i) out[i] = data[offset + i];
    }

    function nonEpochAttestingCommitments(bytes calldata sourceRaw, bytes calldata targetRaw, bytes calldata attestingRaw)
        public pure returns (bytes32 message, uint64 bitmap, bytes memory compressedSignature, bytes32 attestingHash)
    {
        HeaderCommitment memory target;
        (message,,target) = headerVoteCommitments(sourceRaw, targetRaw);
        HeaderCommitment memory attesting = _header(attestingRaw);
        if (target.number == type(uint64).max || attesting.number != target.number + 1
            || attesting.parentHash != target.blockHash) revert InvalidWitness();
        attestingHash = attesting.blockHash;
        RLPReader.Item[] memory headerFields = RLPReader.listItems(attestingRaw);
        bytes memory extra = RLPReader.itemBytes(attestingRaw, headerFields[12]);
        // Explicit non-epoch layout: 32-byte vanity, vote RLP, 65-byte ECDSA seal.
        if (extra.length <= 97 || extra.length > 4096 || extra.length - 97 > 512) revert InvalidWitness();
        BNBVoteWireDiagnostic.Vote memory vote = BNBVoteWireDiagnostic.decode(_slice(extra, 32, extra.length - 97));
        if (vote.dataHash != message) revert InvalidWitness();
        bitmap = vote.bitmap; compressedSignature = vote.signature;
    }

    function _sortBit(bytes calldata sig, uint256 offset) internal pure returns (bool) {
        for (uint256 i; i < 48; ++i) {
            uint8 value = uint8(sig[offset + 16 + i]);
            if (value != uint8(HALF_P[i])) return value > uint8(HALF_P[i]);
        }
        return false;
    }

    // blst v0.3.13 e2.c Compress_BE: x.c1,x.c0 plus compression/sort
    // flags. Sort uses y.c1 unless zero, then y.c0 (sgn0_pty_mod_384x).
    // Curve membership, field canonicality and subgroup are checked by the
    // inherited EIP-2537 pairing; this helper only binds its bytes to raw vote.
    function _compressed(bytes calldata sig) private pure returns (bytes memory out) {
        if (sig.length != 256) revert InvalidWitness();
        bool imagYNonzero;
        for (uint256 component; component < 4; ++component) {
            for (uint256 i; i < 16; ++i) if (sig[component*64+i] != 0) revert InvalidWitness();
        }
        out = new bytes(96);
        for (uint256 i; i < 48; ++i) {
            out[i] = sig[80+i]; out[48+i] = sig[16+i];
            if (sig[208+i] != 0) imagYNonzero = true;
        }
        out[0] |= bytes1(uint8(0x80 | (_sortBit(sig, imagYNonzero ? 192 : 128) ? 0x20 : 0)));
    }

    /// @dev Encoding comparison only; does not check curve membership or BLS.
    function compressPairingSignature(bytes calldata signature) external pure returns (bytes memory) {
        return _compressed(signature);
    }

    function verifyNonEpochAttestingVote(bytes calldata sourceRaw, bytes calldata targetRaw, bytes calldata attestingRaw,
        bytes calldata suppliedKeys, bytes calldata uncompressedSignature) external view returns (bool)
    {
        (bytes32 message, uint64 bitmap, bytes memory signature,) =
            nonEpochAttestingCommitments(sourceRaw, targetRaw, attestingRaw);
        if (keccak256(_compressed(uncompressedSignature)) != keccak256(signature)) revert InvalidWitness();
        return this.verifySuppliedVote(message, suppliedKeys, bitmap, uncompressedSignature);
    }
}
