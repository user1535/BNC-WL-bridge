// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {BNBVoteBLSDiagnostic} from "./BNBVoteBLSDiagnostic.sol";

interface VmBlsGuard {
    function chainId(uint256) external;
    function expectRevert() external;
}

/// @dev Only deployment/input boundaries. Actual pairing/hash-to-curve tests
/// run on explicit Prague Anvil in verify-bnb-bls-evm.py (no mock or RISC0).
contract BNBVoteBLSDiagnosticGuardTest {
    VmBlsGuard private constant vm = VmBlsGuard(address(uint160(uint256(keccak256("hevm cheat code")))));

    function testNativeChainIdsCannotDeployDiagnostic() public {
        vm.chainId(56);
        vm.expectRevert();
        new BNBVoteBLSDiagnostic();
        vm.chainId(103);
        vm.expectRevert();
        new BNBVoteBLSDiagnostic();
        vm.chainId(31337);
        new BNBVoteBLSDiagnostic();
    }

    function testEmptyWitnessFailsBeforeMissingPrecompiles() public {
        BNBVoteBLSDiagnostic diagnostic = new BNBVoteBLSDiagnostic();
        vm.expectRevert();
        diagnostic.verifySuppliedVote(bytes32(uint256(1)), new bytes(0), 1, new bytes(256));
    }
}
