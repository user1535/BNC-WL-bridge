// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/// @dev Local, stateless supplied-key BLS diagnostic. No authenticated epoch,
/// PoP registration, header/finality policy, root storage or asset authority.
/// Requires EIP-2537. Hash-to-curve is computed here, never supplied by caller.
contract BNBVoteBLSDiagnostic {
    bytes private constant DST = "BLS_SIG_BLS12381G2_XMD:SHA-256_SSWU_RO_POP_";
    bytes private constant P =
        hex"000000000000000000000000000000001a0111ea397fe69a4b1ba7b6434bacd764774b84f38512bf6730d2a0f6b0f6241eabfffeb153ffffb9feffffffffaaab";
    bytes private constant NEG_G1 =
        hex"0000000000000000000000000000000017f1d3a73197d7942695638c4fa9ac0fc3688c4f9774b905a14e3a3f171bac586c55e83ff97a1aeffb3af00adb22c6bb00000000000000000000000000000000114d1d6855d545a8aa7d76c8cf2e21f267816aef1db507c96655b9d5caac42364e6f38ba0ecb751bad54dcd6b939c2ca";
    error InvalidWitness();
    error InvalidPairing();
    error PrecompileUnavailableOrRejected();

    constructor() {
        require(block.chainid == 31337 || block.chainid == 31338, "local diagnostic only");
    }

    function _call(uint160 target, bytes memory data, uint256 width) private view returns (bytes memory output) {
        bool ok;
        // Bound gas burned on malformed curve inputs. Empty-code success must
        // fail the exact output-width check (WorldLand currently lacks these).
        (ok, output) = address(target).staticcall{gas: 2_000_000}(data);
        if (!ok || output.length != width) revert PrecompileUnavailableOrRejected();
    }

    function _nonzero(bytes memory data) private pure returns (bool) {
        for (uint256 i; i < data.length; i += 32) {
            bytes32 word;
            assembly { word := mload(add(add(data, 32), i)) }
            if (word != bytes32(0)) return true;
        }
        return false;
    }

    function _reduce(bytes memory uniform, uint256 offset) private view returns (bytes memory) {
        bytes memory input = abi.encodePacked(uint256(64), uint256(1), uint256(64));
        bytes memory element = new bytes(64);
        for (uint256 j; j < 64; ++j) {
            element[j] = uniform[offset + j];
        }
        return _call(5, bytes.concat(input, element, hex"01", P), 64);
    }

    function hashVoteToG2(bytes32 message) public view returns (bytes memory) {
        bytes memory dstPrime = bytes.concat(DST, bytes1(uint8(DST.length)));
        // RFC9380 SHA256 XMD: count2, m2, L64 => 256 uniform bytes.
        bytes32 b0 = sha256(bytes.concat(new bytes(64), abi.encodePacked(message), hex"010000", dstPrime));
        bytes32 previous = sha256(abi.encodePacked(b0, bytes1(uint8(1)), dstPrime));
        bytes memory uniform = abi.encodePacked(previous);
        for (uint8 i = 2; i <= 8; ++i) {
            previous = sha256(abi.encodePacked(b0 ^ previous, bytes1(i), dstPrime));
            uniform = bytes.concat(uniform, abi.encodePacked(previous));
        }
        bytes memory q0 = _call(17, bytes.concat(_reduce(uniform, 0), _reduce(uniform, 64)), 256);
        bytes memory q1 = _call(17, bytes.concat(_reduce(uniform, 128), _reduce(uniform, 192)), 256);
        return _call(13, bytes.concat(q0, q1), 256);
    }

    function _aggregate(bytes calldata keys, uint64 bitmap) private view returns (bytes memory) {
        uint256 n = keys.length / 128;
        if (keys.length % 128 != 0 || n == 0 || n > 64 || (n < 64 && bitmap >> n != 0)) revert InvalidWitness();
        bytes memory msm = new bytes(n * 160);
        bytes32[] memory seen = new bytes32[](n);
        uint256 participants;
        for (uint256 i; i < n; ++i) {
            bytes memory point = keys[i * 128:(i + 1) * 128];
            if (!_nonzero(point)) revert InvalidWitness();
            bytes32 digest = keccak256(point);
            for (uint256 j; j < i; ++j) {
                if (seen[j] == digest) revert InvalidWitness();
            }
            seen[i] = digest;
            uint256 scalar = (bitmap >> i) & 1;
            participants += scalar;
            assembly {
                let dest := add(add(msm, 32), mul(i, 160))
                let src := add(point, 32)
                mstore(dest, mload(src))
                mstore(add(dest, 32), mload(add(src, 32)))
                mstore(add(dest, 64), mload(add(src, 64)))
                mstore(add(dest, 96), mload(add(src, 96)))
                mstore(add(dest, 128), scalar)
            }
        }
        if (participants < (n * 2 + 2) / 3) revert InvalidWitness();
        // G1MSM performs subgroup checks, including keys with scalar zero.
        bytes memory aggregate = _call(12, msm, 128);
        if (!_nonzero(aggregate)) revert InvalidWitness();
        return aggregate;
    }

    function verifySuppliedVote(bytes32 message, bytes calldata keys, uint64 bitmap, bytes calldata signature)
        external
        view
        returns (bool)
    {
        if (message == bytes32(0) || signature.length != 256 || !_nonzero(signature)) revert InvalidWitness();
        bytes memory aggregate = _aggregate(keys, bitmap);
        bytes memory result = _call(15, bytes.concat(aggregate, hashVoteToG2(message), NEG_G1, signature), 32);
        if (abi.decode(result, (uint256)) != 1) revert InvalidPairing();
        return true;
    }
}
