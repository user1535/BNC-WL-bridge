// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {BNBEpochHeaderVoteDiagnostic} from "./BNBEpochHeaderVoteDiagnostic.sol";
import {RLPReader} from "../src/bridge/lib/RLPReader.sol";

/// @dev Local stateless pinned BNB56 seal mathematics. The supplied epoch is
/// not an authenticated bootstrap or active target-1 snapshot. No transition,
/// turn/recent signer, timing, difficulty/fork selection or finality is checked.
contract BNBParliaSealDiagnostic is BNBEpochHeaderVoteDiagnostic {
    function _bytesRLP(bytes memory data) private pure returns (bytes memory) {
        if (data.length == 1 && uint8(data[0]) < 0x80) return data;
        if (data.length <= 55) return abi.encodePacked(bytes1(uint8(0x80+data.length)),data);
        if (data.length <= 255) return abi.encodePacked(hex"b8",uint8(data.length),data);
        return abi.encodePacked(hex"b9",uint16(data.length),data);
    }

    function _listRLP(bytes memory payload) private pure returns (bytes memory) {
        if (payload.length <= 55) return abi.encodePacked(bytes1(uint8(0xc0+payload.length)),payload);
        if (payload.length <= 255) return abi.encodePacked(hex"f8",uint8(payload.length),payload);
        return abi.encodePacked(hex"f9",uint16(payload.length),payload);
    }

    function _width(RLPReader.Item memory field, uint256 width, bool optional) private pure {
        if (field.length != width && !(optional && field.length == 0)) revert InvalidWitness();
    }

    function _sealParts(bytes memory raw) private pure returns (bytes32 digest, bytes memory signature, address coinbase) {
        _header(raw); // canonical flat header, raw cap, parent/root/number binding
        RLPReader.Item[] memory fields = RLPReader.listItems(raw);
        if (fields.length > 21) revert InvalidWitness(); // known pinned codec only
        _width(fields[1],32,false); _width(fields[2],20,false);
        _width(fields[3],32,false); _width(fields[4],32,false); _width(fields[6],256,false);
        RLPReader.itemUint(raw,fields[7]);
        for (uint256 i = 9; i <= 11; ++i) if (RLPReader.itemUint(raw,fields[i]) > type(uint64).max) revert InvalidWitness();
        _width(fields[13],32,false); _width(fields[14],8,false);
        if (fields.length > 15) RLPReader.itemUint(raw,fields[15]);
        if (fields.length > 16) _width(fields[16],32,true);
        for (uint256 i = 17; i < fields.length && i <= 18; ++i)
            if (RLPReader.itemUint(raw,fields[i]) > type(uint64).max) revert InvalidWitness();
        if (fields.length > 19) _width(fields[19],32,true);
        if (fields.length > 20) _width(fields[20],32,true);
        bytes memory extra = RLPReader.itemBytes(raw,fields[12]);
        if (extra.length < 65) revert InvalidWitness();
        signature = _slice(extra,extra.length-65,65);
        coinbase = RLPReader.itemAddress(raw,fields[2]);
        // Pinned types.EncodeSigHeader includes chainId and all extra except
        // the ECDSA suffix. Parlia.SealHash for mining excludes votes and is
        // a different task identifier, not the ecrecover digest used here.
        bytes memory payload = hex"38"; // canonical RLP(source chain56)
        for (uint256 i; i < 15; ++i) {
            payload = bytes.concat(payload, i == 12 ? _bytesRLP(_slice(extra,0,extra.length-65))
                : RLPReader.itemEncoded(raw,fields[i]));
        }
        if (fields.length > 19 && fields[19].length == 32) {
            for (uint256 i = 15; i <= 19; ++i) payload = bytes.concat(payload,RLPReader.itemEncoded(raw,fields[i]));
            if (fields.length > 20 && fields[20].length == 32)
                payload = bytes.concat(payload,RLPReader.itemEncoded(raw,fields[20]));
        }
        digest = keccak256(_listRLP(payload));
    }

    function recoverParliaSeal(bytes memory raw) public pure returns (bytes32 digest, address signer, address coinbase) {
        bytes memory signature;
        (digest,signature,coinbase) = _sealParts(raw);
        if (uint8(signature[64]) > 1) revert InvalidWitness(); // explicit diagnostic support bound
        bytes32 r; bytes32 s;
        assembly { r := mload(add(signature,32)) s := mload(add(signature,64)) }
        signer = ecrecover(digest,uint8(signature[64])+27,r,s);
        if (signer == address(0) || signer != coinbase) revert InvalidWitness();
    }

    /// @dev Codec diagnostic only. Does not verify this digest's signature.
    function parliaSealHash(bytes calldata raw) external pure returns (bytes32 digest) {
        (digest,,) = _sealParts(raw);
    }

    function _requireSuppliedMember(bytes memory raw, EpochData memory epoch) private pure {
        (,address signer,) = recoverParliaSeal(raw);
        for (uint256 index; index < epoch.count; ++index) {
            uint160 validator;
            for (uint256 i; i < 20; ++i) validator = (validator<<8) | uint8(epoch.extra[33+index*68+i]);
            if (signer == address(validator)) return;
        }
        revert InvalidWitness();
    }

    function _checkSeals(bytes memory sourceRaw, bytes memory targetRaw, bytes memory attestingRaw,
        bytes memory epochRaw) private pure {
        EpochData memory epoch = _epochData(epochRaw);
        // The epoch announcing a new set can itself be signed by the old set.
        // Check its seal math/coinbase, without requiring membership in its
        // own announced set. The three vote witness headers use supplied keys.
        recoverParliaSeal(epochRaw);
        _requireSuppliedMember(sourceRaw,epoch); _requireSuppliedMember(targetRaw,epoch);
        _requireSuppliedMember(attestingRaw,epoch);
    }

    function verifyEpochSealedVote(bytes memory sourceRaw, bytes memory targetRaw, bytes memory attestingRaw,
        bytes memory epochRaw, bytes memory keys, bytes memory signature) public view returns (bool)
    {
        _checkSeals(sourceRaw,targetRaw,attestingRaw,epochRaw);
        return this.verifySuppliedEpochVote(sourceRaw,targetRaw,attestingRaw,epochRaw,keys,signature);
    }
}
