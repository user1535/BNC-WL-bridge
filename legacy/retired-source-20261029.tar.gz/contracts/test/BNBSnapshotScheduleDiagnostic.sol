// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {BNBRawHeaderVoteDiagnostic} from "./BNBRawHeaderVoteDiagnostic.sol";

/// @dev Supplied-state arithmetic, fixed post-Bohr epoch1000 only. No ancestor
/// authentication, fork activation, snapshot replay or finality is provided.
/// Does not select an authoritative validator set or mutate an asset registry.
contract BNBSnapshotScheduleDiagnostic is BNBRawHeaderVoteDiagnostic {
    function _history(uint8 count, uint8 turnLength) private pure returns (uint64 delay) {
        if (count == 0 || count > 64 || turnLength == 0) revert InvalidWitness();
        delay = (uint64(count)/2+1)*uint64(turnLength)-1;
        if (delay >= 1000) revert InvalidWitness(); // explicit single-epoch diagnostic bound
    }

    function delaySchedule(uint64 epochNumber, uint8 oldCount, uint8 oldTurn, uint8 newCount,
        uint8 newTurn, uint64 snapshotNumber) external pure returns (
        uint64 delay, uint64 switchNumber, uint64 firstNewHeaderNumber,
        bool newSetAtSnapshot, uint64 newDelay, bool switchSentinelRequired)
    {
        if (epochNumber == 0 || epochNumber%1000 != 0 || epochNumber > type(uint64).max-1000
            || snapshotNumber < epochNumber || snapshotNumber >= epochNumber+1000) revert InvalidWitness();
        delay = _history(oldCount,oldTurn);
        newDelay = _history(newCount,newTurn);
        switchNumber = epochNumber+delay;
        firstNewHeaderNumber = switchNumber+1;
        newSetAtSnapshot = snapshotNumber >= switchNumber;
        // Upstream post-Bohr Recents[MaxUint64-epochIndex] prevents a second
        // switch when a larger new set/turn creates another later trigger.
        switchSentinelRequired = newDelay > delay;
    }

    /// @dev [BLS voter target-1, source sealer parent, target sealer parent,
    /// attesting sealer parent]. Required commitments, not trusted snapshots.
    function snapshotRoles(bytes calldata sourceRaw, bytes calldata targetRaw, bytes calldata attestingRaw)
        external pure returns (uint64[4] memory numbers, bytes32[4] memory hashes)
    {
        (,HeaderCommitment memory source,HeaderCommitment memory target) = headerVoteCommitments(sourceRaw,targetRaw);
        HeaderCommitment memory attesting = _header(attestingRaw);
        if (source.number == 0 || target.number == type(uint64).max || attesting.number != target.number+1
            || attesting.parentHash != target.blockHash) revert InvalidWitness();
        numbers = [target.number-1,source.number-1,target.number-1,attesting.number-1];
        hashes = [target.parentHash,source.parentHash,target.parentHash,attesting.parentHash];
    }
}
