// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {NativeProofDiagnostic} from "./NativeProofDiagnostic.sol";
import {LocalRiscZeroGroth16Verifier} from "../src/bridge/LocalRiscZeroGroth16Verifier.sol";
import {IRiscZeroVerifier} from "../src/bridge/Risc0HeaderUpdater.sol";
import {MPTReceiptProofCore} from "../src/bridge/MPTReceiptProofCore.sol";

interface VmNativeReal {
    function readFile(string calldata) external view returns (string memory);
    function parseJsonBytes(string calldata, string calldata) external pure returns (bytes memory);
    function parseJsonBytes32(string calldata, string calldata) external pure returns (bytes32);
    function parseJsonAddress(string calldata, string calldata) external pure returns (address);
    function parseJsonUint(string calldata, string calldata) external pure returns (uint256);
    function parseJson(string calldata, string calldata) external pure returns (bytes memory);
    function expectRevert() external;
}

/// @dev Genuine captured Groth16 fixtures. No fake verifier or proving backend;
/// passing means serialization/MPT inclusion, never source finality or assets.
contract NativeRealProofTest {
    VmNativeReal private constant vm = VmNativeReal(address(uint160(uint256(keccak256("hevm cheat code")))));

    function nativeFixture(string memory name) private view returns (string memory) {
        return vm.readFile(string.concat("test/fixtures/native-real-", name, "-groth16.json"));
    }

    function testBothActualNativeGroth16Pairings() public {
        LocalRiscZeroGroth16Verifier verifier = new LocalRiscZeroGroth16Verifier();
        for (uint256 i; i < 2; ++i) {
            string memory json = nativeFixture(i == 0 ? "worldland" : "bnb");
            bytes memory journal = vm.parseJsonBytes(json, ".journal");
            require(journal.length == 224, "journal width");
            verifier.verify(vm.parseJsonBytes(json, ".seal"), vm.parseJsonBytes32(json, ".imageId"), sha256(journal));
        }
    }

    function testGenuineNativeBnbProofWithBothActualType4Logs() public {
        string memory json = nativeFixture("bnb");
        bytes32 image = vm.parseJsonBytes32(json, ".imageId");
        NativeProofDiagnostic diagnostic = new NativeProofDiagnostic(IRiscZeroVerifier(address(new LocalRiscZeroGroth16Verifier())), image);
        for (uint256 i; i < 2; ++i) {
            string memory receipt = vm.readFile(
                i == 0 ? "test/fixtures/native-type4-index16.json" : "test/fixtures/native-type4-index107.json"
            );
            NativeProofDiagnostic.Header memory header = NativeProofDiagnostic.Header(
                uint64(vm.parseJsonUint(json, ".blockNumber")),
                vm.parseJsonBytes32(json, ".blockHash"),
                vm.parseJsonBytes32(json, ".parentHash"),
                vm.parseJsonBytes32(receipt, ".root")
            );
            MPTReceiptProofCore.VerifiedLog memory result = diagnostic.verifyHeaderLog(
                vm.parseJsonBytes(json, ".seal"),
                vm.parseJsonBytes(json, ".journal"),
                header,
                vm.parseJsonUint(receipt, ".txIndex"),
                vm.parseJsonUint(receipt, ".logIndex"),
                abi.decode(vm.parseJson(receipt, ".proofNodes"), (bytes[]))
            );
            require(result.emitter == vm.parseJsonAddress(receipt, ".emitter"), "native emitter");
            bytes32[] memory topics = abi.decode(vm.parseJson(receipt, ".topics"), (bytes32[]));
            require(keccak256(abi.encode(result.topics)) == keccak256(abi.encode(topics)), "native topics");
            require(keccak256(result.data) == keccak256(vm.parseJsonBytes(receipt, ".data")), "native data");
        }
    }

    function testNativeProofCannotCrossSourceJournalsOrSpoofReceiptRoot() public {
        string memory bnb = nativeFixture("bnb");
        string memory wl = nativeFixture("worldland");
        LocalRiscZeroGroth16Verifier verifier = new LocalRiscZeroGroth16Verifier();
        bytes32 image = vm.parseJsonBytes32(bnb, ".imageId");
        bytes memory journal = vm.parseJsonBytes(bnb, ".journal");
        bytes memory worldlandSeal = vm.parseJsonBytes(wl, ".seal");
        bytes32 bnbDigest = sha256(journal);
        vm.expectRevert();
        verifier.verify(worldlandSeal, image, bnbDigest);
        NativeProofDiagnostic diagnostic = new NativeProofDiagnostic(IRiscZeroVerifier(address(verifier)), image);
        NativeProofDiagnostic.Header memory header = NativeProofDiagnostic.Header(
            uint64(vm.parseJsonUint(bnb, ".blockNumber")),
            vm.parseJsonBytes32(bnb, ".blockHash"),
            vm.parseJsonBytes32(bnb, ".parentHash"),
            bytes32(uint256(1))
        );
        bytes memory seal = vm.parseJsonBytes(bnb, ".seal");
        vm.expectRevert();
        diagnostic.verifyHeaderLog(seal, journal, header, 16, 0, new bytes[](0));
    }
}
