// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {LocalRiscZeroGroth16Verifier} from "../src/bridge/LocalRiscZeroGroth16Verifier.sol";
import {Risc0HeaderUpdater, IRiscZeroVerifier} from "../src/bridge/Risc0HeaderUpdater.sol";

interface VmRealVerifier {
    function chainId(uint256 newChainId) external;
    function readFile(string calldata path) external view returns (string memory);
    function parseJsonBytes(string calldata json, string calldata key) external pure returns (bytes memory);
    function parseJsonBytes32(string calldata json, string calldata key) external pure returns (bytes32);
    function parseJsonUint(string calldata json, string calldata key) external pure returns (uint256);
    function expectRevert() external;
    function prank(address sender) external;
}

/// @dev A real CPU-generated Groth16 fixture; no mock verification in these tests.
contract RiscZeroRealVerifierTest {
    VmRealVerifier private constant vm = VmRealVerifier(address(uint160(uint256(keccak256("hevm cheat code")))));
    LocalRiscZeroGroth16Verifier private verifier;
    bytes private seal;
    bytes private journal;
    bytes private batchData;
    bytes32 private imageId;
    bytes32 private anchor;
    uint256 private start;

    function setUp() public {
        vm.chainId(31338);
        string memory fixture = vm.readFile("test/fixtures/real-header-groth16.json");
        seal = vm.parseJsonBytes(fixture, ".seal");
        journal = vm.parseJsonBytes(fixture, ".journal");
        batchData = vm.parseJsonBytes(fixture, ".batchData");
        imageId = vm.parseJsonBytes32(fixture, ".imageId");
        anchor = vm.parseJsonBytes32(fixture, ".anchorHash");
        start = vm.parseJsonUint(fixture, ".startBlock");
        verifier = new LocalRiscZeroGroth16Verifier();
        require(seal.length == 260 && journal.length == 224, "invalid fixture");
    }

    function _updater(bytes32 expectedImage) private returns (Risc0HeaderUpdater) {
        return new Risc0HeaderUpdater(31337, IRiscZeroVerifier(address(verifier)), expectedImage, start - 1, anchor);
    }

    function testRealGroth16SealAccepted() public view {
        verifier.verify(seal, imageId, sha256(journal));
    }

    function testForgedGroth16CoordinatesRejected() public {
        bytes memory altered = seal;
        altered[altered.length - 1] ^= 0x01;
        bytes32 digest = sha256(journal);
        vm.expectRevert();
        verifier.verify{gas: 500_000}(altered, imageId, digest);
    }

    function testWrongVerifierSelectorRejected() public {
        bytes memory altered = seal;
        altered[0] ^= 0x01;
        bytes32 digest = sha256(journal);
        vm.expectRevert();
        verifier.verify(altered, imageId, digest);
    }

    function testWrongImageAndJournalRejected() public {
        bytes32 digest = sha256(journal);
        vm.expectRevert();
        verifier.verify(seal, imageId ^ bytes32(uint256(1)), digest);
        bytes memory altered = journal;
        altered[altered.length - 1] ^= 0x01;
        digest = sha256(altered);
        vm.expectRevert();
        verifier.verify(seal, imageId, digest);
    }

    function testRealUpdaterAcceptsUserAndRejectsReplay() public {
        Risc0HeaderUpdater updater = _updater(imageId);
        vm.prank(address(0xB0B));
        updater.submitHeaderProof(seal, journal, batchData);
        Risc0HeaderUpdater.MinimalHeader[] memory batch = abi.decode(batchData, (Risc0HeaderUpdater.MinimalHeader[]));
        for (uint256 i = 0; i < batch.length; i++) {
            require(updater.isBlockCovered(31337, batch[i].number, batch[i].blockHash));
            require(updater.getReceiptRoot(31337, batch[i].number, batch[i].blockHash) == batch[i].receiptRoot);
        }
        vm.expectRevert();
        updater.submitHeaderProof(seal, journal, batchData);
    }

    function testRealUpdaterRejectsWrongImageAndBatchRoot() public {
        Risc0HeaderUpdater wrongImage = _updater(imageId ^ bytes32(uint256(1)));
        vm.expectRevert();
        wrongImage.submitHeaderProof(seal, journal, batchData);
        require(wrongImage.latestBlock() == start - 1);
        Risc0HeaderUpdater updater = _updater(imageId);
        Risc0HeaderUpdater.MinimalHeader[] memory altered = abi.decode(batchData, (Risc0HeaderUpdater.MinimalHeader[]));
        altered[0].receiptRoot ^= bytes32(uint256(1));
        vm.expectRevert();
        updater.submitHeaderProof(seal, journal, abi.encode(altered));
        require(updater.latestBlock() == start - 1);
    }

    function testRealVerifierCannotDeployOnMainnets() public {
        vm.chainId(56);
        vm.expectRevert();
        new LocalRiscZeroGroth16Verifier();
        vm.chainId(103);
        vm.expectRevert();
        new LocalRiscZeroGroth16Verifier();
    }
}
