// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {BNBRiscZeroVoteDiagnostic, BNBRiscZeroHintedVoteDiagnostic} from "./BNBRiscZeroVoteDiagnostic.sol";
import {IRiscZeroVerifier} from "../src/bridge/Risc0HeaderUpdater.sol";

interface VmVoteBoundary {
    function chainId(uint256) external;
}

/// @dev Always rejects; never substitutes a successful Groth16 verifier.
contract RejectingVoteVerifier is IRiscZeroVerifier {
    error CryptographicVerifierReached();
    function verify(bytes calldata, bytes32, bytes32) external pure {
        revert CryptographicVerifierReached();
    }
}

contract BNBRiscZeroVoteDiagnosticBoundaryTest {
    VmVoteBoundary private constant vm = VmVoteBoundary(address(uint160(uint256(keccak256("hevm cheat code")))));

    function base() private pure returns (BNBRiscZeroVoteDiagnostic.VotePublic memory) {
        return BNBRiscZeroVoteDiagnostic.VotePublic(56, 100, 102, 3, bytes32(uint256(1)),
            bytes32(uint256(2)), bytes32(uint256(3)), bytes32(uint256(4)), bytes32(uint256(5)), 1835007, 21);
    }

    function selector(BNBRiscZeroVoteDiagnostic diagnostic, bytes memory journal) private view returns (bytes4 found) {
        (bool ok, bytes memory error) = address(diagnostic).staticcall(
            abi.encodeCall(diagnostic.verifyVote, (hex"", journal))
        );
        require(!ok && error.length >= 4, "expected explicit rejection");
        assembly { found := mload(add(error, 32)) }
    }

    function testValidShapeReachesRejectingCryptoVerifierIncluding64KeyBoundary() public {
        BNBRiscZeroVoteDiagnostic diagnostic = new BNBRiscZeroVoteDiagnostic(new RejectingVoteVerifier());
        BNBRiscZeroVoteDiagnostic.VotePublic memory value = base();
        require(selector(diagnostic, abi.encode(value)) == RejectingVoteVerifier.CryptographicVerifierReached.selector,
            "valid shape must reach cryptographic verifier");
        value.keyCount = 64; value.bitmap = type(uint64).max;
        require(selector(diagnostic, abi.encode(value)) == RejectingVoteVerifier.CryptographicVerifierReached.selector,
            "64-key bitmap shift boundary");
    }

    function testMalformedPublicBoundsStopBeforeCryptoVerifier() public {
        BNBRiscZeroVoteDiagnostic diagnostic = new BNBRiscZeroVoteDiagnostic(new RejectingVoteVerifier());
        for (uint256 i; i < 12; ++i) {
            BNBRiscZeroVoteDiagnostic.VotePublic memory v = base();
            if (i == 0) v.sourceId = 103;
            else if (i == 1) v.count = 2;
            else if (i == 2) v.end = 103;
            else if (i == 3) v.start = type(uint64).max;
            else if (i == 4) v.anchor = 0;
            else if (i == 5) v.endHash = 0;
            else if (i == 6) v.batchRoot = 0;
            else if (i == 7) v.epochHash = 0;
            else if (i == 8) v.voteDataHash = 0;
            else if (i == 9) v.bitmap = 1; // lacks supplied quorum
            else if (i == 10) v.bitmap = uint64(1) << 21; // outside21 slots
            else v.keyCount = 65;
            require(selector(diagnostic, abi.encode(v)) == BNBRiscZeroVoteDiagnostic.InvalidVoteJournal.selector,
                "public bounds must reject before verifier");
        }
        require(selector(diagnostic, new bytes(224)) == BNBRiscZeroVoteDiagnostic.InvalidVoteJournal.selector,
            "old native journal must reject");
    }

    function testNativeNetworksAndMissingVerifierCannotDeploy() public {
        RejectingVoteVerifier verifier = new RejectingVoteVerifier();
        for (uint256 i; i < 2; ++i) {
            vm.chainId(i == 0 ? 56 : 103);
            try new BNBRiscZeroVoteDiagnostic(verifier) { revert("native chain deployment accepted"); }
            catch {}
        }
        vm.chainId(31337);
        try new BNBRiscZeroVoteDiagnostic(IRiscZeroVerifier(address(1))) { revert("missing verifier accepted"); }
        catch {}
    }

    function testCandidatePinsSeparateImageAndKeepsPublicBounds() public {
        RejectingVoteVerifier verifier = new RejectingVoteVerifier();
        BNBRiscZeroVoteDiagnostic original = new BNBRiscZeroVoteDiagnostic(verifier);
        BNBRiscZeroVoteDiagnostic candidate = new BNBRiscZeroHintedVoteDiagnostic(verifier);
        require(original.BLS_IMAGE() == 0x9aab5eba7939ee001357aeb9b0e084314270174e3956109eef87f961f5db50f6,
            "original image changed");
        require(candidate.BLS_IMAGE() == 0xee7d7ec0047419866b74142713542217b4122daeb9c098e5cec8730d956c2909,
            "explicit candidate image required");
        require(selector(candidate, abi.encode(base())) == RejectingVoteVerifier.CryptographicVerifierReached.selector,
            "candidate valid shape must reach verifier");
        BNBRiscZeroVoteDiagnostic.VotePublic memory malformed = base();
        malformed.sourceId = 103;
        require(selector(candidate, abi.encode(malformed)) == BNBRiscZeroVoteDiagnostic.InvalidVoteJournal.selector,
            "candidate keeps source-domain bounds");
        vm.chainId(56);
        try new BNBRiscZeroHintedVoteDiagnostic(verifier) { revert("candidate native deployment accepted"); }
        catch {}
        vm.chainId(31337);
    }
}
