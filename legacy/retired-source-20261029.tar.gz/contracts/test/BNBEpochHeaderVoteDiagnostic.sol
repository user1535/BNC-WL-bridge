// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {BNBAttestingHeaderVoteDiagnostic} from "./BNBAttestingHeaderVoteDiagnostic.sol";
import {RLPReader} from "../src/bridge/lib/RLPReader.sol";
import {BNBVoteWireDiagnostic} from "./BNBVoteWireDiagnostic.sol";

/// @dev Explicit supplied post-Bohr epoch byte-layout diagnostic only.
/// Does not authenticate epoch eligibility, delayed snapshot transitions,
/// registration PoP, ECDSA seals, bootstrap or highest justified/finality state.
contract BNBEpochHeaderVoteDiagnostic is BNBAttestingHeaderVoteDiagnostic {
    struct EpochData {
        HeaderCommitment header;
        bytes extra;
        uint256 keysEnd;
        uint8 count;
        uint8 turnLength;
    }

    function _epochData(bytes memory epochRaw) internal pure returns (EpochData memory epoch) {
        epoch.header = _header(epochRaw);
        RLPReader.Item[] memory fields = RLPReader.listItems(epochRaw);
        epoch.extra = RLPReader.itemBytes(epochRaw, fields[12]);
        if (epoch.extra.length < 32+1+68+1+65) revert InvalidWitness();
        epoch.count = uint8(epoch.extra[32]);
        epoch.keysEnd = 33 + uint256(epoch.count)*68;
        if (epoch.count == 0 || epoch.count > 64 || epoch.keysEnd+1+65 > epoch.extra.length) revert InvalidWitness();
        epoch.turnLength = uint8(epoch.extra[epoch.keysEnd]);
        if (epoch.turnLength == 0) revert InvalidWitness();
    }

    function _optionalVote(EpochData memory epoch) private pure
        returns (bool present, BNBVoteWireDiagnostic.Vote memory vote)
    {
        uint256 length = epoch.extra.length - epoch.keysEnd - 1 - 65;
        if (length == 0) return (false, vote);
        return (true, BNBVoteWireDiagnostic.decode(_slice(epoch.extra, epoch.keysEnd+1, length)));
    }

    /// @dev Optional vote schema metadata; optional signature is not verified.
    function epochOptionalVoteMetadata(bytes calldata epochRaw) external pure
        returns (bool present, bytes32 dataHash, uint64 bitmap, bytes32 signatureHash, uint256 reservedExtraLength)
    {
        BNBVoteWireDiagnostic.Vote memory vote;
        (present, vote) = _optionalVote(_epochData(epochRaw));
        if (!present) return (false, bytes32(0), 0, bytes32(0), 0);
        return (true, vote.dataHash, vote.bitmap, keccak256(vote.signature), vote.reservedExtra.length);
    }

    function suppliedEpochCommitments(bytes calldata epochRaw, bytes calldata keys) public pure
        returns (bytes32 epochHash, uint64 epochNumber, uint8 count, uint8 turnLength)
    {
        EpochData memory epoch = _epochData(epochRaw);
        if (keys.length != uint256(epoch.count)*128) revert InvalidWitness();
        _matchEpochKeys(epoch.extra, keys, epoch.count);
        _optionalVote(epoch);
        return (epoch.header.blockHash, epoch.header.number, epoch.count, epoch.turnLength);
    }

    function _matchEpochKeys(bytes memory extra, bytes calldata keys, uint8 count) private pure {
        uint160 previous;
        for (uint256 index; index < count; ++index) {
            uint256 entry = 33+index*68;
            uint160 validator;
            for (uint256 i; i < 20; ++i) validator = (validator<<8) | uint8(extra[entry+i]);
            if (validator == 0 || (index != 0 && validator <= previous)) revert InvalidWitness();
            previous = validator;
            uint256 offset = index*128;
            for (uint256 i; i < 16; ++i)
                if (keys[offset+i] != 0 || keys[offset+64+i] != 0) revert InvalidWitness();
            for (uint256 i; i < 48; ++i) {
                bytes1 value = keys[offset+16+i];
                if (i == 0) value |= bytes1(uint8(0x80 | (_sortBit(keys, offset+64) ? 0x20 : 0)));
                if (value != extra[entry+20+i]) revert InvalidWitness();
            }
        }
    }

    function verifySuppliedEpochVote(bytes calldata sourceRaw, bytes calldata targetRaw, bytes calldata attestingRaw,
        bytes calldata epochRaw, bytes calldata suppliedKeys, bytes calldata uncompressedSignature) external view returns (bool)
    {
        suppliedEpochCommitments(epochRaw, suppliedKeys);
        // The inherited BLS path checks all keys, including nonparticipants,
        // for canonical coordinates/curve subgroup, duplicates and quorum.
        return this.verifyNonEpochAttestingVote(sourceRaw, targetRaw, attestingRaw, suppliedKeys, uncompressedSignature);
    }
}
