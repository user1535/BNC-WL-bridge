// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {BNBVoteBLSDiagnostic} from "./BNBVoteBLSDiagnostic.sol";
import {RLPReader} from "../src/bridge/lib/RLPReader.sol";

/// @dev Local stateless diagnostic: mathematical supplied-key vote + raw
/// source/target header commitments. Consumes common parent/number/root fields;
/// does not validate complete native fork/header policy, attesting-header vote
/// extraction, PoP registration, epoch transition, highest justified or finality.
/// No root registry, asset authority or authenticated bootstrap is provided.
contract BNBRawHeaderVoteDiagnostic is BNBVoteBLSDiagnostic {
    struct HeaderCommitment {
        uint64 number;
        bytes32 blockHash;
        bytes32 parentHash;
        bytes32 receiptRoot;
    }

    function _header(bytes memory raw) internal pure returns (HeaderCommitment memory header) {
        if (raw.length == 0 || raw.length > 4096) revert InvalidWitness();
        RLPReader.Item[] memory items = RLPReader.listItems(raw);
        if (items.length < 15 || items.length > 26) revert InvalidWitness();
        // Reject nested data rather than treating arbitrary list payloads as scalars.
        for (uint256 i; i < items.length; ++i) {
            if (items[i].isList) revert InvalidWitness();
        }
        uint256 number = RLPReader.itemUint(raw, items[8]);
        if (number > type(uint64).max) revert InvalidWitness();
        header.number = uint64(number);
        header.blockHash = keccak256(raw);
        header.parentHash = RLPReader.itemBytes32(raw, items[0]);
        header.receiptRoot = RLPReader.itemBytes32(raw, items[5]);
    }

    function _rlpNumber(uint64 value) private pure returns (bytes memory) {
        if (value == 0) return hex"80";
        if (value < 128) return abi.encodePacked(bytes1(uint8(value)));
        uint64 remaining = value;
        uint256 width;
        while (remaining != 0) { ++width; remaining >>= 8; }
        bytes memory encoded = new bytes(width + 1);
        encoded[0] = bytes1(uint8(0x80 + width));
        for (uint256 i; i < width; ++i) encoded[width - i] = bytes1(uint8(value >> (8 * i)));
        return encoded;
    }

    function headerVoteCommitments(bytes calldata sourceRaw, bytes calldata targetRaw)
        public pure returns (bytes32 message, HeaderCommitment memory source, HeaderCommitment memory target)
    {
        source = _header(sourceRaw); target = _header(targetRaw);
        if (source.number == type(uint64).max || target.number != source.number + 1
            || target.parentHash != source.blockHash) revert InvalidWitness();
        // Pinned Parlia VoteData: RLP([sourceNumber,sourceHash,targetNumber,targetHash]).
        // Two 32-byte hashes force long-list length68..84, which fits one byte.
        bytes memory payload = bytes.concat(_rlpNumber(source.number), abi.encodePacked(hex"a0", source.blockHash),
            _rlpNumber(target.number), abi.encodePacked(hex"a0", target.blockHash));
        message = keccak256(abi.encodePacked(hex"f8", bytes1(uint8(payload.length)), payload));
    }

    function verifyRawHeaderVote(bytes calldata sourceRaw, bytes calldata targetRaw, bytes calldata suppliedKeys,
        uint64 bitmap, bytes calldata signature) external view returns (bool)
    {
        (bytes32 message,,) = headerVoteCommitments(sourceRaw, targetRaw);
        // The inherited verifier computes hash-to-G2 and pairing; no caller hash input.
        return this.verifySuppliedVote(message, suppliedKeys, bitmap, signature);
    }
}
