// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {RLPReader} from "../src/bridge/lib/RLPReader.sol";

/// @dev Canonical pinned Parlia VoteAttestation wire schema only. No signature,
/// snapshot, fork, source selection or finality authentication is performed.
library BNBVoteWireDiagnostic {
    error InvalidVoteWire();

    struct Vote {
        uint64 bitmap;
        bytes signature;
        uint64 sourceNumber;
        bytes32 sourceHash;
        uint64 targetNumber;
        bytes32 targetHash;
        bytes reservedExtra;
        bytes32 dataHash;
    }

    function decode(bytes memory raw) internal pure returns (Vote memory vote) {
        if (raw.length == 0 || raw.length > 512) revert InvalidVoteWire();
        RLPReader.Item[] memory fields = RLPReader.listItems(raw);
        if (fields.length != 4 || !fields[2].isList || fields[3].isList || fields[3].length > 256)
            revert InvalidVoteWire();
        vote.bitmap = _uint64(raw, fields[0]);
        vote.signature = RLPReader.itemBytes(raw, fields[1]);
        if (vote.bitmap == 0 || vote.signature.length != 96) revert InvalidVoteWire();
        bool nonzero;
        for (uint256 i; i < 96; ++i) if (vote.signature[i] != 0) nonzero = true;
        if (!nonzero) revert InvalidVoteWire();
        RLPReader.Item[] memory data = RLPReader.listItems(raw, fields[2]);
        if (data.length != 4) revert InvalidVoteWire();
        vote.sourceNumber = _uint64(raw, data[0]);
        vote.sourceHash = RLPReader.itemBytes32(raw, data[1]);
        vote.targetNumber = _uint64(raw, data[2]);
        vote.targetHash = RLPReader.itemBytes32(raw, data[3]);
        if (vote.sourceNumber >= vote.targetNumber || vote.sourceHash == bytes32(0) || vote.targetHash == bytes32(0))
            revert InvalidVoteWire();
        vote.reservedExtra = RLPReader.itemBytes(raw, fields[3]);
        vote.dataHash = keccak256(RLPReader.itemEncoded(raw, fields[2]));
    }

    function _uint64(bytes memory raw, RLPReader.Item memory item) private pure returns (uint64) {
        uint256 number = RLPReader.itemUint(raw, item);
        if (number > type(uint64).max) revert InvalidVoteWire();
        return uint64(number);
    }
}
