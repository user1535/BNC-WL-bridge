// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Risc0HeaderUpdater, IRiscZeroVerifier} from "../src/bridge/Risc0HeaderUpdater.sol";

interface VmUpdater {
    function chainId(uint256 newChainId) external;
    function prank(address sender) external;
    function expectRevert(bytes4 selector) external;
    function expectRevert() external;
}

/// @dev This mock checks call wiring only; it does not verify a RISC0 seal.
contract LocalMockRiscZeroVerifier is IRiscZeroVerifier {
    bytes32 public immutable imageId;
    bytes32 public expectedDigest;

    constructor(bytes32 imageId_) {
        imageId = imageId_;
    }

    function setExpectedDigest(bytes32 digest) external {
        expectedDigest = digest;
    }

    function verify(bytes calldata seal, bytes32 imageId_, bytes32 journalDigest) external view {
        require(
            seal.length == 1 && seal[0] == 0x42 && imageId_ == imageId && journalDigest == expectedDigest,
            "mock rejected"
        );
    }
}

contract Risc0HeaderUpdaterTest {
    VmUpdater private constant vm = VmUpdater(address(uint160(uint256(keccak256("hevm cheat code")))));
    bytes32 private constant IMAGE_ID = bytes32(uint256(0x111));
    bytes32 private constant ANCHOR = bytes32(uint256(0x222));
    address private constant SUBMITTER = address(0xB0B);

    function _batch(uint64 first, uint256 count, bytes32 parent)
        private
        pure
        returns (Risc0HeaderUpdater.MinimalHeader[] memory batch)
    {
        batch = new Risc0HeaderUpdater.MinimalHeader[](count);
        for (uint256 i = 0; i < count; i++) {
            bytes32 blockHash = keccak256(abi.encode(first + uint64(i), parent));
            batch[i] = Risc0HeaderUpdater.MinimalHeader({
                number: first + uint64(i),
                blockHash: blockHash,
                parentHash: parent,
                receiptRoot: keccak256(abi.encode("receipts", first + uint64(i)))
            });
            parent = blockHash;
        }
    }

    function _root(Risc0HeaderUpdater.MinimalHeader[] memory batch) private pure returns (bytes32) {
        bytes32[] memory level = new bytes32[](batch.length);
        for (uint256 i = 0; i < batch.length; i++) {
            level[i] = keccak256(
                abi.encode(
                    uint256(31337),
                    uint256(batch[i].number),
                    batch[i].blockHash,
                    batch[i].parentHash,
                    batch[i].receiptRoot
                )
            );
        }
        uint256 count = level.length;
        while (count > 1) {
            uint256 nextCount = (count + 1) / 2;
            for (uint256 i = 0; i < nextCount; i++) {
                bytes32 left = level[2 * i];
                bytes32 right = 2 * i + 1 < count ? level[2 * i + 1] : left;
                level[i] = keccak256(abi.encodePacked(left, right));
            }
            count = nextCount;
        }
        return level[0];
    }

    function _journal(Risc0HeaderUpdater.MinimalHeader[] memory batch, bytes32 anchor)
        private
        pure
        returns (bytes memory)
    {
        return abi.encode(
            uint256(31337),
            uint256(batch[0].number),
            uint256(batch[batch.length - 1].number),
            anchor,
            batch[batch.length - 1].blockHash,
            _root(batch),
            uint256(batch.length)
        );
    }

    function testLocalBatchesRequireMatchingJournalAndVerifier() public {
        vm.chainId(31338);
        LocalMockRiscZeroVerifier verifier = new LocalMockRiscZeroVerifier(IMAGE_ID);
        Risc0HeaderUpdater updater = new Risc0HeaderUpdater(31337, verifier, IMAGE_ID, 100, ANCHOR);
        Risc0HeaderUpdater.MinimalHeader[] memory batch = _batch(101, 3, ANCHOR);
        bytes memory journal = _journal(batch, ANCHOR);
        verifier.setExpectedDigest(sha256(journal));

        Risc0HeaderUpdater.MinimalHeader[] memory altered = _batch(101, 3, ANCHOR);
        altered[1].receiptRoot = bytes32(uint256(7));
        vm.expectRevert(Risc0HeaderUpdater.InvalidJournal.selector);
        updater.submitHeaderProof(hex"42", journal, abi.encode(altered));
        vm.expectRevert();
        updater.submitHeaderProof(hex"00", journal, abi.encode(batch));

        vm.prank(SUBMITTER);
        updater.submitHeaderProof(hex"42", journal, abi.encode(batch));
        require(updater.latestBlock() == 103);
        require(updater.latestHash() == batch[2].blockHash);
        for (uint256 i = 0; i < batch.length; i++) {
            require(updater.isBlockCovered(31337, batch[i].number, batch[i].blockHash));
            require(updater.getReceiptRoot(31337, batch[i].number, batch[i].blockHash) == batch[i].receiptRoot);
        }
        require(!updater.isBlockCovered(56, 102, batch[1].blockHash));
        vm.expectRevert(Risc0HeaderUpdater.InvalidBatch.selector);
        updater.submitHeaderProof(hex"42", journal, abi.encode(batch));

        Risc0HeaderUpdater.MinimalHeader[] memory next = _batch(104, 1, batch[2].blockHash);
        bytes memory nextJournal = _journal(next, batch[2].blockHash);
        verifier.setExpectedDigest(sha256(nextJournal));
        updater.submitHeaderProof(hex"42", nextJournal, abi.encode(next));
        require(updater.latestBlock() == 104);
        require(updater.getReceiptRoot(31337, 104, next[0].blockHash) == next[0].receiptRoot);
    }

    function testGuestProducedJournalMatchesSolidityCommitment() public {
        vm.chainId(31338);
        bytes32 anchor = bytes32(uint256(0x111));
        Risc0HeaderUpdater.MinimalHeader[] memory batch = new Risc0HeaderUpdater.MinimalHeader[](3);
        for (uint256 i = 0; i < 3; i++) {
            batch[i] = Risc0HeaderUpdater.MinimalHeader({
                number: uint64(101 + i),
                blockHash: bytes32(uint256(0x222 + i)),
                parentHash: i == 0 ? anchor : bytes32(uint256(0x221 + i)),
                receiptRoot: bytes32(uint256(0xa1 + i))
            });
        }
        // Constants are from risc0/fixtures/local-three-headers.journal.hex,
        // produced by executing the actual RISC0 guest with the JSON fixture.
        bytes32 guestRoot = 0xde70e13efe2924e5ee1d263d1890e96c7ec2ed34abdbd7ee98e15dc297d51fde;
        bytes32 guestJournalDigest = 0x232b2be3ae32184335a7709eee69ba3552d2b09ba5ea9f3ecfbc3981738d79a6;
        require(_root(batch) == guestRoot);
        bytes memory journal = _journal(batch, anchor);
        require(sha256(journal) == guestJournalDigest);
        // Go BuildBatchArtifacts encodes the same tuple array for submitHeaderProof.
        require(sha256(abi.encode(batch)) == 0x45b86503b5e63c01cd2bb4b18715380fcf216cab666a5ae379dc947197891aa7);
        LocalMockRiscZeroVerifier verifier = new LocalMockRiscZeroVerifier(IMAGE_ID);
        verifier.setExpectedDigest(guestJournalDigest);
        Risc0HeaderUpdater updater = new Risc0HeaderUpdater(31337, verifier, IMAGE_ID, 100, anchor);
        updater.submitHeaderProof(hex"42", journal, abi.encode(batch));
        require(updater.getReceiptRoot(31337, 102, batch[1].blockHash) == batch[1].receiptRoot);
    }

    function testUpdaterRejectsVerifierWithoutCode() public {
        vm.chainId(31338);
        vm.expectRevert(Risc0HeaderUpdater.InvalidConfiguration.selector);
        new Risc0HeaderUpdater(31337, IRiscZeroVerifier(address(0xB0B)), IMAGE_ID, 100, ANCHOR);
    }

    function testUpdaterRejectsLiveDestinationChain() public {
        vm.chainId(56);
        LocalMockRiscZeroVerifier verifier = new LocalMockRiscZeroVerifier(IMAGE_ID);
        vm.expectRevert(Risc0HeaderUpdater.InvalidConfiguration.selector);
        new Risc0HeaderUpdater(103, verifier, IMAGE_ID, 100, ANCHOR);
    }
}
