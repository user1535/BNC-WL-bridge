// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IRiscZeroVerifier} from "../src/bridge/Risc0HeaderUpdater.sol";

/// @dev Local stateless verifier for supplied-epoch BLS mathematics only.
/// No authenticated bootstrap, PoP, snapshot/finality, root registry or assets.
contract BNBRiscZeroVoteDiagnostic {
    IRiscZeroVerifier public immutable verifier;

    function BLS_IMAGE() public pure virtual returns (bytes32) {
        return 0x9aab5eba7939ee001357aeb9b0e084314270174e3956109eef87f961f5db50f6;
    }

    // Matches the native224 prefix and the distinct128byte BLS suffix exactly.
    struct VotePublic {
        uint64 sourceId;
        uint64 start;
        uint64 end;
        uint64 count;
        bytes32 anchor;
        bytes32 endHash;
        bytes32 batchRoot;
        bytes32 epochHash;
        bytes32 voteDataHash;
        uint64 bitmap;
        uint8 keyCount;
    }

    error InvalidVoteJournal();

    constructor(IRiscZeroVerifier verifier_) {
        require(block.chainid == 31337 || block.chainid == 31338, "local diagnostic only");
        require(address(verifier_).code.length != 0, "verifier code required");
        verifier = verifier_;
    }

    function verifyVote(bytes calldata seal, bytes calldata journal) external view returns (VotePublic memory vote) {
        if (journal.length != 352) revert InvalidVoteJournal();
        vote = abi.decode(journal, (VotePublic));
        if (
            vote.sourceId != 56 || vote.count != 3 || vote.start > type(uint64).max - 2
                || vote.end != vote.start + 2 || vote.anchor == 0 || vote.endHash == 0
                || vote.batchRoot == 0 || vote.epochHash == 0 || vote.voteDataHash == 0
                || vote.bitmap == 0 || vote.keyCount == 0 || vote.keyCount > 64
                || (vote.keyCount < 64 && vote.bitmap >> vote.keyCount != 0)
        ) revert InvalidVoteJournal();
        uint256 votes;
        uint64 bits = vote.bitmap;
        while (bits != 0) {
            bits &= bits - 1;
            ++votes;
        }
        if (votes < (uint256(vote.keyCount) * 2 + 2) / 3) revert InvalidVoteJournal();
        verifier.verify(seal, BLS_IMAGE(), sha256(journal));
    }
}

/// @dev Explicit checked-coordinate guest candidate; same local-only scope.
/// The original diagnostic remains pinned to9aab and cannot accept this image.
contract BNBRiscZeroHintedVoteDiagnostic is BNBRiscZeroVoteDiagnostic {
    constructor(IRiscZeroVerifier verifier_) BNBRiscZeroVoteDiagnostic(verifier_) {}

    function BLS_IMAGE() public pure override returns (bytes32) {
        return 0xee7d7ec0047419866b74142713542217b4122daeb9c098e5cec8730d956c2909;
    }
}
