// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IRiscZeroVerifier} from "../src/bridge/Risc0HeaderUpdater.sol";
import {MPTReceiptProofCore} from "../src/bridge/MPTReceiptProofCore.sol";

/// @notice Local diagnostic: native serialization proof + receipt inclusion.
/// @dev No authenticated anchor/finality, root storage, mint, burn or unlock.
contract NativeProofDiagnostic {
    struct Header {
        uint64 number;
        bytes32 blockHash;
        bytes32 parentHash;
        bytes32 receiptRoot;
    }

    struct PublicBatch {
        uint256 sourceId;
        uint256 start;
        uint256 end;
        uint256 count;
        bytes32 anchor;
        bytes32 endHash;
        bytes32 root;
    }

    IRiscZeroVerifier public immutable verifier;
    bytes32 public immutable nativeImage;
    error InvalidNativeCommitment();

    constructor(IRiscZeroVerifier verifier_, bytes32 image_) {
        require(block.chainid == 31337 || block.chainid == 31338, "local diagnostic only");
        require(address(verifier_).code.length != 0 && image_ != bytes32(0), "invalid verifier/image");
        verifier = verifier_;
        nativeImage = image_;
    }

    function verifyHeaderLog(
        bytes calldata seal,
        bytes calldata journal,
        Header calldata header,
        uint256 txIndex,
        uint256 localLogIndex,
        bytes[] calldata nodes
    ) external view returns (MPTReceiptProofCore.VerifiedLog memory) {
        _validateCommitment(journal, header);
        verifier.verify(seal, nativeImage, sha256(journal));
        return MPTReceiptProofCore.verifyLog(header.receiptRoot, txIndex, localLogIndex, nodes);
    }

    function _validateCommitment(bytes calldata journal, Header calldata header) private pure {
        if (journal.length != 224) revert InvalidNativeCommitment();
        PublicBatch memory batch = abi.decode(journal, (PublicBatch));
        if (
            !(batch.sourceId == 103 || batch.sourceId == 56) || batch.count != 1 || batch.start != header.number
                || batch.end != batch.start || batch.anchor != header.parentHash || batch.endHash != header.blockHash
                || batch.root
                    != keccak256(
                        abi.encode(batch.sourceId, batch.start, header.blockHash, header.parentHash, header.receiptRoot)
                    )
        ) revert InvalidNativeCommitment();
    }
}
