// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {NativeProofDiagnostic} from "./NativeProofDiagnostic.sol";
import {IRiscZeroVerifier} from "../src/bridge/Risc0HeaderUpdater.sol";
import {MPTReceiptProofCore} from "../src/bridge/MPTReceiptProofCore.sol";

interface VmNativeDiagnostic {
    function readFile(string calldata) external view returns (string memory);
    function parseJsonBytes(string calldata, string calldata) external pure returns (bytes memory);
    function parseJsonBytes32(string calldata, string calldata) external pure returns (bytes32);
    function parseJsonUint(string calldata, string calldata) external pure returns (uint256);
    function parseJson(string calldata, string calldata) external pure returns (bytes memory);
    function expectRevert() external;
    function chainId(uint256) external;
}

/// @dev Explicit mock: these tests verify composition/format, not Groth16.
contract DevMockNativeVerifier is IRiscZeroVerifier {
    bytes32 private immutable expectedImage;

    constructor(bytes32 image) {
        expectedImage = image;
    }

    function verify(bytes calldata seal, bytes32 image, bytes32) external view {
        require(image == expectedImage && keccak256(seal) == keccak256(hex"01"), "mock-only seal/image");
    }
}

contract NativeProofDiagnosticTest {
    VmNativeDiagnostic private constant vm =
        VmNativeDiagnostic(address(uint160(uint256(keccak256("hevm cheat code")))));

    function fixture()
        private
        view
        returns (bytes memory journal, NativeProofDiagnostic.Header memory header, bytes32 image)
    {
        string memory json = vm.readFile("test/fixtures/native-header-bnb.json");
        journal = vm.parseJsonBytes(json, ".journal");
        header = NativeProofDiagnostic.Header(
            uint64(vm.parseJsonUint(json, ".blockNumber")),
            vm.parseJsonBytes32(json, ".blockHash"),
            vm.parseJsonBytes32(json, ".parentHash"),
            vm.parseJsonBytes32(json, ".receiptRoot")
        );
        image = vm.parseJsonBytes32(json, ".imageId");
    }

    function proof(string memory name) private view returns (uint256 index, uint256 logIndex, bytes[] memory nodes) {
        string memory json = vm.readFile(string.concat("test/fixtures/", name));
        index = vm.parseJsonUint(json, ".txIndex");
        logIndex = vm.parseJsonUint(json, ".logIndex");
        nodes = abi.decode(vm.parseJson(json, ".proofNodes"), (bytes[]));
    }

    function testNativeGuestJournalAndBothActualType4MPTWithExplicitMock() public {
        (bytes memory journal, NativeProofDiagnostic.Header memory header, bytes32 image) = fixture();
        NativeProofDiagnostic diagnostic = new NativeProofDiagnostic(new DevMockNativeVerifier(image), image);
        for (uint256 i; i < 2; ++i) {
            string memory name = i == 0 ? "native-type4-index16.json" : "native-type4-index107.json";
            (uint256 index, uint256 logIndex, bytes[] memory nodes) = proof(name);
            MPTReceiptProofCore.VerifiedLog memory result =
                diagnostic.verifyHeaderLog(hex"01", journal, header, index, logIndex, nodes);
            string memory json = vm.readFile(string.concat("test/fixtures/", name));
            bytes32[] memory topics = abi.decode(vm.parseJson(json, ".topics"), (bytes32[]));
            require(keccak256(abi.encode(result.topics)) == keccak256(abi.encode(topics)), "different native topics");
            require(keccak256(result.data) == keccak256(vm.parseJsonBytes(json, ".data")), "different native data");
        }
    }

    function testChangedPublicHeaderCommitmentRejectedBeforeReceiptUse() public {
        (bytes memory journal, NativeProofDiagnostic.Header memory header, bytes32 image) = fixture();
        NativeProofDiagnostic diagnostic = new NativeProofDiagnostic(new DevMockNativeVerifier(image), image);
        (uint256 index, uint256 logIndex, bytes[] memory nodes) = proof("native-type4-index16.json");
        for (uint256 i; i < 4; ++i) {
            NativeProofDiagnostic.Header memory changed =
                NativeProofDiagnostic.Header(header.number, header.blockHash, header.parentHash, header.receiptRoot);
            if (i == 0) changed.number += 1;
            else if (i == 1) changed.blockHash = bytes32(uint256(changed.blockHash) ^ 1);
            else if (i == 2) changed.parentHash = bytes32(uint256(changed.parentHash) ^ 1);
            else changed.receiptRoot = bytes32(uint256(changed.receiptRoot) ^ 1);
            vm.expectRevert();
            diagnostic.verifyHeaderLog(hex"01", journal, changed, index, logIndex, nodes);
        }
        vm.expectRevert();
        diagnostic.verifyHeaderLog(hex"01", bytes.concat(journal, hex"00"), header, index, logIndex, nodes);
    }

    function testWrongMPTAndMockSealRejected() public {
        (bytes memory journal, NativeProofDiagnostic.Header memory header, bytes32 image) = fixture();
        NativeProofDiagnostic diagnostic = new NativeProofDiagnostic(new DevMockNativeVerifier(image), image);
        (uint256 index, uint256 logIndex, bytes[] memory nodes) = proof("native-type4-index16.json");
        vm.expectRevert();
        diagnostic.verifyHeaderLog(hex"01", journal, header, index + 1, logIndex, nodes);
        vm.expectRevert();
        diagnostic.verifyHeaderLog(hex"02", journal, header, index, logIndex, nodes);
    }

    function testDiagnosticDeploymentRejectsLiveChainIds() public {
        (,, bytes32 image) = fixture();
        DevMockNativeVerifier mock = new DevMockNativeVerifier(image);
        vm.chainId(56);
        vm.expectRevert();
        new NativeProofDiagnostic(mock, image);
        vm.chainId(103);
        vm.expectRevert();
        new NativeProofDiagnostic(mock, image);
        vm.chainId(31337);
    }
}
