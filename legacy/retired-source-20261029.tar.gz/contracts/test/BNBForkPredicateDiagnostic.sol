// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {BNBRawHeaderVoteDiagnostic} from "./BNBRawHeaderVoteDiagnostic.sol";
import {RLPReader} from "../src/bridge/lib/RLPReader.sol";

/// @dev Nine pinned BNBv1.7.8 mainnet config predicates only. Caller supplied
/// identity/height/time is not a bootstrap proof or native fork validation.
contract BNBForkPredicateDiagnostic is BNBRawHeaderVoteDiagnostic {
    bytes32 public constant PINNED_GENESIS = 0x0d21840abff46b96c84b2ac9e10e4f5cdaeb5693cb665db62a2f3b02d2d57b5b;
    bytes32 public constant CONFIG_SOURCE_SHA256 = 0x2b8a681c79dd05555ec7186bd1a69da47add698f6782da2e514c805cefb4be4d;

    // bits: London,Luban,Bohr,Lorentz,Maxwell,Fermi,Osaka,Mendel,Pasteur.
    function forkFlags(uint64 sourceChainId, bytes32 genesis, uint64 number, uint64 timestamp)
        public pure returns (uint16 flags)
    {
        if (sourceChainId != 56 || genesis != PINNED_GENESIS) revert InvalidWitness();
        bool london = number >= 31302048;
        if (london) flags |= 1;
        if (number >= 29020050) flags |= 2;
        if (!london) return flags; // every listed timestamp predicate requires IsLondon
        if (timestamp >= 1727317200) flags |= 4;
        if (timestamp >= 1745903100) flags |= 8;
        if (timestamp >= 1751250600) flags |= 16;
        if (timestamp >= 1768357800) flags |= 32;
        if (timestamp >= 1777343400) flags |= 64|128; // Osaka/Mendel activate together here
        if (timestamp >= 1787625000) flags |= 256;
    }

    function rawForkFlags(bytes calldata raw, uint64 sourceChainId, bytes32 genesis)
        external pure returns (bytes32 blockHash, uint64 number, uint64 timestamp, uint16 flags)
    {
        HeaderCommitment memory header = _header(raw);
        RLPReader.Item[] memory fields = RLPReader.listItems(raw);
        uint256 time = RLPReader.itemUint(raw,fields[11]);
        if (time > type(uint64).max) revert InvalidWitness();
        blockHash = header.blockHash; number = header.number; timestamp = uint64(time);
        flags = forkFlags(sourceChainId,genesis,number,timestamp);
    }
}
