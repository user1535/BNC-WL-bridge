# RISC0 증명 범위와 브리지 보안 평가

## 현행 적용 범위 — 2026-10-06

이 문서는 **향후 RISC0 확장과 과거 실험의 보안 평가**로 보존한다. 아래 2026-10-01 기준의 API 미구현·운영자 등록 불필요·헤더 사용자 제출 설명은 당시 모델의 기록이며 현재 기본 시제품 설명이 아니다. 현재 기본은 신뢰 RPC·운영자 receipt root 등록·MPT이며 RISC0은 실행하지 않는다. 원본 진위는 RPC와 root 등록 운영자를 신뢰한다. MPT는 등록 root 기준 포함 관계를 검사한다. 현행 구현과 미검증 범위는 [구현 설명](implementation-details.md)과 [현재 상태](current-status-report.md)를 따른다.

## 보존된 과거 평가 (2026-10-01)

검토 기준: **2026-10-01 15:08 KST**의 로컬 코드와 저장 결과. 목표 운영 방식은 사용자 설명을 따르며, 목표와 현재 구현을 구분한다. 새로운 공격 거래나 새 실체인 증명은 실행하지 않았다.

## 핵심 판정

목표 흐름은 **USER가 원본 체인에서 자기 자산을 잠금 → 신뢰한 교수님/연구자 서버가 충분히 지난 블록을 공개 웹/RPC에서 읽어 증명 패키지 생성 → USER가 목적지 체인 거래를 직접 서명·제출 → 계약 검증 뒤 로그에 지정된 USER 계정에 wrapped token mint**다. 역방향은 USER의 wrapped burn, 서버의 증명 제공, USER의 원본 체인 청구와 기존 잠금 해제다. 서버는 USER 거래를 대신 서명·방송하지 않는다. 현재 코드는 이 흐름을 로컬 Anvil·Go CLI·Rust host로 재현했다. USER와 원격 서버 간 실제 전달 API, 실체인 adapter 및 실자산 배포는 아직 없다. [구현 흐름](/home/gangryun/BNC-WL/docs/implementation-details.md), [로컬 Groth16 결과](/home/gangryun/BNC-WL/results/local-risc0-current/summary.json).

본 연구는 완전한 trustless bridge를 목표로 하지 않는다. **신뢰한 서버가 신뢰한 공개 웹/RPC의 충분히 지난 블록만 증명한다**는 운영 전제가 원본 데이터의 신뢰 근거다. RISC0는 그 입력에 대해 선택된 게스트가 수행한 계산과 공개 journal을 증명한다. source 합의·canonical성·최종성을 독립 증명한다는 뜻은 아니다. 그 독립 검증은 선언한 연구 범위 밖이다. [RISC Zero v3.0.0 검증 인터페이스](https://github.com/risc0/risc0-ethereum/blob/v3.0.0/contracts/src/IRiscZeroVerifier.sol).

**별도 운영자 서명은 위 목표 흐름의 필수 단계가 아니다.** 사용자는 증명 과정이 외부에 공개되지 않는다고 설명했다. 게스트 ELF·host와 임의 입력용 증명 서비스가 외부에 제공되지 않고 서버가 정직하게 원본 데이터를 선택한다면, 외부가 가짜 입력의 새 유효 증명을 만들 수 있다고 이 조사에서 단정할 근거는 없다. 다만 검증기는 증명 생성자의 신원 자체를 증명하지 않는다. 게스트 ELF 공개·유출 또는 임의 입력 증명 서비스 개방은 그 운영 전제를 바꾼다. RISC Zero는 증명에 게스트 ELF가 필요하고 검증에는 image ID를 사용한다고 설명한다. [RISC Zero 3.0.5 Prover](https://docs.rs/risc0-zkvm/3.0.5/risc0_zkvm/trait.Prover.html), [Receipt](https://docs.rs/risc0-zkvm/3.0.5/risc0_zkvm/struct.Receipt.html).

## 1. 행위자와 온체인 검사

| 단계 | 목표와 현재 코드의 대응 |
| --- | --- |
| 원본 거래 | USER가 [bridgeLock](/home/gangryun/BNC-WL/contracts/src/token/BridgeLockableToken.sol:68)을 직접 서명한다. 토큰은 USER 계정 내부 locked balance를 늘리고 Locked 로그를 낸다. 별도 vault로 송금하지 않는다. 역방향에는 [bridgeBurn](/home/gangryun/BNC-WL/contracts/src/token/BridgeWrappedToken.sol)을 쓴다. |
| 서버 수집 | 신뢰한 서버가 충분히 지난 블록의 header·receipt·거래를 공개 웹/RPC에서 읽는다. 현재 [Go adapter](/home/gangryun/BNC-WL/proof-generator/internal/chain/adapter.go:92)는 로컬 RPC를 읽고 [제출 전 재조회](/home/gangryun/BNC-WL/proof-generator/cmd/bridge-proof/mode.go:208)한다. 실제 서버 API와 실체인 확인 기간은 미완료다. |
| 증명 패키지 | 서버는 header batch의 RISC0 seal·journal·batch data와 receipt MPT proof를 USER에게 반환한다. 현재 [Rust host](/home/gangryun/BNC-WL/risc0/host/src/main.rs:191)와 [Go package](/home/gangryun/BNC-WL/proof-generator/cmd/bridge-proof/main.go:47)가 로컬에서 이를 생성한다. Go는 USER 키를 받거나 거래를 방송하지 않는다. |
| USER 제출 | USER가 header가 미등록이면 [submitHeaderProof](/home/gangryun/BNC-WL/contracts/src/bridge/Risc0HeaderUpdater.sol:68)를, 이어 [submitLockProof](/home/gangryun/BNC-WL/contracts/src/bridge/LockMintReceiver.sol:38)를 목적지에 직접 서명·제출한다. 이미 등록된 header는 재사용할 수 있다. |
| 계약 지급 | updater는 고정 image ID와 journal digest에 대한 seal을 검증해 receipt root를 저장한다. receiver는 그 root 아래 MPT 포함성, source token emitter, event·ID·destination·recipient·replay를 확인하고 **로그에 지정된 계정**에 mint한다. 거래를 보낸 주소가 자동으로 수령인이 되는 구조가 아니다. 역방향 [BurnUnlockReceiver](/home/gangryun/BNC-WL/contracts/src/bridge/BurnUnlockReceiver.sol:41)는 기존 잠금 한도에서 해제한다. |

**RISC0 header 증명과 receipt/log MPT 청구는 별개 검사다.** minimal/strict 게스트는 header batch 관계를 증명하고 updater가 root를 저장한다. lock/burn 거래가 그 root 아래에 있는지는 [MPTReceiptProofCore](/home/gangryun/BNC-WL/contracts/src/bridge/MPTReceiptProofCore.sol:19)가 목적지 체인에서 검증한다. USER 한 명의 lock마다 RISC0 증명을 새로 만드는 것이 아니라, 등록된 header를 여러 USER가 공유할 수 있다.

## 2. 선언한 신뢰 가정과 범위

1. **데이터 소스:** 신뢰한 공개 웹/RPC가 반환한 WorldLand·BNB 체인 데이터를 사용한다. 악의적 공급자가 완전히 조작된 체인을 일관되게 주는 경우와 source 합의 전체의 zkVM 독립 검증은 범위 밖이다.
2. **서버:** 교수님/연구자가 운영하는 서버가 정직하게 충분히 지난 블록을 선택하고 실제 관측 데이터만 증명한다. USER 개인키를 갖지 않고 USER 거래를 방송하지 않는다. 증명 과정은 외부 비공개 운영이라는 사용자 설명을 전제로 한다. 다만 실제 서비스의 게스트 ELF·host 배포 범위와 임의 입력 API 차단은 로컬 실험만으로 확인되지 않는다.
3. **배포:** 같은 신뢰된 주체가 공식 또는 검증된 verifier와 올바른 guest image ID, anchor, 체인 ID, token/receiver를 배포한다. 악의적 운영자·배포자는 범위 밖이다. 정직한 배포자의 실수는 여전히 점검해야 한다.

정직한 공개 소스에서도 확인 시간 이후의 재구성 위험이 정확히 0이 되는 것은 아니다. WorldLand·BNB별 충분한 확인 시간과 충돌 시 동결·복구 정책은 목표 운영 방식에 맞게 정해야 한다. 반면 source 전체 합의를 게스트에 추가하거나 운영자 서명 키를 새로 도입하는 것은 이 모델의 필수 완료 조건이 아니다.

[DevHeaderRegistry](/home/gangryun/BNC-WL/contracts/src/bridge/DevHeaderRegistry.sol:6)의 devOperator는 로컬 fast/dev 실험에서 root를 직접 기록하는 배포자이며, 위 목표 RISC0 사용자 경로의 서버 승인자가 아니다. 그 키의 위험을 일반 zk 경로에 그대로 적용하지 않는다.

## 3. 현재 증명 수준

| 경로 | 실제 확인된 것 | 확인하지 않는 것과 자산 연결 |
| --- | --- | --- |
| dev/fast | 등록된 root 아래 receipt MPT·event·중복 청구. | RISC0 header proof 없음. 개발용 운영자 경로. |
| minimal / accelerated | 번호·부모 hash·anchor, 0이 아닌 hash/root, batch Merkle root와 224-byte journal. 실제 로컬 Groth16/EVM·양방향 MPT 자산 청구. | 전체 header RLP hash·독립 source 합의 없음. 로컬 자산 경로에 연결. [guest](/home/gangryun/BNC-WL/risc0/methods/guest/src/main.rs:67). |
| strict | 위 관계와 로컬 Ethereum 형태 canonical RLP의 Keccak hash·parent/number/root 결합. 실제 로컬 Groth16/EVM 수락. | WorldLand/BNB native 합의·finality 아님. 로컬 자산 경로에 연결. [guest](/home/gangryun/BNC-WL/risc0/methods-bound/guest/src/main.rs:68). |
| native WorldLand/BNB | 각 체인 형태의 full RLP/hash·parent/number/root 결합을 별도 실제 Groth16/EVM 진단. | 실자산 root 등록·청구와 미연결. [WorldLand](/home/gangryun/BNC-WL/results/native-worldland-evm/summary.json), [BNB](/home/gangryun/BNC-WL/results/native-bnb-evm-mpt/summary.json). |
| BNB BLS hinted | 공급 epoch 키·bitmap/quorum·pairing과 352-byte journal의 실제 Groth16/EVM 진단. | 활성 validator 집합의 독립 인증·자산 root 등록 없음. [결과](/home/gangryun/BNC-WL/results/bnb-vote-hinted-groth16-evm/summary.json). |

native/BLS 진단의 미인증 항목은 기술적으로 표시해야 하지만 **서버가 신뢰한 데이터를 고른다는 연구 가정을 부정하는 결함으로 세지 않는다.** 진단 결과는 rootRegistryUpdated=false, assetClaimsSubmitted=0, chainAuthenticated=false, realAssetDeploymentAllowed=false를 명시한다. [BNB 진단 계약](/home/gangryun/BNC-WL/contracts/test/BNBRiscZeroVoteDiagnostic.sol:59).

## 4. 현재 구현에 맞춘 보안·운영 위험

| 항목 | 판정 | 조건·영향·근거 |
| --- | --- | --- |
| **S1. 비공개 증명 경계 이탈** | **조건부 중대 위험; 현재 외부의 새 증명 생성 능력은 미확인.** | [host](/home/gangryun/BNC-WL/risc0/host/src/main.rs:191)는 로컬 파일의 입력으로 증명할 수 있고 [updater](/home/gangryun/BNC-WL/contracts/src/bridge/Risc0HeaderUpdater.sol:68)는 제출자를 제한하지 않는다. 외부가 고정 image의 게스트 ELF/host 또는 임의 입력 증명 서비스를 얻으면 내부적으로 일관된 허위 header·receipt root의 **유효한 증명**을 만들 수 있다. 허위 root 아래 가짜 Locked/Burned 로그로 청구를 시도하거나 정상 header 진행을 막을 수 있다. 이는 Groth16 위조가 아니다. 사용자 설명의 서버 전용 증명 운영이 실제로 유지된다면 이 공격 경로가 지금 열려 있다고 단정할 수 없다. |
| **S2. 이른 블록 수락·reorg** | **실체인 정책 미완료.** | 로컬 [SafeHeader](/home/gangryun/BNC-WL/proof-generator/internal/chain/adapter.go:92)는 최신 높이에서 confirmations를 빼고 제출 전 다시 조회한다. 정직한 소스에도 더 깊은 재구성이 가능하고 [updater](/home/gangryun/BNC-WL/contracts/src/bridge/Risc0HeaderUpdater.sol:72)는 충돌 복구 정책 없이 latestHash를 확장한다. WorldLand/BNB별 실제 대기 기간·중단·복구 시험이 남았다. |
| **S3. 정직한 배포자의 설정 실수** | **신뢰 가정 안의 잔여 위험.** | 잘못된 verifier, guest image, anchor, source/destination ID, token/receiver binding은 의도한 보장을 바꾼다. 생성자의 verifier 확인은 code.length>0까지다. 배포 code hash와 설정 manifest 대조가 필요하다. 기존 배포의 verifier를 일반 USER가 교체할 수 있다는 뜻은 아니다. [생성자](/home/gangryun/BNC-WL/contracts/src/bridge/Risc0HeaderUpdater.sol:49). |
| **S4. MPT/RLP·event 파서 결함** | **실제 결함 1건 수정; 전체 감사 미완료.** | 빈 branch value의 비포함을 라이브러리가 한때 ok=true로 반환했으나 현재 수정됐다. 수정 후 geth 포함128·비포함6, mutation256, Foundry53과 fast 회귀가 통과했다. receiver는 비어 있지 않은 receipt도 요구하므로 과거 무단 mint는 입증되지 않았다. 전체 receiptRoot→txIndex→typed receipt→log 경로의 추가 검증은 남는다. [결과](/home/gangryun/BNC-WL/results/mpt-differential-128/summary.json), [receipt core](/home/gangryun/BNC-WL/contracts/src/bridge/MPTReceiptProofCore.sol:19). |
| **S5. 증명 지연·청구 불가** | **실측 처리량 실패.** | 300.146초 로컬 시험에서 source 300헤더 동안 destination 수락은 4헤더, 최대 lag 296이었다. 증명 서버 장애·자원 소진은 USER의 mint/unlock도 늦춘다. BNB hinted 분할 증명 성공은 장기 accepted 처리량 성공이 아니다. [측정](/home/gangryun/BNC-WL/results/paced-groth16/summary.json), [BNB 진단](/home/gangryun/BNC-WL/results/bnb-vote-hinted-groth16-from-recursion/summary.json). |
| **S6. 실자산 경계 미완료** | **현재 라이브 자산 피해 경로 아님.** | 현재 updater·지원 토큰은 로컬 chain 31337/31338과 같은-owner 내부 잠금·비양도 wrapped 모델이다. 기존 ERC-20/native WL·실체인으로 단순 확장하면 권한·상환 가정이 달라진다. 실제 자산 선택, adapter, 배포 binding과 회계 검증이 남았다. [토큰](/home/gangryun/BNC-WL/contracts/src/token/BridgeLockableToken.sol), [updater guard](/home/gangryun/BNC-WL/contracts/src/bridge/Risc0HeaderUpdater.sol:56). |

S1은 게스트 ELF/임의 입력 증명 서비스가 외부에 열리는 **조건부** 시나리오다. 최소 게스트는 비영 hash/root와 연결 관계만 검사하므로 실제 원본 블록이 아닌 데이터도 그 조건을 만족할 수 있다. strict의 RLP hash 결합이나 BNB 공급키 pairing도 source 합의를 독립 증명하지 않는다. 그러나 현재 외부에서 해당 ELF/서비스에 접근할 수 있다는 증거는 확인하지 않았다. [minimal 검사](/home/gangryun/BNC-WL/risc0/methods/guest/src/main.rs:68), [strict 검사](/home/gangryun/BNC-WL/risc0/methods-bound/guest/src/main.rs:68).

그 조건부 경로에서도 피해를 무제한 제3자 탈취로 단정하지 않는다. 현재 mint는 로그의 같은 계정 recipient에게 지급하고 wrapped는 비양도다. unlock은 같은 계정의 기존 locked balance 한도에서 일어난다. 실제 영향은 채택할 자산·배포 구성에 달려 있다. [mint](/home/gangryun/BNC-WL/contracts/src/bridge/LockMintReceiver.sol:38), [unlock](/home/gangryun/BNC-WL/contracts/src/bridge/BurnUnlockReceiver.sol:41), [잠금 제한](/home/gangryun/BNC-WL/contracts/src/token/BridgeLockableToken.sol:101).

## 5. 확인된 방어와 완료 기준

- **이미 발급된 증명 변조 거부:** updater는 batch Merkle root·전체 224-byte journal을 재계산하고 고정 image ID 및 sha256(journal)에 대한 Groth16 seal을 검증한다. header/root/journal을 바꾼 기존 증명을 수락한 사례는 없다. [업데이터](/home/gangryun/BNC-WL/contracts/src/bridge/Risc0HeaderUpdater.sol:68).
- **receipt·event·중복 청구 방어:** 저장 root 아래 MPT 포함성, emitter, event ID·destination·recipient, claimed mapping을 확인한다. 타인이 USER의 청구 거래를 보내더라도 지급 대상을 바꿀 수 없다. [mint](/home/gangryun/BNC-WL/contracts/src/bridge/LockMintReceiver.sol:38), [unlock](/home/gangryun/BNC-WL/contracts/src/bridge/BurnUnlockReceiver.sol:41).
- **로컬 생성기 점검:** Go 경로는 source header를 재조회하고 새/캐시 receipt의 image·journal·kind·seal을 대조하며 RISC0_DEV_MODE를 거부한다. 외부 운영 서버의 접근 통제까지 검증했다는 뜻은 아니다. [LocalProver](/home/gangryun/BNC-WL/proof-generator/internal/risc0/prover.go:94).

현재 연구 모델에서 남은 작업:

- [ ] 신뢰한 서버가 실제 WorldLand/BNB 웹/RPC에서 충분히 지난 USER 거래·header·receipt를 직접 읽고, USER가 준 식별자는 검색 조건으로만 사용하며 반환 데이터는 서버 조회 결과에서 구성한다.
- [ ] source별 확인 기간·재조회 시점과 reorg 발견 시 증명·청구 중단 및 복구 정책을 정하고 시험한다.
- [ ] 게스트 ELF/host 배포 범위와 임의 입력용 proving API 노출 여부를 고정한다. 외부 proving을 허용하는 방향으로 바뀔 때 운영자 서명 또는 온체인 제출 권한을 다시 설계한다.
- [ ] 서버가 USER에게 header 증명·MPT 청구 패키지를 돌려주고 USER가 목적지 거래를 직접 서명·제출하는 실제 서비스 경로를 로컬 CLI 재현과 별도로 검증한다.
- [ ] 로컬 전용 chain guard와 native/BLS 진단을 넘어 실체인 adapter·자산·verifier/image/anchor/token binding을 검증한다.
- [ ] 실제 서버 경로를 포함한 accepted-head 처리량을 다시 측정하고 MPT/RLP·계약·배포 구성을 추가 감사한다.

이 목록에 **source 전체 합의의 zkVM 재구현, 악의적 교수님/연구자 서버나 완전히 조작된 신뢰 RPC에 대한 방어, 별도 운영자 서명 키**를 필수 항목으로 넣지 않는다. 이들은 선언한 연구 범위 밖이거나 비공개 증명 운영 전제가 달라질 때의 선택이다.

## 6. 조사 방법과 고정 증거

코드 SHA256: minimal guest 7dca91f9d325147064cc72673079a558b408eabf3c7f5e964f089018a3b1aa38, strict guest 7efdc15dcdb88a58f86e6dcd75a790c2e142eca917fc7d38482428fc386a7ac2, native types 4f867ede937610092d432e9460ce7dfb65c5b4b68abdf91e8a429cc22e5be051, BNB hinted types 63eb7e98eed34cf899a51706e19f9781e2b503ec4407fb7c2ec4b52bcb37fe1b, updater bdf77e455aa823ad784c2938c2b170b1fe704a024d30e16cb7dea82f53818b5d, MPT library f6bfd4d8708018d4421f6c3099a76938a026e23faac99699fe91f04fb41f2ce8.

이 보고서는 위 코드와 저장된 로컬 결과, [공식 RISC Zero v3.0.0 verifier](https://github.com/risc0/risc0-ethereum/blob/v3.0.0/contracts/src/IRiscZeroVerifier.sol), [RISC Zero 3.0.5 Prover](https://docs.rs/risc0-zkvm/3.0.5/risc0_zkvm/trait.Prover.html)를 대조했다. 정적 검토와 저장 증거 확인의 범위이며 전체 감사·형식 검증·새 실체인 거래·새 proof 생성은 포함하지 않는다.
