# BNC-WL 문서

2026-10-29 기본 경로는 **서버 운영자·RPC 신뢰 + 사용자 직접 제출 + 실제 RISC0 연산 증명**이다.

- [로컬 사용 매뉴얼](local-demo-manual.md)
- [현재 상태](current-status-report.md)
- [구현·API·검증 범위](implementation-details.md)
- [범위·후속 작업](plan-gap-analysis.md)
- [이전 연산 증명 보존본](../legacy/rpc-mpt-risc0-internal-20261006/README.md)
- [제거한 구현 보존본](../legacy/tee-retired-20261029/README.md)

private_keyless_Bridge.docx, source/bridge-design.docx 및 archive의 문서는 과거 모델의 기록이다. 이번 복구의 최신 사양은 위 Markdown 문서를 따른다. protocol-sources와 JSON source manifest는 출처 기록이므로 변경하지 않는다.
