# 고정된 프로토콜 인코더 참조

현재 기본(2026-10-06)은 신뢰 RPC·MPT이며 이 디렉터리의 고정된 native codec·합의 자료는 출처 기록 및 향후 확장 참조다. 해당 자료가 기본 시제품의 합의 인증을 제공한다는 뜻은 아니다. 원본 소스·라이선스·manifest 해시는 유지한다.

WorldLand v1.1.3 commit 5de8aad8131d2495c98b95558697e5a04f518630, BNB bsc v1.7.8 commit cdb7548b5baacfdae92f9f63437d6456411665f3의 소스 참조다. manifest.json은 URL과 원본 SHA를 보존한다. LGPL-3.0 관련 원본 COPYING.LESSER와 파일별 저작권 고지를 보존했다. source hash/rlpgen encoder는 serialization 비교용이며 대상 live node release/fork 인증이 아니다.

internal/protocoloracle은 원본 generated EncodeRLP 로직을 fixture oracle로만 실행한다. BNB 로직은 원본 그대로, WorldLand는 RLP import 경로만 고정된 geth v1.14.12로 바꾼다. header.go harness는 geth 기본 타입과 WorldLand/BNB 확장 필드다. oracle-manifest.json에 원본/수정 SHA와 변경 범위를 기록했다. 실제 WorldLand RLP 라이브러리 전체를 실행한 노드 fixture가 아니므로 합의나 라이브 호환성을 주장하지 않는다.

Go 기반 비교 fixture는 인공적으로 만든 12 WorldLand optional 조합과 64 BNB 조합이다. 실체인 RPC, transaction, vote 또는 finality fixture로 표시하지 않는다. 이전에 다운로드한 v1.1.3 tag 소스는 GitHub API로 같은 commit임을 확인했고, 이후 header-rlp 소스는 commit URL을 사용했다.

## 실제 RPC fixture와 receipt codec 확장

WorldLand103/BNB56 각2개의 실제 full header RLP/hash/parent 및 변조 root 거부를 확인했다(native-header-worldland-rechecked/native-header-bnb-rechecked). BNB JSON의 milliTimestamp는 Time와 MixDigest에서 파생하는 메타데이터로 검사하며 RLP 필드로 추가하지 않는다. 관측 노드 version은 WL1.1.2-unstable/BNB1.7.7이며 고정 encoder reference와 관측 fixture 일치 범위로만 해석한다.

BNB121receipt actual root 및 두 type4 MPT fixture의 SHA는 docs/native-receipt-fixtures.json. [공식 EIP-7702](https://eips.ethereum.org/EIPS/eip-7702)의 type0x04 receipt payload(status,cumulativeGasUsed,bloom,logs)와 [geth v1.15.11 receipt 소스](https://github.com/ethereum/go-ethereum/blob/v1.15.11/core/types/receipt.go)를 참조했다. geth-v1.15.11-receipt.go는 참조 원문/SHA 보존이며 빌드 의존성은1.14.12를 유지한다. 서명 authorization은 receipt payload에 넣지 않는다. raw source와 offline 포함성 검사는 source 합의·최종성을 인증하지 않는다.

## BNB vote attestation offline 진단 완료

bnb-attestation-inspect --input <saved header> --layout post-luban-non-epoch는 pinned v1.7.8 vote.go/parlia.go를 기준으로 raw extraData의 bitmap·96byte aggregate signature·voteData4필드/Keccak hash를 진단한다. epoch/fork 선택은 supplied layout 가정이며 자동 인증하지 않는다. results/native-bnb-attestation: 실제 두 header에서 bitmap set20bits, source<target·target의 supplied parent 일치, canonical/truncated/trailing/잘못된 range·empty fields 및 header변조 거부·Go race PASS. source signature/BLS key·validator set·quorum·finality는 모두미검증false다. 새로운guardian 또는 fullParlia 구현은 도입하지 않았다. vote.go 원문/SHA는 protocol-sources manifest에 보존했다. 실제 서명 검증 전에 인증된 validator snapshot/epoch 전이와 justified anchor 정책이 필요하다.

Vote wire reference: [pinned BNB vote.go](https://github.com/bnb-chain/bsc/blob/cdb7548b5baacfdae92f9f63437d6456411665f3/core/types/vote.go). parser 구현은 quorum/BLS/finality 인증으로 표시하지 않는다.

## BNB 실제 aggregate pairing 진단 추가

[서명 진단 명세](/home/gangryun/BNC-WL/docs/implementation-details.md#bnb-diagnostics): saved actual epoch124532000 supplied21keys, headers124532730/1의20참여/required14·actualpairing PASS. key possession/validator set·전이/finality/chainauth는false다. pin된BNBgo.mod/snapshot 및Prysm5.3.2 signature/publickey/interface·GPLLICENSE 원문/SHA를manifest에보존했다. 기존wire decode만성공한기록과구분한다. 선택CGo CLI는기본chain/fast에연결하지않는다.

blst v0.3.13의 e2.c·no_asm.h·Apache-2.0 LICENSE를 pinned Go module cache에서 보존했다. E2 Compress_BE의 x.c1/x.c0와 y 부호 규칙이 새 로컬 EVM 압축 binding의 참조다. URL 직접 fetch는 이 실행에서 cache miss로 실패했으며 module go.mod/go.sum에 고정된 로컬 원문과 SHA를 manifest에 기록했다. 공개 +/-point4개의 blst Deserialize/SigValidate/Compress oracle와 EVM을 실제 대조했다. 원문은 실행 코드나 instruction으로 취급하지 않는다.

2026-09-29: 고정 BNB v1.7.8 params/config.go를 공식 commit에서 추가 다운로드했다. mainnet fork predicate 비교 준비용이며 다운로드·SHA 일치가 source chain bootstrap 인증은 아니다. 파생 method harness는 원문 method를 유지하고 별도 oracle-manifest에 추적한다. [진단 범위](/home/gangryun/BNC-WL/docs/implementation-details.md#bnb-diagnostics).
