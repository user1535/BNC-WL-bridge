# 사용자 직접 제출 + RISC0 연산 증명 구현

기준: 2026-10-29. 신뢰 대상은 서버 운영자와 RPC다. 현재 기본 경로에는 TEE가 없다.

## 흐름과 권한

1. `wallet/demo-wallet.mjs` 또는 외부 EIP-1193 지갑이 source의 lock/burn 거래를 사용자 계정으로 서명한다.
2. `scripts/proof-service.py`가 confirmation을 확인하고 로컬 운영자의 DevHeaderRegistry에 해당 블록 root를 등록한다.
3. Go `.bin/bridge-proof`가 receipt trie/MPT·이벤트·목적지 청구 calldata를 생성한다.
4. `scripts/receipt-computation.py`가 guest 입력 전체를 키로 캐시하고 bounded worker로 실제 RISC0 composite proof를 생성한다. 재사용 시 SDK에서 검증하며 가짜 영수증이나 execute 결과를 허용하지 않는다.
5. 게스트는 MPT·receipt·이벤트·도메인·금액·수신자·nonce를 검증하고 journal에 입력 commitment를 기록한다. Image ID는 `configs/receipt-computation.json`에 고정한다.
6. 증명 생성 후 원본 block hash/root·confirmation·목적지 등록 root를 다시 확인한다. Reorg나 confirmation 손실이 있으면 패키지 반환을 거부한다.
7. 브라우저는 receipt SHA256, journal과 입력의 연결, MPT와 ABI를 대조한다. 청구 preview와 실제 서명 직전 preview를 다시 실행하면서 SDK 재검증을 요청한다.
8. 사용자가 목적지 청구를 직접 서명한다. 목적지 계약은 MPT·이벤트·도메인·replay를 확인한다.

RISC0 연산 증명은 서버 SDK에서 검증한다. composite proof를 목적지 calldata에 넣어 EVM에서 검증하는 경로는 이번 복구 범위에 포함하지 않는다. 계약의 MPT 검증은 유지한다. 사용자 개인키와 운영자 root 등록 권한은 구분한다.

## API

- `GET /api/manifest`: 공개 체인·계약·runtime, `proofPolicy=trusted-rpc-receipt-root`, `computationPolicy=risc0-receipt-computation`, 고정 guest/검증 위치, 신뢰 모델.
- `POST /api/jobs`: action·transferId·fromBlock만 받는다. 같은 요청은 같은 job으로 합쳐진다.
- `GET /api/jobs/{id}`: queued/running/waiting_confirmations/ready/failed.
- `GET /api/jobs/{id}/package`: source 재확인 및 실제 SDK 재검증 후 receiptBase64·SHA256·journal을 포함하는 패키지를 반환한다. ready 이전에는 거부한다.
- `POST /api/computation/verify`: 패키지의 receipt를 실제 RISC0 SDK로 검증한다. 같은 guest, 실제 journal, 모든 guest 입력의 일치 및 현재 source와 등록 root를 확인한다. 업로드 최대 16 MiB, receipt 최대 8 MiB.
- `/api/chains`, `/api/audit`, `/api/transactions`: 기존 체인 현황·공개 감사·거래 기록.
- `/rpc/wl`, `/rpc/bnb`: 제한된 읽기와 사용자가 이미 서명한 raw transaction 전달. 서버 서명·unlocked send·관리자 RPC는 브라우저 경로에 노출하지 않는다.

Host/Origin과 JSON body 크기 제한을 유지한다. HTTP의 sdkVerified=true 필드를 그대로 믿지 않고 실제 SDK 검증 결과를 확인한다. SDK에 제공하는 입력은 고정한 guest 필드만으로 구성하여 journal commitment와 연결한다.

## 작업·복구·자원

세션/launcher/service flock, 입력별 증명 캐시, 영속 job JSON을 사용한다. 실행 중 중단된 job은 재개 시 queued가 되며 완성된 receipt는 실제 SDK 검증을 거쳐 재사용한다. 새 입력은 다른 캐시를 사용한다. 서비스 종료 시 worker와 host/r0vm process group을 회수한다.

증명 생성은 CPU 최대 12개, RAM/cgroup 가용량 70%, 1800초, 파일당 64 MiB로 제한한다. 실행 경로는 `runtime-config.py`가 `.bin`, PATH와 `.risc0/bin`을 확인한다. RISC0_DEV_MODE와 외부 proving credential은 로컬 증명 프로세스로 전달하지 않는다.

## 테스트

```bash
cargo test --offline --manifest-path risc0/receipt-computation/Cargo.toml -p bridge-receipt-core
go -C proof-generator test ./...
forge test --root contracts
node --test wallet/client.test.mjs
python3 scripts/check-receipt-computation.py
node scripts/check-risc0-computation-demo.mjs
```

브라우저 테스트는 실행 중인 기본 로컬 서버, Node와 Playwright/Chrome을 사용한다. 공개 데모 지갑으로 실제 로컬 거래 4개와 양방향 새 RISC0 증명을 생성하므로 중복 실행하지 않는다. 결과는 `results/restoration-20261029`에 기록한다.
