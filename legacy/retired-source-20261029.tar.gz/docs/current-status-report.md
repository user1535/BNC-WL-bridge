# 현재 개발 상태

기준: 2026-10-29. **사용자 직접 제출 + 실제 RISC0 내부 연산 증명 + 기존 웹 UI 복구와 로컬 실행 검증 완료.**

- 실행: `bash scripts/run-server.sh`, UI http://127.0.0.1:8580/, 상태 `results/prototype-risc0`.
- 서버 운영자와 RPC를 신뢰한다. 이전 TEE 소스·UI·실행기·CI·worker를 제거하고 복구용 아카이브만 legacy에 보존했다. 기존 TEE 개발 heartbeat는 PAUSED다.
- 실제 새 RISC0 composite proof를 lock/burn 양쪽에서 생성하고 SDK로 검증했다. 각각 261.74초 / 271.78초, 최대 RSS 약 4.90 / 4.93 GB(십진), CPU 상한 12개였다.
- 원래 웹페이지의 브라우저 데모 지갑으로 lock → mint → burn → unlock 거래 4개를 직접 승인·서명했다. 최종 원본 100, 잠금 0, wrapped 0으로 복원됐다.
- 양방향 각각 증명 누락, 잘못된 guest/journal/scope/input commitment, receipt 변조 후 SHA256 재계산을 거부했다. 실제 SDK가 변조 receipt를 거부한다. 중복 청구도 차단했다.
- 증명 패키지 JSON 다운로드·재업로드·SDK 재검증, 페이지 새로고침과 매뉴얼·감사 UI를 검증했다.
- 서버와 두 노드를 정상 종료한 뒤 같은 상태로 재시작했다. 계약·잔액·source 블록·기존 증명 파일 hash/mtime이 유지됐고 새 증명 생성은 0개였다. 재시작 후 다운로드한 증명의 재검증과 replay 거부를 확인했다.
- 영속 세션 ID로 브라우저 요청·미확인 거래 저장소를 분리한다. 기존 저장소를 덮어쓰지 않는 것도 브라우저에서 확인했다.
- Go 전체 검사, Solidity 56개, Rust core 4개, 기존 wallet 회귀 9개, 실제 SDK·프로세스 취소 검사 7개 통과.

## 증거

- [종합 결과](../results/restoration-20261029/summary.json)
- [브라우저 양방향 왕복](../results/restoration-20261029/browser-summary.json)
- [재시작 상태·캐시 대조](../results/restoration-20261029/after-restart.json)
- [재시작 후 UI 검증](../results/restoration-20261029/restart-browser-summary.json)
- [실행 화면](../results/restoration-20261029/restored-ui.png)
- [정확한 소스 hash](../results/restoration-20261029/source-sha256.json)

## 검증 범위

RISC0 composite 연산 증명은 서버 SDK에서 검증하며 목적지 계약은 운영자 등록 root에 대해 MPT·이벤트·도메인·replay를 검증한다. 연산 증명의 온체인 RISC0 검증이나 원본 체인 합의·최종성 인증을 완료했다고 주장하지 않는다. 서버 운영자·RPC를 신뢰하는 모델이다.

두 Anvil 로컬 체인 31337/31338과 브라우저 데모 지갑을 사용했다. 실제 WorldLand/BSC 배포, 실자산, 외부 확장 지갑 실측은 수행하지 않았다. 기존 시제품 세션과 증거는 별도로 보존했다.
