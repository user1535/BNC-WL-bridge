# BNC-WL current scope — 2026-10-29

The user now trusts the bridge server operator and RPC provider. Restore and maintain the original web wallet with user-signed direct submission and actual RISC Zero receipt/MPT/event computation proofs. This supersedes the old untrusted-server/TEE requirements.

- Default: `bash scripts/run-server.sh`, mode `risc0-computation`, state `results/prototype-risc0`, UI 127.0.0.1:8580; chains 31337/31338 only.
- RISC Zero guest is pinned in configs/receipt-computation.json. Require real composite receipt SDK verification; never use RISC0_DEV_MODE or silently fall back to native-only mode.
- Composite computation receipts are verified by the server SDK. The destination contracts verify MPT/event/domain/replay against operator-registered roots. Do not claim on-chain RISC Zero verification or source consensus/finality authentication.
- User asset actions and claims are signed in the browser wallet. The server may register roots and audit commitments with the local operator. No personal private keys, testnet/mainnet deployment or real assets.
- TEE implementation is retired to legacy/tee-retired-20261029/source-and-progress.tar.gz. Do not reactivate its automation, source, UI, CI or services.
- Preserve historical results and old state. Do not reset existing sessions or overwrite the original legacy archive to restore code.
- Bound proving to at most 12 CPUs, 70% available/cgroup memory, 1800 seconds and 64 MiB per file. Inspect active jobs and locks before proving; do not duplicate work.
- Keep docs/current-status-report.md and results/prototype-progress.json accurate. Report actual execution and remaining limitations separately.
