# WorldLand ↔ BNB bridge — user submission + RISC Zero computation

2026-10-29: 서버 운영자와 RPC를 신뢰하는 모델로 복구했습니다. 기존 웹 지갑에서 사용자가 lock → mint → burn → unlock을 직접 승인하고 제출합니다. 기본 증명 요청은 실제 RISC0 내부 연산 증명을 필수로 생성·SDK 검증합니다.

```bash
bash scripts/run-server.sh
```

웹 UI: http://127.0.0.1:8580/ — 확장 없이 데모 지갑 연결로 시작합니다. 공개 Anvil 테스트 계정을 브라우저에서 서명하는 로컬 시연입니다. 실제 개인키나 자산을 사용하지 마세요.

## 검증 범위

- 서버: 신뢰하는 원본 RPC 확인, confirmation 2블록, 운영자 root 등록, Go MPT 패키지 생성, RISC0 guest 실행·실제 composite proof 생성·SDK 재검증.
- 브라우저: MPT·이벤트·금액·수신자·도메인·calldata 대조, RISC0 journal/input commitment 및 receipt SHA256 확인, 청구 검토와 제출 직전 서버 SDK 재검증 요청.
- 목적지 계약: 운영자 등록 root에 대한 MPT·이벤트·도메인·중복 청구 검증 후 mint/unlock.
- RISC0 composite proof는 서버 SDK에서 검증하며 온체인 RISC0 검증은 하지 않습니다. 원본 합의·최종성 인증은 포함하지 않습니다.
- 서버는 사용자 개인키를 수집하거나 사용자 자산 거래를 서명하지 않습니다. 서버의 로컬 운영자 권한으로 root·감사 기록을 등록합니다.

## 실행 조건

Linux x86_64, Python 3.12, Foundry/solc 0.8.24, Go(생성기 재빌드 시), RISC0 SDK 3.0.5 호스트와 호환 r0vm이 필요합니다. CPU composite proving에는 Docker가 필요하지 않습니다.

```bash
python3 scripts/server-doctor.py --mode risc0-computation
# 필요할 경우: cargo build --release --locked --manifest-path risc0/receipt-computation/Cargo.toml -p bridge-receipt-host
```

기본 세션은 `results/prototype-risc0`, RPC 포트는 8565/8566입니다. Ctrl+C로 종료하면 노드 상태를 저장하며 같은 명령으로 재개합니다. 기존 세션과 증거는 별도로 보존합니다. RISC0 실패 시 청구 패키지를 제공하지 않으며 증명 없는 모드로 자동 전환하지 않습니다.

`BNC_API_PORT`, `BNC_WL_PORT`, `BNC_BNB_PORT`, `BNC_STATE_DIR`로 로컬 경로·포트를 바꿀 수 있습니다. `BNC_MODE=trusted-rpc`는 증명 없는 명시적 비교 모드이며 기본 복구 경로가 아닙니다. 이전 `zk` 헤더 증명 실험도 별도 비교 경로입니다. 현재 기본 모드는 로컬 실행 전용입니다.

## 문서와 보존 자료

- [사용 매뉴얼](docs/local-demo-manual.md)
- [현재 상태와 실제 검증 결과](docs/current-status-report.md)
- [구현과 API](docs/implementation-details.md)
- [범위와 후속 작업](docs/plan-gap-analysis.md)
- [기존 RPC/MPT + RISC0 보존본](legacy/rpc-mpt-risc0-internal-20261006/README.md)
- [제거한 이전 구현의 복구용 아카이브](legacy/tee-retired-20261029/README.md)

원본 체인의 인증을 뜻하는 `chainAuthenticated`와 실자산 허용을 뜻하는 `realAssetDeploymentAllowed`는 모두 false입니다. 실제 WorldLand/BSC 배포나 외부 확장 지갑 검증 완료를 주장하지 않습니다.
