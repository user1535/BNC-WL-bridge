#!/usr/bin/env python3
"""Real captured BNB BLS + EVM hash-to-curve on owned local Anvil; no RISC0."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import signal
import socket
import subprocess
import time
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
BOOL_TRUE = '0x' + (1).to_bytes(32, 'big').hex()


def main():
    def interrupted(signum, frame):
        raise KeyboardInterrupt('BLS diagnostic interrupted')
    signal.signal(signal.SIGTERM, interrupted)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--hardfork', choices=('prague', 'cancun'), default='prague')
    args = parser.parse_args()
    out = args.output_dir.resolve()
    out.mkdir(parents=True, exist_ok=False)
    url = 'http://127.0.0.1:8575'
    report = {'measuredAt': datetime.now(timezone.utc).isoformat(), 'localVerdict': 'FAIL',
        'hardfork': args.hardfork, 'risc0Used': False, 'proofsGenerated': 0,
        'sourceConsensusAuthenticated': False, 'validatorSetAuthenticated': False,
        'proofOfPossessionAuthenticated': False, 'finalityVerified': False,
        'chainAuthenticated': False, 'realAssetDeploymentAllowed': False,
        'assetClaimsSubmitted': 0, 'checks': [], 'transactions': []}
    node = None

    def command(arguments):
        result = subprocess.run([str(a) for a in arguments], cwd=ROOT, capture_output=True, text=True, timeout=120)
        if result.returncode:
            raise ValueError(result.stderr or result.stdout)
        return result.stdout.strip()

    def rpc(method, params):
        request = urllib.request.Request(url, json.dumps({'jsonrpc': '2.0', 'id': 1,
            'method': method, 'params': params}).encode(), {'Content-Type': 'application/json'})
        with urllib.request.urlopen(request, timeout=15) as response:
            data = json.load(response)
        if 'error' in data:
            raise ValueError(str(data['error']))
        return data['result']

    def decode_bytes(value):
        data = bytes.fromhex(value[2:])
        if len(data) < 64 or int.from_bytes(data[:32], 'big') != 32:
            raise ValueError('invalid dynamic bytes ABI')
        size = int.from_bytes(data[32:64], 'big')
        if size != 256 or len(data) != 64 + size:
            raise ValueError('G2 output width')
        return '0x' + data[64:].hex()

    def flip(value, index=-1):
        data = bytearray.fromhex(value[2:]); data[index] ^= 1
        return '0x' + data.hex()

    try:
        exporter = ROOT / '.bin/bnb-vote-signature-inspect'
        command(['go', '-C', ROOT / 'proof-generator', 'build', '-o', exporter, './cmd/bnb-vote-signature-inspect'])
        report['exporterSHA256'] = hashlib.sha256(exporter.read_bytes()).hexdigest()
        witnesses = []
        captured = ROOT / 'proof-generator/internal/chain/testdata/native-live-captured'
        for label in ('parent', 'latest'):
            result = json.loads(command([exporter, '--input', captured / ('bnb-' + label + '.json'),
                '--epoch-input', captured / 'bnb-epoch.json', '--layout', 'post-luban-non-epoch',
                '--epoch-layout', 'post-bohr-epoch', '--epoch-length', '1000', '--evm-witness']))
            if not result['inspection']['pairingVerifiedAgainstSuppliedKeys']:
                raise ValueError('actual offline pairing required')
            witness = result['evmWitness']
            if (witness['chainAuthenticated'] or witness['validatorSetAuthenticated']
                or len(bytes.fromhex(witness['signatureEIP2537'][2:])) != 256
                or len(bytes.fromhex(witness['suppliedKeysEIP2537'][2:])) != 128 * witness['validatorCount']):
                raise ValueError('invalid witness/scope')
            (out / (label + '-witness.json')).write_text(json.dumps(result, indent=2) + '\n')
            witnesses.append(witness)
        command(['forge', 'build', '--root', ROOT / 'contracts', '--offline', '--quiet'])
        with socket.socket() as probe:
            probe.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            probe.bind(('127.0.0.1', 8575)); probe.listen(1)
        with (out / 'anvil.log').open('w') as log:
            node = subprocess.Popen(['anvil', '--silent', '--host', '127.0.0.1', '--port', '8575',
                '--chain-id', '31337', '--hardfork', args.hardfork], stdout=log, stderr=log)
        for _ in range(50):
            if node.poll() is not None:
                raise ValueError('owned node exited')
            try:
                if int(rpc('eth_chainId', []), 16) != 31337:
                    raise ValueError('local chain required')
                break
            except OSError:
                time.sleep(.1)
        else:
            raise ValueError('owned node startup timeout')
        sender = rpc('eth_accounts', [])[0]
        contract = json.loads(command(['forge', 'create', '--root', ROOT / 'contracts',
            'test/BNBVoteBLSDiagnostic.sol:BNBVoteBLSDiagnostic', '--rpc-url', url,
            '--unlocked', '--from', sender, '--broadcast', '--json']))['deployedTo']

        def verify_data(witness, **changes):
            w = dict(witness, **changes)
            return command(['cast', 'calldata', 'verifySuppliedVote(bytes32,bytes,uint64,bytes)',
                w['voteDataHash'], w['suppliedKeysEIP2537'], w['voteBitmap'], w['signatureEIP2537']])

        def rejected(label, data):
            try:
                rpc('eth_call', [{'from': sender, 'to': contract, 'data': data, 'gas': hex(8_000_000)}, 'latest'])
            except ValueError as error:
                if 'execution reverted' not in str(error).lower():
                    raise
                report['checks'].append({'name': label, 'rejected': True, 'error': str(error)})
            else:
                raise ValueError(label + ' incorrectly accepted')

        for index, witness in enumerate(witnesses):
            data = verify_data(witness)
            if args.hardfork == 'cancun':
                rejected('missing-precompiles-' + str(index), data)
                continue
            hashed = rpc('eth_call', [{'to': contract, 'data': command(['cast', 'calldata',
                'hashVoteToG2(bytes32)', witness['voteDataHash']])}, 'latest'])
            if decode_bytes(hashed) != witness['referenceHashPointEIP2537']:
                raise ValueError('EVM hash-to-curve differs from blst reference')
            if rpc('eth_call', [{'to': contract, 'data': data}, 'latest']) != BOOL_TRUE:
                raise ValueError('actual EVM BLS pairing rejected')
            receipt = json.loads(command(['cast', 'send', contract, '--data', data,
                '--rpc-url', url, '--unlocked', '--from', sender, '--json']))
            if int(receipt['status'], 16) != 1:
                raise ValueError('actual diagnostic transaction failed')
            (out / ('verified-' + str(index) + '-transaction.json')).write_text(json.dumps(receipt, indent=2) + '\n')
            report['transactions'].append({'hash': receipt['transactionHash'], 'gasUsed': int(receipt['gasUsed'], 16),
                'calldataBytes': len(bytes.fromhex(data[2:]))})
            report['checks'].append({'name': 'actual-vote-' + str(index),
                'hashToCurveMatchesBlst': True, 'actualEvmPairingVerified': True})
        if args.hardfork == 'prague':
            w = witnesses[0]
            keys = bytes.fromhex(w['suppliedKeysEIP2537'][2:])
            unselected = next(i for i in range(w['validatorCount']) if not w['voteBitmap'] & (1 << i))
            malformed_unselected = bytearray(keys); malformed_unselected[unselected * 128] = 1
            torsion_unselected = bytearray(keys)
            # (x=0,y=2) is on y^2=x^3+4 but has order3, outside G1's
            # prime subgroup. Check even its unselected/scalar-zero input.
            torsion_unselected[unselected * 128:(unselected + 1) * 128] = bytes(127) + b'\x02'
            negatives = [
                ('wrong-message', {'voteDataHash': flip(w['voteDataHash'])}),
                ('below-quorum', {'voteBitmap': 1}),
                ('bitmap-outside-set', {'voteBitmap': w['voteBitmap'] | (1 << w['validatorCount'])}),
                ('duplicate-key', {'suppliedKeysEIP2537': '0x' + (keys[:128] + keys[:128] + keys[256:]).hex()}),
                ('infinity-key', {'suppliedKeysEIP2537': '0x' + (bytes(128) + keys[128:]).hex()}),
                ('bad-unselected-key', {'suppliedKeysEIP2537': '0x' + malformed_unselected.hex()}),
                ('unselected-torsion-key', {'suppliedKeysEIP2537': '0x' + torsion_unselected.hex()}),
                ('malformed-key', {'suppliedKeysEIP2537': flip(w['suppliedKeysEIP2537'])}),
                ('malformed-signature', {'signatureEIP2537': flip(w['signatureEIP2537'])}),
                ('infinity-signature', {'signatureEIP2537': '0x' + bytes(256).hex()}),
                ('wrong-vote-signature', {'signatureEIP2537': witnesses[1]['signatureEIP2537']}),
                ('truncated-signature', {'signatureEIP2537': w['signatureEIP2537'][:-2]}),
                ('empty-keys', {'suppliedKeysEIP2537': '0x'}),
            ]
            for label, changes in negatives:
                rejected(label, verify_data(w, **changes))
        runtime = rpc('eth_getCode', [contract, 'latest'])
        (out / 'diagnostic-runtime.hex').write_text(runtime + '\n')
        report.update(localVerdict='PASS', diagnosticContract=contract,
            actualEvmBlsPairingMeasured=args.hardfork == 'prague',
            missingPrecompilesFailClosedMeasured=args.hardfork == 'cancun',
            runtimeKeccak=command(['cast', 'keccak', runtime]),
            sourceSHA256=hashlib.sha256((ROOT / 'contracts/test/BNBVoteBLSDiagnostic.sol').read_bytes()).hexdigest())
    except BaseException as error:
        report['error'] = str(error)
        raise
    finally:
        if node and node.poll() is None:
            node.terminate()
            try:
                node.wait(timeout=5)
            except subprocess.TimeoutExpired:
                node.kill(); node.wait()
        report['ownedNodeStopped'] = node is None or node.poll() is not None
        report['artifactSHA256'] = {str(p.relative_to(out)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in out.rglob('*') if p.is_file()}
        (out / 'summary.json').write_text(json.dumps(report, indent=2) + '\n')
    print(report['localVerdict'], args.hardfork, len(report['checks']), report['transactions'])


if __name__ == '__main__':
    main()
