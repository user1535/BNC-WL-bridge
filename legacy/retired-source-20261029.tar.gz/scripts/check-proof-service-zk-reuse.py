#!/usr/bin/env python3
"""Read-only API delivery backed by saved real SDK Groth16 and local EVM state."""
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import time
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('zk_service_check',ROOT/'scripts/proof-service.py')
api=importlib.util.module_from_spec(spec);spec.loader.exec_module(api)
source=ROOT/'results/session-zk-large-multiblock'
out=ROOT/'results/prototype-zk-api-reuse'
out.mkdir(exist_ok=False)
for name in ('session.json','wl-state.json','bnb-state.json','risc0-host'):
    shutil.copy2(source/name,out/name)
session=api.local.Session(out)
session.start('risc0_batch')
service=None
try:
    header=json.loads((source/'lock-96-16-headers.json').read_text())
    api.local.write_json(out/'receipt.json',header['proofReceipt'])
    checked=json.loads(subprocess.check_output([str(session.prover_host()),'--verify-receipt',str(out/'receipt.json')],text=True,timeout=120))
    assert checked['verified'] is True and checked['receipt_kind']=='groth16'
    assert checked['image_id']==session.data['image_id'] and checked['journal']==header['journal']
    service=api.Service(out,confirmations=2)
    results=[]
    for action in ('lock','burn'):
        event=next(e for e in session.data['events'] if e['action']==action)
        request=dict(action=action,transferId=event['id'],fromBlock=event['block'])
        identifier=service.submit(request)['id']
        for _ in range(100):
            job=service.get(identifier)
            if job['state']=='ready':break
            if job['state']=='failed':raise ValueError(job['detail'])
            time.sleep(.1)
        else:raise ValueError('package timeout')
        package=service.get(identifier,True)
        assert package['headerMode']=='risc0_batch' and package['headerCovered'] is True
        assert package['transferId']==event['id'] and package['chainAuthenticated'] is False
        results.append(dict(action=action,jobId=identifier,headerCovered=True,block=event['block']))
    result=dict(passed=True,actualSdkGroth16Reverified=True,imageId=checked['image_id'],
                sourceState=str(source),readOnlyApiResults=results,newProofs=0,newWalletBroadcasts=0,
                newGroth16WorkerValidated=False,chainAuthenticated=False,realAssetDeploymentAllowed=False)
    api.local.write_json(out/'summary.json',result)
    print(json.dumps(result))
finally:
    if service:
        service.stop.set();service.worker.join(timeout=70)
    session.stop()
