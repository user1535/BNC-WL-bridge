#!/usr/bin/env python3
"""Exercise actual strict guest execution and contrast the existing minimal image."""
import argparse
import hashlib
import shutil
import copy
import json
import os
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'results/bound-header-guards'
BOUND = ROOT / 'risc0/target/release/bridge-header-bound-host'
MINIMAL = ROOT / 'risc0/target/release/bridge-header-benchmark'


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output-dir',type=Path,default=OUT)
    args=parser.parse_args()
    output=args.output_dir.resolve()
    output.mkdir(parents=True,exist_ok=False)
    bound=output/'bound-host'; minimal=output/'minimal-host'
    shutil.copy2(BOUND,bound); shutil.copy2(MINIMAL,minimal)
    inspection = json.loads((ROOT / 'risc0/header-binding/fixtures/anvil-prague.json').read_text())
    rpc_header = json.loads((ROOT / 'proof-generator/internal/chain/testdata/anvil-prague-header.json').read_text())
    array = lambda value: list(bytes.fromhex(value.removeprefix('0x')))
    base = {'chain_id': 31337, 'anchor_hash': array(rpc_header['parentHash']), 'headers': [{
        'number': inspection['blockNumber'], 'block_hash': array(inspection['suppliedHash']),
        'parent_hash': array(rpc_header['parentHash']), 'receipt_root': array(inspection['receiptRoot']),
        'canonical_rlp': array(inspection['headerRlp'])}]}
    env = dict(os.environ, RISC0_DEV_MODE='0', RISC0_PROVER='ipc', RISC0_SERVER_PATH=str(Path.home()/'.cargo/bin/r0vm'))
    rows = []

    def execute(name, data, expected, host=None):
        path = output / f'{name}.json'; path.write_text(json.dumps(data))
        proc = subprocess.run([str(host or bound), '--journal-only', '--input', str(path)], env=env, text=True, capture_output=True, timeout=60)
        (output / f'{name}.stdout').write_text(proc.stdout)
        (output / f'{name}.stderr').write_text(proc.stderr)
        if expected != (proc.returncode == 0): raise AssertionError(f'{name}: {proc.stderr}')
        if not expected and name != 'missing-rlp' and 'canonical header binding failed' not in proc.stderr:
            raise AssertionError(f'{name}: failed for unrelated reason: {proc.stderr}')
        rows.append({'name': name, 'accepted': proc.returncode == 0})

    execute('valid-prague', base, True)
    changed = copy.deepcopy(base); changed['headers'][0]['receipt_root'][0] ^= 1
    execute('false-receipt-root', changed, False)
    execute('minimal-false-root-relation', changed, True, minimal)
    changed = copy.deepcopy(base); changed['headers'][0]['canonical_rlp'][-1] ^= 1
    execute('altered-rlp', changed, False)
    changed = copy.deepcopy(base); changed['headers'][0]['canonical_rlp'].append(0x80)
    execute('trailing-rlp', changed, False)
    changed = copy.deepcopy(base); changed['headers'][0]['number'] += 1
    execute('wrong-number', changed, False)
    changed = copy.deepcopy(base); del changed['headers'][0]['canonical_rlp']
    execute('missing-rlp', changed, False)
    strict_id = subprocess.check_output([str(bound), '--image-id'], text=True).strip()
    minimal_id = subprocess.check_output([str(minimal), '--image-id'], text=True).strip()
    assert strict_id != minimal_id
    summary = {'strictImage': strict_id, 'minimalImage': minimal_id, 'checks': rows, 'strictHostSHA256':hashlib.sha256(bound.read_bytes()).hexdigest(),
               'minimalHostSHA256':hashlib.sha256(minimal.read_bytes()).hexdigest(),
               'hashBindingGuestExecuted': True, 'cryptographicProofGeneratedHere': False,
               'chainAuthenticated': False, 'realAssetDeploymentAllowed': False}
    (output/'summary.json').write_text(json.dumps(summary, indent=2)+'\n')
    print('strict guest actual execution: valid header accepted; false root/RLP/number rejected; distinct image verified')


if __name__ == '__main__': main()
