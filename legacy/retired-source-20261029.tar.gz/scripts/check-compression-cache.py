#!/usr/bin/env python3
"""Read-only adversarial checks of genuine SDK lift/join/resolve checkpoints."""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ("host", "input", "cache", "prepare-evidence", "dir"):
        p.add_argument("--" + name, type=Path, required=True)
    args = p.parse_args()
    cache, host, witness = args.cache.absolute(), args.host.absolute(), args.input.absolute()
    manifest = json.loads((cache / "manifest.json").read_text())
    if manifest["segments"] != 2 or manifest["assumptions"] != 1 or not (cache / "succinct.json").is_file():
        p.error("requires completed genuine tiny2 VM+1 assumption recursion cache")
    original = {str(x.relative_to(cache)): sha(x) for x in cache.rglob("*") if x.is_file()}
    out = args.dir.absolute()
    out.mkdir(parents=True, exist_ok=False)
    prepared = json.loads((args.prepare_evidence / "summary.json").read_text())
    env = dict(os.environ, RISC0_DEV_MODE="0", RISC0_PROVER="ipc", RAYON_NUM_THREADS=str(manifest["threads"]),
               BRIDGE_RISC0_SEGMENT_PO2="19", RISC0_SERVER_PATH=str((Path.home() / ".cargo/bin/r0vm").resolve()),
               BRIDGE_RISC0_CACHE_MANIFEST_SHA256=prepared["result"]["manifestSHA256"])
    results = []

    def invoke(name, target, source, reject=None, partial=False, changed_pin=False):
        case_env = dict(env)
        if changed_pin:
            case_env["BRIDGE_RISC0_CACHE_MANIFEST_SHA256"] = sha(target / "manifest.json")
        result = subprocess.run([host, "--compression-audit", source, target],
                                env=case_env, capture_output=True, text=True, timeout=45)
        (out / (name + ".stdout.json")).write_text(result.stdout)
        (out / (name + ".stderr.txt")).write_text(result.stderr)
        if reject:
            ok = result.returncode != 0 and reject in result.stderr
        else:
            row = json.loads(result.stdout) if result.returncode == 0 else {}
            ok = (row.get("status") == ("PARTIAL" if partial else "PASS")
                  and row.get("newVerifiedUnits") == 0
                  and row.get("fullReceiptVerified") is (not partial))
        results.append({"case": name, "passed": ok, "exitCode": result.returncode,
                        "expectedReason": reject, "newProofsAllowed": False})
        if not ok:
            raise ValueError(f"{name}: {result.stdout} {result.stderr}")

    invoke("genuine-full-succinct", cache, witness)

    def case(name, mutate, reject="Error:", changed_pin=False, partial=False):
        target = out / name
        shutil.copytree(cache, target)
        source = target / "input.json"
        shutil.copy2(witness, source)
        mutate(target, source)
        invoke(name, target, source, reject, partial, changed_pin)

    def field(root, key, value):
        path = root / "manifest.json"
        row = json.loads(path.read_text())
        row[key] = value
        path.write_text(json.dumps(row))

    for key, value in (("schema", 2), ("image", "0" * 64), ("host_sha256", "0" * 64),
                       ("server_sha256", "0" * 64), ("threads", 1), ("segments", 3)):
        case("wrong-" + key, lambda r, s, k=key, v=value: field(r, k, v), changed_pin=True)
    case("unknown-field", lambda r, s: field(r, "unsupported", True), "unknown field", True)
    case("rewritten-manifest-pin", lambda r, s: field(r, "segments", 3), "preparation manifest pin mismatch")

    def node_seal(root, source):
        path = root / "lift-0000.json"
        row = json.loads(path.read_text())
        row["seal"][0] ^= 1
        path.write_text(json.dumps(row))
    case("altered-lift-seal", node_seal)
    case("swapped-valid-lift", lambda r, s: shutil.copyfile(r / "lift-0001.json", r / "lift-0000.json"),
         "recursion node claim mismatch")
    case("wrong-valid-join", lambda r, s: shutil.copyfile(r / "lift-0000.json", r / "join-0000-0001.json"),
         "recursion node claim mismatch")
    case("unresolved-valid-final", lambda r, s: shutil.copyfile(r / "join-0000-0001.json", r / "resolve-0000.json"),
         "recursion node claim mismatch")

    def source_receipt(root, source, fake=False):
        path = root / "composite.json"
        row = json.loads(path.read_text())
        if fake:
            row["inner"] = {"Fake": {"claim": {"Pruned": [0] * 8}}}
        else:
            row["inner"]["Composite"]["assumption_receipts"] = []
        path.write_text(json.dumps(row))
        m = json.loads((root / "manifest.json").read_text())
        m["composite"].update(sha256=sha(path), bytes=path.stat().st_size)
        (root / "manifest.json").write_text(json.dumps(m))
    case("source-unresolved-keccak", source_receipt, changed_pin=True)
    case("source-fake", lambda r, s: source_receipt(r, s, True), changed_pin=True)

    def final_journal(root, source):
        path = root / "succinct.json"
        row = json.loads(path.read_text())
        row["journal"]["bytes"][0] ^= 1
        path.write_text(json.dumps(row))
    case("altered-final-journal", final_journal)
    for kind in ("symlink", "fifo"):
        def nonregular(root, source, kind=kind):
            path = root / "lift-0000.json"
            path.unlink()
            if kind == "symlink":
                path.symlink_to(cache / "lift-0000.json")
            else:
                os.mkfifo(path)
        case(kind, nonregular, "cached proof must be a regular file")
    with (cache / "cache.lock").open("r+") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        invoke("concurrent-lock", cache, witness, "compression cache already in use")
    case("missing-lift-is-partial", lambda r, s: (r / "lift-0001.json").unlink(), None, partial=True)
    case("missing-final-audit-no-write", lambda r, s: (r / "succinct.json").unlink(), None)
    if (out / "missing-final-audit-no-write/succinct.json").exists():
        raise ValueError("audit wrote missing final receipt")
    after = {str(x.relative_to(cache)): sha(x) for x in cache.rglob("*") if x.is_file()}
    if after != original:
        raise ValueError("audit modified original cache")
    report = {"status": "PASS", "checks": results, "originalCacheUnchanged": True,
              "newProofsGenerated": 0, "evmAcceptanceMeasured": False,
              "chainAuthenticated": False, "realAssetDeploymentAllowed": False}
    (out / "summary.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report))


if __name__ == "__main__":
    main()
