from pathlib import Path
from docx import Document
from docx.shared import Pt, RGBColor, Cm
from docx.oxml.ns import qn
from docx.enum.text import WD_BREAK
from zipfile import ZipFile
import json

ROOT=Path(__file__).resolve().parents[1]
import argparse,os
parser=argparse.ArgumentParser();parser.add_argument('--source',type=Path,default=Path(os.environ.get('BNC_DOCX_SOURCE',ROOT/'docs/source/bridge-design.docx')))
source=parser.parse_args().source
target=ROOT/'docs/private_keyless_Bridge.docx'
doc=Document(source)
replacements={
'Private Key 없는 Relayer 구조 설계안':'개인키 없는 WorldLand BNB 브리지 시제품 설계',
'Ethereum ↔ WorldLand RISC0 Bridge':'WorldLand와 BNB 역할 로컬 체인의 사용자 직접 제출 모델',
'3.USER가 증명을 직접 Destination 체인에 제출 (relayer는 private key X => tx 생성 불가 =>직접 전달 불가능)':'3. USER가 반환된 unsigned calldata를 확인하고 목적지 거래를 직접 서명한다. 헤더가 미등록이면 헤더 등록 후 자산 청구를 각각 승인한다.',
'WorldLand NativeVault contract: 사용자의 WL을 lock()하고 Locked 이벤트를 발생. ':'Source Token Contract: 현재는 BridgeLockableToken.bridgeLock으로 사용자 계정 내부 잔액을 잠근다. 네이티브 WL과 기존 ERC20 통합은 후속 범위다.',
'User Client: 사용자가 WL lock과 Ethereum submitProof() 트랜잭션을 직접 서명·전송 ':'User Client: 원본 잠금과 wrapped 소각, 목적지 헤더 등록과 청구를 지갑에서 직접 서명하고 전송한다.',
'Ethereum Bridge Contract: proof를 검증하고 replay를 확인한 뒤 wWL을 mint ':'Destination Bridge Contract: LockMintReceiver와 BurnUnlockReceiver가 receipt MPT, 이벤트, 체인과 수신자, 중복 청구를 검사해 mint 또는 unlock을 실행한다.',
'Wrapped WL Token: 검증 완료 후 Ethereum에서 사용자에게 wWL을 발행':'Wrapped Token: 로컬 BNB 역할 체인에서 동일 사용자에게 발행하고, 같은 소유자만 소각하여 원본 잠금을 해제한다.',
'Design principle: Bridge correctness depends on proof validity, not on the identity or private key of the relayer.':'신뢰 전제: 원본 데이터를 선택하는 서버와 RPC를 신뢰한다. 목적지 계약은 증명과 지급 조건을 검사한다. 증명 서버는 자산 개인키를 보관하거나 사용자의 거래를 서명하지 않는다.',
}
for paragraph in doc.paragraphs:
    if paragraph.text in replacements:
        paragraph.text=replacements[paragraph.text]
doc.paragraphs[0].style='Title'
for name in ('Title','Subtitle','Heading 1','Heading 2'):
    style=doc.styles[name]
    style.font.color.rgb=RGBColor(0,0,0)
    style.font.name='Malgun Gothic'
    style.element.get_or_add_rPr().rFonts.set(qn('w:eastAsia'),'Malgun Gothic')
doc.add_page_break()
doc.add_paragraph('시제품 개발 현황 2026년 10월 2일',style='Heading 1')
doc.add_paragraph('기존 로컬 브리지에 HTTP 증명 전달 API와 지갑 화면의 요청 기능을 연결했다. 사용자가 원본 거래를 직접 승인하고, 서버가 receipt MPT 패키지를 반환하며, 사용자가 목적지 거래를 직접 승인하는 흐름을 구현했다. 실체인 자산 배포와 운영 성능 판정은 후속 범위다.')
doc.add_paragraph('사용자와 서버의 호출 흐름',style='Heading 2')
for text in [
'1. 서버 세션 불러오기 버튼은 GET /api/manifest로 체인 ID, 계약 주소와 runtime code를 읽는다. 사용자 지갑 연결은 EIP1193를 사용한다.',
'2. bridgeLock 또는 bridgeBurn 거래를 사용자가 승인한다. 거래 상태 조회 후 receipt의 이벤트에서 transferId와 blockNumber를 읽어 증명 요청 입력을 채운다.',
'3. POST /api/jobs는 action, transferId, fromBlock을 받는다. 서버 RPC와 계약 설정은 세션에 고정하며 요청에서 키, RPC URL 또는 서명 설정을 받지 않는다.',
'4. 서버는 기본 확인 블록 2개를 기다린다. Go bridge-proof가 source receipt MPT와 목적지 계약 연결을 검증하고 unsigned package를 만든다.',
'5. GET /api/jobs/{id}로 상태를 조회하고 /package로 결과를 받는다. 전달 직전에 source blockHash와 receiptsRoot, 확인 블록 수를 다시 검사한다.',
'6. 사용자는 패키지를 확인한다. ZK 경로의 미등록 헤더는 submitHeaderProof를 먼저 승인하고, 이후 submitLockProof 또는 submitBurnProof를 승인한다. fast 경로의 개발 헤더 등록은 별도 로컬 운영자 도구를 사용한다.',
]:
    doc.add_paragraph(text)
doc.add_paragraph('구현과 검증 범위',style='Heading 2')
for text in [
'브라우저와 실제 Anvil 두 체인의 fast 왕복은 통과했다. lock, mint, burn, unlock의 사용자 거래 4건 후 원본 100, 잠금 0, wrapped 0을 확인했다. 브라우저 검사는 실제 외부 확장 지갑 대신 통제된 EIP1193 공급자를 사용했다.',
'확인 블록 대기, 동일 요청의 같은 작업 ID 반환, 새로고침 후 요청 복구, 외부 Origin과 잘못된 Host 거부, 요청 RPC 변경 거부, 원본 reorg 후 패키지 전달 거부를 검사했다.',
'작업은 proof-jobs에 저장된다. 서버 재시작 시 running 작업은 queued로 복구하며, 읽기 전용 생성 작업을 다시 수행한다. 사용자 지갑 거래를 재전송하지 않는다.',
'ZK 미등록 헤더용 bounded worker를 연결했다. 기존 run-local-proof.py를 통해 CPU 12, RAM 70퍼센트, 증명 제한 1800초와 파일 64MiB를 유지한다. strict 배치 1개, minimal 배치 4개 한도를 유지하며 긴 구간은 중간 헤더 배치를 순서대로 사용자에게 반환한다. 새 서버 경로의 실제 Groth16 검증 결과는 저장소의 최신 진행 기록을 따른다.',
]:
    doc.add_paragraph(text)
doc.add_paragraph('긴 헤더 구간의 사용자 순차 제출',style='Heading 2')
doc.add_paragraph('header_ready 상태는 이벤트 블록에 아직 도달하지 않은 중간 증명이다. 서버는 실제 SDK 검증과 원본 구간 재조회, 목적지 최신 헤더와 anchor 확인 후 header step 패키지를 반환한다. 사용자는 헤더 구간을 검토하고 직접 승인한다. 자산 청구는 이벤트 블록의 coverage가 확보될 때까지 비활성화한다.')
doc.add_paragraph('저장된 실제 image4f61 Groth16으로 헤더 112부터 115까지를 전달하고 브라우저의 사용자 거래 한 건으로 로컬 EVM 수락을 확인했다. 사용한 가스는 465718이다. 이후 같은 요청이 목적지 최신 상태를 읽어 다음 구간 116부터 116까지를 계산했다. 잘못된 image, journal, calldata, 체인, 주소, value 여섯 변조를 거부하고 이미 수락된 배치의 재제출을 막았다.')
doc.add_paragraph('헤더 수락 직후 running 작업 중단 상태를 주입하고 서버를 재시작한 검사에서 최신 헤더 115와 다음 구간 116을 유지했다. 추가 지갑 거래와 새 증명 생성은 모두 0건이었다. 이는 저장된 증명의 전달과 순차 제출 검증이며, 새 Groth16 생성과 마지막 이벤트 자산 청구 완료는 후속 검증이다.')
doc.add_paragraph('중간 배치의 근거는 results/prototype-header-steps/summary.json과 restart-summary.json이다. 후속 새 증명 검증 결과는 아래 절과 최신 진행 기록을 따른다.')

doc.add_paragraph('새 증명 생성과 사용자 자산 청구',style='Heading 2')
fresh_root=ROOT/'results/prototype-header-steps'
for file in sorted((fresh_root/'proof-jobs').glob('*-proof-*/proof/summary.json')):
    evidence=json.loads(file.read_text(encoding='utf-8'))
    if evidence.get('localVerdict')=='PASS':
        resource=evidence.get('resources',{})
        doc.add_paragraph('원본 체인 ID '+str(evidence['sourceChainId'])+'의 '+str(evidence['batchSize'])+'개 헤더에서 새 Groth16을 생성하고 SDK로 재검증했다. 실행 시간은 '+str(round(resource.get('wall_seconds',0),3))+'초이며 최대 process group RSS는 '+str(resource.get('peak_group_rss_kb'))+'KiB이다. CPU 12개, RAM 70퍼센트, 1800초, 파일 64MiB 제한을 유지했다.')
fresh_file=fresh_root/'fresh-browser-summary.json'
if fresh_file.exists():
    fresh=json.loads(fresh_file.read_text(encoding='utf-8'))
    if fresh.get('passed'):
        final=fresh['after']
        doc.add_paragraph('새 헤더와 사용자 claim, 사용자 burn 및 반대 방향 헤더와 unlock을 실제 로컬 EVM에서 검증했다. 마지막 잔액은 원본 '+final['original']+', 잠금 '+final['locked']+', wrapped '+final['wrapped']+'이며 모두 토큰 최소 단위다. 실제 외부 확장 지갑 검증을 뜻하지 않는다.')
    else:
        doc.add_paragraph('새 헤더와 mint의 온체인 수락을 확인했으며 반대 방향 검증은 진행 중이다. 전체 왕복 완료는 fresh-browser-summary.json의 passed 값이 true인 경우에만 표시한다.')
concurrent=fresh_root/'concurrency-summary.json'
if concurrent.exists() and json.loads(concurrent.read_text(encoding='utf-8')).get('passed'):
    doc.add_paragraph('실제 증명 실행 중 HTTP 동시 요청 8개가 같은 작업 ID를 유지했고 두 번째 builder는 process lock으로 거부됐다. 추가 증명 시도와 서버 거래 방송은 0건이었다. 서버가 중단돼도 기존 제한된 작업을 기다리고 완료 산출물을 SDK와 원본 상태에 대조한 뒤 복구한다.')
doc.add_paragraph('근거는 results/prototype-header-steps/fresh-browser-summary.json, proof-jobs의 실제 proof summary.json 및 concurrency-summary.json이다.')

doc.add_paragraph('실제 증명 작업의 장애 처리',style='Heading 2')
for name,summary_text in [
    ('prototype-fresh-reorg-fault','실제 proving 도중 원본 사용자 lock을 되돌렸다. SDK가 새 Groth16을 수락했어도 확인 블록을 잃은 source 패키지의 전달을 API가 차단했다.'),
    ('prototype-fresh-cancel-fault','실제 HTTP API에 SIGTERM을 보내 proving 중인 소유 SDK host와 Docker scope의 정리, failed job과 패키지 차단을 검증했다.'),
]:
    file=ROOT/'results'/name/'summary.json'
    if file.exists() and json.loads(file.read_text(encoding='utf-8')).get('passed'):
        doc.add_paragraph(summary_text+' 정상 시제품 상태는 별도로 보존했고 테스트 사용자 lock은 되돌렸다.')
timeout=fresh_root/'timeout-summary.json'
if timeout.exists() and json.loads(timeout.read_text(encoding='utf-8')).get('passed'):
    doc.add_paragraph('실제 prover의 시험 한도를 5초로 낮추자 5.094초에 TIME_LIMIT으로 종료됐다. 소유 process와 Docker가 남지 않았다. 정상 최대 한도 1800초를 유지했다.')
doc.add_paragraph('새 증명의 목적지 updater stale 차단은 양방향 모두 통과했다. proving 도중 updater 변경 주입과 실제 외부 확장 지갑 검증은 후속 범위다.')

doc.add_paragraph('다른 Linux 서버와 AWS 실행 준비',style='Heading 2')
doc.add_paragraph('코드 위치는 실행 파일 기준으로 찾고 상태는 BNC_STATE_DIR의 외부 폴더에 보존한다. 실행 모드, 체인 포트, API 포트, 공개 도메인과 prover 경로를 환경변수로 지정한다. 릴리스는 Linux x86_64 대상이며 세션 상태와 개인 설정은 포함하지 않는다. Python, Foundry, RISC0와 Docker 의존성은 별도로 설치하고 server-doctor로 확인한다.')
doc.add_paragraph('run-server.sh, server.env.example, systemd와 nginx 설정 생성 도구를 제공한다. 공개 HTTPS 도메인의 RPC URL을 지갑에 전달하고 네트워크가 없으면 추가를 요청한다. RPC 전송은 사용자가 지갑에서 서명한 raw transaction만 허용하며 eth_sendTransaction, 서명과 노드 관리 메서드는 차단한다. 증명 worker는 거래를 작성하거나 서명하지 않는다.')
doc.add_paragraph('공백이 있는 별도 경로에 릴리스를 풀고 독립 상태 폴더와 변경한 포트로 실제 Anvil을 실행했다. 지갑 클라이언트의 서명 거래 수락과 receipt 조회, 사용자 lock에서 unsigned MPT 패키지 전달, 네트워크 등록 경로를 검증했다. 이는 로컬 재배치 시험이며 실제 AWS 서버 배포 또는 외부 확장 지갑 검증은 아니다.')
doc.add_paragraph('CPU 최대 12개와 가용 affinity/cgroup 제한, RAM 가용 한도의 70퍼센트, 1800초, 파일 64MiB를 유지한다. 세션당 단일 writer와 영속 상태를 사용하며 다중 서버 작업 분배와 운영 부하 시험은 후속 범위다. 근거: results/server-portability-summary.json 및 docs/implementation-details.md.')
doc.add_paragraph('실행과 개발 재개',style='Heading 2')
doc.add_paragraph('WSL 저장소에서 python3 scripts/proof-service.py --session results/prototype-api-session-v3 --confirmations 2를 실행하고 http://127.0.0.1:8580을 연다. 세션의 Anvil이 실행 중이어야 한다. ZK 세션은 --prove 옵션과 고정된 RISC0 host, Docker가 필요하다.')
doc.add_paragraph('30분 간격 자동화가 이 대화의 미완료 개발을 재개한다. results/prototype-progress.json에 완료 범위, 다음 작업과 실행 명령을 보존한다. 사용량 제한을 우회하지 않으며 실행 환경과 사용량이 허용될 때 진행한다.')
doc.add_paragraph('근거 파일',style='Heading 2')
for text in [
'scripts/proof-service.py  scripts/build-unsigned-headers.py  wallet/ui.mjs',
'results/prototype-api-session-v3/api-browser-summary.json',
'docs/current-status-report.md  docs/implementation-details.md  docs/plan-gap-analysis.md',
]:
    doc.add_paragraph(text)
current=doc.add_paragraph('현재 기본 모델 — 2026년 10월 6일',style='Heading 1')
current._p.getparent().remove(current._p);doc.paragraphs[0]._p.addnext(current._p)
current_text=doc.add_paragraph('현재 기본 로컬 시연은 신뢰 RPC·MPT 모델로 확정됐다. RISC0은 추후 선택적 확장 영역이며 기본 시제품의 완료 필수 조건이 아니다. 확인된 거래 블록 receipt root만 운영자 계정으로 등록하고 거래 포함 MPT·이벤트·금액·수신자·replay 검증을 유지한다. 헤더 연속 증명·4블록 반복 승인·RISC0/Groth16 생성은 사용하지 않는다. 사용자는 lock/burn/claim만 직접 승인한다. 아래의 ZK 헤더 제출 절은 보존된 이전 모델의 기록이며 현재 기본 시연 절차가 아니다. 실제 브라우저 양방향 왕복에서 original/available100, wrapped0 복원과 replay 거부 PASS. 기본 포트8580, 보존된 이전 세션8582. 상세 사용법 docs/local-demo-manual.md, 근거 results/trusted-rpc-demo-summary.json. 서버는 사용자 키를 수집하거나 사용자 자산 거래를 서명하지 않으며 신뢰 운영자의 root 등록만 수행한다. 페이지 렌더 QA는 기존 도구 부재로 미완료다.')
current_text._p.getparent().remove(current_text._p);current._p.addnext(current_text._p)
ui_current=doc.add_paragraph('현재 UI는 두 체인의 상태와 지갑 현황을 함께 표시하며 거래 시작 부분에서 WorldLand(원본 잠금·반환 청구)/BNB(wrapped 소각·발행 청구)를 선택한다. 수량은 일반 토큰 단위 하나로 입력한다. 연결 계정의 전체 이벤트를 조회해 목적지 계약 기반 청구 완료/미청구/확인 불가를 표시한다. 증명 요청은 한 번 제출하고 자동으로 패키지를 수신하며 JSON 다운로드는 선택이다. 목적지 화면으로 이동해 청구 확인·지갑 승인 후 저장된 거래 상태 조회로 수락 여부를 확인한다. 미확인 거래가 있어도 지갑 재연결은 가능하며 자동 재전송하지 않는다. 외부 확장 지갑 승인·거절·재연결 시험과 DOCX 페이지 검수는 미검증으로 남긴다.')
ui_current._p.getparent().remove(ui_current._p);current_text._p.addnext(ui_current._p)
audit_current=doc.add_paragraph('추가 운영 기능: 두 체인의 감사 계약에 서버 감사 로그의 연결 해시를 등록하고 공개 API/UI에 브리지 거래·증명 이력을 남긴다. 등록 root와 반복 조회한 원본 기록이 다르면 신규 증명·패키지 제공을 긴급 정지한다. 임의 오류 요청만으로 정지하지 않는다. 기존 불변 배포 계약은 직접 청구 정지가 미지원이고, 새 DevHeaderRegistry 배포에서 root 조회를 차단해 온체인 신규 청구를 중단한다. 기존 지급을 취소하지 않으며 현재 잔액은 보존했다. 테스트넷이나 독립 제3자 감사 서비스에 배포한 것은 아니다.')
audit_current._p.getparent().remove(audit_current._p);ui_current._p.addnext(audit_current._p)
target.parent.mkdir(exist_ok=True)
doc.save(target)
with ZipFile(source) as before, ZipFile(target) as after:
    assert before.read('word/media/image1.png')==after.read('word/media/image1.png')
assert Document(target).paragraphs[0].style.name=='Title'
print(target)
print('Original diagram retained; OOXML round-trip passed')
