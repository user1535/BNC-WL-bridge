#!/usr/bin/env python3
"""Accept a genuine offline local Groth16 batch in an actual owned EVM updater."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import time
import urllib.request

ROOT = Path(__file__).resolve().parents[1]


def main():
    def interrupted(signum, frame): raise KeyboardInterrupt('local updater diagnostic interrupted')
    signal.signal(signal.SIGTERM, interrupted)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--evidence', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--diagnostic-max-headers', type=int, choices=(4, 8, 16, 32, 64, 128), default=4,
        help='explicit larger local profiling proof only; no asset claim or normal generator cap change')
    args = parser.parse_args()
    out = args.output_dir.resolve(); out.mkdir(parents=True, exist_ok=False)
    source = args.evidence.resolve()
    env = dict(os.environ, RISC0_DEV_MODE='0')
    report = {'measuredAt': datetime.now(timezone.utc).isoformat(), 'localVerdict': 'FAIL',
        'sourceEvidence': str(source), 'freshProofGeneratedHere': False,
        'chainAuthenticated': False, 'realAssetDeploymentAllowed': False, 'assetClaimsSubmitted': 0,
        'userSignedAssetTransactions': False, 'negativeChecks': []}
    url = 'http://127.0.0.1:8576'
    node = None

    def command(arguments):
        result = subprocess.run([str(a) for a in arguments], cwd=ROOT, env=env, text=True,
            capture_output=True, timeout=120)
        if result.returncode: raise ValueError(result.stderr or result.stdout)
        return result.stdout.strip()

    def rpc(method, params):
        with urllib.request.urlopen(urllib.request.Request(url, json.dumps({'jsonrpc': '2.0', 'id': 1,
            'method': method, 'params': params}).encode(), {'Content-Type': 'application/json'}), timeout=15) as response:
            data = json.load(response)
        if 'error' in data: raise ValueError(str(data['error']))
        return data['result']

    def raw(value): return '0x' + bytes(value).hex()

    try:
        summary = json.loads((source / 'summary.json').read_text())
        for name, key in [('risc0-host', 'hostSHA256'), ('input.json', 'inputSHA256'), ('receipt.json', 'receiptSHA256')]:
            if hashlib.sha256((source / name).read_bytes()).hexdigest() != summary[key]:
                raise ValueError('evidence SHA changed: ' + name)
        if summary['localVerdict'] != 'PASS' or summary['chainAuthenticated'] is not False:
            raise ValueError('completed untrusted local evidence required')
        verified = json.loads(command([source / 'risc0-host', '--verify-receipt', source / 'receipt.json']))
        binding = verified.get('header_binding', 'minimal-link')
        if (not verified['verified'] or verified['receipt_kind'] != 'groth16' or not verified['evm_compatible']
            or verified['chain_authenticated'] is not False or verified['image_id'] != summary['imageId']
            or binding not in ('minimal-link', 'canonical-rlp')):
            raise ValueError('genuine local Groth16 required')
        inp = json.loads((source / 'input.json').read_text()); headers = inp['headers']
        source_id = inp['chain_id']; destination_id = {31337: 31338, 31338: 31337}[source_id]
        if not 1 <= len(headers) <= args.diagnostic_max_headers: raise ValueError('chosen local diagnostic export cap')
        if args.diagnostic_max_headers != 4 and (summary.get('profilePhasesRequested') is not True
            or summary.get('diagnosticMaxHeaders') != args.diagnostic_max_headers or binding != 'minimal-link'
            or summary.get('normalGeneratorExportCapChanged') is not False):
            raise ValueError('larger batch requires explicit completed minimal-link phase profile')
        report.update(diagnosticMaxHeaders=args.diagnostic_max_headers, normalGeneratorExportCapChanged=False)
        seal, journal, image = verified['seal'], verified['journal'], verified['image_id']
        for item in json.loads((ROOT / 'docs/risc0-verifier-sources.json').read_text()):
            if hashlib.sha256((ROOT / item['path']).read_bytes()).hexdigest() != item['local_sha256']:
                raise ValueError('pinned verifier source changed')
        with socket.socket() as probe:
            probe.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            probe.bind(('127.0.0.1', 8576)); probe.listen(1)
        with (out / 'anvil.log').open('w') as log:
            node = subprocess.Popen(['anvil', '--silent', '--host', '127.0.0.1', '--port', '8576',
                '--chain-id', str(destination_id)], stdout=log, stderr=log)
        for _ in range(50):
            if node.poll() is not None: raise ValueError('owned node exited')
            try:
                if int(rpc('eth_chainId', []), 16) != destination_id: raise ValueError('local destination required')
                break
            except OSError: time.sleep(.1)
        else: raise ValueError('local node startup timeout')
        sender = rpc('eth_accounts', [])[0]

        def deploy(contract, arguments=()):
            cmd = ['forge', 'create', '--root', ROOT / 'contracts', contract, '--rpc-url', url,
                '--unlocked', '--from', sender, '--broadcast', '--json']
            if arguments: cmd += ['--constructor-args', *arguments]
            return json.loads(command(cmd))['deployedTo']

        verifier = deploy('src/bridge/LocalRiscZeroGroth16Verifier.sol:LocalRiscZeroGroth16Verifier')
        updater = deploy('src/bridge/Risc0HeaderUpdater.sol:Risc0HeaderUpdater',
            (source_id, verifier, image, headers[0]['number'] - 1, raw(inp['anchor_hash'])))
        tuples = '[' + ','.join('(' + ','.join((str(h['number']), raw(h['block_hash']), raw(h['parent_hash']),
            raw(h['receipt_root']))) + ')' for h in headers) + ']'
        batch_data = command(['cast', 'abi-encode', 'f((uint64,bytes32,bytes32,bytes32)[])', tuples])

        def data(s, j): return command(['cast', 'calldata', 'submitHeaderProof(bytes,bytes,bytes)', s, j, batch_data])

        def rejected(name, payload, target=updater):
            try: rpc('eth_call', [{'from': sender, 'to': target, 'data': payload}, 'latest'])
            except ValueError as error:
                if 'execution reverted' not in str(error).lower(): raise
                report['negativeChecks'].append({'name': name, 'rejected': True})
            else: raise ValueError(name + ' incorrectly accepted')

        def flip(h):
            b = bytearray.fromhex(h[2:]); b[-1] ^= 1
            return '0x' + b.hex()

        rejected('altered-seal', data(flip(seal), journal))
        rejected('wrong-journal', data(seal, flip(journal)))
        digest = '0x' + hashlib.sha256(bytes.fromhex(journal[2:])).hexdigest()
        rejected('wrong-image', command(['cast', 'calldata', 'verify(bytes,bytes32,bytes32)', seal, flip(image), digest]), verifier)
        payload = data(seal, journal)
        receipt = json.loads(command(['cast', 'send', updater, '--data', payload, '--rpc-url', url,
            '--unlocked', '--from', sender, '--json']))
        if int(receipt['status'], 16) != 1: raise ValueError('actual updater transaction failed')
        (out / 'accepted-transaction.json').write_text(json.dumps(receipt, indent=2) + '\n')
        rejected('already-accepted-batch', payload)
        for header in headers:
            coverage = command(['cast', 'call', updater, 'isBlockCovered(uint256,uint256,bytes32)(bool)',
                source_id, header['number'], raw(header['block_hash']), '--rpc-url', url])
            root = command(['cast', 'call', updater, 'getReceiptRoot(uint256,uint256,bytes32)(bytes32)',
                source_id, header['number'], raw(header['block_hash']), '--rpc-url', url])
            if coverage != 'true' or root.lower() != raw(header['receipt_root']).lower():
                raise ValueError('accepted header coverage/root mismatch')
        report.update(localVerdict='PASS', realEvmHeaderAcceptance=True, imageId=image,
            headerBinding=binding, sourceChainId=source_id, destinationChainId=destination_id,
            batchSize=len(headers), updater=updater, verifier=verifier, gasUsed=int(receipt['gasUsed'], 16),
            calldataBytes=len(bytes.fromhex(payload[2:])), receiptSHA256=summary['receiptSHA256'],
            acceptedCoverageAndRootsChecked=True)
    except BaseException as error:
        report['error'] = str(error); raise
    finally:
        if node and node.poll() is None:
            node.terminate()
            try: node.wait(timeout=5)
            except subprocess.TimeoutExpired: node.kill(); node.wait()
        report['ownedNodeStopped'] = node is None or node.poll() is not None
        (out / 'summary.json').write_text(json.dumps(report, indent=2) + '\n')
    print('PASS actual updater', report['imageId'], report['batchSize'], report['gasUsed'])


if __name__ == '__main__': main()
