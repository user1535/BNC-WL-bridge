#!/usr/bin/env python3
"""Read a running owned local session and export public wallet contract bindings."""
import argparse
import importlib.util
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('local_session',ROOT/'scripts/local-session.py')
module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--session',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    session=module.Session(args.session); session.guard()
    data=session.data
    if data['phase']!='ready' or data['mode'] not in ('dev','risc0_batch'):
        raise ValueError('ready dev or Groth16 local session required')
    manifest={'version':1,'mode':data['mode'],'headerBinding':data.get('header_binding','minimal-link'),
        'chainAuthenticated':False,'realAssetDeploymentAllowed':False,
        'chains':{k:{'id':v['id'],'rpc':v['rpc']} for k,v in data['chains'].items()},
        'contracts':{},'runtimeCode':{},'imageId':data.get('image_id'), 'users':data['users']}
    for name,chain in [('original','wl'),('wrapped','bnb'),('mint','bnb'),('unlock','wl'),('wl_headers','wl'),('bnb_headers','bnb')]:
        address=data['contracts'][name]
        code=session.rpc(chain,'eth_getCode',[address,'latest'])
        if code=='0x': raise ValueError('missing contract runtime: '+name)
        manifest['contracts'][name]=address;manifest['runtimeCode'][name]=code
    args.output.parent.mkdir(parents=True,exist_ok=True)
    with args.output.open('x') as handle: json.dump(manifest,handle,indent=2);handle.write('\n')
    print(args.output)
if __name__=='__main__': main()
