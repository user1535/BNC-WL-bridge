#!/usr/bin/env python3
"""Bounded eth_call observations of EIP-2537; no transactions or authentication."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import time
import urllib.error
import urllib.request

TARGETS = {
    'worldland': ('https://seoul.worldland.foundation/', 103),
    'bnb': ('https://bsc-dataseed.nariox.org/', 56),
}
SPEC = 'https://eips.ethereum.org/EIPS/eip-2537'
ONE = '0x' + (1).to_bytes(32, 'big').hex()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--chain', choices=('worldland', 'bnb', 'both'), default='both')
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    out = args.output_dir.resolve()
    out.mkdir(parents=True, exist_ok=False)
    report = {
        'observedAt': datetime.now(timezone.utc).isoformat(), 'readOnly': True,
        'specification': SPEC, 'rpcCalls': 0, 'transactionsSent': 0, 'proofsGenerated': 0,
        'chainAuthenticated': False, 'realAssetDeploymentAllowed': False,
        'scope': 'RPC eth_call behaviour at one pinned height; no fork/consensus authentication',
        'targets': {}, 'localVerdict': 'INCOMPLETE',
    }
    last_request = 0

    def query(directory, endpoint, label, method, params):
        nonlocal last_request
        if method not in ('eth_chainId', 'web3_clientVersion', 'eth_getBlockByNumber', 'eth_call'):
            raise ValueError('unsupported diagnostic method')
        time.sleep(max(0, .5 - (time.monotonic() - last_request)))
        request = {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params}
        (directory / (label + '-request.json')).write_text(json.dumps(request) + '\n')
        last_request = time.monotonic()
        report['rpcCalls'] += 1
        try:
            with urllib.request.urlopen(urllib.request.Request(endpoint, json.dumps(request).encode(),
                {'Content-Type': 'application/json', 'User-Agent': 'WorldLand-BNB-read-only-BLS-diagnostic'}),
                timeout=15) as response:
                raw = response.read(2 * 1024 * 1024 + 1)
            if len(raw) > 2 * 1024 * 1024:
                raise ValueError('response limit exceeded')
            (directory / (label + '-response.json')).write_bytes(raw)
            data = json.loads(raw)
            if data.get('id') != 1 or data.get('jsonrpc') != '2.0':
                raise ValueError('invalid RPC envelope')
            if 'result' not in data and 'error' not in data:
                raise ValueError('missing RPC outcome')
            return data
        except (OSError, ValueError, urllib.error.URLError) as error:
            data = {'transportError': str(error)}
            (directory / (label + '-transport-error.json')).write_text(json.dumps(data) + '\n')
            return data

    def required(data):
        if data.get('error') or data.get('transportError') or data.get('result') is None:
            raise ValueError(str(data))
        return data['result']

    def execution_error(data):
        message = str(data.get('error', {}).get('message', '')).lower()
        return any(term in message for term in ('execution', 'revert', 'out of gas', 'invalid input length',
                                                'invalid point', 'invalid field', 'precompile'))

    # EIP-2537 infinity is all-zero coordinates. Variable-length empty inputs
    # must error; an unknown empty-code address returning 0x is not support.
    vectors = {
        'g1add': (11, bytes(256), '0x' + bytes(128).hex()),
        'g1msm': (12, bytes(128) + (1).to_bytes(32, 'big'), '0x' + bytes(128).hex()),
        'g2add': (13, bytes(512), '0x' + bytes(256).hex()),
        'g2msm': (14, bytes(256) + (1).to_bytes(32, 'big'), '0x' + bytes(256).hex()),
        'pairing': (15, bytes(384), ONE),
    }
    for name, (endpoint, chain_id) in TARGETS.items():
        if args.chain not in ('both', name):
            continue
        directory = out / name
        directory.mkdir()
        row = {'endpoint': endpoint, 'expectedChainId': chain_id, 'verdict': 'INCOMPLETE', 'operations': {}}
        report['targets'][name] = row
        try:
            if int(required(query(directory, endpoint, 'chain-id', 'eth_chainId', [])), 16) != chain_id:
                raise ValueError('unexpected chain ID')
            row['clientVersion'] = required(query(directory, endpoint, 'client', 'web3_clientVersion', []))
            header = required(query(directory, endpoint, 'head', 'eth_getBlockByNumber', ['latest', False]))
            height, block_hash = header['number'], header['hash']
            row.update(blockNumber=int(height, 16), blockHash=block_hash)

            def call(label, address, payload):
                return query(directory, endpoint, label, 'eth_call', [{
                    'to': '0x' + address.to_bytes(20, 'big').hex(),
                    'data': '0x' + payload.hex(), 'gas': hex(2_000_000),
                }, height])

            row['bn254EmptyPairingControl'] = call('bn254-control', 8, b'')
            if row['bn254EmptyPairingControl'].get('result', '').lower() != ONE:
                raise ValueError('known BN254 control failed; capability observation is inconclusive')
            for operation, (address, payload, expected) in vectors.items():
                valid = call(operation + '-infinity', address, payload)
                invalid = call(operation + '-invalid-length', address, b'\x00')
                entry = {'address': hex(address), 'inputBytes': len(payload), 'expectedResult': expected,
                    'validOutcome': valid, 'invalidLengthOutcome': invalid,
                    'canonicalInfinityResultMatches': valid.get('result', '').lower() == expected,
                    'invalidLengthRejectedByExecution': execution_error(invalid)}
                if operation in ('g1msm', 'g2msm', 'pairing'):
                    empty = call(operation + '-empty', address, b'')
                    entry.update(emptyInputOutcome=empty, emptyInputRejectedByExecution=execution_error(empty))
                entry['observedBehaviourMatchesEIP2537'] = (entry['canonicalInfinityResultMatches']
                    and entry['invalidLengthRejectedByExecution']
                    and entry.get('emptyInputRejectedByExecution', True))
                row['operations'][operation] = entry
            rechecked = required(query(directory, endpoint, 'head-rechecked', 'eth_getBlockByNumber', [height, False]))
            if rechecked['hash'].lower() != block_hash.lower():
                raise ValueError('pinned block changed during observation')
            row['headUnchangedDuringObservation'] = True
            row['allObservedOperationsMatchEIP2537'] = all(
                v['observedBehaviourMatchesEIP2537'] for v in row['operations'].values())
            outcomes = [v['validOutcome'] for v in row['operations'].values()]
            if row['allObservedOperationsMatchEIP2537']:
                row['verdict'] = 'OBSERVED_SUPPORTED'
            elif all(v.get('result') == '0x' for v in outcomes):
                row['verdict'] = 'OBSERVED_EMPTY_CODE_BEHAVIOUR'
            else:
                row['verdict'] = 'INCONCLUSIVE_OR_PARTIAL'
            row['limitations'] = [
                'RPC-reported block, client and chain ID are unauthenticated',
                'infinity vectors probe availability, not full curve conformance or BLS signature validity',
                'map-to-curve operations 0x10/0x11 were not probed',
                'validator keys, PoP registration, epoch transitions and finality are not authenticated',
            ]
        except (ValueError, KeyError, TypeError) as error:
            row['error'] = str(error)
    report['localVerdict'] = 'PASS' if all(r['verdict'] in (
        'OBSERVED_SUPPORTED', 'OBSERVED_EMPTY_CODE_BEHAVIOUR') for r in report['targets'].values()) else 'INCOMPLETE'
    report['artifactSHA256'] = {str(p.relative_to(out)): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in out.rglob('*') if p.is_file()}
    (out / 'summary.json').write_text(json.dumps(report, indent=2) + '\n')
    for name, row in report['targets'].items():
        print(name, row['verdict'], row.get('error', ''))
    return 0 if report['localVerdict'] == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
