#!/usr/bin/env python3
"""Pinned BNB config predicates against an independent Go source harness; local only."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import signal
import socket
import subprocess
import time
import urllib.request

ROOT = Path(__file__).resolve().parents[1]


def main():
    def interrupted(*_): raise KeyboardInterrupt('fork predicate diagnostic interrupted')
    signal.signal(signal.SIGTERM, interrupted)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    out = args.output_dir.resolve(); out.mkdir(parents=True, exist_ok=False)
    url = 'http://127.0.0.1:8579'; node = None
    report = {'measuredAt':datetime.now(timezone.utc).isoformat(),'localVerdict':'FAIL',
        'risc0Used':False,'proofsGenerated':0,'assetClaimsSubmitted':0,'checks':[],
        'forkPolicyAuthenticated':False,'snapshotAuthenticated':False,'nativeForkPolicyValidated':False,
        'finalityVerified':False,'chainAuthenticated':False,'realAssetDeploymentAllowed':False}
    def command(argv):
        p = subprocess.run([str(a) for a in argv],cwd=ROOT,capture_output=True,text=True,timeout=120)
        if p.returncode: raise ValueError(p.stderr or p.stdout)
        return p.stdout.strip()
    def rpc(method,params):
        req = urllib.request.Request(url,json.dumps({'jsonrpc':'2.0','id':1,'method':method,'params':params}).encode(),
            {'Content-Type':'application/json'})
        with urllib.request.urlopen(req,timeout=15) as reply: data=json.load(reply)
        if 'error' in data: raise ValueError(str(data['error']))
        return data['result']
    try:
        captured = ROOT/'proof-generator/internal/chain/testdata/native-live-captured'
        for item in json.loads((captured/'manifest.json').read_text())['fixtures']:
            if hashlib.sha256((captured/item['file']).read_bytes()).hexdigest()!=item['sha256']:
                raise ValueError('captured fixture changed')
        for item in json.loads((ROOT/'docs/protocol-sources/oracle-manifest.json').read_text()):
            if hashlib.sha256((ROOT/item['path']).read_bytes()).hexdigest()!=item['localSHA256']:
                raise ValueError('pinned oracle changed')
        config = ROOT/'docs/protocol-sources/bnb-v1.7.8-config.go'
        expected_source = '2b8a681c79dd05555ec7186bd1a69da47add698f6782da2e514c805cefb4be4d'
        if hashlib.sha256(config.read_bytes()).hexdigest()!=expected_source: raise ValueError('pinned mainnet config changed')
        binary = out/'bnb-fork-vectors'
        command(['go','-C',ROOT/'proof-generator','build','-o',binary,'./cmd/bnb-fork-vectors'])
        vectors = json.loads(command([binary,'--fixture-dir',captured]))
        if (vectors['configSourceSHA256']!=expected_source or vectors['sourceChainId']!=56
            or vectors['chainAuthenticated'] is not False or vectors['nativeForkPolicyValidated'] is not False):
            raise ValueError('fork predicate oracle scope mismatch')
        artifact = out/'fork-predicate-oracle.json'
        artifact.write_text(json.dumps(vectors,indent=2)+'\n')
        report['oracleSHA256'] = hashlib.sha256(artifact.read_bytes()).hexdigest()
        report['binarySHA256'] = hashlib.sha256(binary.read_bytes()).hexdigest()
        report['configSourceSHA256'] = expected_source
        command(['forge','build','--root',ROOT/'contracts','--offline','--quiet'])
        report['sourceSHA256'] = {p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in (
            'contracts/test/BNBForkPredicateDiagnostic.sol','contracts/test/BNBRawHeaderVoteDiagnostic.sol',
            'contracts/test/BNBVoteBLSDiagnostic.sol','contracts/src/bridge/lib/RLPReader.sol',
            'proof-generator/cmd/bnb-fork-vectors/main.go','proof-generator/internal/protocoloracle/bnb/fork_predicates.go')}
        with socket.socket() as probe:
            probe.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1); probe.bind(('127.0.0.1',8579)); probe.listen(1)
        with (out/'anvil.log').open('w') as log:
            node = subprocess.Popen(['anvil','--silent','--host','127.0.0.1','--port','8579','--chain-id','31337',
                '--hardfork','cancun'],stdout=log,stderr=log)
        for _ in range(50):
            if node.poll() is not None: raise ValueError('owned node exited')
            try:
                if int(rpc('eth_chainId',[]),16)!=31337: raise ValueError('wrong node')
                break
            except OSError: time.sleep(.1)
        else: raise ValueError('owned node startup timeout')
        sender = rpc('eth_accounts',[])[0]
        contract = json.loads(command(['forge','create','--root',ROOT/'contracts',
            'test/BNBForkPredicateDiagnostic.sol:BNBForkPredicateDiagnostic','--rpc-url',url,
            '--unlocked','--from',sender,'--broadcast','--json']))['deployedTo']
        def call(data): return rpc('eth_call',[{'to':contract,'data':data},'latest'])
        def reject(name,data):
            try: call(data)
            except ValueError as error:
                if 'execution reverted' not in str(error).lower(): raise
                report['checks'].append({'name':name,'rejected':True})
            else: raise ValueError(name+' unexpectedly accepted')
        if call(command(['cast','calldata','CONFIG_SOURCE_SHA256()']))!='0x'+expected_source:
            raise ValueError('EVM selected config differs from pinned oracle')
        scalar_checks = []
        for v in vectors['scalarVectors']:
            data = command(['cast','calldata','forkFlags(uint64,bytes32,uint64,uint64)',
                v['sourceChainId'],v['genesis'],v['number'],v['timestamp']])
            if v['accepted']:
                if call(data)!='0x'+v['expectedFlags'].to_bytes(32,'big').hex():
                    raise ValueError('pinned config predicate mismatch: '+v['name'])
            else: reject('domain-'+v['name'],data)
            scalar_checks.append({'name':v['name'],'accepted':v['accepted'],'goEvmAgreement':True})
        actual_checks = []
        for v in vectors['actualRawVectors']:
            data = command(['cast','calldata','rawForkFlags(bytes,uint64,bytes32)',v['rawHeader'],56,vectors['pinnedGenesis']])
            expected = bytes.fromhex(v['headerHash'][2:])+b''.join(int(v[k]).to_bytes(32,'big') for k in ('number','timestamp','expectedFlags'))
            if call(data)!='0x'+expected.hex(): raise ValueError('raw actual header/config mismatch')
            actual_checks.append({'name':v['name'],'headerHash':v['headerHash'],'number':v['number'],
                'timestamp':v['timestamp'],'flags':v['expectedFlags'],'goEvmAgreement':True})
        for v in vectors['rawNegativeVectors']:
            reject(v['name'],command(['cast','calldata','rawForkFlags(bytes,uint64,bytes32)',v['rawHeader'],56,vectors['pinnedGenesis']]))
        report.update(localVerdict='PASS',forkPredicatesCompared=True,flagOrder=vectors['flagOrder'],
            scalarChecks=scalar_checks,scalarOracleCases=len(scalar_checks),
            scalarPositiveCases=sum(v['accepted'] for v in scalar_checks),scalarNegativeCases=sum(not v['accepted'] for v in scalar_checks),
            actualRawChecks=actual_checks,actualRawCases=len(actual_checks),rawNegativeCases=len(vectors['rawNegativeVectors']))
    except BaseException as error:
        report['error']=str(error); raise
    finally:
        if node and node.poll() is None:
            node.terminate()
            try: node.wait(timeout=5)
            except subprocess.TimeoutExpired: node.kill(); node.wait()
        report['ownedNodeStopped']=node is None or node.poll() is not None
        (out/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
    print('PASS pinned fork predicates; bootstrap/native policy/auth/proof/assets0')


if __name__=='__main__': main()
