#!/usr/bin/env python3
"""RISC0-free actual BNB supplied-key vote + raw source/target commitments in a local EVM."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import signal
import socket
import subprocess
import time
import urllib.request

ROOT = Path(__file__).resolve().parents[1]


def main():
    def interrupted(*_): raise KeyboardInterrupt('raw header vote diagnostic interrupted')
    signal.signal(signal.SIGTERM, interrupted)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--hardfork', choices=('prague', 'cancun'), default='prague')
    parser.add_argument('--attesting-header', action='store_true',
                        help='explicit post-Luban non-epoch adjacent witness; extract vote and bind compressed signature')
    parser.add_argument('--epoch-header', action='store_true',
                        help='also bind supplied post-Bohr epoch key bytes; no epoch eligibility/transition authentication')
    parser.add_argument('--ecdsa-seals', action='store_true',
                        help='also compare pinned BNB56 seal hash/recovery and supplied-epoch membership; no consensus state')
    args = parser.parse_args()
    if args.epoch_header and not args.attesting_header: parser.error('epoch byte binding requires attesting-header')
    if args.ecdsa_seals and not args.epoch_header: parser.error('ECDSA seal diagnostic requires epoch-header')
    out = args.output_dir.resolve(); out.mkdir(parents=True, exist_ok=False)
    url = 'http://127.0.0.1:8577'; node = None
    report = {'measuredAt': datetime.now(timezone.utc).isoformat(), 'localVerdict': 'FAIL',
        'hardfork': args.hardfork, 'risc0Used': False, 'proofsGenerated': 0, 'assetClaimsSubmitted': 0,
        'sourceConsensusAuthenticated': False, 'proofOfPossessionAuthenticated': False,
        'validatorSetAuthenticated': False, 'highestJustifiedSourceVerified': False,
        'finalityVerified': False, 'nativeForkPolicyValidated': False, 'attestingHeaderPayloadBoundHere': False,
        'chainAuthenticated': False, 'realAssetDeploymentAllowed': False, 'checks': [], 'transactions': []}
    report['attestingHeaderPayloadBindingRequested'] = args.attesting_header

    def command(arguments):
        p = subprocess.run([str(a) for a in arguments], cwd=ROOT, capture_output=True, text=True, timeout=120)
        if p.returncode: raise ValueError(p.stderr or p.stdout)
        return p.stdout.strip()
    def rpc(method, params):
        with urllib.request.urlopen(urllib.request.Request(url, json.dumps({'jsonrpc':'2.0', 'id':1,
            'method':method, 'params':params}).encode(), {'Content-Type':'application/json'}), timeout=15) as response:
            data = json.load(response)
        if 'error' in data: raise ValueError(str(data['error']))
        return data['result']
    def hex_bytes(data): return '0x' + data.hex()
    def flip(value):
        b = bytearray.fromhex(value[2:]); b[-1] ^= 1; return hex_bytes(b)
    def mutate_root(raw):
        # Locate field5 in an already Go-verified canonical fixture. This scanner
        # only mutates test input; acceptance/parsing happens in the EVM contract.
        b = bytearray.fromhex(raw[2:])
        def payload(offset):
            prefix = b[offset]
            if prefix < 0x80: return offset, 1, offset + 1
            short = prefix - (0xc0 if prefix >= 0xc0 else 0x80)
            if short <= 55: return offset + 1, short, offset + 1 + short
            width = prefix - (0xf7 if prefix >= 0xc0 else 0xb7)
            length = int.from_bytes(b[offset+1:offset+1+width], 'big')
            start = offset + 1 + width
            return start, length, start + length
        cursor, _, _ = payload(0)
        for index in range(6):
            start, length, end = payload(cursor)
            if index == 5:
                if length != 32: raise ValueError('fixture root width')
                b[start+31] ^= 1
                return hex_bytes(b)
            cursor = end

    try:
        captured = ROOT / 'proof-generator/internal/chain/testdata/native-live-captured'
        for row in json.loads((captured / 'manifest.json').read_text())['fixtures']:
            if hashlib.sha256((captured / row['file']).read_bytes()).hexdigest() != row['sha256']:
                raise ValueError('captured native fixture changed')
        exporter = out / 'bnb-vote-signature-inspect'; inspector = out / 'bridge-header-inspect'
        oracle = out / 'bnb-raw-vote-vectors'
        binaries = [(exporter,'bnb-vote-signature-inspect'), (inspector,'bridge-header-inspect'),
                    (oracle, 'bnb-raw-vote-vectors')]
        epoch_oracle = out / 'bnb-epoch-vote-vectors'
        if args.epoch_header: binaries.append((epoch_oracle, 'bnb-epoch-vote-vectors'))
        seal_inspector = out / 'bnb-seal-inspect'
        seal_oracle = out / 'bnb-seal-vectors'
        if args.ecdsa_seals:
            binaries.extend([(seal_inspector,'bnb-seal-inspect'), (seal_oracle,'bnb-seal-vectors')])
        for binary, package in binaries:
            command(['go', '-C', ROOT / 'proof-generator', 'build', '-o', binary, './cmd/' + package])
        report['binarySHA256'] = {b.name:hashlib.sha256(b.read_bytes()).hexdigest() for b,_ in binaries}
        epoch = json.loads(command([inspector, '--input', captured / 'bnb-epoch.json', '--encoding-profile','bnb-v1.7.8'])) if args.epoch_header else None
        epoch_vectors = None
        if args.epoch_header:
            epoch_vectors = json.loads(command([epoch_oracle, '--input', captured / 'bnb-epoch.json',
                '--vote-input', captured / 'bnb-parent.json']))
            artifact = out / 'epoch-vote-schema-oracle.json'
            artifact.write_text(json.dumps(epoch_vectors,indent=2)+'\n')
            report['epochVoteSchemaOracleSHA256'] = hashlib.sha256(artifact.read_bytes()).hexdigest()
        seal_inspections = {}
        if args.ecdsa_seals:
            for label in ('epoch','source728','target729','parent','latest'):
                inspected = json.loads(command([seal_inspector,'--input',captured/('bnb-'+label+'.json'),'--source-chain-id','56']))
                if (inspected.get('signerMatchesCoinbase') is not True or inspected.get('chainAuthenticated') is not False
                    or inspected.get('snapshotAuthenticated') is not False or inspected.get('sourceChainId') != 56):
                    raise ValueError('Go seal inspector exceeded its scope')
                seal_inspections[label] = inspected
            (out/'ecdsa-seal-inspections.json').write_text(json.dumps(seal_inspections,indent=2)+'\n')
            seal_vectors = json.loads(command([seal_oracle,'--fixture-dir',captured]))
            if (seal_vectors['sourceChainId'] != 56 or seal_vectors['newSignaturesGenerated'] != 0
                or seal_vectors['unsupportedSourceDomainsRejected'] != [0,57,31337]
                or seal_vectors['chainAuthenticated'] is not False):
                raise ValueError('seal codec oracle scope mismatch')
            artifact = out / 'ecdsa-seal-codec-oracle.json'
            artifact.write_text(json.dumps(seal_vectors,indent=2)+'\n')
            report['ecdsaSealCodecOracleSHA256'] = hashlib.sha256(artifact.read_bytes()).hexdigest()
        vectors = json.loads(command([oracle]))
        (out / 'synthetic-number-oracle.json').write_text(json.dumps(vectors,indent=2)+'\n')
        rows = []
        for label, source, target in [('parent','source728','target729'), ('latest','target729','parent')]:
            inspected = json.loads(command([exporter, '--input', captured / ('bnb-'+label+'.json'),
                '--epoch-input', captured / 'bnb-epoch.json', '--layout', 'post-luban-non-epoch',
                '--epoch-layout', 'post-bohr-epoch', '--epoch-length', '1000', '--source-input',
                captured / ('bnb-'+source+'.json'), '--target-input', captured / ('bnb-'+target+'.json'), '--evm-witness']))
            if (inspected['inspection']['pairingVerifiedAgainstSuppliedKeys'] is not True
                or inspected['inspection']['signedSourceTargetHeadersBound'] is not True):
                raise ValueError('offline actual signed header witness required')
            headers = [json.loads(command([inspector, '--input', captured / ('bnb-'+name+'.json'),
                '--encoding-profile', 'bnb-v1.7.8'])) for name in (source,target)]
            if not all(h['hashMatchesRpc'] and not h['chainAuthenticated'] for h in headers):
                raise ValueError('native raw hash binding required')
            row = {'label':label, 'signedVote':inspected, 'headers':headers,
                'parentHashes':[json.loads((captured / ('bnb-'+n+'.json')).read_text())['parentHash'] for n in (source,target)]}
            if args.attesting_header:
                row['attestingHeader'] = json.loads(command([inspector, '--input', captured / ('bnb-'+label+'.json'),
                    '--encoding-profile', 'bnb-v1.7.8']))
            (out / (label+'-witness.json')).write_text(json.dumps(row,indent=2)+'\n'); rows.append(row)
        command(['forge','build','--root',ROOT / 'contracts','--offline','--quiet'])
        report['contractSourceSHA256'] = {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [
            ROOT / 'contracts/test/BNBRawHeaderVoteDiagnostic.sol', ROOT / 'contracts/test/BNBVoteBLSDiagnostic.sol',
            ROOT / 'contracts/test/BNBAttestingHeaderVoteDiagnostic.sol', ROOT / 'contracts/src/bridge/lib/RLPReader.sol']}
        p = ROOT / 'contracts/test/BNBVoteWireDiagnostic.sol'
        report['contractSourceSHA256'][str(p.relative_to(ROOT))] = hashlib.sha256(p.read_bytes()).hexdigest()
        if args.epoch_header:
            p = ROOT / 'contracts/test/BNBEpochHeaderVoteDiagnostic.sol'
            report['contractSourceSHA256'][str(p.relative_to(ROOT))] = hashlib.sha256(p.read_bytes()).hexdigest()
        if args.ecdsa_seals:
            p = ROOT / 'contracts/test/BNBParliaSealDiagnostic.sol'
            report['contractSourceSHA256'][str(p.relative_to(ROOT))] = hashlib.sha256(p.read_bytes()).hexdigest()
        with socket.socket() as probe:
            probe.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1); probe.bind(('127.0.0.1',8577)); probe.listen(1)
        with (out / 'anvil.log').open('w') as log:
            node = subprocess.Popen(['anvil','--silent','--host','127.0.0.1','--port','8577','--chain-id','31337',
                '--hardfork',args.hardfork],stdout=log,stderr=log)
        for _ in range(50):
            if node.poll() is not None: raise ValueError('owned diagnostic node exited')
            try:
                if int(rpc('eth_chainId',[]),16) != 31337: raise ValueError('wrong local node')
                break
            except OSError: time.sleep(.1)
        else: raise ValueError('local startup timeout')
        sender = rpc('eth_accounts',[])[0]
        contract_name = 'BNBAttestingHeaderVoteDiagnostic' if args.attesting_header else 'BNBRawHeaderVoteDiagnostic'
        if args.epoch_header: contract_name = 'BNBEpochHeaderVoteDiagnostic'
        if args.ecdsa_seals: contract_name = 'BNBParliaSealDiagnostic'
        contract = json.loads(command(['forge','create','--root',ROOT / 'contracts',
            'test/'+contract_name+'.sol:'+contract_name,'--rpc-url',url,
            '--unlocked','--from',sender,'--broadcast','--json']))['deployedTo']

        # Independent geth serializer/hash oracle exercises zero, short/long RLP
        # integer transitions and uint64 limits. These vectors have no signatures.
        for vector in vectors['vectors']:
            encoded = rpc('eth_call',[{'to':contract,'data':command(['cast','calldata',
                'headerVoteCommitments(bytes,bytes)',vector['sourceRaw'],vector['targetRaw']])},'latest'])
            output = bytes.fromhex(encoded[2:])
            if (len(output) != 9*32 or hex_bytes(output[:32]) != vector['voteDataHash']
                or int.from_bytes(output[32:64],'big') != int(vector['sourceNumber'])
                or hex_bytes(output[64:96]) != vector['sourceHash']
                or int.from_bytes(output[160:192],'big') != int(vector['targetNumber'])
                or hex_bytes(output[192:224]) != vector['targetHash']):
                raise ValueError('synthetic geth integer-boundary oracle mismatch')
        report['syntheticRlpIntegerOracleCases'] = len(vectors['vectors'])
        if args.ecdsa_seals:
            seal_checks = []
            for label,inspected in seal_inspections.items():
                payload = bytes.fromhex(rpc('eth_call',[{'to':contract,'data':command(['cast','calldata',
                    'recoverParliaSeal(bytes)',inspected['headerRlp']])},'latest'])[2:])
                expected = (bytes.fromhex(inspected['sealHash'][2:]) + bytes.fromhex(inspected['signer'][2:]).rjust(32,b'\0')
                    + bytes.fromhex(inspected['coinbase'][2:]).rjust(32,b'\0'))
                if payload != expected: raise ValueError('EVM seal hash/recovery differs from pinned Go: '+label)
                seal_checks.append({'label':label,'goEvmAgreement':True,'signerMatchesCoinbase':True,
                    'headerHash':inspected['headerHash'],'sealHash':inspected['sealHash'],'signer':inspected['signer']})
            report['ecdsaSealChecks'] = seal_checks

        def verify_data(row, source_raw=None, target_raw=None, signature=None, attesting_raw=None, supplied_keys=None, epoch_raw=None):
            w = row['signedVote']['evmWitness']
            if args.ecdsa_seals:
                return command(['cast','calldata','verifyEpochSealedVote(bytes,bytes,bytes,bytes,bytes,bytes)',
                    source_raw or row['headers'][0]['headerRlp'],target_raw or row['headers'][1]['headerRlp'],
                    attesting_raw or row['attestingHeader']['headerRlp'],epoch_raw or epoch['headerRlp'],
                    supplied_keys or w['suppliedKeysEIP2537'],signature or w['signatureEIP2537']])
            if args.epoch_header:
                return command(['cast','calldata','verifySuppliedEpochVote(bytes,bytes,bytes,bytes,bytes,bytes)',
                    source_raw or row['headers'][0]['headerRlp'],target_raw or row['headers'][1]['headerRlp'],
                    attesting_raw or row['attestingHeader']['headerRlp'],epoch_raw or epoch['headerRlp'],
                    supplied_keys or w['suppliedKeysEIP2537'],signature or w['signatureEIP2537']])
            if args.attesting_header:
                return command(['cast','calldata','verifyNonEpochAttestingVote(bytes,bytes,bytes,bytes,bytes)',
                    source_raw or row['headers'][0]['headerRlp'],target_raw or row['headers'][1]['headerRlp'],
                    attesting_raw or row['attestingHeader']['headerRlp'],w['suppliedKeysEIP2537'],
                    signature or w['signatureEIP2537']])
            return command(['cast','calldata','verifyRawHeaderVote(bytes,bytes,bytes,uint64,bytes)',
                source_raw or row['headers'][0]['headerRlp'],target_raw or row['headers'][1]['headerRlp'],
                w['suppliedKeysEIP2537'],w['voteBitmap'],signature or w['signatureEIP2537']])
        def rejected(name,data):
            try: rpc('eth_call',[{'from':sender,'to':contract,'data':data,'gas':hex(8_000_000)},'latest'])
            except ValueError as error:
                if 'execution reverted' not in str(error).lower(): raise
                report['checks'].append({'name':name,'rejected':True})
            else: raise ValueError(name+' unexpectedly accepted')
        if args.ecdsa_seals:
            codec_checks = []
            for vector in seal_vectors['vectors']:
                digest_call = command(['cast','calldata','parliaSealHash(bytes)',vector['headerRaw']])
                recovery_call = command(['cast','calldata','recoverParliaSeal(bytes)',vector['headerRaw']])
                if vector['codecAccepted']:
                    if rpc('eth_call',[{'to':contract,'data':digest_call},'latest']) != vector['sealHash']:
                        raise ValueError('pinned seal codec oracle mismatch: '+vector['name'])
                else:
                    rejected('seal-codec-'+vector['name'],digest_call)
                if vector['recoveryAccepted']:
                    recovered = bytes.fromhex(rpc('eth_call',[{'to':contract,'data':recovery_call},'latest'])[2:])
                    expected = (bytes.fromhex(vector['sealHash'][2:])
                        + bytes.fromhex(vector['signer'][2:]).rjust(32,b'\0')
                        + bytes.fromhex(vector['coinbase'][2:]).rjust(32,b'\0'))
                    if recovered != expected: raise ValueError('public seal recovery oracle mismatch: '+vector['name'])
                else:
                    rejected('seal-recovery-'+vector['name'],recovery_call)
                codec_checks.append({k:vector[k] for k in ('name','synthetic','codecAccepted','recoveryAccepted')})
                codec_checks[-1]['goEvmAgreement'] = True
            report.update(ecdsaSealCodecChecks=codec_checks,ecdsaSealCodecOracleCases=len(codec_checks),
                ecdsaSealRecoveryPositiveCases=sum(v['recoveryAccepted'] for v in codec_checks),
                ecdsaSealRecoveryNegativeCases=sum(not v['recoveryAccepted'] for v in codec_checks),
                unsupportedSourceDomainsRejected=[0,57,31337],publicHighSMalleationAccepted=True,
                highSCheckScope='ecrecover mathematics only; not native fork or consensus policy')
        if args.epoch_header:
            schema_checks = []
            keys = rows[0]['signedVote']['evmWitness']['suppliedKeysEIP2537']
            for vector in epoch_vectors['vectors']:
                metadata = command(['cast','calldata','epochOptionalVoteMetadata(bytes)',vector['epochRaw']])
                commitment = command(['cast','calldata','suppliedEpochCommitments(bytes,bytes)',vector['epochRaw'],keys])
                if not vector['goAccepted']:
                    rejected('epoch-vote-schema-'+vector['name'],metadata)
                    rejected('epoch-vote-commitment-'+vector['name'],commitment)
                else:
                    value = bytes.fromhex(rpc('eth_call',[{'to':contract,'data':metadata},'latest'])[2:])
                    expected = bytes(160)
                    if vector['present']:
                        expected = ((1).to_bytes(32,'big') + bytes.fromhex(vector['voteDataHash'][2:])
                            + vector['voteBitmap'].to_bytes(32,'big') + bytes.fromhex(vector['signatureHash'][2:])
                            + vector['reservedExtraLength'].to_bytes(32,'big'))
                    if value != expected: raise ValueError('epoch vote schema metadata differs from Go: '+vector['name'])
                    bound = bytes.fromhex(rpc('eth_call',[{'to':contract,'data':commitment},'latest'])[2:])
                    if len(bound)!=128 or hex_bytes(bound[:32]) != vector['epochHash']:
                        raise ValueError('modified epoch header commitment differs from geth')
                schema_checks.append({'name':vector['name'],'synthetic':vector['synthetic'],
                    'goAccepted':vector['goAccepted'],'evmAgreement':True,'bothSchemaAndCommitmentPathChecked':True})
            report['epochVoteSchemaChecks'] = schema_checks
            report['epochVoteSchemaOracleCases'] = len(schema_checks)
            report['epochVoteSchemaPositiveCases'] = sum(c['goAccepted'] for c in schema_checks)
            report['epochVoteSchemaNegativeCases'] = sum(not c['goAccepted'] for c in schema_checks)
        for row in rows:
            h = row['headers']; w = row['signedVote']['evmWitness']
            output = bytes.fromhex(rpc('eth_call',[{'to':contract,'data':command(['cast','calldata',
                'headerVoteCommitments(bytes,bytes)',h[0]['headerRlp'],h[1]['headerRlp']])},'latest'])[2:])
            if len(output) != 9*32: raise ValueError('header commitment ABI width')
            words = [output[i:i+32] for i in range(0,len(output),32)]
            expected = [bytes.fromhex(w['voteDataHash'][2:])]
            for index in (0,1):
                expected += [h[index]['blockNumber'].to_bytes(32,'big'),bytes.fromhex(h[index]['recomputedHash'][2:]),
                    bytes.fromhex(row['parentHashes'][index][2:]),bytes.fromhex(h[index]['receiptRoot'][2:])]
            if words != expected: raise ValueError('EVM header/VoteData encoding differs from actual Go witness')
            if args.attesting_header:
                a = row['attestingHeader']; vote = row['signedVote']['inspection']['vote']
                for oracle in w['referenceCompressionOracle']:
                    encoded = bytes.fromhex(rpc('eth_call',[{'to':contract,'data':command(['cast','calldata',
                        'compressPairingSignature(bytes)',oracle['pointEIP2537']])},'latest'])[2:])
                    if (len(encoded) != 160 or int.from_bytes(encoded[:32],'big') != 32
                        or int.from_bytes(encoded[32:64],'big') != 96 or hex_bytes(encoded[64:]) != oracle['compressed']):
                        raise ValueError('EVM compression differs from independent blst +/- public point oracle')
                payload = bytes.fromhex(rpc('eth_call',[{'to':contract,'data':command(['cast','calldata',
                    'nonEpochAttestingCommitments(bytes,bytes,bytes)',h[0]['headerRlp'],h[1]['headerRlp'],a['headerRlp']])},'latest'])[2:])
                if (len(payload) != 256 or hex_bytes(payload[:32]) != w['voteDataHash']
                    or int.from_bytes(payload[32:64],'big') != w['voteBitmap']
                    or int.from_bytes(payload[64:96],'big') != 128
                    or hex_bytes(payload[96:128]) != a['recomputedHash']
                    or int.from_bytes(payload[128:160],'big') != 96
                    or hex_bytes(payload[160:256]) != vote['aggregateSignature']):
                    raise ValueError('EVM attesting raw payload differs from Go decoder')
            if args.epoch_header:
                payload = bytes.fromhex(rpc('eth_call',[{'to':contract,'data':command(['cast','calldata',
                    'suppliedEpochCommitments(bytes,bytes)',epoch['headerRlp'],w['suppliedKeysEIP2537']])},'latest'])[2:])
                if (len(payload) != 128 or hex_bytes(payload[:32]) != epoch['recomputedHash']
                    or int.from_bytes(payload[32:64],'big') != epoch['blockNumber']
                    or int.from_bytes(payload[64:96],'big') != w['validatorCount']
                    or int.from_bytes(payload[96:128],'big') != row['signedVote']['inspection']['suppliedEpoch']['turnLength']):
                    raise ValueError('EVM supplied epoch key binding differs from Go')
            data = verify_data(row)
            if args.hardfork == 'cancun': rejected('missing-precompiles-'+row['label'],data); continue
            call_started = time.perf_counter()
            if rpc('eth_call',[{'to':contract,'data':data},'latest']) != hex_bytes((1).to_bytes(32,'big')):
                raise ValueError('actual signed raw header pairing rejected')
            call_seconds = time.perf_counter() - call_started
            transaction_started = time.perf_counter()
            receipt = json.loads(command(['cast','send',contract,'--data',data,'--rpc-url',url,
                '--unlocked','--from',sender,'--json']))
            transaction_seconds = time.perf_counter() - transaction_started
            if int(receipt['status'],16) != 1: raise ValueError('raw signed header transaction failed')
            (out / (row['label']+'-accepted.json')).write_text(json.dumps(receipt,indent=2)+'\n')
            report['transactions'].append({'label':row['label'],'hash':receipt['transactionHash'],
                'gasUsed':int(receipt['gasUsed'],16),'calldataBytes':len(bytes.fromhex(data[2:])),
                'ethCallWallSeconds':call_seconds,'castSendThroughReceiptWallSeconds':transaction_seconds,
                'timingScope':'single local Prague RPC/math check for one vote target with source/target/attesting and supplied epoch; automine; no finality wait or active snapshot authentication'})
            report['checks'].append({'name':'actual-'+row['label'],'evmVoteHashMatchesGo':True,
                'rawNumberHashParentRootChecked':True,'actualEvmPairingVerified':True})
        if args.hardfork == 'prague':
            row = rows[0]; src,tgt = [h['headerRlp'] for h in row['headers']]
            for name,data in [
                ('reversed-source-target',verify_data(row,source_raw=tgt,target_raw=src)),
                ('unrelated-target',verify_data(row,target_raw=rows[1]['headers'][1]['headerRlp'])),
                ('target-receipt-root-mutated',verify_data(row,target_raw=mutate_root(tgt))),
                ('source-receipt-root-mutated',verify_data(row,source_raw=mutate_root(src))),
                ('trailing-source-rlp',verify_data(row,source_raw=src+'00')),
                ('truncated-target-rlp',verify_data(row,target_raw=tgt[:-2])),
                ('oversized-raw-header',verify_data(row,source_raw='0x'+'00'*4097)),
                ('wrong-signature',verify_data(row,signature=flip(row['signedVote']['evmWitness']['signatureEIP2537'])))]:
                rejected(name,data)
            if args.attesting_header:
                raw = row['attestingHeader']['headerRlp']
                compressed = row['signedVote']['inspection']['vote']['aggregateSignature']
                if raw.count(compressed[2:]) != 1: raise ValueError('signature mutation fixture ambiguous')
                sort_flipped = '0x'+format(int(compressed[2:4],16)^0x20,'02x')+compressed[4:]
                bad_padding = '0x01'+row['signedVote']['evmWitness']['signatureEIP2537'][4:]
                for name,data in [
                    ('unrelated-attesting-header',verify_data(row,attesting_raw=rows[1]['attestingHeader']['headerRlp'])),
                    ('compressed-signature-sort-bit',verify_data(row,attesting_raw=raw.replace(compressed[2:],sort_flipped[2:]))),
                    ('compressed-signature-coordinate',verify_data(row,attesting_raw=raw.replace(compressed[2:],flip(compressed)[2:]))),
                    ('other-valid-uncompressed-signature',verify_data(row,signature=rows[1]['signedVote']['evmWitness']['signatureEIP2537'])),
                    ('uncompressed-field-padding',verify_data(row,signature=bad_padding)),
                    ('trailing-attesting-rlp',verify_data(row,attesting_raw=raw+'00'))]:
                    rejected(name,data)
            if args.ecdsa_seals:
                # Signature suffix is the final scalar in extraData (not necessarily
                # the end of the full RLP header). Change only that public seal.
                raw = row['attestingHeader']['headerRlp']
                signature = seal_inspections['parent']['signature'][2:]
                if raw.count(signature)!=1: raise ValueError('ECDSA mutation fixture ambiguous')
                for name,modified in [
                    ('ecdsa-invalid-recovery-id',signature[:-2]+'1b'),
                    ('ecdsa-zero-r','00'*32+signature[64:]),
                    ('ecdsa-zero-s',signature[:64]+'00'*32+signature[128:]),
                    ('ecdsa-altered-r',format(int(signature[:2],16)^1,'02x')+signature[2:]),
                    ('ecdsa-altered-s',signature[:64]+format(int(signature[64:66],16)^1,'02x')+signature[66:])]:
                    rejected(name,verify_data(row,attesting_raw=raw.replace(signature,modified)))
                signature = seal_inspections['epoch']['signature'][2:]
                if epoch['headerRlp'].count(signature)!=1: raise ValueError('epoch ECDSA mutation fixture ambiguous')
                rejected('epoch-ecdsa-zero-r',verify_data(row,epoch_raw=epoch['headerRlp'].replace(signature,'00'*32+signature[64:])))
            if args.epoch_header:
                keys = row['signedVote']['evmWitness']['suppliedKeysEIP2537']
                for name,data in [
                    ('epoch-key-coordinate',verify_data(row,supplied_keys=flip(keys))),
                    ('epoch-key-order',verify_data(row,supplied_keys='0x'+keys[258:514]+keys[2:258]+keys[514:])),
                    ('epoch-key-count',verify_data(row,supplied_keys=keys[:-256])),
                    ('non-epoch-as-epoch',verify_data(row,epoch_raw=row['attestingHeader']['headerRlp'])),
                    ('trailing-epoch-rlp',verify_data(row,epoch_raw=epoch['headerRlp']+'00'))]:
                    rejected(name,data)
        report.update(localVerdict='PASS',rawHeaderCommitmentsMeasured=True,
            actualEvmSignedRawHeaderPairing=args.hardfork=='prague',missingPrecompilesFailClosed=args.hardfork=='cancun')
        if args.attesting_header:
            report.update(attestingHeaderPayloadBoundHere=True,compressedSignatureBoundToPairingInput=True,
                layoutAssumption='post-luban-non-epoch; adjacent source/target/attesting only',
                attestingEcdsaSealVerified=False,validatorTransitionVerified=False,
                observedCompressedSortBits=[bool(int(r['signedVote']['inspection']['vote']['aggregateSignature'][2:4],16)&0x20) for r in rows])
            report['publicPointCompressionOracleCases'] = sum(len(r['signedVote']['evmWitness']['referenceCompressionOracle']) for r in rows)
            report['compressionOracleSortBits'] = sorted({bool(int(o['compressed'][2:4],16)&0x20) for r in rows for o in r['signedVote']['evmWitness']['referenceCompressionOracle']})
        if args.epoch_header:
            report.update(suppliedEpochKeysBoundHere=True,epochEligibilityAuthenticated=False,
                          epochLayoutAssumption='post-bohr-epoch',epochHeader=epoch,
                          epochOptionalVotePayloadValidated=True,epochOptionalVoteSignatureVerified=False)
        if args.ecdsa_seals:
            report.update(ecdsaSealMathMeasured=True,ecdsaSignerMembershipAgainstSuppliedEpoch=True,
                attestingEcdsaSealVerified=True,epochSealSignerMembershipInOwnAnnouncedSetRequired=False,
                sourceChainIdForSeal=56,supportedSealRecoveryIds=[0,1],snapshotAuthenticated=False,
                recentSignerAndTurnPolicyVerified=False,timingDifficultyPolicyVerified=False)
    except BaseException as error:
        report['error']=str(error); raise
    finally:
        if node and node.poll() is None:
            node.terminate()
            try: node.wait(timeout=5)
            except subprocess.TimeoutExpired: node.kill(); node.wait()
        report['ownedNodeStopped']=node is None or node.poll() is not None
        (out / 'summary.json').write_text(json.dumps(report,indent=2)+'\n')
    print('PASS raw header commitments + supplied-key vote',args.hardfork,'RISC0/proving/assets0; authfalse')


if __name__=='__main__':main()
