import {chromium,launchOptions} from './browser-runtime.mjs';
import fs from 'node:fs';
import {fileURLToPath} from 'node:url';
import {WalletClient,validateHeaderStep} from '../wallet/client.mjs';
const root=new URL('../results/prototype-header-steps/',import.meta.url);
const session=JSON.parse(fs.readFileSync(new URL('session.json',root))),saved=JSON.parse(fs.readFileSync(new URL('request.json',root)));
const base='http://127.0.0.1:8580',owner=session.users[0],sends=[];
let chain='bnb';
async function rpc(method,params=[],network=chain) {
  const response=await fetch(session.chains[network].rpc,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({jsonrpc:'2.0',id:1,method,params})});
  const data=await response.json();if(data.error)throw Object.assign(new Error(data.error.message),data.error);return data.result;
}
async function api(path,body) {
  const r=await fetch(base+path,{method:body?'POST':'GET',headers:body?{'Content-Type':'application/json','X-Bridge-Request':'1'}:{},body:body?JSON.stringify(body):undefined});
  return {status:r.status,data:await r.json()};
}
const manifest=(await api('/api/manifest')).data;
const report={passed:false,newProofs:0,serverBroadcasts:0,externalExtensionTested:false,chainAuthenticated:false,realAssetDeploymentAllowed:false};
let browser;
try {
  let initial=await api('/api/jobs',saved.request);
  for(let n=0;n<50&&initial.data.state!=='header_ready';n++) {
    await new Promise(r=>setTimeout(r,200));initial=await api('/api/jobs/'+saved.id);
    if(initial.data.state==='failed')throw new Error(initial.data.detail);
  }
  if(initial.data.state!=='header_ready')throw new Error('intermediate header not returned');
  const result=await api('/api/jobs/'+saved.id+'/package');if(result.status!==200)throw new Error(result.data.error);
  const step=result.data,v=validateHeaderStep(step,manifest);
  if(v.entries[0].number!==112n||v.entries.at(-1).number!==115n)throw new Error('wrong range');
  fs.writeFileSync(new URL('header-step.json',root),JSON.stringify(step,null,2));
  let rejected=0;
  for(const mutate of [
    p=>p.headerProof.imageId='0x'+'11'.repeat(32),
    p=>p.headerProof.journal=p.headerProof.journal.slice(0,-2)+'05',
    p=>p.headerTransaction.data+='00',
    p=>p.headerTransaction.chainId=56,
    p=>p.headerTransaction.to=manifest.contracts.original,
    p=>p.headerTransaction.value='1',
  ]) {
    const p=structuredClone(step);mutate(p);try{validateHeaderStep(p,manifest);}catch{rejected++;continue;}
    throw new Error('tampered step accepted');
  }
  browser=await chromium.launch(launchOptions);
  const context=await browser.newContext(),page=await context.newPage(),errors=[];
  page.on('pageerror',e=>errors.push(e.message));
  await page.exposeFunction('__wallet',async({method,params=[]})=>{
    if(['eth_accounts','eth_requestAccounts'].includes(method))return [owner];
    if(method==='wallet_switchEthereumChain'){chain=BigInt(params[0].chainId)===31337n?'wl':'bnb';return null;}
    const result=await rpc(method,params);if(method==='eth_sendTransaction')sends.push(result);return result;
  });
  await page.addInitScript(()=>{window.ethereum={on(){},request:args=>window.__wallet(args)};});
  const connect=async()=>{
    await page.locator('#load-service').click();await page.waitForFunction(()=>!document.getElementById('connect').disabled);
    await page.locator('#connect').click();await page.waitForFunction(()=>document.getElementById('account').textContent.startsWith('0x'));
  };
  await page.goto(base);await connect();
  await page.evaluate(saved=>localStorage.setItem('worldland-bnb-proof-request-v1',JSON.stringify(saved)),saved);
  await page.reload();await connect();await page.locator('#poll-proof').click();
  await page.waitForFunction(()=>!document.getElementById('prepare-header').disabled);
  if(!await page.locator('#prepare-claim').isDisabled())throw new Error('intermediate header enabled asset claim');
  await page.locator('#prepare-header').click();await page.waitForFunction(()=>!document.getElementById('submit').disabled);
  const review=await page.locator('#review').innerText();if(!review.includes('112 → 115'))throw new Error('missing header review range');
  await page.locator('#submit').click();await page.waitForFunction(()=>document.getElementById('status').textContent.includes('지갑이 전송한 거래:'));
  await page.reload();await connect();await page.locator('#recover').click();await page.waitForFunction(()=>document.getElementById('status').textContent==='거래가 수락됐습니다.');
  const client=new WalletClient({on(){},request:({method,params=[]})=>['eth_accounts','eth_requestAccounts'].includes(method)?Promise.resolve([owner]):rpc(method,params)},manifest);
  try{await client.previewHeaderStep(step);throw new Error('stale header allowed');}catch(e){if(!e.message.includes('stale'))throw e;}
  const stale=await api('/api/jobs/'+saved.id+'/package');if(stale.status!==409)throw new Error('stale delivered');
  await page.locator('#request-proof').click();
  await page.waitForFunction(()=>document.getElementById('status').textContent.includes('요청을 저장했습니다.'));
  let next;
  for(let n=0;n<40;n++){next=(await api('/api/jobs/'+saved.id)).data;if(next.state==='waiting_headers')break;if(next.state==='failed')throw new Error(next.detail);await page.waitForTimeout(200);}
  if(next.state!=='waiting_headers'||!next.detail.includes('116..116'))throw new Error('did not resample next range');
  if(sends.length!==1||errors.length)throw new Error('duplicate wallet sends or browser errors');
  const receipt=await rpc('eth_getTransactionReceipt',[sends[0]],'bnb');
  if(BigInt(receipt.status)!==1n)throw new Error('actual Groth16 EVM rejected');
  await page.screenshot({path:fileURLToPath(new URL('header-step-screen.png',root)),fullPage:true});
  Object.assign(report,{passed:true,actualSdkGroth16:true,actualEvmAccepted:true,range:[112,115],nextRange:[116,116],
    reloadRecovered:true,claimBlockedUntilEventCoverage:true,staleSdkAndWalletRejected:true,tamperedCasesRejected:rejected,walletSends:sends,
    gasUsed:BigInt(receipt.gasUsed).toString(),nextState:next.state});
} catch(error) {report.error=error.message;throw error;}
finally {fs.writeFileSync(new URL('summary.json',root),JSON.stringify(report,null,2));await browser?.close();}
