import {chromium,launchOptions} from './browser-runtime.mjs';
import fs from 'node:fs';
const browser=await chromium.launch(launchOptions);
try{
 const page=await browser.newPage();const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto('http://127.0.0.1:8580/');await page.getByText('● 서버 연결됨').waitFor();
 await page.locator('#wl-connection').filter({hasText:'연결 정상'}).waitFor();
 if(await page.locator('#bnb-height').textContent()==='—')throw Error('BNB block missing');
 await page.route('**/api/chains',route=>route.fulfill({status:503,contentType:'application/json',body:'{}'}));
 await page.getByText('상태 조회 실패 · 자동 재시도 중').waitFor();
 await page.unroute('**/api/chains');
 await page.locator('#wl-connection').filter({hasText:'연결 정상'}).waitFor();
 await page.locator('#load-service').click();
 await page.locator('#wallet-help').waitFor({state:'visible'});
 if(!(await page.locator('#connect').isDisabled()))throw Error('missing wallet connection enabled');
 await page.locator('#demo-forward').click();
 if(await page.locator('#amount').inputValue()!=='1000000000000000000')throw Error('amount conversion');
 await page.locator('#demo-return').click();
 if(await page.locator('#action').inputValue()!=='burn')throw Error('return preset');
 await page.locator('#demo-amount').fill('0');await page.locator('#demo-forward').click();
 if(!(await page.locator('#status').textContent()).includes('0보다'))throw Error('zero validation');
 await page.setViewportSize({width:390,height:844});
 if(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth))throw Error('mobile overflow');
 await page.getByRole('link',{name:'사용 매뉴얼'}).click();await page.getByRole('heading',{name:'BNB → WorldLand 반환',exact:true}).waitFor();
 if(errors.length)throw Error(errors.join('\n'));
 fs.writeFileSync(new URL('../results/demo-ui-summary.json',import.meta.url),JSON.stringify({passed:true,checks:['chain status and polling outage recovery','service indicator','18 decimal amount preset','return direction','zero rejection','mobile layout','manual navigation','no browser errors'],transactionsSent:0},null,2));
 console.log('demo UI PASS');
}finally{await browser.close();}
