#!/usr/bin/env python3
"""Pinned, bounded offline native receipt export. Never broadcasts an asset claim."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
import signal
from pathlib import Path
import shutil
import shlex
import subprocess
import uuid

ROOT = Path(__file__).resolve().parents[1]
DOCKER_IMAGE='risczero/risc0-groth16-prover:v2025-04-03.1'
DOCKER_DIGEST='sha256:a4f80ce2e0b8e2bb7637a93c37136a6776ac00ec843a3fdf1c67b1d5ffea64ee'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def docker_scope(out, env, memory_bytes, threads, go_memory_limit='5GiB', gogc=50):
    """Record an exact container ID and request label; never stop other work."""
    docker=shutil.which('docker')
    if not docker:raise ValueError('local Docker executable unavailable')
    docker=str(Path(docker).resolve())
    scope=out/'docker-scope';scope.mkdir(mode=0o700)
    cid=scope/'container.cid';label='native-'+uuid.uuid4().hex
    wrapper=scope/'docker'
    q=shlex.quote
    if go_memory_limit not in ('3GiB','4GiB','5GiB','6GiB') or not 25<=gogc<=100:
        raise ValueError('invalid bounded Go GC settings')
    wrapper.write_text('#!/bin/sh\nif [ "$1" = run ]; then\nshift\nexec '+q(docker)
        +' run --pull=never --cidfile '+q(str(cid))+' --label '+q('worldland-bnb.prover='+label)
        +' --memory '+str(memory_bytes)+' --memory-swap '+str(memory_bytes)+' --cpus '+str(threads)
        +' --env '+q('GOMEMLIMIT='+go_memory_limit)+' --env '+q('GOGC='+str(gogc))
        +' "$@"\nfi\nexec '+q(docker)+' "$@"\n')
    wrapper.chmod(0o700)
    env.update(PATH=str(scope)+os.pathsep+env.get('PATH',''),RISC0_WORK_DIR=str(scope))
    ownership={'docker':docker,'scope':str(scope),'cid':str(cid),'label':label,
               'memoryLimitBytes':memory_bytes,'cpuLimit':threads,
               'goMemoryLimit':go_memory_limit,'gogc':gogc,'goMemoryLimitIsSoft':True}
    (scope/'ownership.json').write_text(json.dumps(ownership,indent=2)+'\n')
    return ownership


def clean_docker_scope(scope):
    if not scope:return {'containerCreated':False}
    path=Path(scope['cid'])
    if not path.exists():return {'containerCreated':False}
    container=path.read_text().strip()
    if len(container)!=64 or any(c not in '0123456789abcdef' for c in container):
        raise ValueError('invalid owned Docker ID')
    command=[scope['docker'],'inspect','--format','{{index .Config.Labels "worldland-bnb.prover"}}',container]
    inspect=subprocess.run(command,text=True,capture_output=True,timeout=10)
    if inspect.returncode:
        if 'no such object' in inspect.stderr.lower() or 'no such container' in inspect.stderr.lower():
            return {'containerCreated':True,'alreadyRemoved':True,'containerId':container}
        raise RuntimeError('cannot confirm owned Docker state: '+inspect.stderr.strip())
    if inspect.stdout.strip()!=scope['label']:raise ValueError('Docker request ownership mismatch')
    subprocess.run([scope['docker'],'rm','-f',container],text=True,capture_output=True,check=True,timeout=15)
    return {'containerCreated':True,'removedOwnedContainer':True,'containerId':container}


def main():
    def interrupted(signum, frame):
        raise KeyboardInterrupt('native proof interrupted')
    signal.signal(signal.SIGTERM,interrupted)
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--host',type=Path,default=ROOT/'risc0/target/release/bridge-native-header-host')
    parser.add_argument('--input',type=Path,required=True)
    parser.add_argument('--output-dir',type=Path,required=True)
    parser.add_argument('--kind',choices=('composite','groth16'),required=True)
    parser.add_argument('--timeout-seconds',type=int,default=900)
    parser.add_argument('--threads',type=int,default=4)
    parser.add_argument('--docker-memory-fraction',type=float,default=.6)
    parser.add_argument('--go-memory-limit',choices=('3GiB','4GiB','5GiB','6GiB'),default='5GiB')
    parser.add_argument('--gogc',type=int,default=50)
    args=parser.parse_args()
    if not 1<=args.threads<=(os.cpu_count() or 1) or args.timeout_seconds<1 or not .4<=args.docker_memory_fraction<=.7 or not 25<=args.gogc<=100:
        parser.error('invalid CPU threads or timeout')
    # Reuse the owned process-group monitor, including interruption cleanup.
    spec=importlib.util.spec_from_file_location('header_benchmark_monitor',ROOT/'scripts/benchmark-header.py')
    monitor=importlib.util.module_from_spec(spec);spec.loader.exec_module(monitor)
    out=args.output_dir.resolve();out.mkdir(parents=True,exist_ok=False)
    host=out/'native-host';shutil.copy2(args.host,host)
    input_path=out/'input.json';shutil.copy2(args.input,input_path)
    server=Path.home()/'.cargo/bin/r0vm'
    env=dict(os.environ,RISC0_DEV_MODE='0',RISC0_PROVER='ipc',RISC0_SERVER_PATH=str(server),
             BRIDGE_RISC0_SEGMENT_PO2='18',RAYON_NUM_THREADS=str(args.threads))
    image=subprocess.check_output([host,'--image-id'],env=env,text=True).strip()
    if subprocess.check_output([host,'--header-binding'],env=env,text=True).strip()!='native-rlp':
        raise ValueError('compiled native guest required')
    inp=json.loads(input_path.read_text())
    if inp.get('chain_id') not in (103,56) or len(inp.get('headers',[]))!=1:
        raise ValueError('one offline native header required')
    physical_kb=os.sysconf('SC_PHYS_PAGES')*os.sysconf('SC_PAGE_SIZE')//1024
    report={'measuredAt':datetime.now(timezone.utc).isoformat(),'localVerdict':'FAIL','imageId':image,
            'headerBinding':'native-rlp','sourceChainId':inp['chain_id'],'requestedReceiptKind':args.kind,
            'hostSHA256':sha(host),'serverSHA256':sha(server),'inputSHA256':sha(input_path),
            'monitorSHA256':sha(ROOT/'scripts/benchmark-header.py'),'threads':args.threads,
            'segmentPo2':18,'memoryLimitKiB':int(physical_kb*.7),'timeoutSeconds':args.timeout_seconds,
            'memoryScope':'sampled sum of owned process-group RSS; Docker compressor memory is not included',
            'sourceInput':'saved public RPC header supplied offline; consensus/finality not authenticated',
            'proofGenerationAttempted':True,'evmAcceptanceMeasured':False,'rpcRequests':0,
            'chainAuthenticated':False,'realAssetDeploymentAllowed':False}
    receipt=out/'receipt.json'
    scope=None
    try:
        # Groth16 requires the existing local Docker backend. This check does not
        # install an image, start a daemon, reset credits or select a paid prover.
        if args.kind=='groth16':
            subprocess.run(['docker','info'],capture_output=True,check=True,timeout=30)
            digests=json.loads(subprocess.check_output(['docker','image','inspect','--format','{{json .RepoDigests}}',DOCKER_IMAGE],text=True,timeout=15))
            if not any(d.endswith('@'+DOCKER_DIGEST) for d in digests):
                raise ValueError('installed compressor image digest differs from pinned official artifact')
            scope=docker_scope(out,env,int(physical_kb*1024*args.docker_memory_fraction),args.threads,args.go_memory_limit,args.gogc)
            report.update(dockerScope=scope,dockerImage=DOCKER_IMAGE,dockerDigest=DOCKER_DIGEST)
        command=[str(host),'--prove-receipt','--input',str(input_path),'--receipt-output',str(receipt),'--receipt-kind',args.kind]
        report['workState']='proving'
        (out/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
        proc,resources=monitor.run_with_memory_limit(command,env,report['memoryLimitKiB'],args.timeout_seconds)
        (out/'prove.stdout.json').write_text(proc.stdout);(out/'prove.stderr.txt').write_text(proc.stderr)
        report.update(resources=resources,exitCode=proc.returncode)
        if proc.returncode:raise RuntimeError(f'bounded native prover failed with {proc.returncode}')
        metadata=json.loads(proc.stdout)
        verified=subprocess.run([host,'--verify-receipt',receipt],env=env,text=True,capture_output=True,check=True,timeout=120)
        (out/'verified.stdout.json').write_text(verified.stdout);(out/'verified.stderr.txt').write_text(verified.stderr)
        check=json.loads(verified.stdout)
        for row in (metadata,check):
            if (row.get('verified') is not True or row.get('imageId')!=image or row.get('headerBinding')!='native-rlp'
                or row.get('receiptKind')!=args.kind or row.get('chainAuthenticated') is not False
                or row.get('realAssetDeploymentAllowed') is not False):raise ValueError('native proof metadata mismatch')
        if check['journal']!=metadata['journal'] or check['seal']!=metadata['seal']:
            raise ValueError('native journal/seal mismatch')
        if sha(host)!=report['hostSHA256'] or sha(server)!=report['serverSHA256']:
            raise ValueError('pinned host or SDK server changed')
        report.update(localVerdict='PASS',workState='complete',cryptographicallyReverified=True,receiptSHA256=sha(receipt),proof=metadata)
    except BaseException as error:
        report.update(workState='failed',error=str(error));raise
    finally:
        try:report['dockerCleanup']=clean_docker_scope(scope)
        except Exception as error:
            report.update(localVerdict='FAIL',cleanupError=str(error));raise
        finally:(out/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
    print(f'native {args.kind} receipt generation and crypto verification: PASS; no EVM/asset submission')


if __name__=='__main__':main()
