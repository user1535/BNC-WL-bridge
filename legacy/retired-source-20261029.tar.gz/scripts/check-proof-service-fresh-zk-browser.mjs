import {chromium,launchOptions} from './browser-runtime.mjs';
import fs from 'node:fs';
import {Interface} from '../wallet/vendor/ethers-6.15.0.min.mjs';
const root=new URL('../results/prototype-header-steps/',import.meta.url);
const session=JSON.parse(fs.readFileSync(new URL('session.json',root)));
const saved=JSON.parse(fs.readFileSync(new URL('request.json',root)));
const base='http://127.0.0.1:8580',owner=session.users[0],sends=[];
let chain='bnb';
async function rpc(method,params=[],network=chain){
 const r=await fetch(session.chains[network].rpc,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({jsonrpc:'2.0',id:1,method,params})});
 const v=await r.json();if(v.error)throw Object.assign(new Error(v.error.message),v.error);return v.result;
}
async function api(path){const r=await fetch(base+path),v=await r.json();if(!r.ok)throw new Error(v.error);return v;}
const abi=new Interface(['function balanceOf(address) view returns(uint256)','function lockedBalanceOf(address) view returns(uint256)']);
async function balances(){
 const call=async(n,to,f)=>abi.decodeFunctionResult(f,await rpc('eth_call',[{to,data:abi.encodeFunctionData(f,[owner])},'latest'],n))[0].toString();
 return {original:await call('wl',session.contracts.original,'balanceOf'),locked:await call('wl',session.contracts.original,'lockedBalanceOf'),wrapped:await call('bnb',session.contracts.wrapped,'balanceOf')};
}
const report={passed:false,externalExtensionTested:false,serverBroadcasts:0,chainAuthenticated:false,realAssetDeploymentAllowed:false,steps:[]};
let browser,page;
try{
 report.before=JSON.parse(fs.readFileSync(new URL('fresh-browser-summary-initial-failure.json',root))).before;
 browser=await chromium.launch(launchOptions);
 const context=await browser.newContext(),errors=[];page=await context.newPage();
 page.on('pageerror',e=>errors.push(e.message));
 await page.exposeFunction('__wallet',async({method,params=[]})=>{try{
  if(['eth_accounts','eth_requestAccounts'].includes(method))return {result:[owner]};
  if(method==='wallet_switchEthereumChain'){chain=BigInt(params[0].chainId)===31337n?'wl':'bnb';return {result:null};}
  const v=await rpc(method,params);if(method==='eth_sendTransaction')sends.push({chain,hash:v});return {result:v};
 }catch(e){return {error:{message:e.message,code:e.code,data:e.data}};}
 });
 await page.addInitScript(()=>{window.ethereum={on(){},request:async args=>{const v=await window.__wallet(args);if(v.error)throw Object.assign(new Error(v.error.message),v.error);return v.result;}};});
 const connect=async()=>{await page.locator('#load-service').click();await page.waitForFunction(()=>!document.getElementById('connect').disabled);await page.locator('#connect').click();await page.waitForFunction(()=>document.getElementById('account').textContent.startsWith('0x'));};
 const submit=async button=>{
  await page.locator(button).click();await page.waitForFunction(()=>!document.getElementById('submit').disabled);
  await page.locator('#submit').click();await page.waitForFunction(()=>document.getElementById('status').textContent.includes('지갑이 전송한 거래:'));
  const send=sends.at(-1);let receipt;
  for(let n=0;n<120;n++){receipt=await rpc('eth_getTransactionReceipt',[send.hash],send.chain);if(receipt)break;await page.waitForTimeout(250);}
  if(!receipt||BigInt(receipt.status)!==1n)throw new Error('EVM receipt rejected or unresolved '+button);
  await page.locator('#recover').click();await page.waitForFunction(()=>document.getElementById('status').textContent==='거래가 수락됐습니다.');
  report.steps.push({button,...send,gasUsed:BigInt(receipt.gasUsed).toString()});
  fs.writeFileSync(new URL('fresh-browser-summary.json',root),JSON.stringify({...report,walletSends:sends},null,2));
 };
 const settle=async action=>{
  const destination=action==='lock'?'bnb':'wl';
  await page.locator(destination==='wl'?'#switch-wl':'#switch-bnb').click();
  for(let batch=0;batch<16;batch++){
   let job,request;
   for(let n=0;n<2100;n++){
    request=await page.evaluate(()=>JSON.parse(localStorage.getItem('worldland-bnb-proof-request-v1')));
    job=await api('/api/jobs/'+request.id);
    if(job.state==='ready'||job.state==='header_ready')break;
    if(job.state==='failed')throw new Error(job.detail);
    if(n%30===0)console.log(action,job.state,job.detail);
    await page.waitForTimeout(1000);
   }
   if(!['ready','header_ready'].includes(job.state))throw new Error('bounded proof request timeout');
   const p=await api('/api/jobs/'+request.id+'/package');
   fs.writeFileSync(new URL('fresh-'+action+'-batch-'+batch+'.json',root),JSON.stringify(p,null,2));
   await page.locator('#poll-proof').click();await page.waitForFunction(()=>!document.getElementById('prepare-header').disabled);
   if(p.kind==='header-step'||!p.headerCovered){
    await submit('#prepare-header');await page.locator('#request-proof').click();
    await page.waitForFunction(()=>document.getElementById('status').textContent.includes('요청을 저장했습니다.'));
    continue;
   }
   await submit('#prepare-claim');return;
  }
  throw new Error('too many intermediate batches');
 };
 await page.goto(base);await connect();
 await page.evaluate(v=>localStorage.setItem('worldland-bnb-proof-request-v1',JSON.stringify(v)),saved);
 await page.reload();await connect();
 await page.locator('#request-proof').click();await page.waitForFunction(()=>document.getElementById('status').textContent.includes('요청을 저장했습니다.'));
 const replay=new Interface(['function claimedTransfer(bytes32) view returns(bool)']);
 const already=replay.decodeFunctionResult('claimedTransfer',await rpc('eth_call',[{to:session.contracts.mint,data:replay.encodeFunctionData('claimedTransfer',[saved.request.transferId])},'latest'],'bnb'))[0];
 if(!already)await settle('lock');else report.lockClaimRecovered=true;
 report.afterMint=await balances();
 const amount=25000000000000000000n;
 if(!fs.existsSync(new URL('fresh-burn-request.json',root))&&BigInt(report.afterMint.wrapped)!==BigInt(report.before.wrapped)+amount)throw new Error('mint balance mismatch');
 const burnFile=new URL('fresh-burn-request.json',root);
 if(fs.existsSync(burnFile)){
  const request=JSON.parse(fs.readFileSync(burnFile));
  await page.evaluate(v=>localStorage.setItem('worldland-bnb-proof-request-v1',JSON.stringify(v)),request);
  await page.reload();await connect();report.burnRequestRecovered=true;
 }else{
  await page.locator('#switch-bnb').click();await page.locator('#action').selectOption('burn');await page.locator('#amount').fill(amount.toString());
  await submit('#prepare-action');
  await page.locator('#request-proof').click();await page.waitForFunction(()=>document.getElementById('status').textContent.includes('요청을 저장했습니다.'));
  const request=await page.evaluate(()=>JSON.parse(localStorage.getItem('worldland-bnb-proof-request-v1')));
  fs.writeFileSync(burnFile,JSON.stringify(request,null,2));
  await rpc('evm_mine',[],'bnb');await rpc('evm_mine',[],'bnb');
 }
 await settle('burn');
 report.after=await balances();
 if(report.after.original!==report.before.original||BigInt(report.after.locked)!==BigInt(report.before.locked)-amount||report.after.wrapped!==report.before.wrapped)throw new Error('roundtrip conservation mismatch');
 if(errors.length)throw new Error(errors.join(';'));
 report.passed=true;report.walletSends=sends;report.browserReloadRecovered=true;
 console.log(JSON.stringify(report));
}catch(e){report.error=e.message;report.walletSends=sends;report.screenStatus=await page?.locator('#status').innerText();report.review=await page?.locator('#review').innerText();throw e;}
finally{fs.writeFileSync(new URL('fresh-browser-summary.json',root),JSON.stringify(report,null,2));await browser?.close();}
