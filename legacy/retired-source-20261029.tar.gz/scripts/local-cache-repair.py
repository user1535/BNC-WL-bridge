#!/usr/bin/env python3
"""Clone local public chain state and verify explicit recovery of a tampered real proof cache."""
import base64
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
import urllib.request

ROOT = Path(__file__).resolve().parent.parent
SOURCE = 'http://127.0.0.1:8558'
RPC = 'http://127.0.0.1:8557'
INPUT = ROOT / 'results/local-risc0-current'
OUTPUT = ROOT / 'results/cache-repair-current'


def rpc(url, method, params):
    request = urllib.request.Request(url, json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params}).encode(), {'Content-Type': 'application/json'})
    result = json.load(urllib.request.urlopen(request, timeout=15))
    if 'error' in result:
        raise RuntimeError(str(result['error']))
    return result['result']


def main():
    if int(rpc(SOURCE, 'eth_chainId', []), 16) != 31337:
        raise RuntimeError('source is not the expected local chain')
    try:
        rpc(RPC, 'eth_chainId', [])
    except OSError:
        pass
    else:
        raise RuntimeError('port 8557 already occupied; unknown service preserved')
    package = json.loads((INPUT / 'lock-header.json').read_text())
    if OUTPUT.exists():
        raise RuntimeError('existing repair evidence preserved; select another output directory in script')
    OUTPUT.mkdir()
    cache = OUTPUT / 'cache/groth16'
    cache.mkdir(parents=True)
    selected = [(p, json.loads(p.read_text())) for p in (INPUT / 'proof-cache/groth16').glob('*.json')]
    selected = [(p, c) for p, c in selected if c['key']['sourceChainId'] == 31337 and c['key']['startBlock'] == package['startBlock']]
    assert len(selected) == 1
    source_path, cached = selected[0]
    receipt = json.loads(base64.b64decode(cached['proofData']))
    receipt['journal']['bytes'][0] ^= 1
    cached['proofData'] = base64.b64encode(json.dumps(receipt).encode()).decode()
    path = cache / source_path.name
    path.write_text(json.dumps(cached))
    tampered_hash = hashlib.sha256(path.read_bytes()).hexdigest()
    state = rpc(SOURCE, 'anvil_dumpState', [])
    with (OUTPUT / 'anvil.log').open('w') as log:
        anvil = subprocess.Popen(['anvil', '--silent', '--host', '127.0.0.1', '--port', '8557', '--chain-id', '31337'], stdout=log, stderr=log)
    try:
        for _ in range(50):
            try:
                rpc(RPC, 'eth_chainId', [])
                break
            except OSError:
                time.sleep(.2)
        assert rpc(RPC, 'anvil_loadState', [state])
        os.environ.setdefault('RISC0_SERVER_PATH', str(Path.home() / '.cargo/bin/r0vm'))
        args = [str(ROOT / '.bin/bridge-header-data'), '--rpc', RPC, '--chain-id', '31337', '--start', str(package['startBlock']),
            '--count', '1', '--risc0-host', str(ROOT / 'risc0/target/release/bridge-header-benchmark'),
            '--proof-cache', str(OUTPUT / 'cache'), '--receipt-kind', 'groth16', '--proof-timeout', '20m']
        rejected = subprocess.run(args, text=True, capture_output=True)
        (OUTPUT / 'default-rejection.stderr.txt').write_text(rejected.stderr)
        assert rejected.returncode != 0 and not rejected.stdout and 'cached proof rejected' in rejected.stderr
        print('tampered real Groth16 cache rejected; explicitly quarantining and re-proving', flush=True)
        repaired = subprocess.run([*args, '--repair-cache'], text=True, capture_output=True)
        (OUTPUT / 'repair.stderr.txt').write_text(repaired.stderr)
        (OUTPUT / 'repaired-package.json').write_text(repaired.stdout)
        assert repaired.returncode == 0, repaired.stderr
        result = json.loads(repaired.stdout)
        assert result['proofVerified'] and result['evmCompatible'] and not result['cacheHit']
        quarantined = list(cache.glob('*.rejected'))
        assert len(quarantined) == 1 and hashlib.sha256(quarantined[0].read_bytes()).hexdigest() == tampered_hash
        hit = subprocess.run(args, text=True, capture_output=True)
        assert hit.returncode == 0 and json.loads(hit.stdout)['cacheHit'], hit.stderr
        summary = {'receipt_kind': 'groth16', 'tampered_real_receipt_rejected_by_default': True,
            'explicit_repair_generated_verified_proof': True, 'rejected_evidence_preserved': True,
            'replacement_cache_hit_verified': True, 'chain_authenticated': False, 'asset_transactions_sent': 0}
        (OUTPUT / 'summary.json').write_text(json.dumps(summary, indent=2)+'\n')
        print('real cache reject / quarantine / regenerate / verified reuse: PASS')
    finally:
        anvil.terminate()
        anvil.wait(timeout=10)


if __name__ == '__main__':
    main()
