#!/usr/bin/env python3
"""Compare supplied snapshot role/delay arithmetic in an owned local EVM; no consensus replay."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import signal
import socket
import subprocess
import time
import urllib.request

ROOT = Path(__file__).resolve().parents[1]


def main():
    def interrupted(*_): raise KeyboardInterrupt('snapshot diagnostic interrupted')
    signal.signal(signal.SIGTERM, interrupted)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    out = args.output_dir.resolve(); out.mkdir(parents=True, exist_ok=False)
    url = 'http://127.0.0.1:8578'; node = None
    report = {'measuredAt':datetime.now(timezone.utc).isoformat(),'localVerdict':'FAIL',
        'risc0Used':False,'proofsGenerated':0,'assetClaimsSubmitted':0,'checks':[],
        'profileAssumption':'supplied-post-bohr-fixed-epoch1000','actualSnapshotReplayMeasured':False,
        'forkPolicyAuthenticated':False,'oldConfigurationsAuthenticated':False,'snapshotAuthenticated':False,
        'finalityVerified':False,'chainAuthenticated':False,'realAssetDeploymentAllowed':False}
    def command(argv):
        p = subprocess.run([str(a) for a in argv],cwd=ROOT,capture_output=True,text=True,timeout=120)
        if p.returncode: raise ValueError(p.stderr or p.stdout)
        return p.stdout.strip()
    def rpc(method,params):
        req = urllib.request.Request(url,json.dumps({'jsonrpc':'2.0','id':1,'method':method,'params':params}).encode(),
            {'Content-Type':'application/json'})
        with urllib.request.urlopen(req,timeout=15) as reply: data=json.load(reply)
        if 'error' in data: raise ValueError(str(data['error']))
        return data['result']
    try:
        captured = ROOT/'proof-generator/internal/chain/testdata/native-live-captured'
        for item in json.loads((captured/'manifest.json').read_text())['fixtures']:
            if hashlib.sha256((captured/item['file']).read_bytes()).hexdigest()!=item['sha256']:
                raise ValueError('captured fixture changed')
        for item in json.loads((ROOT/'docs/protocol-sources/oracle-manifest.json').read_text()):
            if hashlib.sha256((ROOT/item['path']).read_bytes()).hexdigest()!=item['localSHA256']:
                raise ValueError('pinned arithmetic/encoding oracle changed')
        binary = out/'bnb-snapshot-vectors'
        command(['go','-C',ROOT/'proof-generator','build','-o',binary,'./cmd/bnb-snapshot-vectors'])
        vectors = json.loads(command([binary,'--fixture-dir',captured]))
        if (vectors['snapshotAuthenticated'] is not False or vectors['actualSnapshotReplayMeasured'] is not False
            or vectors['oldConfigurationsAuthenticated'] is not False or vectors['profileAssumption']!=report['profileAssumption']):
            raise ValueError('supplied schedule oracle scope mismatch')
        artifact = out/'snapshot-schedule-oracle.json'
        artifact.write_text(json.dumps(vectors,indent=2)+'\n')
        report['oracleSHA256'] = hashlib.sha256(artifact.read_bytes()).hexdigest()
        report['binarySHA256'] = hashlib.sha256(binary.read_bytes()).hexdigest()
        command(['forge','build','--root',ROOT/'contracts','--offline','--quiet'])
        report['sourceSHA256'] = {p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in (
            'contracts/test/BNBSnapshotScheduleDiagnostic.sol','contracts/test/BNBRawHeaderVoteDiagnostic.sol',
            'contracts/test/BNBVoteBLSDiagnostic.sol','contracts/src/bridge/lib/RLPReader.sol',
            'proof-generator/cmd/bnb-snapshot-vectors/main.go','proof-generator/internal/protocoloracle/bnb/snapshot_history.go')}
        with socket.socket() as probe:
            probe.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1); probe.bind(('127.0.0.1',8578)); probe.listen(1)
        with (out/'anvil.log').open('w') as log:
            node = subprocess.Popen(['anvil','--silent','--host','127.0.0.1','--port','8578','--chain-id','31337',
                '--hardfork','cancun'],stdout=log,stderr=log)
        for _ in range(50):
            if node.poll() is not None: raise ValueError('owned node exited')
            try:
                if int(rpc('eth_chainId',[]),16)!=31337: raise ValueError('wrong node')
                break
            except OSError: time.sleep(.1)
        else: raise ValueError('owned node startup timeout')
        sender = rpc('eth_accounts',[])[0]
        contract = json.loads(command(['forge','create','--root',ROOT/'contracts',
            'test/BNBSnapshotScheduleDiagnostic.sol:BNBSnapshotScheduleDiagnostic','--rpc-url',url,
            '--unlocked','--from',sender,'--broadcast','--json']))['deployedTo']
        def call(data): return rpc('eth_call',[{'to':contract,'data':data},'latest'])
        def reject(name,data):
            try: call(data)
            except ValueError as error:
                if 'execution reverted' not in str(error).lower(): raise
                report['checks'].append({'name':name,'rejected':True})
            else: raise ValueError(name+' unexpectedly accepted')
        schedule_checks = []
        for v in vectors['scheduleVectors']:
            data = command(['cast','calldata','delaySchedule(uint64,uint8,uint8,uint8,uint8,uint64)',
                v['epochNumber'],v['oldCount'],v['oldTurn'],v['newCount'],v['newTurn'],v['snapshotNumber']])
            if v['accepted']:
                expected = '0x'+b''.join(int(x).to_bytes(32,'big') for x in v['expected']).hex()
                if call(data)!=expected: raise ValueError('upstream history arithmetic mismatch: '+v['name'])
            else: reject('schedule-'+v['name'],data)
            schedule_checks.append({'name':v['name'],'accepted':v['accepted'],'goEvmAgreement':True})
        for v in vectors['roleVectors']:
            data = command(['cast','calldata','snapshotRoles(bytes,bytes,bytes)',v['sourceRaw'],v['targetRaw'],v['attestingRaw']])
            expected = b''.join(n.to_bytes(32,'big') for n in v['numbers'])+b''.join(bytes.fromhex(h[2:]) for h in v['hashes'])
            if call(data)!='0x'+expected.hex(): raise ValueError('actual header role commitment mismatch')
            report['checks'].append({'name':'actual-role-'+v['name'],'goEvmAgreement':True,
                'requiredNumbers':v['numbers'],'requiredHashes':v['hashes']})
        first,second = vectors['roleVectors']
        for name,source,target,attesting in (
            ('reversed-role-pair',first['targetRaw'],first['sourceRaw'],first['attestingRaw']),
            ('unrelated-attesting-role',first['sourceRaw'],first['targetRaw'],second['attestingRaw']),
            ('trailing-role-rlp',first['sourceRaw']+'00',first['targetRaw'],first['attestingRaw']),
            ('truncated-role-rlp',first['sourceRaw'],first['targetRaw'][:-2],first['attestingRaw'])):
            reject(name,command(['cast','calldata','snapshotRoles(bytes,bytes,bytes)',source,target,attesting]))
        report.update(localVerdict='PASS',scheduleChecks=schedule_checks,scheduleOracleCases=len(schedule_checks),
            schedulePositiveCases=sum(v['accepted'] for v in schedule_checks),
            scheduleNegativeCases=sum(not v['accepted'] for v in schedule_checks),actualRoleCases=2,
            roleNegativeCases=4,observedEpochNumber=vectors['epochNumber'],observedEpochHash=vectors['epochHash'],
            observedNewCount=vectors['observedNewCount'],observedNewTurn=vectors['observedNewTurn'])
    except BaseException as error:
        report['error']=str(error); raise
    finally:
        if node and node.poll() is None:
            node.terminate()
            try: node.wait(timeout=5)
            except subprocess.TimeoutExpired: node.kill(); node.wait()
        report['ownedNodeStopped']=node is None or node.poll() is not None
        (out/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
    print('PASS supplied snapshot role/delay arithmetic; actual replay/auth/proof/assets0')


if __name__=='__main__': main()
