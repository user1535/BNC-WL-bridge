#!/usr/bin/env python3
"""Execute the distinct native guest on saved public headers; no RPC/proving."""
import argparse
import copy
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--host', type=Path, default=ROOT/'risc0/target/release/bridge-native-header-host')
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    out = args.output_dir.resolve()
    out.mkdir(parents=True, exist_ok=False)
    host = out/'native-host'
    shutil.copy2(args.host, host)
    env = dict(os.environ, RISC0_DEV_MODE='0', RISC0_PROVER='ipc',
               RISC0_SERVER_PATH=str(Path.home()/'.cargo/bin/r0vm'), RAYON_NUM_THREADS='4')
    image = subprocess.check_output([host, '--image-id'], text=True).strip()
    binding = subprocess.check_output([host, '--header-binding'], text=True).strip()
    if binding != 'native-rlp':
        raise ValueError('not the compiled native guest')
    existing_images = [subprocess.check_output([ROOT/'risc0/target/release'/name, '--image-id'], text=True).strip()
                       for name in ('bridge-header-benchmark', 'bridge-header-bound-host')]
    if image in existing_images:
        raise ValueError('native image must be distinct from local images')
    report = {'measuredAt':datetime.now(timezone.utc).isoformat(), 'localVerdict':'FAIL',
              'nativeImage':image, 'existingLocalImages':existing_images, 'headerBinding':binding,
              'hostSHA256':hashlib.sha256(host.read_bytes()).hexdigest(), 'checks':[],
              'guestExecuted':True, 'cryptographicProofGenerated':False, 'rpcRequests':0,
              'evmAcceptanceMeasured':False, 'chainAuthenticated':False, 'realAssetDeploymentAllowed':False}

    def execute(name, data, expected, parser_failure=False):
        path=out/(name+'.json');path.write_text(json.dumps(data)+'\n')
        proc=subprocess.run([host,'--execute-input',path],env=env,text=True,capture_output=True,timeout=90)
        (out/(name+'.stdout.json')).write_text(proc.stdout)
        (out/(name+'.stderr.txt')).write_text(proc.stderr)
        if (proc.returncode==0) != expected:
            raise AssertionError(f'{name}: expected accepted={expected}: {proc.stderr[-2000:]}')
        if expected:
            row=json.loads(proc.stdout)
            if row['guestExecuted'] is not True or row['proofGenerated'] is not False or row['imageId']!=image or row['chainAuthenticated'] is not False:
                raise ValueError('unexpected execution metadata')
            if len(bytes.fromhex(row['journal'][2:])) != 224:
                raise ValueError('unexpected public journal')
        elif not parser_failure and 'native serialization binding failed' not in proc.stderr:
            raise ValueError(f'{name}: unrelated failure: {proc.stderr[-2000:]}')
        report['checks'].append({'name':name,'accepted':proc.returncode==0,
                                 'rejectionStage':'host-parser' if parser_failure else 'guest' if not expected else None})

    try:
        for chain, chain_id in (('worldland',103),('bnb',56)):
            headers=[]
            for which in ('parent','latest'):
                v=json.loads((ROOT/f'risc0/native-binding/fixtures/{chain}-{which}.json').read_text())
                array=lambda s:list(bytes.fromhex(s[2:]))
                headers.append({'number':v['blockNumber'],'block_hash':array(v['suppliedHash']),
                    'parent_hash':array(v['parentHash']),'receipt_root':array(v['receiptRoot']),
                    'canonical_rlp':array(v['headerRlp']),'worldland_optional_mask':v['worldlandOptionalMask']})
            pair={'chain_id':chain_id,'anchor_hash':headers[0]['parent_hash'],'headers':headers}
            execute(chain+'-pair',pair,True)
            base={**pair,'headers':[headers[0]]}
            execute(chain+'-single',base,True)
            execute(chain+'-latest-single',{'chain_id':chain_id,'anchor_hash':headers[1]['parent_hash'],'headers':[headers[1]]},True)
            variants = {
                'false-root':lambda b:b['headers'][0]['receipt_root'].__setitem__(0,b['headers'][0]['receipt_root'][0]^1),
                'altered-rlp':lambda b:b['headers'][0]['canonical_rlp'].__setitem__(-1,b['headers'][0]['canonical_rlp'][-1]^1),
                'trailing-rlp':lambda b:b['headers'][0]['canonical_rlp'].append(0x80),
                'wrong-number':lambda b:b['headers'][0].__setitem__('number',b['headers'][0]['number']+1),
                'wrong-anchor':lambda b:b.__setitem__('anchor_hash',[1]*32),
                'wrong-profile-mask':lambda b:b['headers'][0].__setitem__('worldland_optional_mask',0 if chain=='worldland' else 1),
                'local-chain-id':lambda b:b.__setitem__('chain_id',31337),
                'empty-batch':lambda b:b.__setitem__('headers',[]),
            }
            for name, mutate in variants.items():
                b=copy.deepcopy(base);mutate(b);execute(chain+'-'+name,b,False)
            b=copy.deepcopy(pair);b['headers'].reverse();execute(chain+'-reversed-pair',b,False)
            b=copy.deepcopy(pair);b['headers'][1]['number']+=1;execute(chain+'-height-gap',b,False)
            b=copy.deepcopy(base);del b['headers'][0]['canonical_rlp'];execute(chain+'-missing-rlp',b,False,True)
            b=copy.deepcopy(base);b['chainAuthenticated']=True;execute(chain+'-unknown-auth-field',b,False,True)
        report['localVerdict']='PASS'
    except Exception as error:
        report['error']=str(error)
        raise
    finally:
        source = {}
        for base in ('risc0/native','risc0/native-binding'):
            for path in (ROOT/base).rglob('*'):
                if path.is_file() and 'target' not in path.parts:
                    source[str(path.relative_to(ROOT))]=hashlib.sha256(path.read_bytes()).hexdigest()
        report['sourceSHA256']=source
        (out/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
    print(f'native guest execution: {len(report["checks"])} checks PASS; no proving/RPC/EVM')


if __name__=='__main__':
    main()
