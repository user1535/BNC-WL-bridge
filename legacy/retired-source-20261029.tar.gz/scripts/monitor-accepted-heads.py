#!/usr/bin/env python3
"""Read-only source/proof/accepted time series; verdict comes from the Go evaluator."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]


def main():
    p = argparse.ArgumentParser()
    for field in ('source-rpc', 'destination-rpc', 'source-chain-id', 'header-source', 'output-dir'):
        p.add_argument('--'+field, required=True)
    p.add_argument('--proof-directory', type=Path, help='worker proposal directory; newest proof is cryptographically reverified')
    p.add_argument('--risc0-host', type=Path)
    p.add_argument('--seconds', type=float, default=300)
    p.add_argument('--interval', type=float, default=10)
    p.add_argument('--max-lag', type=int, default=8)
    args = p.parse_args()
    if args.seconds <= 0 or args.interval <= 0 or args.max_lag < 0 or (args.proof_directory and not args.risc0_host):
        p.error('positive duration/interval, nonnegative lag and proof verification host required')
    output = Path(args.output_dir).resolve()
    output.mkdir(parents=True, exist_ok=False)
    base = [str(ROOT / '.bin/bridge-monitor'), '--source-rpc', args.source_rpc, '--destination-rpc', args.destination_rpc,
            '--source-chain-id', args.source_chain_id, '--header-source', args.header_source]
    samples = []
    started = time.monotonic()
    summary = {'verdict': 'INCONCLUSIVE', 'chainAuthenticated': False, 'transactionsSent': 0}
    try:
        while True:
            command = list(base)
            selected = None
            if args.proof_directory:
                candidates = []
                for file in args.proof_directory.glob('*.json'):
                    package = json.loads(file.read_text())
                    package = package.get('headerPackage', package)
                    if package.get('sourceChainId') == int(args.source_chain_id) and package.get('proofReceipt'):
                        candidates.append((package['endBlock'], file, package))
                if candidates:
                    _, original, package = max(candidates, key=lambda row: row[0])
                    selected = {'path': str(original), 'sha256': hashlib.sha256(original.read_bytes()).hexdigest()}
                    proof = output / 'selected-proof.json'
                    proof.write_text(json.dumps(package))
                    command += ['--proof-package', str(proof), '--risc0-host', str(args.risc0_host.resolve())]
            sample = json.loads(subprocess.check_output(command, text=True, timeout=65))
            sample['elapsedSeconds'] = time.monotonic()-started
            sample['selectedProof'] = selected
            samples.append(sample)
            (output / 'samples.json').write_text(json.dumps(samples, indent=2)+'\n')
            if samples[-1]['elapsedSeconds'] - samples[0]['elapsedSeconds'] >= args.seconds:
                break
            time.sleep(min(args.interval, args.seconds - (samples[-1]['elapsedSeconds']-samples[0]['elapsedSeconds'])))
        result = subprocess.check_output([str(ROOT / '.bin/bridge-rate-verdict')], text=True, timeout=10,
                                         input=json.dumps({'samples': samples, 'maxLag': args.max_lag}))
        summary.update(json.loads(result))
        summary['sampleCount'] = len(samples)
        summary['maximumLagPolicy'] = args.max_lag
    except BaseException as error:
        summary['error'] = str(error)
        raise
    finally:
        (output / 'summary.json').write_text(json.dumps(summary, indent=2)+'\n')
        print(json.dumps(summary))


if __name__ == '__main__': main()
