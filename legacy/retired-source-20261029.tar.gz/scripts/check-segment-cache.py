#!/usr/bin/env python3
"""Adversarial read-only checks of a completed genuine segment/Keccak cache."""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent.parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--host", type=Path, required=True)
    p.add_argument("--input", type=Path, required=True)
    p.add_argument("--cache", type=Path, required=True)
    p.add_argument("--prepare-evidence", type=Path, required=True)
    p.add_argument("--dir", type=Path, required=True)
    args = p.parse_args()
    cache, host, witness = args.cache.absolute(), args.host.absolute(), args.input.absolute()
    original = {str(x.relative_to(cache)): sha(x) for x in cache.rglob("*") if x.is_file()}
    manifest = json.loads((cache / "manifest.json").read_text())
    if len(manifest["traces"]) < 2 or not manifest["keccaks"] or not (cache / "composite.json").is_file():
        p.error("requires completed actual cache with multiple VM segments and Keccak")
    out = args.dir.absolute()
    out.mkdir(parents=True, exist_ok=False)
    prepared = json.loads((args.prepare_evidence.absolute() / "summary.json").read_text())
    env = dict(os.environ, RISC0_DEV_MODE="0", RISC0_PROVER="ipc", RAYON_NUM_THREADS=str(manifest["threads"]),
               BRIDGE_RISC0_SEGMENT_PO2=str(manifest["segment_po2"]),
               BRIDGE_RISC0_KECCAK_PO2=str(manifest["keccak_po2"]),
               BRIDGE_RISC0_DIAGNOSTIC_MAX_HEADERS=str(prepared.get("diagnosticMaxHeaders", 4)),
               RISC0_SERVER_PATH=str((Path.home() / ".cargo/bin/r0vm").resolve()))
    pin = prepared["result"]["manifestSHA256"]
    env["BRIDGE_RISC0_CACHE_MANIFEST_SHA256"] = pin
    results = []

    def invoke(name, target, source, expected=None, partial=False, changed_pin=False):
        case_env = dict(env)
        if changed_pin:
            case_env["BRIDGE_RISC0_CACHE_MANIFEST_SHA256"] = sha(target / "manifest.json")
        result = subprocess.run([str(host), "--segments-audit", str(source), str(target)],
                                capture_output=True, text=True, env=case_env, timeout=45)
        (out / (name + ".stdout.json")).write_text(result.stdout)
        (out / (name + ".stderr.txt")).write_text(result.stderr)
        if expected:
            passed = result.returncode != 0 and expected in result.stderr
        else:
            row = json.loads(result.stdout) if result.returncode == 0 else {}
            passed = (row.get("status") == ("PARTIAL" if partial else "PASS")
                      and row.get("newVerifiedUnits") == 0
                      and row.get("fullReceiptVerified") is (not partial)
                      and row.get("executionTranscriptsRechecked") is True)
        results.append({"case": name, "passed": passed, "exitCode": result.returncode,
                        "expectedReason": expected, "newProvingAllowed": False})
        if not passed:
            raise ValueError(f"{name}: unexpected result: {result.stdout} {result.stderr}")

    invoke("genuine-complete", cache, witness)

    def case(name, mutate, reason):
        target = out / name
        shutil.copytree(cache, target)
        source = target / "input.json"
        shutil.copy2(witness, source)
        mutate(target, source)
        invoke(name, target, source, reason, changed_pin=reason != "preparation manifest pin mismatch")

    def change_manifest(root, field, value):
        path = root / "manifest.json"
        row = json.loads(path.read_text())
        row[field] = value
        path.write_text(json.dumps(row))

    for field, value in (("schema", 2), ("image", "0" * 64), ("host_sha256", "0" * 64),
                         ("server_sha256", "0" * 64),
                         ("segment_po2", 16 if manifest["segment_po2"] != 16 else 19), ("threads", 1)):
        case("wrong-" + field, lambda r, s, f=field, v=value: change_manifest(r, f, v), "cache schema/input")
    case("unknown-schema-field", lambda r, s: change_manifest(r, "unsupported", True), "unknown field")
    case("reordered-traces", lambda r, s: change_manifest(r, "traces", list(reversed(manifest["traces"]))),
         "segment trace basename/order mismatch")
    modified = json.loads(json.dumps(manifest["traces"]))
    modified[0]["cycles"] += 1
    case("wrong-cycles", lambda r, s: change_manifest(r, "traces", modified),
         "reexecuted segment transcript/order/cycles mismatch")

    def corrupted_trace(root, source, update_hash=False):
        path = root / manifest["traces"][0]["artifact"]["name"]
        data = bytearray(path.read_bytes())
        data[0] ^= 1
        path.write_bytes(data)
        if update_hash:
            row = json.loads((root / "manifest.json").read_text())
            row["traces"][0]["artifact"]["sha256"] = sha(path)
            (root / "manifest.json").write_text(json.dumps(row))

    case("corrupted-trace", corrupted_trace, "artifact hash/length mismatch")
    case("trace-with-rewritten-hash", lambda r, s: corrupted_trace(r, s, True),
         "preparation manifest pin mismatch")
    case("missing-keccak-request", lambda r, s: change_manifest(r, "keccaks", []), "unexpected Keccak request")

    def change_input(root, source):
        row = json.loads(source.read_text())
        # Keep the local witness executable so this checks cache input binding,
        # rather than failing earlier on broken multi-header number continuity.
        if row.get("chain_id") in (31337, 31338):
            row["chain_id"] = 31338 if row["chain_id"] == 31337 else 31337
        else:
            row["headers"][0]["number"] += 1
        source.write_text(json.dumps(row))
    case("different-input", change_input, "cache schema/input")

    def seal(root, source, name="segment-receipt-0000.json"):
        path = root / name
        row = json.loads(path.read_text())
        row["seal"][0] ^= 1
        path.write_text(json.dumps(row))
    case("altered-segment-seal", seal, "Error:")

    def swap(root, source, a_name="segment-receipt-0000.json", b_name="segment-receipt-0001.json"):
        a, b = root / a_name, root / b_name
        av, bv = a.read_bytes(), b.read_bytes()
        a.write_bytes(bv)
        b.write_bytes(av)
    case("swapped-segment-receipts", swap, "segment index mismatch")

    unions = sorted(cache.glob("union-*.json"))
    if len(manifest["keccaks"]) > 1:
        if len(unions) < 2:
            p.error("multi-Keccak audit requires completed cache with multiple genuine unions")
        case("altered-union-seal", lambda r, s: seal(r, s, unions[0].name), "Error:")
        case("swapped-valid-unions", lambda r, s: swap(r, s, unions[0].name, unions[1].name),
             "cached union child claims mismatch")
        case("swapped-valid-keccaks", lambda r, s: swap(r, s, "keccak-receipt-0000.json", "keccak-receipt-0001.json"),
             "cached Keccak claim mismatch")

    def strip_assumption(root, source):
        path = root / "composite.json"
        row = json.loads(path.read_text())
        row["inner"]["Composite"]["assumption_receipts"] = []
        path.write_text(json.dumps(row))
    case("unresolved-keccak", strip_assumption, "Error:")

    def fake(root, source):
        path = root / "composite.json"
        row = json.loads(path.read_text())
        row["inner"] = {"Fake": {"claim": {"Pruned": [0] * 8}}}
        path.write_text(json.dumps(row))
    case("fake-composite", fake, "cached receipt kind")

    for kind in ("symlink", "fifo"):
        def nonregular(root, source, which=kind):
            path = root / "segment-receipt-0000.json"
            path.unlink()
            if which == "symlink":
                path.symlink_to(cache / "segment-receipt-0000.json")
            else:
                os.mkfifo(path)
        case(kind, nonregular, "cached proof must be a regular file")
    with (cache / "cache.lock").open("r+") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        invoke("concurrent-cache-lock", cache, witness, "cache already in use")
    partial = out / "missing-proof"
    shutil.copytree(cache, partial)
    (partial / "keccak-receipt-0000.json").unlink()
    invoke("missing-proof-is-partial", partial, witness, partial=True)
    if unions:
        partial_union = out / "missing-union"
        shutil.copytree(cache, partial_union)
        (partial_union / unions[0].name).unlink()
        invoke("missing-union-is-partial", partial_union, witness, partial=True)
    after = {str(x.relative_to(cache)): sha(x) for x in cache.rglob("*") if x.is_file()}
    if after != original:
        raise ValueError("read-only audit modified original cache")
    report = {"status": "PASS", "checks": results, "originalCacheUnchanged": True,
              "newProofsGenerated": 0, "evmAcceptanceMeasured": False,
              "chainAuthenticated": False, "realAssetDeploymentAllowed": False}
    (out / "summary.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report))


if __name__ == "__main__":
    main()
