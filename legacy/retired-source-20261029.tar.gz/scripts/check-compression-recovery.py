#!/usr/bin/env python3
"""Actual SDK/parser rejection checks for explicit saved receipt compression."""
import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--host', type=Path, required=True)
    parser.add_argument('--evidence', type=Path, required=True)
    parser.add_argument('--large-evidence', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    out = args.output_dir.resolve(); out.mkdir(parents=True, exist_ok=False)
    source = args.evidence.resolve(); host = out / 'risc0-host'; shutil.copy2(args.host, host)
    original = json.loads((source / 'phases/succinct.json').read_text())
    inp = json.loads((source / 'input.json').read_text())
    source_hash = hashlib.sha256((source / 'phases/succinct.json').read_bytes()).hexdigest()
    env = dict(os.environ, RISC0_DEV_MODE='0', RISC0_PROVER='ipc',
        RISC0_SERVER_PATH=str(Path.home() / '.cargo/bin/r0vm'), BRIDGE_RISC0_SEGMENT_PO2='18')
    report = {'localVerdict': 'FAIL', 'scope': 'actual saved SDK succinct and local input rejection checks',
        'hostSHA256': hashlib.sha256(host.read_bytes()).hexdigest(), 'sourceReceiptSHA256': source_hash,
        'newProofsGenerated': 0, 'evmTransactionsBroadcast': 0, 'chainAuthenticated': False,
        'realAssetDeploymentAllowed': False, 'checks': []}
    try:
        valid_input = out / 'input.json'; valid_input.write_text(json.dumps(inp))
        valid_receipt = out / 'succinct.json'; valid_receipt.write_text(json.dumps(original))
        bad_journal = copy.deepcopy(original); bad_journal['journal']['bytes'][-1] ^= 1
        journal_path = out / 'bad-journal.json'; journal_path.write_text(json.dumps(bad_journal))
        different = copy.deepcopy(inp); different['headers'][-1]['receipt_root'][-1] ^= 1
        different_path = out / 'different-valid-input.json'; different_path.write_text(json.dumps(different))
        fake = copy.deepcopy(original); fake['inner'] = {'Fake': {'claim': {'Pruned': [0] * 8}}}
        fake_path = out / 'fake.json'; fake_path.write_text(json.dumps(fake))
        sparse = out / 'oversize.json'
        with sparse.open('wb') as f: f.truncate(64 * 1024 * 1024 + 1)
        cases = [
            ('fake', valid_input, fake_path, {}, 'actual saved composite or succinct'),
            ('development-mode', valid_input, valid_receipt, {'RISC0_DEV_MODE': '1'}, 'RISC0_DEV_MODE is forbidden'),
            ('tampered-journal', valid_input, journal_path, {}, None),
            ('different-valid-input', different_path, valid_receipt, {}, 'profile phase image/claim/journal mismatch'),
            ('completed-groth16', valid_input, source / 'receipt.json', {}, 'actual saved composite or succinct'),
            ('normal-cap-rejects16', args.large_evidence.resolve() / 'input.json',
                args.large_evidence.resolve() / 'phases/succinct.json', {}, 'explicit export/diagnostic cap'),
            ('oversize-saved-receipt', valid_input, sparse, {}, 'bounded artifact cap'),
            ('existing-output', valid_input, valid_receipt, {}, 'refuse to replace a receipt artifact')]
        for name, input_path, receipt_path, extra, expected in cases:
            directory = out / name; directory.mkdir()
            output = directory / 'receipt.json'
            if name == 'existing-output': output.write_text('preserved receipt sentinel')
            result = subprocess.run([str(host), '--resume-profile-receipt', '--input', str(input_path),
                '--receipt-input', str(receipt_path), '--receipt-output', str(output)],
                env=dict(env, **extra), capture_output=True, text=True, timeout=120)
            (directory / 'stdout.txt').write_text(result.stdout)
            (directory / 'stderr.txt').write_text(result.stderr)
            if result.returncode == 0 or result.stdout or 'usage:' in result.stderr:
                raise ValueError(name + ': recovery command failed to reject the intended input')
            if expected and expected not in result.stderr:
                raise ValueError(name + ': wrong rejection: ' + result.stderr)
            if (directory / 'phases').exists(): raise ValueError(name + ': compression started before guard')
            if name == 'existing-output':
                if output.read_text() != 'preserved receipt sentinel': raise ValueError('existing receipt overwritten')
            elif output.exists(): raise ValueError(name + ': failed guard exported a receipt')
            report['checks'].append({'name': name, 'rejectedBeforeCompression': True, 'exitCode': result.returncode})
        if hashlib.sha256((source / 'phases/succinct.json').read_bytes()).hexdigest() != source_hash:
            raise ValueError('original saved receipt changed')
        report.update(localVerdict='PASS', originalSavedReceiptUnchanged=True)
    except BaseException as error:
        report['error'] = str(error); raise
    finally:
        (out / 'summary.json').write_text(json.dumps(report, indent=2) + '\n')
    print('PASS actual saved succinct SDK/parser guards8; no new proof/EVM submission')


if __name__ == '__main__': main()
