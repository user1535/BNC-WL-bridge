#!/usr/bin/env python3
"""Recheck a completed 16-header user scenario on copied local state, without broadcasting."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import socket
import subprocess
import time
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
IMAGE = '0x4f612b40d3aa2c81542ca04f91042e59c9acab41334837ef7396e9f9feb47e98'


def main():
    def interrupted(*_): raise KeyboardInterrupt('saved local evidence verification interrupted')
    signal.signal(signal.SIGTERM, interrupted)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--evidence', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    source = args.evidence.resolve()
    out = args.output_dir.resolve(); out.mkdir(parents=True, exist_ok=False)
    env = dict(os.environ, RISC0_DEV_MODE='0', RISC0_PROVER='ipc')
    report = {'measuredAt': datetime.now(timezone.utc).isoformat(), 'localVerdict': 'FAIL',
        'sourceEvidence': str(source), 'freshProofGenerated': False, 'transactionsBroadcast': 0,
        'chainAuthenticated': False, 'realAssetDeploymentAllowed': False,
        'walletBackend': 'historical Anvil unlocked user accounts; no new signing',
        'checks': []}
    nodes = []
    urls = {'wl': 'http://127.0.0.1:8580', 'bnb': 'http://127.0.0.1:8581'}

    def load(path): return json.loads(path.read_text())
    def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
    def require(condition, message):
        if not condition: raise ValueError(message)
    def command(arguments, timeout=120):
        result = subprocess.run([str(a) for a in arguments], cwd=ROOT, env=env,
            text=True, capture_output=True, timeout=timeout)
        require(result.returncode == 0, result.stderr or result.stdout or 'command failed')
        return result.stdout.strip()
    def rpc(chain, method, params):
        with urllib.request.urlopen(urllib.request.Request(urls[chain], json.dumps({
            'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params}).encode(),
            {'Content-Type': 'application/json'}), timeout=15) as response:
            result = json.load(response)
        if 'error' in result: raise ValueError(str(result['error']))
        return result['result']
    def view(chain, address, signature, *arguments):
        return command(['cast', 'call', address, signature, *arguments,
            '--rpc-url', urls[chain]]).split()[0]
    def raw(value): return '0x' + bytes(value).hex()
    def transaction(chain, archived, sender, target, payload=None):
        actual = rpc(chain, 'eth_getTransactionReceipt', [archived['transactionHash']])
        tx = rpc(chain, 'eth_getTransactionByHash', [archived['transactionHash']])
        require(actual is not None and tx is not None and int(actual['status'], 16) == 1,
            'successful persisted transaction missing')
        for key in ('transactionHash', 'blockHash', 'blockNumber', 'status', 'logs'):
            require(actual[key] == archived[key], 'persisted transaction differs: ' + key)
        require(tx['from'].lower() == sender.lower() and tx['to'].lower() == target.lower(),
            'transaction sender/target differs from event user/contract')
        if payload is not None: require(tx['input'].lower() == payload.lower(), 'transaction calldata mismatch')
        return actual

    before = {}
    try:
        summary = load(source / 'summary.json'); session = load(source / 'session.json')
        require(summary.get('localVerdict') == 'PASS' and summary.get('workState') == 'complete'
            and summary.get('ownedNodesStopped') is True, 'completed stopped local scenario required')
        for key in ('actualGroth16EvmAcceptance', 'mptRoundtrip', 'proofArtifactsUnchangedDuringClaims',
                    'restartBeforeBothClaimGroups'):
            require(summary.get(key) is True, 'missing completed scenario evidence: ' + key)
        require(summary.get('chainAuthenticated') is False and summary.get('realAssetDeploymentAllowed') is False
            and summary.get('syntheticHeaders') is False and summary.get('normalGeneratorExportCapChanged') is False,
            'evidence scope mismatch')
        require(session.get('mode') == 'risc0_batch' and session.get('header_binding') == 'minimal-link'
            and session.get('image_id') == IMAGE and summary.get('imageId') == IMAGE,
            'only the recorded accelerated minimal-link local session is supported')
        users = session['users']; events = session['events']; contracts = session['contracts']
        require(len(users) == len(set(users)) == 3 and len(events) == 6 and all(e.get('claimed') is True for e in events),
            'three distinct users and six completed claims required')
        require(sha(source / 'risc0-host') == session['host_sha256'], 'session host changed')
        before = {str(p.relative_to(source)): sha(p) for p in source.rglob('*') if p.is_file()}
        command(['go', '-C', ROOT / 'proof-generator', 'build', '-o', out / 'bridge-proof', './cmd/bridge-proof'])
        report['generatorSHA256'] = sha(out / 'bridge-proof')
        report['hostSHA256'] = session['host_sha256']
        for chain, port, chain_id in [('wl', 8580, 31337), ('bnb', 8581, 31338)]:
            with socket.socket() as probe:
                probe.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                probe.bind(('127.0.0.1', port)); probe.listen(1)
            shutil.copy2(source / f'{chain}-state.json', out / f'{chain}-state.json')
            with (out / f'{chain}-anvil.log').open('w') as log:
                node = subprocess.Popen(['anvil', '--silent', '--host', '127.0.0.1', '--port', str(port),
                    '--chain-id', str(chain_id), '--state', str(out / f'{chain}-state.json'),
                    '--preserve-historical-states'], stdout=log, stderr=log)
                nodes.append(node)
            for _ in range(50):
                require(node.poll() is None, 'owned state clone exited')
                try:
                    require(int(rpc(chain, 'eth_chainId', []), 16) == chain_id, 'wrong local chain ID')
                    break
                except OSError: time.sleep(.1)
            else: raise ValueError('owned state clone startup timeout')
        for action, source_chain, destination, start, heights, token, remote, updater, receiver in [
            ('lock', 'wl', 'bnb', 96, [100, 104, 107], contracts['original'], contracts['wrapped'], contracts['bnb_headers'], contracts['mint']),
            ('burn', 'bnb', 'wl', 6, [10, 14, 17], contracts['wrapped'], contracts['original'], contracts['wl_headers'], contracts['unlock'])]:
            group = [e for e in events if e['action'] == action]
            require([e['block'] for e in group] == heights and {e['user'] for e in group} == set(users),
                'event block/user group mismatch')
            profile = source / f'{action}-{start}-16-profile'; prof = load(profile / 'summary.json')
            for filename, key in [('risc0-host', 'hostSHA256'), ('input.json', 'inputSHA256'), ('receipt.json', 'receiptSHA256')]:
                require(sha(profile / filename) == prof[key], 'profile artifact changed: ' + filename)
            require(prof.get('localVerdict') == 'PASS' and prof.get('diagnosticMaxHeaders') == 16
                and prof.get('batchSize') == 16 and prof.get('normalGeneratorExportCapChanged') is False,
                'completed explicit16 Groth16 profile required')
            verified = json.loads(command([profile / 'risc0-host', '--verify-receipt', profile / 'receipt.json']))
            package = load(source / f'{action}-{start}-16-headers.json')
            require(verified.get('verified') is True and verified.get('receipt_kind') == 'groth16'
                and verified.get('evm_compatible') is True and verified.get('image_id') == IMAGE
                and verified.get('header_binding') == 'minimal-link' and verified.get('chain_authenticated') is False,
                'actual SDK Groth16 crypto verification failed')
            for sdk_key, package_key in [('image_id', 'imageId'), ('journal', 'journal'), ('seal', 'seal')]:
                require(verified[sdk_key].lower() == package[package_key].lower(), 'SDK/package binding mismatch')
            require(package['proofReceipt'] == load(profile / 'receipt.json')
                and package['guestInput'] == load(profile / 'input.json'), 'proof package differs from pinned artifacts')
            headers = package['guestInput']['headers']
            require(len(headers) == 16 and [h['number'] for h in headers] == list(range(start, start + 16)),
                'full16 header range required')
            anchor = rpc(source_chain, 'eth_getBlockByNumber', [hex(start - 1), False])
            require(anchor['hash'].lower() == raw(package['guestInput']['anchor_hash']), 'persisted source anchor changed')
            for h in headers:
                block = rpc(source_chain, 'eth_getBlockByNumber', [hex(h['number']), False])
                for rpc_key, field in [('hash', 'block_hash'), ('parentHash', 'parent_hash'), ('receiptsRoot', 'receipt_root')]:
                    require(block[rpc_key].lower() == raw(h[field]), 'persisted source header differs: ' + field)
                require(view(destination, updater, 'isBlockCovered(uint256,uint256,bytes32)(bool)',
                    package['sourceChainId'], h['number'], raw(h['block_hash'])) == 'true', 'saved updater coverage missing')
                require(view(destination, updater, 'getReceiptRoot(uint256,uint256,bytes32)(bytes32)',
                    package['sourceChainId'], h['number'], raw(h['block_hash'])).lower() == raw(h['receipt_root']),
                    'saved updater root differs')
            require(view(destination, updater, 'guestImageId()(bytes32)').lower() == IMAGE, 'updater image mismatch')
            payload = command(['cast', 'calldata', 'submitHeaderProof(bytes,bytes,bytes)',
                package['seal'], package['journal'], package['batchData']])
            accepted = load(source / f'{action}-{start}-accepted.json')
            transaction(destination, accepted, group[-1]['user'], updater, payload)
            for event in group:
                transaction(source_chain, load(source / (event['id'] + '-receipt.json')), event['user'], token)
                saved = load(source / (event['id'] + '-package.json'))
                regenerated = json.loads(command([out / 'bridge-proof', '--rpc', urls[source_chain],
                    '--chain-id', package['sourceChainId'], '--token', token, '--destination-token', remote,
                    '--id', event['id'], '--action', action, '--from-block', event['block'],
                    '--destination-rpc', urls[destination], '--header-source', updater, '--receiver', receiver,
                    '--header-mode', 'risc0_batch', '--risc0-host', source / 'risc0-host']))
                require(regenerated.get('headerCovered') is True and regenerated.get('coverageChecked') is True
                    and 'headerTransaction' not in regenerated and 'headerProof' not in regenerated
                    and regenerated.get('chainAuthenticated') is False, 'covered claim attempted new header proof')
                require(regenerated['claimTransaction'] == saved['claimTransaction']
                    and regenerated['recipient'].lower() == event['user'].lower()
                    and regenerated['amount'] == str(25 * 10**18), 'regenerated MPT/user claim differs')
                tx = regenerated['claimTransaction']
                transaction(destination, load(source / (event['id'] + '-claim.json')), event['user'], receiver, tx['data'])
                try: rpc(destination, 'eth_call', [{'from': event['user'], 'to': receiver, 'data': tx['data']}, 'latest'])
                except ValueError as error:
                    require('execution reverted' in str(error).lower(), 'RPC failure is not replay rejection')
                else: raise ValueError('already consumed claim unexpectedly accepted')
            report['checks'].append({'action': action, 'sourceChainId': package['sourceChainId'],
                'sdkGroth16Reverified': True, 'acceptedHeaderTransactionChecked': True,
                'full16SourceAndUpdaterRootsChecked': True, 'regeneratedMptClaims': 3,
                'historicalUserSenderAndCalldataChecked': True, 'consumedClaimReplaysRejected': 3,
                'gasUsed': int(accepted['gasUsed'], 16), 'receiptSHA256': prof['receiptSHA256']})
        balances = []
        for user in users:
            original = int(view('wl', contracts['original'], 'balanceOf(address)(uint256)', user))
            locked = int(view('wl', contracts['original'], 'lockedBalanceOf(address)(uint256)', user))
            wrapped = int(view('bnb', contracts['wrapped'], 'balanceOf(address)(uint256)', user))
            require((original, locked, wrapped) == (100 * 10**18, 0, 0), 'persisted final per-user balance differs')
            balances.append({'user': user, 'original': str(original), 'locked': str(locked), 'wrapped': str(wrapped)})
        require(int(view('bnb', contracts['wrapped'], 'totalSupply()(uint256)')) == 0, 'persisted wrapped supply nonzero')
        report.update(localVerdict='PASS', persistedStateRechecked=True, balances=balances,
            consumedClaimReplaysRejected=6, fullHeaderRootsChecked=32, mptClaimsRegenerated=6)
    except BaseException as error:
        report['error'] = str(error); raise
    finally:
        for node in nodes:
            if node.poll() is None:
                node.terminate()
                try: node.wait(timeout=5)
                except subprocess.TimeoutExpired: node.kill(); node.wait()
        report['ownedNodesStopped'] = all(n.poll() is not None for n in nodes)
        if before:
            after = {str(p.relative_to(source)): sha(p) for p in source.rglob('*') if p.is_file()}
            report['originalEvidenceUnchanged'] = before == after
            if before != after: report.update(localVerdict='FAIL', evidenceChangeError='original evidence changed during verification')
            (out / 'source-evidence-sha256.json').write_text(json.dumps(before, indent=2) + '\n')
        (out / 'summary.json').write_text(json.dumps(report, indent=2) + '\n')
    require(report['localVerdict'] == 'PASS', 'saved local evidence verification failed')
    print('PASS saved actual16 Groth16/MPT3user both directions; replay6/finalbalances; broadcasts0/newproof0')


if __name__ == '__main__': main()
