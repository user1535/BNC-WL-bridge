#!/usr/bin/env python3
"""Persistent, local-only wallet client. The Go generators never sign transactions."""
import argparse
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import shutil
import subprocess
import sys
import time
import urllib.request
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parent.parent
spec=importlib.util.spec_from_file_location('session_runtime',ROOT/'scripts/runtime-config.py')
runtime=importlib.util.module_from_spec(spec);spec.loader.exec_module(runtime)
HOST=runtime.binary('BNC_PROVER_HOST',ROOT/'.bin/risc0-host' if (ROOT/'.bin/risc0-host').exists() else ROOT/'risc0/target/release/bridge-header-benchmark')
PROOF=runtime.binary('BNC_PROOF_BIN',ROOT/'.bin/bridge-proof')
HEADER=runtime.binary('BNC_HEADER_BIN',ROOT/'.bin/bridge-header-data')
os.environ.setdefault('RISC0_SERVER_PATH',str(runtime.r0vm()))


def command(args, *, output=True):
    result = subprocess.run([str(v) for v in args], text=True, capture_output=True)
    if result.returncode:
        raise RuntimeError(result.stderr.strip() or result.stdout.strip() or 'command failed')
    return result.stdout.strip() if output else None


def write_json(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


class Session:
    def __init__(self, directory):
        self.root = directory.resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.path = self.root / 'session.json'
        self.data = json.loads(self.path.read_text()) if self.path.exists() else {}

    def save(self):
        write_json(self.path, self.data)

    def prover_host(self):
        snapshot = self.root / 'risc0-host'
        expected = self.data.get('image_id')
        if not expected and self.data.get('phase') == 'ready' and self.data['mode'] == 'risc0_batch':
            expected = self.view('bnb', self.data['contracts']['bnb_headers'], 'guestImageId()(bytes32)')
        if not snapshot.exists():
            candidates = [HOST, ROOT / '.bin/bridge-header-benchmark-baseline']
            if self.data.get('header_binding', 'minimal-link') == 'canonical-rlp':
                candidates = [ROOT / 'risc0/target/release/bridge-header-bound-host']
            selected = next((p for p in candidates if p.is_file() and (not expected or command([p, '--image-id']) == expected)), None)
            if selected is None:
                raise RuntimeError('compiled guest changed; restore a matching host or use a new session directory')
            temporary = snapshot.with_suffix('.tmp')
            shutil.copy2(selected, temporary)
            temporary.replace(snapshot)
            self.data['image_id'] = command([snapshot, '--image-id'])
            self.data['host_sha256'] = hashlib.sha256(snapshot.read_bytes()).hexdigest()
            self.save()
        if hashlib.sha256(snapshot.read_bytes()).hexdigest() != self.data.get('host_sha256'):
            raise RuntimeError('session prover host changed; restore the recorded binary')
        if self.data.get('header_binding', 'minimal-link') == 'canonical-rlp' and command([snapshot, '--header-binding']) != 'canonical-rlp':
            raise RuntimeError('session requires a strict canonical-RLP host')
        return snapshot

    def rpc(self, chain, method, params):
        url = self.data['chains'][chain]['rpc']
        request = urllib.request.Request(url, json.dumps({'jsonrpc': '2.0', 'id': 1,
            'method': method, 'params': params}).encode(), {'Content-Type': 'application/json'})
        response = json.load(urllib.request.urlopen(request, timeout=15))
        if 'error' in response:
            raise RuntimeError(str(response['error']))
        return response['result']

    def guard(self):
        for chain, expected in [('wl', 31337), ('bnb', 31338)]:
            config=self.data['chains'][chain];url=urlsplit(config['rpc'])
            if (url.scheme!='http' or url.hostname!='127.0.0.1' or url.port!=config['port']
                or url.username or url.password or url.path or url.query or url.fragment):
                raise RuntimeError('owned session requires its configured loopback RPC')
            if int(self.rpc(chain, 'eth_chainId', []), 16) != expected:
                raise RuntimeError('local session chain ID changed')
            pid = self.data['chains'][chain]['pid']
            cmdline = Path(f'/proc/{pid}/cmdline').read_bytes().split(b'\0')
            if Path(os.fsdecode(cmdline[0])).name != 'anvil' or os.fsencode(str(self.root / f'{chain}-state.json')) not in cmdline:
                raise RuntimeError('RPC process is not this session Anvil')

    def start(self, mode, binding='minimal-link'):
        if binding not in ['minimal-link', 'canonical-rlp'] or (binding == 'canonical-rlp' and mode == 'dev'):
            raise RuntimeError('canonical-RLP binding requires a RISC0 mode')
        if not self.data:
            self.data = {'version': 1, 'mode': mode, 'header_binding': binding, 'phase': 'created', 'chains': {}, 'contracts': {},
                'events': [], 'chain_authenticated': False, 'real_asset_deployment_allowed': False}
            if runtime.port('BNC_WL_PORT',8565)==runtime.port('BNC_BNB_PORT',8566):
                raise ValueError('chain ports must differ')
            for chain, port, chain_id in [('wl', runtime.port('BNC_WL_PORT',8565), 31337), ('bnb', runtime.port('BNC_BNB_PORT',8566), 31338)]:
                self.data['chains'][chain] = {'rpc': f'http://127.0.0.1:{port}', 'port': port, 'id': chain_id}
            self.save()
        if self.data['mode'] != mode:
            raise RuntimeError('existing session mode is immutable')
        if self.data.get('header_binding', 'minimal-link') != binding:
            raise RuntimeError('existing session header binding is immutable')
        for chain, config in self.data['chains'].items():
            try:
                self.rpc(chain, 'eth_chainId', [])
            except Exception:
                with (self.root / f'{chain}-anvil.log').open('a') as log:
                    process = subprocess.Popen(['anvil', '--silent', '--host', '127.0.0.1', '--port', str(config['port']),
                        '--chain-id', str(config['id']), '--state', str(self.root / f'{chain}-state.json'),
                        '--state-interval', '1', '--preserve-historical-states'], stdout=log, stderr=log, start_new_session=True)
                    config['pid'] = process.pid
                    self.save()
                for _ in range(50):
                    try:
                        self.rpc(chain, 'eth_chainId', [])
                        break
                    except Exception:
                        time.sleep(.2)
            # A responding unknown service must never be adopted or reset.
        self.guard()
        print('local session nodes running; state files preserve restart data')

    def view(self, chain, address, signature, *args):
        return command(['cast', 'call', address, signature, *args, '--rpc-url', self.data['chains'][chain]['rpc']]).split()[0]

    def send(self, chain, sender, address, *args):
        self.guard()
        result = json.loads(command(['cast', 'send', address, *args, '--rpc-url', self.data['chains'][chain]['rpc'],
            '--unlocked', '--from', sender, '--json']))
        if int(result['status'], 16) != 1:
            raise RuntimeError('wallet transaction reverted')
        return result

    def deploy(self, key, chain, contract, *args):
        if key in self.data['contracts']:
            return self.data['contracts'][key]
        cmd = ['forge', 'create', '--root', ROOT / 'contracts', contract, '--rpc-url', self.data['chains'][chain]['rpc'],
            '--unlocked', '--from', self.data['operator'], '--broadcast', '--json']
        if args:
            cmd += ['--constructor-args', *args]
        address = json.loads(command(cmd))['deployedTo']
        self.data['contracts'][key] = address
        self.save()
        return address

    def setup(self):
        self.guard()
        ROOT.joinpath('.bin').mkdir(exist_ok=True)
        if not PROOF.is_file() or os.environ.get('BNC_REBUILD_BINARIES')=='1':
            PROOF.parent.mkdir(parents=True,exist_ok=True)
            command(['go','-C',ROOT/'proof-generator','build','-o',PROOF,'./cmd/bridge-proof'])
        if self.data['mode'] != 'dev':
            self.prover_host()
            if not HEADER.is_file() or os.environ.get('BNC_REBUILD_BINARIES')=='1':
                HEADER.parent.mkdir(parents=True,exist_ok=True)
                command(['go','-C',ROOT/'proof-generator','build','-o',HEADER,'./cmd/bridge-header-data'])
        accounts = self.rpc('wl', 'eth_accounts', [])
        self.data['operator'], self.data['users'] = accounts[0], accounts[1:4]
        self.save()
        if self.data['phase'] == 'ready':
            print('deployment already ready')
            return
        operator = self.data['operator']
        original = self.deploy('original', 'wl', 'src/token/BridgeLockableToken.sol:BridgeLockableToken', 'Local WorldLand', 'WL', str(1000 * 10**18), '31338')
        wrapped = self.deploy('wrapped', 'bnb', 'src/token/BridgeWrappedToken.sol:BridgeWrappedToken', 'Local Wrapped WorldLand', 'wWL', '31337', original)
        if int(self.view('wl', original, 'destinationWrappedToken()(address)'), 16) == 0:
            self.send('wl', operator, original, 'bindDestinationWrappedToken(address)', wrapped)
        for user in self.data['users']:
            funding_key = 'funded_' + user.lower()
            if not self.data.get(funding_key):
                # Funding is idempotent across a process interruption after broadcast.
                if int(self.view('wl', original, 'balanceOf(address)(uint256)', user)) == 0:
                    self.send('wl', operator, original, 'transfer(address,uint256)', user, str(100 * 10**18))
                self.data[funding_key] = True
                self.save()
        if self.data['mode'] == 'risc0_batch':
            command(['docker', 'info'])
            image = command([self.prover_host(), '--image-id'])
            for chain in ['wl', 'bnb']:
                self.deploy(chain + '_verifier', chain, 'src/bridge/LocalRiscZeroGroth16Verifier.sol:LocalRiscZeroGroth16Verifier')
            tip = self.rpc('wl', 'eth_getBlockByNumber', ['latest', False])
            self.deploy('bnb_headers', 'bnb', 'src/bridge/Risc0HeaderUpdater.sol:Risc0HeaderUpdater', '31337', self.data['contracts']['bnb_verifier'], image, str(int(tip['number'], 16)), tip['hash'])
        else:
            self.deploy('bnb_headers', 'bnb', 'src/bridge/DevHeaderRegistry.sol:DevHeaderRegistry', '31337')
        mint = self.deploy('mint', 'bnb', 'src/bridge/LockMintReceiver.sol:LockMintReceiver', wrapped, self.data['contracts']['bnb_headers'])
        if int(self.view('bnb', wrapped, 'mintReceiver()(address)'), 16) == 0:
            self.send('bnb', operator, wrapped, 'bindMintReceiver(address)', mint)
        if self.data['mode'] == 'risc0_batch':
            tip = self.rpc('bnb', 'eth_getBlockByNumber', ['latest', False])
            self.deploy('wl_headers', 'wl', 'src/bridge/Risc0HeaderUpdater.sol:Risc0HeaderUpdater', '31338', self.data['contracts']['wl_verifier'], image, str(int(tip['number'], 16)), tip['hash'])
        else:
            self.deploy('wl_headers', 'wl', 'src/bridge/DevHeaderRegistry.sol:DevHeaderRegistry', '31338')
        unlock = self.deploy('unlock', 'wl', 'src/bridge/BurnUnlockReceiver.sol:BurnUnlockReceiver', original, self.data['contracts']['wl_headers'], wrapped)
        if int(self.view('wl', original, 'unlockReceiver()(address)'), 16) == 0:
            self.send('wl', operator, original, 'bindUnlockReceiver(address)', unlock)
        self.data['phase'] = 'ready'
        self.save()
        print('deployment ready; wallets are local Anvil accounts; no private key stored in session')

    def route(self, action):
        c = self.data['contracts']
        return ('wl', 'bnb', c['original'], c['wrapped'], c['bnb_headers'], c['mint']) if action == 'lock' else ('bnb', 'wl', c['wrapped'], c['original'], c['wl_headers'], c['unlock'])

    def action(self, action, index, amount):
        source, destination, token, _, _, _ = self.route(action)
        user = self.data['users'][index]
        signature = 'bridgeLock(uint256,address,uint256)' if action == 'lock' else 'bridgeBurn(uint256,address,uint256)'
        pending = self.data.get('pending_action')
        if pending:
            if (pending['action'], pending['user'], pending['amount']) != (action, user, amount):
                raise RuntimeError('finish the pending wallet action with recover before creating another action')
            return self.recover()
        arguments = [signature, str(amount), user, str(self.data['chains'][destination]['id'])]
        pending = {'action': action, 'user': user, 'source': source, 'token': token, 'amount': amount,
            'arguments': arguments, 'data': command(['cast', 'calldata', *arguments]),
            'wallet_nonce': int(self.rpc(source, 'eth_getTransactionCount', [user, 'latest']), 16),
            'before_block': int(self.rpc(source, 'eth_blockNumber', []), 16)}
        self.data['pending_action'] = pending
        self.save()  # Durable intent before any signing/broadcast.
        receipt = self.send(source, user, token, *arguments, '--nonce', str(pending['wallet_nonce']))
        self.record_action(pending, receipt)

    def record_action(self, pending, receipt):
        event = {'action': pending['action'], 'id': receipt['logs'][-1]['topics'][1], 'block': int(receipt['blockNumber'], 16), 'user': pending['user'], 'tx_hash': receipt['transactionHash']}
        write_json(self.root / (event['id'] + '-receipt.json'), receipt)
        if not any(e['tx_hash'] == event['tx_hash'] for e in self.data['events']):
            self.data['events'].append(event)
        self.data['pending_action'] = None
        self.save()
        print(json.dumps(event))

    def recover(self):
        pending = self.data.get('pending_action')
        if not pending:
            print('no interrupted wallet action')
            return
        self.guard()
        source, user, nonce = pending['source'], pending['user'], pending['wallet_nonce']
        tip = int(self.rpc(source, 'eth_blockNumber', []), 16)
        if tip - pending['before_block'] > 256:
            raise RuntimeError('recovery exceeds 256 local blocks; inspect the recorded nonce before any retry')
        for height in range(pending['before_block'] + 1, tip + 1):
            block = self.rpc(source, 'eth_getBlockByNumber', [hex(height), True])
            for tx in block['transactions']:
                if tx['from'].lower() == user.lower() and int(tx['nonce'], 16) == nonce:
                    if tx['to'].lower() != pending['token'].lower() or tx['input'].lower() != pending['data'].lower():
                        raise RuntimeError('wallet nonce consumed by another transaction; inspect before retry')
                    receipt = self.rpc(source, 'eth_getTransactionReceipt', [tx['hash']])
                    if int(receipt['status'], 16) != 1:
                        self.data['pending_action'] = None
                        self.save()
                        raise RuntimeError('interrupted wallet transaction reverted; not repeated')
                    self.record_action(pending, receipt)
                    print('interrupted accepted action recovered; no extra transaction')
                    return
        current = int(self.rpc(source, 'eth_getTransactionCount', [user, 'pending']), 16)
        if current != nonce:
            raise RuntimeError('pending/advanced wallet nonce is unresolved; retry recover after mining')
        receipt = self.send(source, user, pending['token'], *pending['arguments'], '--nonce', str(nonce))
        self.record_action(pending, receipt)
        print('saved unbroadcast action submitted once with the recorded wallet nonce')

    def package(self, event, header_file=None):
        source, destination, token, remote_token, headers, receiver = self.route(event['action'])
        cmd = [PROOF, '--rpc', self.data['chains'][source]['rpc'], '--chain-id', self.data['chains'][source]['id'], '--token', token,
            '--destination-token', remote_token, '--id', event['id'], '--action', event['action'], '--from-block', event['block'],
            '--destination-rpc', self.data['chains'][destination]['rpc'], '--header-source', headers, '--receiver', receiver,
            '--header-mode', self.data['mode']]
        if self.data['mode'] != 'dev':
            cmd += ['--risc0-host', self.prover_host()]
        if header_file:
            cmd += ['--header-package', header_file]
        package = json.loads(command(cmd))
        write_json(self.root / (event['id'] + '-package.json'), package)
        return package

    def make_headers(self, action, start, count):
        source, _, _, _, _, _ = self.route(action)
        path = self.root / f'{action}-{start}-{count}-headers.json'
        cmd = [HEADER, '--rpc', self.data['chains'][source]['rpc'], '--chain-id', self.data['chains'][source]['id'], '--start', start, '--count', count,
            '--risc0-host', self.prover_host(), '--proof-cache', self.root / 'proof-cache', '--receipt-kind', 'groth16' if self.data['mode'] == 'risc0_batch' else 'composite', '--proof-timeout', '45m']
        cmd += ['--header-binding', self.data.get('header_binding', 'minimal-link')]
        print(f'proving {action} headers {start}..{start + count - 1}', flush=True)
        package = json.loads(command(cmd))
        write_json(path, package)
        return path, package

    def headers(self, event):
        source, destination, _, _, updater, _ = self.route(event['action'])
        block = self.rpc(source, 'eth_getBlockByNumber', [hex(event['block']), False])
        covered = self.view(destination, updater, 'isBlockCovered(uint256,uint256,bytes32)(bool)', str(self.data['chains'][source]['id']), str(event['block']), block['hash'])
        if covered == 'true':
            return
        if self.data['mode'] != 'risc0_batch':
            if self.data['mode'] == 'risc0_composite':
                path, _ = self.make_headers(event['action'], event['block'], 1)
                self.package(event, path)  # Reverify image/journal/chain/batch before trusted registration.
            self.send(destination, self.data['operator'], updater, 'registerHeader(uint256,bytes32,bytes32)', str(event['block']), block['hash'], block['receiptsRoot'])
            return
        while True:
            start = int(self.view(destination, updater, 'latestBlock()(uint256)')) + 1
            if start > event['block']:
                break
            limit = 1 if self.data.get('header_binding') == 'canonical-rlp' else 4
            path, p = self.make_headers(event['action'], start, min(limit, event['block'] - start + 1))
            # Cryptographic verification and ABI/journal binding already occurred in header-data.
            current = int(self.view(destination, updater, 'latestBlock()(uint256)'))
            if current >= p['endBlock']:
                continue
            if current + 1 != p['startBlock'] or self.view(destination, updater, 'latestHash()(bytes32)').lower() != p['anchorHash'].lower():
                raise RuntimeError('updater changed while proving; retry to resample its head')
            tx = self.send(destination, event['user'], updater, 'submitHeaderProof(bytes,bytes,bytes)', p['seal'], p['journal'], p['batchData'])
            write_json(self.root / f'{event["action"]}-{start}-accepted.json', tx)

    def claim(self, event):
        _, destination, _, _, _, receiver = self.route(event['action'])
        replay_view = 'claimedTransfer(bytes32)(bool)' if event['action'] == 'lock' else 'claimedWithdrawal(bytes32)(bool)'
        if self.view(destination, receiver, replay_view, event['id']) == 'true':
            receipt_path = self.root / (event['id'] + '-claim.json')
            if not receipt_path.exists():
                self.guard()
                topic = command(['cast', 'keccak', 'LockClaimed(bytes32,address,uint256)' if
                    event['action'] == 'lock' else 'BurnClaimed(bytes32,address,uint256)'])
                tip = int(self.rpc(destination, 'eth_blockNumber', []), 16)
                if tip > 10000:
                    raise RuntimeError('local claim receipt recovery exceeds bounded history; preserve state')
                logs = self.rpc(destination, 'eth_getLogs', [{'address': receiver, 'fromBlock': '0x0',
                    'toBlock': hex(tip), 'topics': [topic, event['id']]}])
                recipient_topic = '0x' + event['user'][2:].lower().zfill(64)
                if (len(logs) != 1 or logs[0].get('removed') or logs[0]['address'].lower() != receiver.lower()
                    or [t.lower() for t in logs[0]['topics']] != [topic.lower(), event['id'].lower(), recipient_topic]):
                    raise RuntimeError('claimed flag has no unique matching local receiver/user log')
                receipt = self.rpc(destination, 'eth_getTransactionReceipt', [logs[0]['transactionHash']])
                if (not receipt or int(receipt['status'], 16) != 1 or receipt['to'].lower() != receiver.lower()
                    or receipt['transactionHash'] != logs[0]['transactionHash']
                    or receipt['blockHash'] != logs[0]['blockHash'] or receipt['blockNumber'] != logs[0]['blockNumber']
                    or receipt['transactionIndex'] != logs[0]['transactionIndex'] or logs[0] not in receipt['logs']):
                    raise RuntimeError('recovered local claim receipt differs from successful receiver log')
                write_json(receipt_path, receipt)
            if event.get('claimed') is not True:
                event['claimed'] = True
                self.save()
            print('claim already accepted; no transaction or proving repeated')
            return
        self.headers(event)
        package = self.package(event)
        if not package['headerCovered'] or package.get('headerTransaction'):
            raise RuntimeError('destination header is not ready')
        tx = package['claimTransaction']
        if tx['chainId'] != self.data['chains'][destination]['id'] or tx['to'].lower() != receiver.lower() or package['recipient'].lower() != event['user'].lower():
            raise RuntimeError('unsigned claim transaction differs from user/session')
        receipt = self.send(destination, event['user'], tx['to'], '--data', tx['data'])
        write_json(self.root / (event['id'] + '-claim.json'), receipt)
        event['claimed'] = True
        self.save()
        print('user claim accepted')

    def stop(self):
        self.guard()
        for config in self.data['chains'].values():
            os.kill(config['pid'], signal.SIGTERM)
        for _ in range(50):
            stopped = True
            for chain in self.data['chains']:
                try:
                    self.rpc(chain, 'eth_chainId', [])
                    stopped = False
                except Exception:
                    pass
            if stopped:
                break
            time.sleep(.2)
        else:
            raise RuntimeError('session nodes did not finish stopping')
        print('session stopped; public manifest, proof cache and Anvil state retained')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dir', type=Path, default=ROOT / 'results/session-fast')
    parser.add_argument('--mode', choices=['dev', 'risc0_composite', 'risc0_batch'], default='dev')
    parser.add_argument('--header-binding', choices=['minimal-link', 'canonical-rlp'], default='minimal-link')
    parser.add_argument('operation', choices=['start', 'deploy', 'stop', 'status', 'lock', 'burn', 'claim', 'headers', 'recover'])
    parser.add_argument('--user', type=int, choices=range(3), default=0)
    parser.add_argument('--amount', type=int, default=25 * 10**18, help='token base units')
    parser.add_argument('--id', help='saved transfer/withdrawal ID; defaults to latest event')
    args = parser.parse_args()
    os.environ.setdefault('RISC0_SERVER_PATH', str(runtime.r0vm()))
    session = Session(args.dir)
    with (session.root / 'client.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        session = Session(args.dir)  # Resample after another wallet operation releases the lock.
        if args.operation == 'start':
            session.start(args.mode, args.header_binding)
        elif args.operation == 'stop':
            session.stop()
        elif args.operation == 'status':
            print(json.dumps(session.data, indent=2))
        else:
            session.guard()
            if args.operation == 'deploy':
                session.setup()
            elif session.data.get('phase') != 'ready':
                raise RuntimeError('deploy this session first')
            elif args.operation == 'recover':
                session.recover()
            elif args.operation in ['lock', 'burn']:
                if args.amount <= 0:
                    raise RuntimeError('amount must be positive')
                session.action(args.operation, args.user, args.amount)
            else:
                events = [e for e in session.data['events'] if args.id is None or e['id'] == args.id]
                if not events:
                    raise RuntimeError('no saved event with this ID')
                getattr(session, args.operation)(events[-1])


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, OSError, ValueError, KeyError) as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)
