#!/usr/bin/env python3
"""Measure local operator-registry storage gas, never RISC0 proof/throughput gas."""
import argparse,hashlib,json,subprocess,time,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--output-dir',type=Path,required=True);args=parser.parse_args()
 out=args.output_dir.resolve();out.mkdir(parents=True,exist_ok=False)
 url='http://127.0.0.1:8576';node=None
 report={'localVerdict':'FAIL','scope':'DEV operator-supplied registry batch storage only, synthetic hashes/roots','risc0ProofMeasured':False,'chainAuthenticated':False,'realAssetDeploymentAllowed':False,'rows':[]}
 def command(cmd):return subprocess.check_output([str(x) for x in cmd],cwd=ROOT,text=True,stderr=subprocess.PIPE).strip()
 def rpc(method,params):
  req=urllib.request.Request(url,json.dumps({'jsonrpc':'2.0','id':1,'method':method,'params':params}).encode(),{'Content-Type':'application/json'})
  body=json.load(urllib.request.urlopen(req,timeout=15))
  if body.get('error'):raise ValueError(str(body['error']))
  return body['result']
 try:
  try:rpc('eth_chainId',[])
  except OSError:pass
  else:raise ValueError('port already active; do not adopt an unknown node')
  with (out/'anvil.log').open('w') as log:node=subprocess.Popen(['anvil','--silent','--host','127.0.0.1','--port','8576','--chain-id','31338'],stdout=log,stderr=log)
  for _ in range(50):
   try:assert int(rpc('eth_chainId',[]),16)==31338;break
   except OSError:time.sleep(.1)
  else:raise ValueError('startup timeout')
  operator=rpc('eth_accounts',[])[0]
  registry=json.loads(command(['forge','create','--root','contracts','src/bridge/DevHeaderRegistry.sol:DevHeaderRegistry','--rpc-url',url,'--unlocked','--from',operator,'--broadcast','--json','--constructor-args','31337']))['deployedTo']
  code=rpc('eth_getCode',[registry,'latest']);(out/'registry-runtime.hex').write_text(code+'\n')
  report.update(registry=registry,runtimeCodeHash=command(['cast','keccak',code]),sourceSha256=hashlib.sha256((ROOT/'contracts/src/bridge/DevHeaderRegistry.sol').read_bytes()).hexdigest())
  start=1000
  for size in [1,4,16,32,64,128]:
   hashes=['0x'+hashlib.sha256(f'hash-{i}'.encode()).hexdigest() for i in range(start,start+size)]
   roots=['0x'+hashlib.sha256(f'root-{i}'.encode()).hexdigest() for i in range(start,start+size)]
   signature='registerHeaderBatch(uint256,bytes32[],bytes32[])';arguments=[str(start),'['+','.join(hashes)+']','['+','.join(roots)+']']
   data=command(['cast','calldata',signature,*arguments])
   receipt=json.loads(command(['cast','send',registry,'--data',data,'--rpc-url',url,'--unlocked','--from',operator,'--json']))
   if int(receipt['status'],16)!=1 or len(receipt['logs'])!=size:raise ValueError('not all synthetic headers registered')
   value=command(['cast','call',registry,'getReceiptRoot(uint256,uint256,bytes32)(bytes32)','31337',str(start+size-1),hashes[-1],'--rpc-url',url])
   if value.lower()!=roots[-1].lower():raise ValueError('last storage root differs')
   artifact=out/f'batch-{size}-receipt.json';artifact.write_text(json.dumps(receipt,indent=2)+'\n');(out/f'batch-{size}-calldata.hex').write_text(data+'\n')
   gas=int(receipt['gasUsed'],16)
   report['rows'].append({'batchSize':size,'startBlock':start,'gasUsed':gas,'gasPerHeader':gas/size,'calldataBytes':len(bytes.fromhex(data[2:])),'registeredEvents':len(receipt['logs']),'receiptSha256':hashlib.sha256(artifact.read_bytes()).hexdigest()})
   start+=size
  report['localVerdict']='PASS'
 except Exception as error:report['error']=str(error);raise
 finally:
  if node is not None and node.poll() is None:
   node.terminate()
   try:node.wait(timeout=10)
   except subprocess.TimeoutExpired:node.kill();node.wait(timeout=5)
  (out/'summary.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report['rows'],indent=2))
if __name__=='__main__':main()
