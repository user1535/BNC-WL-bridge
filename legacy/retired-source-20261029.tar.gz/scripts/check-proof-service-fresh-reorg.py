#!/usr/bin/env python3
"""Actual bounded proof followed by source event reorg, isolated local clone."""
import importlib.util,json,shutil,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('fresh_reorg_api',ROOT/'scripts/proof-service.py')
api=importlib.util.module_from_spec(spec);spec.loader.exec_module(api)
base=api.local.Session(ROOT/'results/prototype-header-steps');base.guard();base.stop()
out=ROOT/'results/prototype-fresh-reorg-fault';out.mkdir(exist_ok=False)
for name in ('session.json','wl-state.json','bnb-state.json','risc0-host'):shutil.copy2(base.root/name,out/name)
s=api.local.Session(out);s.start('risc0_batch','minimal-link')
service=None
try:
 snapshot=s.rpc('wl','evm_snapshot',[])
 # Separate explicit local test wallet action. Service only returns unsigned data.
 s.action('lock',0,10**18);event=s.data['events'][-1]
 s.rpc('wl','evm_mine',[]);s.rpc('wl','evm_mine',[])
 service=api.Service(out,confirmations=2,prove=True)
 request=dict(action='lock',transferId=event['id'],fromBlock=event['block'])
 identifier=service.submit(request)['id']
 for _ in range(300):
  files=list((out/'proof-jobs').glob(identifier+'-proof-*/proof/summary.json'))
  if files and json.loads(files[0].read_text())['workState']=='proving':break
  state=service.get(identifier)
  if state['state']=='failed':raise ValueError(state['detail'])
  time.sleep(.1)
 else:raise ValueError('actual prover did not start')
 assert s.rpc('wl','evm_revert',[snapshot]) is True
 print('source event reverted while actual capped Groth16 is proving',flush=True)
 for _ in range(1950):
  job=service.get(identifier)
  if job['state']=='failed':break
  if job['state'] in ('ready','header_ready'):raise ValueError('reorg proof was incorrectly deliverable')
  time.sleep(1)
 else:raise ValueError('bounded source reorg test timeout')
 proof=json.loads(files[0].read_text())
 assert proof['localVerdict']=='PASS' and proof['cryptographicallyReverified']
 try:service.get(identifier,True)
 except ValueError as e:assert 'not ready' in str(e)
 else:raise ValueError('stale package delivered')
 assert len(list((out/'proof-jobs').glob(identifier+'-proof-*')))==1
 report=dict(passed=True,actualFreshSdkGroth16=True,sourceEventRevertedDuringProving=True,jobState=job['state'],rejection=job['detail'],packageBlocked=True,newProofs=1,duplicateAttempts=0,serverBroadcasts=0,localTestWalletLockReverted=True,resources=proof['resources'],chainAuthenticated=False,realAssetDeploymentAllowed=False)
 (out/'summary.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
finally:
 if service:
  service.stop.set();service.worker.join(timeout=130)
 s.stop();base.start('risc0_batch','minimal-link')
