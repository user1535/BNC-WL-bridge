#!/usr/bin/env python3
"""Make an evidence-bound mode decision; never infer authentication from throughput."""
import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RESULTS = ROOT / "results"


def rows(name):
    with (RESULTS / f"header-{name}.csv").open(newline="") as file:
        return list(csv.DictReader(file))


def main():
    bnb = rows("bnb")
    worldland = rows("worldland")
    rate = json.loads((RESULTS / "bnb-rate/summary.json").read_text())
    for name, samples, expected_chain in (("bnb", bnb, 31338), ("worldland", worldland, 31337)):
        if not samples or any(
            int(row["chain_id"]) != expected_chain
            or row["receipt_kind"] != "composite"
            or row["verified"] != "True"
            or row["synthetic_input"] != "True"
            or int(row["end_block"]) - int(row["start_block"]) + 1 != int(row["batch_size"])
            for row in samples
        ):
            raise ValueError(f"{name} benchmark data does not match verified synthetic composite proofs")
    if rate.get("receipt_kind") != "composite" or rate.get("complete_five_minute_run") is not True:
        raise ValueError("rate result is not a complete five-minute composite proof run")
    bnb_best = max(float(row["headers_per_second"]) for row in bnb)
    worldland_best = max(float(row["headers_per_second"]) for row in worldland)
    required = 1 / rate["source_block_interval_s"]
    decision = {
        "worldland": {
            "measured_batch_sizes": [int(row["batch_size"]) for row in worldland],
            "required_batch_sizes": [1, 2, 4, 8, 16, 32, 64],
            "best_synthetic_headers_per_second": worldland_best,
            "official_reference_block_interval_s_as_of_2026_09_23": 10,
            "estimated_required_headers_per_second_at_official_reference_rate": 0.1,
            "official_reference_url": "https://docs.worldland.foundation/network/participants",
            "status": "INCOMPLETE",
            "header_mode": "dev-only",
            "reason": "Measured batches 1/2/4 are slower than the official 10-second reference; larger batches and an independently authenticated WorldLand finality policy are missing",
        },
        "bnb": {
            "measured_batch_sizes": [int(row["batch_size"]) for row in bnb],
            "required_batch_sizes": [1, 2, 4, 8, 16, 32, 64, 128],
            "best_synthetic_headers_per_second": bnb_best,
            "required_headers_per_second_at_local_rate": required,
            "official_reference_block_interval_s_as_of_2026_09_23": 0.45,
            "estimated_required_headers_per_second_at_official_reference_rate": 1 / 0.45,
            "official_reference_url": "https://docs.bnbchain.org/bnb-smart-chain/introduction/",
            "five_minute_lag": rate["ending_header_lag"],
            "five_minute_verdict": rate["verdict"],
            "status": "FAIL",
            "header_mode": "dev-only",
            "reason": "Proof throughput is below the local source rate; larger batches exceed safe memory budget; independent consensus/finality and on-chain acceptance are missing",
        },
        "real_asset_deployment_allowed": False,
    }
    target = RESULTS / "header-mode-decision.json"
    target.write_text(json.dumps(decision, indent=2) + "\n")
    print(target)
    print(f"BNB-like required {required:.3f} headers/s; best measured synthetic batch {bnb_best:.3f} headers/s; live mode unavailable")


if __name__ == "__main__":
    main()
