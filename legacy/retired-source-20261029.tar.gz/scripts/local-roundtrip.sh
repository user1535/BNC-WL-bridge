#!/usr/bin/env bash
set -euo pipefail
ROUNDTRIP_STARTED="$EPOCHREALTIME"

# DEV ONLY. Two ephemeral Anvil chains, real receipt MPT, trusted local headers.
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
HEADER_MODE="${HEADER_MODE:-dev}"
case "$HEADER_MODE" in
    dev) ;;
    risc0_composite)
        RISC0_HOST="$ROOT_DIR/risc0/target/release/bridge-header-benchmark"
        [[ -x "$RISC0_HOST" ]] || { echo "Build the RISC0 host first" >&2; exit 1; }
        export RISC0_SERVER_PATH="${RISC0_SERVER_PATH:-$HOME/.cargo/bin/r0vm}"
        ;;
    *) echo "local-roundtrip supports dev or risc0_composite; use run-local.sh zk for Groth16" >&2; exit 2 ;;
esac
WORLDLAND_RPC="http://127.0.0.1:8545"
BNB_RPC="http://127.0.0.1:8546"
if cast chain-id --rpc-url "$WORLDLAND_RPC" >/dev/null 2>&1 || cast chain-id --rpc-url "$BNB_RPC" >/dev/null 2>&1; then
    echo "Ports 8545 or 8546 are already in use; refusing to reuse an unknown chain." >&2
    exit 1
fi
FAST_RESULT_DIR="${FAST_RESULT_DIR:-$ROOT_DIR/results/local-fast-$(date -u +%Y%m%dT%H%M%SZ)-$$}"
[[ ! -e "$FAST_RESULT_DIR" ]] || { echo "Existing evidence preserved; choose a new FAST_RESULT_DIR" >&2; exit 1; }
mkdir -p "$FAST_RESULT_DIR"
HEADER_WORK="$(mktemp -d)"
anvil --silent --host 127.0.0.1 --port 8545 --chain-id 31337 >"$ROOT_DIR/.anvil-worldland.log" 2>&1 &
WORLDLAND_PID=$!
anvil --silent --host 127.0.0.1 --port 8546 --chain-id 31338 >"$ROOT_DIR/.anvil-bnb.log" 2>&1 &
BNB_PID=$!
cleanup() {
    kill "$WORLDLAND_PID" "$BNB_PID" 2>/dev/null || true
    wait "$WORLDLAND_PID" "$BNB_PID" 2>/dev/null || true
    [[ -z "${LOCK_PACKAGE:-}" ]] || rm -f "$LOCK_PACKAGE"
    [[ -z "${BURN_PACKAGE:-}" ]] || rm -f "$BURN_PACKAGE"
    [[ -z "${COVERED_LOCK_PACKAGE:-}" ]] || rm -f "$COVERED_LOCK_PACKAGE"
    [[ -z "${COVERED_BURN_PACKAGE:-}" ]] || rm -f "$COVERED_BURN_PACKAGE"
    rm -rf "$HEADER_WORK"
}
trap cleanup EXIT
for _ in $(seq 1 50); do
    if cast chain-id --rpc-url "$WORLDLAND_RPC" >/dev/null 2>&1 && cast chain-id --rpc-url "$BNB_RPC" >/dev/null 2>&1; then break; fi
    sleep 0.2
done
[[ "$(cast chain-id --rpc-url "$WORLDLAND_RPC")" == "31337" ]]
[[ "$(cast chain-id --rpc-url "$BNB_RPC")" == "31338" ]]
DEV_ADDRESS="$(cast rpc eth_accounts --rpc-url "$WORLDLAND_RPC" | python3 -c 'import json,sys; print(json.load(sys.stdin)[0])')"
OTHER_ADDRESS="$(cast rpc eth_accounts --rpc-url "$BNB_RPC" | python3 -c 'import json,sys; print(json.load(sys.stdin)[1])')"
WALLET_JSON="$(cast wallet new --json)"
USER_ADDRESS="$(printf '%s' "$WALLET_JSON" | python3 -c 'import json,sys; print(json.load(sys.stdin)[0]["address"])')"
USER_KEY="$(printf '%s' "$WALLET_JSON" | python3 -c 'import json,sys; print(json.load(sys.stdin)[0]["private_key"])')"
unset WALLET_JSON
AMOUNT=25000000000000000000
INITIAL=100000000000000000000
LOCK_PREFIX_FILLERS="${LOCK_PREFIX_FILLERS:-1}"
LOCK_SUFFIX_FILLERS="${LOCK_SUFFIX_FILLERS:-0}"
FRONTRUN_CLAIMS="${FRONTRUN_CLAIMS:-0}"
[[ "$LOCK_PREFIX_FILLERS" =~ ^[0-9]+$ && "$LOCK_SUFFIX_FILLERS" =~ ^[0-9]+$ ]]
[[ "$LOCK_PREFIX_FILLERS" -ge 1 && "$LOCK_PREFIX_FILLERS" -le 100 && "$LOCK_SUFFIX_FILLERS" -le 100 ]]
mkdir -p "$ROOT_DIR/.bin"
go -C "$ROOT_DIR/proof-generator" build -o "$ROOT_DIR/.bin/bridge-proof" ./cmd/bridge-proof
if [[ "$HEADER_MODE" == "risc0_composite" ]]; then
    go -C "$ROOT_DIR/proof-generator" build -o "$ROOT_DIR/.bin/bridge-header-data" ./cmd/bridge-header-data
fi

deploy() {
    local rpc="$1" contract="$2"
    shift 2
    forge create --root "$ROOT_DIR/contracts" "$contract" --rpc-url "$rpc" \
        --unlocked --from "$DEV_ADDRESS" --broadcast --json --constructor-args "$@" \
        | python3 -c 'import json,sys; print(json.load(sys.stdin)["deployedTo"])'
}
send_tx() {
    local rpc="$1" sender="$2" contract="$3" signature="$4"
    shift 4
    local transaction_started="$EPOCHREALTIME"
    if [[ "$sender" == "$USER_ADDRESS" ]]; then
        cast send "$contract" "$signature" "$@" --rpc-url "$rpc" --private-key "$USER_KEY" --json
    else
        cast send "$contract" "$signature" "$@" --rpc-url "$rpc" --unlocked --from "$sender" --json
    fi
    if [[ "$signature" == 'registerHeader(uint256,bytes32,bytes32)' ]]; then
        local transaction_finished="$EPOCHREALTIME"
        python3 - "$FAST_RESULT_DIR/header-timing.jsonl" "$transaction_started" "$transaction_finished" "$rpc" "$contract" <<'PYTIME'
import json,sys
from decimal import Decimal
from pathlib import Path
row={'rpc':sys.argv[4], 'registry':sys.argv[5],
     'wallSeconds':float(Decimal(sys.argv[3])-Decimal(sys.argv[2])),
     'scope':'cast send registerHeader through mined receipt; local automine; excludes package preparation and native authentication'}
with Path(sys.argv[1]).open('a') as output: output.write(json.dumps(row)+'\n')
PYTIME
    fi
}
event_id() {
    python3 -c 'import json,sys; print(json.load(sys.stdin)["logs"][-1]["topics"][1])'
}
package_field() {
    python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))[sys.argv[2]])' "$1" "$2"
}
call_uint() {
    local rpc="$1" contract="$2" signature="$3"
    shift 3
    cast call "$contract" "$signature" "$@" --rpc-url "$rpc" | cut -d' ' -f1
}

ORIGINAL="$(deploy "$WORLDLAND_RPC" src/token/BridgeLockableToken.sol:BridgeLockableToken "WorldLand local" WL "$INITIAL" 31338)"
WRAPPED="$(deploy "$BNB_RPC" src/token/BridgeWrappedToken.sol:BridgeWrappedToken "Wrapped WorldLand local" wWL 31337 "$ORIGINAL")"
send_tx "$WORLDLAND_RPC" "$DEV_ADDRESS" "$ORIGINAL" 'bindDestinationWrappedToken(address)' "$WRAPPED" >/dev/null
BNB_HEADERS="$(deploy "$BNB_RPC" src/bridge/DevHeaderRegistry.sol:DevHeaderRegistry 31337)"
WORLDLAND_HEADERS="$(deploy "$WORLDLAND_RPC" src/bridge/DevHeaderRegistry.sol:DevHeaderRegistry 31338)"
MINT_RECEIVER="$(deploy "$BNB_RPC" src/bridge/LockMintReceiver.sol:LockMintReceiver "$WRAPPED" "$BNB_HEADERS")"
UNLOCK_RECEIVER="$(deploy "$WORLDLAND_RPC" src/bridge/BurnUnlockReceiver.sol:BurnUnlockReceiver "$ORIGINAL" "$WORLDLAND_HEADERS" "$WRAPPED")"
send_tx "$BNB_RPC" "$DEV_ADDRESS" "$WRAPPED" 'bindMintReceiver(address)' "$MINT_RECEIVER" >/dev/null
send_tx "$WORLDLAND_RPC" "$DEV_ADDRESS" "$ORIGINAL" 'bindUnlockReceiver(address)' "$UNLOCK_RECEIVER" >/dev/null

# Fund an ephemeral user wallet on both chains. Only this wallet signs bridge actions.
cast send "$USER_ADDRESS" --value 1ether --rpc-url "$WORLDLAND_RPC" --unlocked --from "$DEV_ADDRESS" >/dev/null
cast send "$USER_ADDRESS" --value 1ether --rpc-url "$BNB_RPC" --unlocked --from "$DEV_ADDRESS" >/dev/null
USER_WL_GAS_START="$(cast balance "$USER_ADDRESS" --rpc-url "$WORLDLAND_RPC")"
USER_BNB_GAS_START="$(cast balance "$USER_ADDRESS" --rpc-url "$BNB_RPC")"
send_tx "$WORLDLAND_RPC" "$DEV_ADDRESS" "$ORIGINAL" 'transfer(address,uint256)' "$USER_ADDRESS" "$INITIAL" >/dev/null
# Put a filler transaction before the lock in one block to exercise txIndex > 0.
NEXT_NONCE="$(cast nonce "$USER_ADDRESS" --rpc-url "$WORLDLAND_RPC")"
cast rpc anvil_setAutomine false --rpc-url "$WORLDLAND_RPC" >/dev/null
for ((i=0; i<LOCK_PREFIX_FILLERS; i++)); do
    cast send "$OTHER_ADDRESS" --value 1wei --rpc-url "$WORLDLAND_RPC" --private-key "$USER_KEY" --nonce "$((NEXT_NONCE + i))" --async >/dev/null
done
LOCK_TX="$(cast send "$ORIGINAL" 'bridgeLock(uint256,address,uint256)' "$AMOUNT" "$USER_ADDRESS" 31338 --rpc-url "$WORLDLAND_RPC" --private-key "$USER_KEY" --nonce "$((NEXT_NONCE + LOCK_PREFIX_FILLERS))" --async)"
for ((i=0; i<LOCK_SUFFIX_FILLERS; i++)); do
    cast send "$OTHER_ADDRESS" --value 1wei --rpc-url "$WORLDLAND_RPC" --private-key "$USER_KEY" --nonce "$((NEXT_NONCE + LOCK_PREFIX_FILLERS + 1 + i))" --async >/dev/null
done
cast rpc anvil_mine 1 --rpc-url "$WORLDLAND_RPC" >/dev/null
cast rpc anvil_setAutomine true --rpc-url "$WORLDLAND_RPC" >/dev/null
LOCK_ID="$(cast receipt "$LOCK_TX" --rpc-url "$WORLDLAND_RPC" --json | event_id)"
LOCK_PACKAGE="$(mktemp)"
"$ROOT_DIR/.bin/bridge-proof" --rpc "$WORLDLAND_RPC" --token "$ORIGINAL" --destination-token "$WRAPPED" --id "$LOCK_ID" --action lock --chain-id 31337 --destination-rpc "$BNB_RPC" --header-source "$BNB_HEADERS" >"$LOCK_PACKAGE"
[[ "$(package_field "$LOCK_PACKAGE" headerCovered)" == "False" ]]
[[ "$(package_field "$LOCK_PACKAGE" coverageChecked)" == "True" ]]
if WRONG_DESTINATION_ERROR="$("$ROOT_DIR/.bin/bridge-proof" --rpc "$WORLDLAND_RPC" --token "$ORIGINAL" --destination-token "$WRAPPED" --id "$LOCK_ID" --action lock --chain-id 31337 --destination-rpc "$WORLDLAND_RPC" --header-source "$BNB_HEADERS" 2>&1)"; then
    echo "Proof generator accepted the wrong destination chain" >&2; exit 1
fi
[[ "$WRONG_DESTINATION_ERROR" == *"destination RPC chain ID"* ]]
[[ "$(package_field "$LOCK_PACKAGE" txIndex)" == "$LOCK_PREFIX_FILLERS" ]]
[[ "$(package_field "$LOCK_PACKAGE" receiptCount)" == "$((LOCK_PREFIX_FILLERS + LOCK_SUFFIX_FILLERS + 1))" ]]
if [[ "$HEADER_MODE" == "risc0_composite" ]]; then
    LOCK_HEIGHT="$(package_field "$LOCK_PACKAGE" blockNumber)"
    "$ROOT_DIR/.bin/bridge-header-data" --rpc "$WORLDLAND_RPC" --chain-id 31337 --start "$LOCK_HEIGHT" --count 1 \
        --risc0-host "$RISC0_HOST" --proof-cache "$HEADER_WORK/cache" >"$HEADER_WORK/lock-header.json"
    "$ROOT_DIR/.bin/bridge-proof" --rpc "$WORLDLAND_RPC" --token "$ORIGINAL" --destination-token "$WRAPPED" --id "$LOCK_ID" --action lock --chain-id 31337 \
        --destination-rpc "$BNB_RPC" --header-source "$BNB_HEADERS" --receiver "$MINT_RECEIVER" --header-mode risc0_composite \
        --risc0-host "$RISC0_HOST" --header-package "$HEADER_WORK/lock-header.json" >"$LOCK_PACKAGE"
    [[ "$(package_field "$LOCK_PACKAGE" headerMode)" == "risc0_composite" ]]
fi
send_tx "$BNB_RPC" "$DEV_ADDRESS" "$BNB_HEADERS" 'registerHeader(uint256,bytes32,bytes32)' \
    "$(package_field "$LOCK_PACKAGE" blockNumber)" "$(package_field "$LOCK_PACKAGE" blockHash)" "$(package_field "$LOCK_PACKAGE" receiptRoot)" >/dev/null
WRONG_HEADERS="$(deploy "$BNB_RPC" src/bridge/DevHeaderRegistry.sol:DevHeaderRegistry 31337)"
WRONG_ROOT="$(python3 -c 'print("0x" + "00" * 31 + "01")')"
send_tx "$BNB_RPC" "$DEV_ADDRESS" "$WRONG_HEADERS" 'registerHeader(uint256,bytes32,bytes32)' \
    "$(package_field "$LOCK_PACKAGE" blockNumber)" "$(package_field "$LOCK_PACKAGE" blockHash)" "$WRONG_ROOT" >/dev/null
if WRONG_ROOT_ERROR="$("$ROOT_DIR/.bin/bridge-proof" --rpc "$WORLDLAND_RPC" --token "$ORIGINAL" --destination-token "$WRAPPED" --id "$LOCK_ID" --action lock --chain-id 31337 --destination-rpc "$BNB_RPC" --header-source "$WRONG_HEADERS" 2>&1)"; then
    echo "Proof generator accepted a destination receipt root mismatch" >&2; exit 1
fi
[[ "$WRONG_ROOT_ERROR" == *"destination receipt root"* ]]
COVERED_LOCK_PACKAGE="$(mktemp)"
"$ROOT_DIR/.bin/bridge-proof" --rpc "$WORLDLAND_RPC" --token "$ORIGINAL" --destination-token "$WRAPPED" --id "$LOCK_ID" --action lock --chain-id 31337 --from-block "$(package_field "$LOCK_PACKAGE" blockNumber)" --destination-rpc "$BNB_RPC" --header-source "$BNB_HEADERS" >"$COVERED_LOCK_PACKAGE"
[[ "$(package_field "$COVERED_LOCK_PACKAGE" headerCovered)" == "True" ]]
[[ "$(package_field "$COVERED_LOCK_PACKAGE" coverageChecked)" == "True" ]]
[[ "$(package_field "$COVERED_LOCK_PACKAGE" calldata)" == "$(package_field "$LOCK_PACKAGE" calldata)" ]]
LOCK_CALLDATA="$(package_field "$LOCK_PACKAGE" calldata)"
# The same source lock must not mint a second wrapped token on the same destination chain.
CLONE_WRAPPED="$(deploy "$BNB_RPC" src/token/BridgeWrappedToken.sol:BridgeWrappedToken "Clone WorldLand local" cloneWL 31337 "$ORIGINAL")"
if CLONE_PACKAGE_ERROR="$("$ROOT_DIR/.bin/bridge-proof" --rpc "$WORLDLAND_RPC" --token "$ORIGINAL" --destination-token "$CLONE_WRAPPED" --id "$LOCK_ID" --action lock --chain-id 31337 2>&1)"; then
    echo "Proof generator accepted the cloned destination token" >&2; exit 1
fi
[[ "$CLONE_PACKAGE_ERROR" == *"bridge event ID mismatch"* ]]
CLONE_RECEIVER="$(deploy "$BNB_RPC" src/bridge/LockMintReceiver.sol:LockMintReceiver "$CLONE_WRAPPED" "$BNB_HEADERS")"
send_tx "$BNB_RPC" "$DEV_ADDRESS" "$CLONE_WRAPPED" 'bindMintReceiver(address)' "$CLONE_RECEIVER" >/dev/null
if cast call "$CLONE_RECEIVER" --data "$LOCK_CALLDATA" --rpc-url "$BNB_RPC" >/dev/null 2>&1; then
    echo "One source lock minted a second wrapped token" >&2; exit 1
fi
[[ "$(call_uint "$BNB_RPC" "$CLONE_WRAPPED" 'balanceOf(address)(uint256)' "$USER_ADDRESS")" == "0" ]]
TAMPERED_LOCK_CALLDATA="$(python3 -c 'import sys; b=bytearray.fromhex(sys.argv[1][2:]); b[4+32+32+32+31] ^= 1; print("0x"+b.hex())' "$LOCK_CALLDATA")"
if cast call "$MINT_RECEIVER" --data "$TAMPERED_LOCK_CALLDATA" --rpc-url "$BNB_RPC" >/dev/null 2>&1; then
    echo "Tampered lock receipt proof was accepted" >&2; exit 1
fi
if [[ "$FRONTRUN_CLAIMS" == "1" ]]; then
    cast send "$MINT_RECEIVER" --data "$LOCK_CALLDATA" --rpc-url "$BNB_RPC" --unlocked --from "$OTHER_ADDRESS" --json >/dev/null
else
    cast send "$MINT_RECEIVER" --data "$LOCK_CALLDATA" --rpc-url "$BNB_RPC" --private-key "$USER_KEY" --json >/dev/null
fi
if cast call "$MINT_RECEIVER" --data "$LOCK_CALLDATA" --rpc-url "$BNB_RPC" >/dev/null 2>&1; then
    echo "Lock replay was accepted" >&2; exit 1
fi
[[ "$(call_uint "$BNB_RPC" "$WRAPPED" 'balanceOf(address)(uint256)' "$USER_ADDRESS")" == "$AMOUNT" ]]
[[ "$(call_uint "$BNB_RPC" "$WRAPPED" 'balanceOf(address)(uint256)' "$OTHER_ADDRESS")" == "0" ]]

BURN_ID="$(send_tx "$BNB_RPC" "$USER_ADDRESS" "$WRAPPED" 'bridgeBurn(uint256,address,uint256)' "$AMOUNT" "$USER_ADDRESS" 31337 | event_id)"
BURN_PACKAGE="$(mktemp)"
"$ROOT_DIR/.bin/bridge-proof" --rpc "$BNB_RPC" --token "$WRAPPED" --destination-token "$ORIGINAL" --id "$BURN_ID" --action burn --chain-id 31338 --destination-rpc "$WORLDLAND_RPC" --header-source "$WORLDLAND_HEADERS" >"$BURN_PACKAGE"
[[ "$(package_field "$BURN_PACKAGE" headerCovered)" == "False" ]]
if [[ "$HEADER_MODE" == "risc0_composite" ]]; then
    BURN_HEIGHT="$(package_field "$BURN_PACKAGE" blockNumber)"
    "$ROOT_DIR/.bin/bridge-header-data" --rpc "$BNB_RPC" --chain-id 31338 --start "$BURN_HEIGHT" --count 1 \
        --risc0-host "$RISC0_HOST" --proof-cache "$HEADER_WORK/cache" >"$HEADER_WORK/burn-header.json"
    "$ROOT_DIR/.bin/bridge-proof" --rpc "$BNB_RPC" --token "$WRAPPED" --destination-token "$ORIGINAL" --id "$BURN_ID" --action burn --chain-id 31338 \
        --destination-rpc "$WORLDLAND_RPC" --header-source "$WORLDLAND_HEADERS" --receiver "$UNLOCK_RECEIVER" --header-mode risc0_composite \
        --risc0-host "$RISC0_HOST" --header-package "$HEADER_WORK/burn-header.json" >"$BURN_PACKAGE"
fi
send_tx "$WORLDLAND_RPC" "$DEV_ADDRESS" "$WORLDLAND_HEADERS" 'registerHeader(uint256,bytes32,bytes32)' \
    "$(package_field "$BURN_PACKAGE" blockNumber)" "$(package_field "$BURN_PACKAGE" blockHash)" "$(package_field "$BURN_PACKAGE" receiptRoot)" >/dev/null
COVERED_BURN_PACKAGE="$(mktemp)"
"$ROOT_DIR/.bin/bridge-proof" --rpc "$BNB_RPC" --token "$WRAPPED" --destination-token "$ORIGINAL" --id "$BURN_ID" --action burn --chain-id 31338 --destination-rpc "$WORLDLAND_RPC" --header-source "$WORLDLAND_HEADERS" >"$COVERED_BURN_PACKAGE"
[[ "$(package_field "$COVERED_BURN_PACKAGE" headerCovered)" == "True" ]]
[[ "$(package_field "$COVERED_BURN_PACKAGE" calldata)" == "$(package_field "$BURN_PACKAGE" calldata)" ]]
BURN_CALLDATA="$(package_field "$BURN_PACKAGE" calldata)"
if [[ "$FRONTRUN_CLAIMS" == "1" ]]; then
    cast send "$UNLOCK_RECEIVER" --data "$BURN_CALLDATA" --rpc-url "$WORLDLAND_RPC" --unlocked --from "$OTHER_ADDRESS" --json >/dev/null
else
    cast send "$UNLOCK_RECEIVER" --data "$BURN_CALLDATA" --rpc-url "$WORLDLAND_RPC" --private-key "$USER_KEY" --json >/dev/null
fi
if cast call "$UNLOCK_RECEIVER" --data "$BURN_CALLDATA" --rpc-url "$WORLDLAND_RPC" >/dev/null 2>&1; then
    echo "Burn replay was accepted" >&2; exit 1
fi
[[ "$(call_uint "$WORLDLAND_RPC" "$ORIGINAL" 'balanceOf(address)(uint256)' "$USER_ADDRESS")" == "$INITIAL" ]]
[[ "$(call_uint "$WORLDLAND_RPC" "$ORIGINAL" 'lockedBalanceOf(address)(uint256)' "$USER_ADDRESS")" == "0" ]]
[[ "$(call_uint "$BNB_RPC" "$WRAPPED" 'totalSupply()(uint256)')" == "0" ]]
USER_WL_GAS_END="$(cast balance "$USER_ADDRESS" --rpc-url "$WORLDLAND_RPC")"
USER_BNB_GAS_END="$(cast balance "$USER_ADDRESS" --rpc-url "$BNB_RPC")"
[[ "$USER_WL_GAS_END" -lt "$USER_WL_GAS_START" ]]
[[ "$USER_BNB_GAS_END" -lt "$USER_BNB_GAS_START" ]]
echo "WorldLand-local balance: initial = final = $INITIAL"
echo "lockedBalance: 0; BNB Smart Chain-local wrapped supply: 0"
echo "lock/mint/burn/unlock: success"
echo "cross-token lock replay: rejected for a second wrapped token"
echo "receipt MPT: verified; txIndex=$(package_field "$LOCK_PACKAGE" txIndex); receiptCount=$(package_field "$LOCK_PACKAGE" receiptCount); tamper and replay rejected"
echo "header mode: $HEADER_MODE; read-only coverage changed from false to true; mismatched destination receipt root rejected"
if [[ "$HEADER_MODE" == "risc0_composite" ]]; then echo "off-chain RISC0 composite verification: both directions; EVM header registration: dev operator"; fi
if [[ "${BRIDGE_FORCE_PER_TX_RECEIPTS:-0}" == "1" ]]; then echo "receipt retrieval: per-transaction fallback"; fi
echo "proof generator: no private key; bridge action signer: ephemeral user wallet"
echo "user native gas spent on both chains: yes"
if [[ "$FRONTRUN_CLAIMS" == "1" ]]; then echo "claim submitter: third-party account; recipient remains original user"; fi
cp "$LOCK_PACKAGE" "$FAST_RESULT_DIR/lock-package.json"
cp "$BURN_PACKAGE" "$FAST_RESULT_DIR/burn-package.json"
cp "$COVERED_LOCK_PACKAGE" "$FAST_RESULT_DIR/lock-covered.json"
cp "$COVERED_BURN_PACKAGE" "$FAST_RESULT_DIR/burn-covered.json"
cp "$ROOT_DIR/.anvil-worldland.log" "$FAST_RESULT_DIR/worldland-anvil.log"
cp "$ROOT_DIR/.anvil-bnb.log" "$FAST_RESULT_DIR/bnb-anvil.log"
if [[ "$HEADER_MODE" == "risc0_composite" ]]; then
    cp "$HEADER_WORK/lock-header.json" "$FAST_RESULT_DIR/lock-header.json"
    cp "$HEADER_WORK/burn-header.json" "$FAST_RESULT_DIR/burn-header.json"
fi
python3 - "$FAST_RESULT_DIR" "$HEADER_MODE" "$INITIAL" "$FRONTRUN_CLAIMS" "$ROUNDTRIP_STARTED" "$EPOCHREALTIME" "$BNB_HEADERS" "$WORLDLAND_HEADERS" <<'PY'
import json,sys
from pathlib import Path
directory=Path(sys.argv[1]); package=json.loads((directory/'lock-package.json').read_text())
summary={'headerMode':sys.argv[2], 'mptRoundtrip':True, 'initialOriginal':sys.argv[3], 'finalOriginal':sys.argv[3],
         'finalLocked':'0', 'finalWrappedSupply':'0', 'lockTxIndex':package['txIndex'], 'lockReceiptCount':package['receiptCount'],
         'claimSubmitter':'third-party' if sys.argv[4]=='1' else 'user', 'chainAuthenticated':False,
         'realAssetDeploymentAllowed':False, 'realGroth16EvmAcceptance':False, 'privateKeySaved':False}
from decimal import Decimal
rows=[json.loads(line) for line in (directory/'header-timing.jsonl').read_text().splitlines()]
for row in rows:
    row['kind']='lock' if row['registry']==sys.argv[7] else 'burn' if row['registry']==sys.argv[8] else 'wrong-root-control'
summary['timing']={'fullScriptWallSeconds':float(Decimal(sys.argv[6])-Decimal(sys.argv[5])),
                   'fullScriptScope':'local node startup, cached Go build, deployments, lock/mint/burn/unlock and negative checks; excludes source finality wait',
                   'headers':rows, 'nativeAuthenticationLatencyMeasured':False,
                   'productionThroughputMeasured':False, 'sampleCountPerDirection':1}
(directory/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
PY
echo "Evidence: $FAST_RESULT_DIR"
