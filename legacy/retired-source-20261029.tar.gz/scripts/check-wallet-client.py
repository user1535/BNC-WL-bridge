#!/usr/bin/env python3
"""Actual browser UI and local EVM roundtrip; controlled test provider, not an extension."""
import argparse,importlib.util,json,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
NODE=Path('/mnt/c/Users/yebeen/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe')
spec=importlib.util.spec_from_file_location('local_session',ROOT/'scripts/local-session.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--session',type=Path,default=ROOT/'results/wallet-client-fast');args=parser.parse_args()
 session=module.Session(args.session);session.guard()
 if session.data['mode']!='dev' or session.data['events']:raise ValueError('fresh ready dev session required')
 report={'localVerdict':'FAIL','externalExtensionTested':False,'testWallet':'controlled EIP-1193 provider backed by unlocked Anvil account','risc0Used':False,'chainAuthenticated':False,'realAssetDeploymentAllowed':False}
 try:
  for phase in ('lock','mint','burn','unlock'):
   subprocess.run([str(NODE),'scripts/check-wallet-browser.mjs',str(session.root.relative_to(ROOT)),phase],cwd=ROOT,check=True,timeout=120)
   if phase in ('lock','burn'):
    receipt=json.loads((session.root/(phase+'-receipt.json')).read_text());log=receipt['logs'][-1]
    event={'action':phase,'id':log['topics'][1],'block':int(receipt['blockNumber'],16),'user':session.data['users'][0],'tx_hash':receipt['transactionHash'],'walletClient':'browser test provider'}
    session.data['events'].append(event);session.save();session.headers(event)
    package=session.package(event);module.write_json(session.root/(phase+'-package.json'),package)
  user=session.data['users'][0];contracts=session.data['contracts']
  original=int(session.view('wl',contracts['original'],'balanceOf(address)(uint256)',user))
  locked=int(session.view('wl',contracts['original'],'lockedBalanceOf(address)(uint256)',user))
  wrapped=int(session.view('bnb',contracts['wrapped'],'balanceOf(address)(uint256)',user))
  assert original==100*10**18 and locked==0 and wrapped==0
  report.update(localVerdict='PASS',browserPhases=4,reloadPendingRecovery=True,userWalletRequests=4,finalOriginal=str(original),finalLocked=str(locked),finalWrapped=str(wrapped))
 except Exception as error:report['error']=str(error);raise
 finally:
  module.write_json(session.root/'wallet-summary.json',report);session.stop()
if __name__=='__main__':main()
