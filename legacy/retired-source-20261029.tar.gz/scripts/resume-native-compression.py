#!/usr/bin/env python3
"""Recover saved SDK recursion output with real gnark compression and verification."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import threading
import time

ROOT=Path(__file__).resolve().parents[1]


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    obj=importlib.util.module_from_spec(spec);spec.loader.exec_module(obj);return obj


def main():
    def interrupted(signum,frame):raise KeyboardInterrupt('compression interrupted')
    signal.signal(signal.SIGTERM,interrupted)
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--failed-dir',type=Path,required=True)
    parser.add_argument('--composite-dir',type=Path,required=True)
    parser.add_argument('--host',type=Path,default=ROOT/'risc0/target/release/bridge-native-header-host')
    parser.add_argument('--output-dir',type=Path,required=True)
    parser.add_argument('--threads',type=int,default=4)
    parser.add_argument('--memory-fraction',type=float,default=.6)
    parser.add_argument('--go-memory-limit',choices=('3GiB','4GiB','5GiB','6GiB'),default='5GiB')
    parser.add_argument('--gogc',type=int,default=50)
    args=parser.parse_args()
    if not .4<=args.memory_fraction<=.7 or not 1<=args.threads<=(os.cpu_count() or 1) or not 25<=args.gogc<=100:parser.error('invalid CPU/RAM/GC bounds')
    monitor=module('native_monitor',ROOT/'scripts/benchmark-header.py');native=module('native_runner',ROOT/'scripts/run-native-proof.py')
    out=args.output_dir.resolve();out.mkdir(parents=True,exist_ok=False)
    failed=args.failed_dir.resolve();composite=args.composite_dir.resolve()
    old=json.loads((failed/'summary.json').read_text());original=json.loads((composite/'summary.json').read_text())
    if old['imageId']!=original['imageId'] or old['inputSHA256']!=original['inputSHA256'] or original['localVerdict']!='PASS':
        raise ValueError('failed SDK input and verified composite evidence do not match')
    host=out/'native-host';shutil.copy2(args.host,host)
    proof_input=out/'composite.json';shutil.copy2(composite/'receipt.json',proof_input)
    env=dict(os.environ,RISC0_DEV_MODE='0',RISC0_PROVER='ipc')
    checked=json.loads(subprocess.check_output([host,'--verify-receipt',proof_input],env=env,text=True,timeout=120))
    if checked['imageId']!=old['imageId'] or checked['receiptKind']!='composite' or checked['chainAuthenticated'] is not False:
        raise ValueError('new host does not verify the saved native image/journal')
    digests=json.loads(subprocess.check_output(['docker','image','inspect','--format','{{json .RepoDigests}}',native.DOCKER_IMAGE],text=True,timeout=15))
    if not any(d.endswith('@'+native.DOCKER_DIGEST) for d in digests):raise ValueError('compressor digest mismatch')
    memory=os.sysconf('SC_PHYS_PAGES')*os.sysconf('SC_PAGE_SIZE')
    scope=native.docker_scope(out,env,int(memory*args.memory_fraction),args.threads,args.go_memory_limit,args.gogc)
    for name in ('input.json','seal.r0'):shutil.copy2(failed/'docker-scope'/name,Path(scope['scope'])/name)
    report={'measuredAt':datetime.now(timezone.utc).isoformat(),'localVerdict':'FAIL','workState':'compressing',
        'imageId':old['imageId'],'sourceChainId':checked['sourceChainId'],'headerBinding':'native-rlp',
        'savedRecursionSHA256':sha(Path(scope['scope'])/'seal.r0'),'savedProverInputSHA256':sha(Path(scope['scope'])/'input.json'),
        'compositeSHA256':sha(proof_input),'hostSHA256':sha(host),'dockerScope':scope,'dockerDigest':native.DOCKER_DIGEST,
        'newZkVmExecution':False,'newStarkProving':False,'newGroth16Proving':True,'recoveryOfFailedSDKCompression':True,
        'evmAcceptanceMeasured':False,'chainAuthenticated':False,'realAssetDeploymentAllowed':False,
        'dockerMemorySamples':[],'dockerPeakMemoryBytes':0}
    stop=threading.Event();sampler=None

    def sample_memory():
        while not stop.wait(1):
            try:
                cid=Path(scope['cid']).read_text().strip()
                if len(cid)!=64 or any(c not in '0123456789abcdef' for c in cid):continue
                result=subprocess.run([scope['docker'],'stats','--no-stream','--format','{{.MemUsage}}',cid],capture_output=True,text=True,timeout=5)
                if result.returncode:continue
                usage=result.stdout.strip();match=re.match(r'([0-9.]+)([KMGT]?i?B)',usage)
                if not match:continue
                unit=match[2];powers={'B':0,'kB':1,'KB':1,'KiB':1,'MB':2,'MiB':2,'GB':3,'GiB':3,'TB':4,'TiB':4}
                value=int(float(match[1])*(1024 if 'i' in unit else 1000)**powers[unit])
                report['dockerMemorySamples'].append({'time':time.time(),'usage':usage,'memoryBytes':value})
                report['dockerPeakMemoryBytes']=max(report['dockerPeakMemoryBytes'],value)
            except (OSError,ValueError,KeyError,subprocess.TimeoutExpired):pass

    try:
        (out/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
        sampler=threading.Thread(target=sample_memory,daemon=True);sampler.start()
        command=['docker','run','--rm','-v',scope['scope']+':/mnt',native.DOCKER_IMAGE]
        result,resources=monitor.run_with_memory_limit(command,env,int(memory*.7)//1024,600)
        (out/'compress.stdout.txt').write_text(result.stdout);(out/'compress.stderr.txt').write_text(result.stderr)
        report.update(exitCode=result.returncode,compressionResources=resources)
        if result.returncode:raise RuntimeError(f'gnark compression failed: {result.returncode}')
        proof_json=Path(scope['scope'])/'proof.json';receipt=out/'receipt.json'
        wrap=subprocess.run([host,'--wrap-groth16','--composite',proof_input,'--proof-json',proof_json,'--receipt-output',receipt],env=env,text=True,capture_output=True,timeout=120)
        (out/'wrap.stdout.json').write_text(wrap.stdout);(out/'wrap.stderr.txt').write_text(wrap.stderr)
        if wrap.returncode:raise RuntimeError('SDK Groth16 assembly/crypto verification failed')
        verified=json.loads(subprocess.check_output([host,'--verify-receipt',receipt],env=env,text=True,timeout=120))
        if (verified['receiptKind']!='groth16' or verified['imageId']!=old['imageId'] or verified['journal']!=checked['journal']
            or verified['verified'] is not True or verified['evmCompatible'] is not True or verified['chainAuthenticated'] is not False):
            raise ValueError('recovered Groth16 predicate/image/journal mismatch')
        (out/'verified.stdout.json').write_text(json.dumps(verified,indent=2)+'\n')
        report.update(localVerdict='PASS',workState='complete',proof=verified,cryptographicallyReverified=True,
                      receiptSHA256=sha(receipt),proofJsonSHA256=sha(proof_json))
    except BaseException as error:
        report.update(workState='failed',error=str(error));raise
    finally:
        stop.set()
        if sampler:sampler.join(timeout=6)
        try:report['dockerCleanup']=native.clean_docker_scope(scope)
        except Exception as error:
            report.update(localVerdict='FAIL',cleanupError=str(error));raise
        finally:(out/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
    print('recovered real native Groth16 compression + SDK crypto verification: PASS; no EVM/assets')


if __name__=='__main__':main()
