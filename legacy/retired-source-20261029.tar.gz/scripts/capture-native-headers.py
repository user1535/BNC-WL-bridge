#!/usr/bin/env python3
"""Bounded read-only public header capture; no signing/proving/transactions/deployment."""
import argparse,datetime,hashlib,json,subprocess,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
TARGETS={
 'worldland':{'url':'https://seoul.worldland.foundation/','chain':103,'profile':'worldland-v1.1.3','source':'https://docs.worldland.foundation/developer/dapp/dev-environment'},
 'bnb':{'url':'https://bsc-dataseed.bnbchain.org/','chain':56,'profile':'bnb-v1.7.8','source':'https://docs.bnbchain.org/bnb-smart-chain/developers/json_rpc/json-rpc-endpoint/'}}
BNB_ALTERNATE='https://bsc-dataseed-public.bnbchain.org/'
BNB_NARIOX='https://bsc-dataseed.nariox.org/'
ALLOWED={'eth_chainId','web3_clientVersion','eth_getBlockByNumber','eth_getBlockByHash'}
def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output-dir',type=Path,required=True)
 parser.add_argument('--chain',choices=['worldland','bnb','both'],default='both')
 parser.add_argument('--replay-capture',type=Path,help='recheck preserved raw responses without network requests')
 parser.add_argument('--bnb-alternate',action='store_true',help='use the second official bnbchain.org endpoint')
 parser.add_argument('--bnb-nariox',action='store_true',help='use the nariox public endpoint listed by the official BNB docs')
 args=parser.parse_args()
 if args.bnb_alternate and args.bnb_nariox:parser.error('select one BNB endpoint')
 out=args.output_dir.resolve();out.mkdir(parents=True,exist_ok=False)
 inspector=ROOT/'.bin/bridge-header-inspect'
 report={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'chainAuthenticated':False,'realAssetDeploymentAllowed':False,'readOnly':True,'offlineReplay':bool(args.replay_capture),'proofsGenerated':0,'transactionsSent':0,'rpcCalls':0,'targets':{}}
 report['inspectorSha256']=hashlib.sha256(inspector.read_bytes()).hexdigest()
 if args.replay_capture:report['sourceCaptureObservedAt']=json.loads((args.replay_capture/'summary.json').read_text())['observedAt']
 def request(target,method,params,directory,label):
  if method not in ALLOWED:raise ValueError('method not allowed')
  payload={'jsonrpc':'2.0','id':1,'method':method,'params':params}
  (directory/(label+'-request.json')).write_text(json.dumps(payload)+'\n')
  if args.replay_capture:
   raw=(args.replay_capture/directory.name/(label+'-response.json')).read_bytes()
  else:
   req=urllib.request.Request(target['url'],json.dumps(payload).encode(),{'Content-Type':'application/json','User-Agent':'WorldLand-BNB-read-only-compatibility'})
   report['rpcCalls']+=1
   with urllib.request.urlopen(req,timeout=15) as response:
    raw=response.read(2*1024*1024+1)
  if len(raw)>2*1024*1024:raise ValueError('RPC response exceeds capture limit')
  (directory/(label+'-response.json')).write_bytes(raw)
  obj=json.loads(raw)
  if obj.get('error'):raise ValueError(str(obj['error']))
  if obj.get('result') is None:raise ValueError('RPC returned null')
  return obj['result']
 try:
  for name,target in TARGETS.items():
   if args.chain!='both' and args.chain!=name:continue
   target=dict(target)
   if name=='bnb' and args.bnb_alternate:target['url']=BNB_ALTERNATE
   if name=='bnb' and args.bnb_nariox:target['url']=BNB_NARIOX
   directory=out/name;directory.mkdir();row={'endpoint':target['url'],'officialEndpointSource':target['source'],'expectedChainId':target['chain'],'encodingProfile':target['profile'],'verdict':'UNAVAILABLE','headers':[]}
   report['targets'][name]=row
   try:
    chain=int(request(target,'eth_chainId',[],directory,'chain-id'),16)
    if chain!=target['chain']:raise ValueError('unexpected chain ID')
    row['rpcChainId']=chain
    try:row['clientVersion']=request(target,'web3_clientVersion',[],directory,'client-version')
    except Exception as error:row['clientVersionError']=str(error)
    latest=request(target,'eth_getBlockByNumber',['latest',False],directory,'latest')
    parent=request(target,'eth_getBlockByHash',[latest['parentHash'],False],directory,'parent')
    if parent['hash'].lower()!=latest['parentHash'].lower() or int(parent['number'],16)+1!=int(latest['number'],16):raise ValueError('RPC parent linkage mismatch')
    for label,header in [('parent',parent),('latest',latest)]:
     # Exclude only RPC metadata, retaining every native header field unchanged.
     native={k:v for k,v in header.items() if k not in ('transactions','uncles','withdrawals','size','totalDifficulty')}
     path=directory/(label+'-header.json');path.write_text(json.dumps(native,indent=2)+'\n')
     command=[str(inspector),'--input',str(path),'--encoding-profile',target['profile']]
     result=subprocess.run(command,text=True,capture_output=True,timeout=30)
     (directory/(label+'-inspection.stdout.json')).write_text(result.stdout)
     (directory/(label+'-inspection.stderr.txt')).write_text(result.stderr)
     if result.returncode:raise ValueError('offline encoder rejected: '+result.stderr.strip())
     inspection=json.loads(result.stdout)
     mutated=dict(native);root=bytearray.fromhex(native['receiptsRoot'][2:]);root[0]^=1;mutated['receiptsRoot']='0x'+root.hex()
     bad=directory/(label+'-mutated-root.json');bad.write_text(json.dumps(mutated)+'\n')
     negative=subprocess.run([str(inspector),'--input',str(bad),'--encoding-profile',target['profile']],text=True,capture_output=True,timeout=30)
     (directory/(label+'-mutated-root.stderr.txt')).write_text(negative.stderr)
     if negative.returncode==0:raise ValueError('mutated root unexpectedly accepted')
     row['headers'].append({'number':int(native['number'],16),'hash':native['hash'],'hashRecomputed':inspection['hashMatchesRpc'],'headerJSONSha256':hashlib.sha256(path.read_bytes()).hexdigest(),'mutatedRootRejected':True})
    row['verdict']='PASS';row['scope']='observed RPC serialization/hash only; no fork/seal/finality authentication'
   except Exception as error:
    row['error']=str(error)
    row['verdict']='CAPTURE_TOOL_ERROR' if isinstance(error,KeyError) else ('INCOMPATIBLE' if 'offline encoder rejected' in str(error) else 'UNAVAILABLE')
  report['verdict']='PASS' if all(r['verdict']=='PASS' for r in report['targets'].values()) else 'INCOMPLETE'
 finally:
  report['artifactSha256']={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.rglob('*') if p.is_file()}
  (out/'summary.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report['targets'],indent=2))
if __name__=='__main__':main()
