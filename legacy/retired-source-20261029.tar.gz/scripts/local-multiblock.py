#!/usr/bin/env python3
"""Three user events in distinct blocks share one real Groth16 accepted batch."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path

spec = importlib.util.spec_from_file_location('local_client', Path(__file__).with_name('local-session.py'))
client = importlib.util.module_from_spec(spec)
spec.loader.exec_module(client)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dir', type=Path, default=client.ROOT / 'results/session-zk-multiblock')
    args = parser.parse_args()
    session = client.Session(args.dir)
    session.start('risc0_batch')
    session.setup()
    try:
        # The bootstrap has unrelated deployment headers after the initial anchor.
        # Synchronize those before creating the measured shared user batch.
        if not session.data.get('bootstrap_synced'):
            tip = int(session.rpc('wl', 'eth_blockNumber', []), 16)
            session.headers({'action': 'lock', 'block': tip, 'user': session.data['users'][0]})
            session.data['bootstrap_synced'] = True
            session.save()
        if not session.data.get('multi_events_created'):
            existing = [e for e in session.data['events'] if e['action'] == 'lock']
            for index in range(len(existing), 3):
                session.action('lock', index, 25 * 10**18)
            session.data['multi_events_created'] = True
            session.save()
        events = [e for e in session.data['events'] if e['action'] == 'lock']
        assert len(events) == 3 and len({e['user'] for e in events}) == 3
        assert [e['block'] for e in events] == list(range(events[0]['block'], events[0]['block'] + 3))
        if not session.data.get('shared_header_accepted'):
            session.headers(events[-1])
            session.data['shared_header_accepted'] = True
            session.save()
        header_file = session.root / f'lock-{events[0]["block"]}-3-headers.json'
        proof = json.loads(header_file.read_text())
        assert proof['receiptKind'] == 'groth16' and proof['startBlock'] == events[0]['block'] and proof['endBlock'] == events[-1]['block']
        assert proof['proofVerified'] and proof['evmCompatible'] and not proof['chainAuthenticated']
        cache = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in (session.root / 'proof-cache').rglob('*.json')}
        accepted_before = len(list(session.root.glob('*-accepted.json')))
        session.stop()
        session.start('risc0_batch')
        for event in reversed(events):
            session.claim(event)
            package = json.loads((session.root / (event['id'] + '-package.json')).read_text())
            assert package['headerMode'] == 'risc0_batch' and package['headerCovered']
            assert 'headerTransaction' not in package and 'headerProof' not in package
        assert cache == {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in (session.root / 'proof-cache').rglob('*.json')}
        assert accepted_before == len(list(session.root.glob('*-accepted.json')))
        supply = int(session.view('bnb', session.data['contracts']['wrapped'], 'totalSupply()(uint256)'))
        assert supply == 75 * 10**18
        for user in session.data['users']:
            assert int(session.view('bnb', session.data['contracts']['wrapped'], 'balanceOf(address)(uint256)', user)) == 25 * 10**18
            assert int(session.view('wl', session.data['contracts']['original'], 'lockedBalanceOf(address)(uint256)', user)) == 25 * 10**18
        summary = {'header_mode': 'risc0_batch', 'receipt_kind': 'groth16', 'users': 3, 'distinct_event_blocks': [e['block'] for e in events],
            'shared_accepted_user_batch_count': 1, 'batch_size': 3, 'claims': 3, 'additional_proving_for_claims': 0,
            'proof_cache_unchanged_during_claims': True, 'restart_before_claims': True,
            'wrapped_supply': str(supply), 'total_locked': str(supply), 'return_direction_tested_here': False,
            'chain_authenticated': False, 'real_asset_deployment_allowed': False}
        client.write_json(session.root / 'summary.json', summary)
        print('real Groth16 batch / three distinct user blocks / restart / shared MPT claims: PASS')
    finally:
        session.stop()


if __name__ == '__main__':
    main()
