#!/usr/bin/env bash
set -euo pipefail

# DEV ONLY: three distinct users share one accepted source header in a local block.
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
WL_RPC=http://127.0.0.1:8545
BNB_RPC=http://127.0.0.1:8546
if cast chain-id --rpc-url "$WL_RPC" >/dev/null 2>&1 || cast chain-id --rpc-url "$BNB_RPC" >/dev/null 2>&1; then
    echo "Ports 8545 or 8546 already in use" >&2; exit 1
fi
anvil --silent --host 127.0.0.1 --port 8545 --chain-id 31337 >"$ROOT_DIR/.anvil-worldland.log" 2>&1 &
WL_PID=$!
anvil --silent --host 127.0.0.1 --port 8546 --chain-id 31338 >"$ROOT_DIR/.anvil-bnb.log" 2>&1 &
BNB_PID=$!
packages=()
cleanup() {
    kill "$WL_PID" "$BNB_PID" 2>/dev/null || true
    wait "$WL_PID" "$BNB_PID" 2>/dev/null || true
    for path in "${packages[@]}"; do rm -f "$path"; done
}
trap cleanup EXIT
for _ in $(seq 1 50); do
    if cast chain-id --rpc-url "$WL_RPC" >/dev/null 2>&1 && cast chain-id --rpc-url "$BNB_RPC" >/dev/null 2>&1; then break; fi
    sleep 0.2
done
[[ "$(cast chain-id --rpc-url "$WL_RPC")" == "31337" ]]
[[ "$(cast chain-id --rpc-url "$BNB_RPC")" == "31338" ]]
DEV="$(cast rpc eth_accounts --rpc-url "$WL_RPC" | python3 -c 'import json,sys; print(json.load(sys.stdin)[0])')"
SUBMITTER="$(cast rpc eth_accounts --rpc-url "$BNB_RPC" | python3 -c 'import json,sys; print(json.load(sys.stdin)[1])')"
AMOUNT=25000000000000000000
INITIAL=100000000000000000000
mkdir -p "$ROOT_DIR/.bin"
go -C "$ROOT_DIR/proof-generator" build -o "$ROOT_DIR/.bin/bridge-proof" ./cmd/bridge-proof
deploy() {
    local rpc="$1" contract="$2"; shift 2
    forge create --root "$ROOT_DIR/contracts" "$contract" --rpc-url "$rpc" --unlocked --from "$DEV" --broadcast --json --constructor-args "$@" \
        | python3 -c 'import json,sys; print(json.load(sys.stdin)["deployedTo"])'
}
field() { python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))[sys.argv[2]])' "$1" "$2"; }
event_id() { python3 -c 'import json,sys; print(json.load(sys.stdin)["logs"][-1]["topics"][1])'; }
call_uint() { local rpc="$1" contract="$2" signature="$3"; shift 3; cast call "$contract" "$signature" "$@" --rpc-url "$rpc" | cut -d' ' -f1; }
ORIGINAL="$(deploy "$WL_RPC" src/token/BridgeLockableToken.sol:BridgeLockableToken "WorldLand local" WL "$INITIAL" 31338)"
WRAPPED="$(deploy "$BNB_RPC" src/token/BridgeWrappedToken.sol:BridgeWrappedToken "Wrapped WorldLand local" wWL 31337 "$ORIGINAL")"
cast send "$ORIGINAL" 'bindDestinationWrappedToken(address)' "$WRAPPED" --rpc-url "$WL_RPC" --unlocked --from "$DEV" >/dev/null
HEADERS="$(deploy "$BNB_RPC" src/bridge/DevHeaderRegistry.sol:DevHeaderRegistry 31337)"
RETURN_HEADERS="$(deploy "$WL_RPC" src/bridge/DevHeaderRegistry.sol:DevHeaderRegistry 31338)"
RECEIVER="$(deploy "$BNB_RPC" src/bridge/LockMintReceiver.sol:LockMintReceiver "$WRAPPED" "$HEADERS")"
UNLOCK_RECEIVER="$(deploy "$WL_RPC" src/bridge/BurnUnlockReceiver.sol:BurnUnlockReceiver "$ORIGINAL" "$RETURN_HEADERS" "$WRAPPED")"
cast send "$WRAPPED" 'bindMintReceiver(address)' "$RECEIVER" --rpc-url "$BNB_RPC" --unlocked --from "$DEV" >/dev/null
cast send "$ORIGINAL" 'bindUnlockReceiver(address)' "$UNLOCK_RECEIVER" --rpc-url "$WL_RPC" --unlocked --from "$DEV" >/dev/null
users=(); keys=(); txs=(); ids=()
for i in 0 1 2; do
    wallet="$(cast wallet new --json)"
    user="$(printf '%s' "$wallet" | python3 -c 'import json,sys; print(json.load(sys.stdin)[0]["address"])')"
    key="$(printf '%s' "$wallet" | python3 -c 'import json,sys; print(json.load(sys.stdin)[0]["private_key"])')"
    users+=("$user"); keys+=("$key")
    cast send "$user" --value 1ether --rpc-url "$WL_RPC" --unlocked --from "$DEV" >/dev/null
    cast send "$user" --value 1ether --rpc-url "$BNB_RPC" --unlocked --from "$DEV" >/dev/null
    cast send "$ORIGINAL" 'transfer(address,uint256)' "$user" "$AMOUNT" --rpc-url "$WL_RPC" --unlocked --from "$DEV" >/dev/null
done
unset wallet user key
cast rpc anvil_setAutomine false --rpc-url "$WL_RPC" >/dev/null
for i in 0 1 2; do
    tx="$(cast send "$ORIGINAL" 'bridgeLock(uint256,address,uint256)' "$AMOUNT" "${users[i]}" 31338 --rpc-url "$WL_RPC" --private-key "${keys[i]}" --async)"
    txs+=("$tx")
done
cast rpc anvil_mine 1 --rpc-url "$WL_RPC" >/dev/null
cast rpc anvil_setAutomine true --rpc-url "$WL_RPC" >/dev/null
for i in 0 1 2; do ids+=("$(cast receipt "${txs[i]}" --rpc-url "$WL_RPC" --json | event_id)"); done
for i in 0 1 2; do
    package="$(mktemp)"; packages+=("$package")
    "$ROOT_DIR/.bin/bridge-proof" --rpc "$WL_RPC" --token "$ORIGINAL" --destination-token "$WRAPPED" \
        --id "${ids[i]}" --action lock --chain-id 31337 --destination-rpc "$BNB_RPC" --header-source "$HEADERS" >"$package"
    [[ "$(field "$package" headerCovered)" == "False" ]]
done
FIRST_BLOCK="$(field "${packages[0]}" blockNumber)"
for package in "${packages[@]}"; do
    [[ "$(field "$package" blockNumber)" == "$FIRST_BLOCK" ]]
    [[ "$(field "$package" receiptRoot)" == "$(field "${packages[0]}" receiptRoot)" ]]
done
cast send "$HEADERS" 'registerHeader(uint256,bytes32,bytes32)' "$FIRST_BLOCK" \
    "$(field "${packages[0]}" blockHash)" "$(field "${packages[0]}" receiptRoot)" --rpc-url "$BNB_RPC" --unlocked --from "$DEV" >/dev/null
for i in 0 1 2; do
    covered="$(mktemp)"; packages+=("$covered")
    "$ROOT_DIR/.bin/bridge-proof" --rpc "$WL_RPC" --token "$ORIGINAL" --destination-token "$WRAPPED" \
        --id "${ids[i]}" --action lock --chain-id 31337 --destination-rpc "$BNB_RPC" --header-source "$HEADERS" >"$covered"
    [[ "$(field "$covered" headerCovered)" == "True" ]]
    cast send "$RECEIVER" --data "$(field "$covered" calldata)" --rpc-url "$BNB_RPC" --unlocked --from "$SUBMITTER" >/dev/null
    [[ "$(call_uint "$BNB_RPC" "$WRAPPED" 'balanceOf(address)(uint256)' "${users[i]}")" == "$AMOUNT" ]]
done
[[ "$(call_uint "$BNB_RPC" "$WRAPPED" 'totalSupply()(uint256)')" == "75000000000000000000" ]]
[[ "$(call_uint "$BNB_RPC" "$WRAPPED" 'balanceOf(address)(uint256)' "$SUBMITTER")" == "0" ]]
# Burn all three claims in a single BNB-local block, then share one return header.
burn_txs=(); burn_ids=(); burn_packages=()
cast rpc anvil_setAutomine false --rpc-url "$BNB_RPC" >/dev/null
for i in 0 1 2; do
    burn_tx="$(cast send "$WRAPPED" 'bridgeBurn(uint256,address,uint256)' "$AMOUNT" "${users[i]}" 31337 --rpc-url "$BNB_RPC" --private-key "${keys[i]}" --async)"
    burn_txs+=("$burn_tx")
done
cast rpc anvil_mine 1 --rpc-url "$BNB_RPC" >/dev/null
cast rpc anvil_setAutomine true --rpc-url "$BNB_RPC" >/dev/null
for i in 0 1 2; do burn_ids+=("$(cast receipt "${burn_txs[i]}" --rpc-url "$BNB_RPC" --json | event_id)"); done
for i in 0 1 2; do
    package="$(mktemp)"; packages+=("$package"); burn_packages+=("$package")
    "$ROOT_DIR/.bin/bridge-proof" --rpc "$BNB_RPC" --token "$WRAPPED" --destination-token "$ORIGINAL" \
        --id "${burn_ids[i]}" --action burn --chain-id 31338 --destination-rpc "$WL_RPC" --header-source "$RETURN_HEADERS" >"$package"
    [[ "$(field "$package" headerCovered)" == "False" ]]
done
BURN_BLOCK="$(field "${burn_packages[0]}" blockNumber)"
for package in "${burn_packages[@]}"; do
    [[ "$(field "$package" blockNumber)" == "$BURN_BLOCK" ]]
    [[ "$(field "$package" receiptRoot)" == "$(field "${burn_packages[0]}" receiptRoot)" ]]
done
[[ "$(call_uint "$BNB_RPC" "$WRAPPED" 'totalSupply()(uint256)')" == "0" ]]
cast send "$RETURN_HEADERS" 'registerHeader(uint256,bytes32,bytes32)' "$BURN_BLOCK" \
    "$(field "${burn_packages[0]}" blockHash)" "$(field "${burn_packages[0]}" receiptRoot)" --rpc-url "$WL_RPC" --unlocked --from "$DEV" >/dev/null
for i in 0 1 2; do
    covered="$(mktemp)"; packages+=("$covered")
    "$ROOT_DIR/.bin/bridge-proof" --rpc "$BNB_RPC" --token "$WRAPPED" --destination-token "$ORIGINAL" \
        --id "${burn_ids[i]}" --action burn --chain-id 31338 --destination-rpc "$WL_RPC" --header-source "$RETURN_HEADERS" >"$covered"
    [[ "$(field "$covered" headerCovered)" == "True" ]]
    cast send "$UNLOCK_RECEIVER" --data "$(field "$covered" calldata)" --rpc-url "$WL_RPC" --unlocked --from "$SUBMITTER" >/dev/null
    [[ "$(call_uint "$WL_RPC" "$ORIGINAL" 'lockedBalanceOf(address)(uint256)' "${users[i]}")" == "0" ]]
    [[ "$(call_uint "$WL_RPC" "$ORIGINAL" 'balanceOf(address)(uint256)' "${users[i]}")" == "$AMOUNT" ]]
done
[[ "$(call_uint "$BNB_RPC" "$WRAPPED" 'totalSupply()(uint256)')" == "0" ]]
[[ "$(call_uint "$BNB_RPC" "$WRAPPED" 'balanceOf(address)(uint256)' "$SUBMITTER")" == "0" ]]
echo "three users: one source block and one return block, one dev header registration per direction"
echo "three MPT mint claims and three MPT unlock claims: success"
echo "shared receipt root: $(field "${packages[0]}" receiptRoot)"
echo "wrapped supply: 75000000000000000000 after mint, 0 after burn; original locked balance: 0 after unlock"
echo "third-party submitter wrapped balance: 0"
echo "header mode: dev; no RISC0 acceptance in this scenario"
