#!/usr/bin/env python3
"""Read-only, bounded Docker memory observations for one recorded prover owner."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import tempfile
import time


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--evidence', type=Path, required=True)
    parser.add_argument('--timeout-seconds', type=int, default=900)
    parser.add_argument('--interval-seconds', type=int, choices=range(1, 31), default=5)
    args = parser.parse_args()
    if not 1 <= args.timeout_seconds <= 1800: parser.error('sampling timeout must be1..1800sec')
    source = args.evidence.resolve()
    ownership_path = source / 'docker-scope/ownership.json'
    start = time.monotonic()
    # The runner publishes ownership after Docker preflight; early observers only wait/read.
    while True:
        try:
            ownership_bytes = ownership_path.read_bytes()
            ownership = json.loads(ownership_bytes)
            break
        except (FileNotFoundError, json.JSONDecodeError):
            if time.monotonic() - start >= min(30, args.timeout_seconds):
                raise ValueError('owned prover metadata not published within bounded startup wait')
            time.sleep(.2)
    output = source / 'docker-memory-samples.json'
    report = {'startedAt': datetime.now(timezone.utc).isoformat(), 'readOnly': True,
        'ownershipSHA256': hashlib.sha256(ownership_bytes).hexdigest(), 'ownership': ownership,
        'memoryScope': 'Docker CLI rounded MemUsage; sampled observation, not exact allocation peak',
        'intervalSeconds': args.interval_seconds, 'timeoutSeconds': args.timeout_seconds,
        'samples': [], 'peakObservedApproxBytes': 0, 'verifiedLabel': False, 'measurementComplete': False,
        'ownedContainerRemovalObserved': False, 'transientStatsFailures': [], 'transientEmptyCIDReads': 0}
    # Never replace an earlier run. Publish complete JSON even while waiting for Docker.
    with output.open('x') as f: f.write(json.dumps(report, indent=2) + '\n')
    def save_report():
        with tempfile.NamedTemporaryFile(mode='w', dir=source, prefix='.owned-memory-', delete=False) as f:
            f.write(json.dumps(report, indent=2) + '\n')
            temporary = f.name
        os.replace(temporary, output)
    def interrupted(*_): raise KeyboardInterrupt('owned memory sampler interrupted')
    signal.signal(signal.SIGTERM, interrupted)
    consecutive_stats_failures = 0
    empty_cid_started = None
    recorded_cid = None
    try:
        while time.monotonic() - start < args.timeout_seconds:
            complete = (source / 'receipt.json').exists()
            try:
                runner = json.loads((source / 'summary.json').read_bytes())
            except (FileNotFoundError, json.JSONDecodeError):
                runner = {}
            if runner.get('workState') == 'failed':
                report['proofRunnerTerminalFailureObserved'] = True
                break
            if not Path(ownership['cid']).exists():
                if complete: break
                time.sleep(args.interval_seconds); continue
            cid = Path(ownership['cid']).read_text().strip()
            if not cid and recorded_cid is None:
                # Docker creates --cidfile before publishing its complete container ID.
                empty_cid_started = empty_cid_started or time.monotonic()
                report['transientEmptyCIDReads'] += 1
                if time.monotonic() - empty_cid_started > 30:
                    raise ValueError('owned CID not published within bounded startup wait')
                save_report(); time.sleep(.2); continue
            if len(cid) != 64 or any(c not in '0123456789abcdef' for c in cid): raise ValueError('invalid owned CID')
            if recorded_cid is not None and cid != recorded_cid: raise ValueError('owned CID changed during measurement')
            recorded_cid = cid
            check = subprocess.run([ownership['docker'], 'inspect', '--format',
                '{{index .Config.Labels "worldland-bnb.prover"}}', cid], text=True, capture_output=True, timeout=15)
            if check.returncode:
                if 'no such' in check.stderr.lower() and (report['verifiedLabel'] or complete):
                    report['ownedContainerRemovalObserved'] = report['verifiedLabel']; break
                raise ValueError('cannot confirm owned container: ' + check.stderr.strip())
            if check.stdout.strip() != ownership['label']: raise ValueError('container ownership differs')
            report['verifiedLabel'] = True
            sample = subprocess.run([ownership['docker'], 'stats', '--no-stream', '--format', '{{json .}}', cid],
                text=True, capture_output=True, timeout=20)
            if sample.returncode:
                if complete: break
                # --rm may remove the container before the host publishes its final receipt.
                # Recheck the exact CID/label on the next iteration, including an EOF from stats.
                consecutive_stats_failures += 1
                report['transientStatsFailures'].append({'at': datetime.now(timezone.utc).isoformat(),
                    'stderr': sample.stderr.strip()})
                save_report()
                if consecutive_stats_failures > 3:
                    raise ValueError('owned Docker stats failed repeatedly: ' + sample.stderr.strip())
                time.sleep(args.interval_seconds); continue
            consecutive_stats_failures = 0
            if sample.stdout.strip():
                row = json.loads(sample.stdout); usage = row['MemUsage'].split('/')[0].strip()
                for unit, factor in [('GiB',1024**3), ('MiB',1024**2), ('KiB',1024), ('GB',10**9), ('MB',10**6), ('kB',1000), ('B',1)]:
                    if usage.endswith(unit): amount = int(float(usage[:-len(unit)].strip()) * factor); break
                else: raise ValueError('unsupported Docker memory unit')
                report['samples'].append({'at': datetime.now(timezone.utc).isoformat(), 'memoryUsage': usage,
                    'approxBytes': amount, 'cpuPercent': row['CPUPerc'], 'containerId': cid})
                report['peakObservedApproxBytes'] = max(amount, report['peakObservedApproxBytes'])
                save_report()
            if complete: break
            time.sleep(args.interval_seconds)
        report['measurementComplete'] = (source / 'receipt.json').exists() or report['ownedContainerRemovalObserved']
    except BaseException as error:
        report['error'] = str(error); raise
    finally:
        report.update(finishedAt=datetime.now(timezone.utc).isoformat(), sampleCount=len(report['samples']))
        save_report()
    print('Owned memory samples', len(report['samples']), report['peakObservedApproxBytes'], 'approx bytes; read-only')


if __name__ == '__main__': main()
