#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
export PATH="$PWD/.bin:$HOME/.foundry/bin:$HOME/.cargo/bin:$PATH"
python_bin="${BNC_PYTHON:-python3}"
mode="${1:-risc0-computation}"
default_session=results/prototype-demo
if [[ "$mode" == risc0-computation ]]; then default_session=results/prototype-risc0; fi
session_dir="${2:-${BNC_STATE_DIR:-$default_session}}"
mkdir -p -- "$session_dir"
exec 9>"$session_dir/launcher.lock"
flock -n 9 || { echo "This state directory already has an active launcher" >&2; exit 1; }
case "$mode" in
  risc0-computation)
      session_mode=dev; service_args=(--trusted-rpc --demo-mine --prove-computation)
      "$python_bin" scripts/server-doctor.py --mode risc0-computation
      ;;
  trusted-rpc) session_mode=dev; service_args=(--trusted-rpc --demo-mine) ;;
  fast) session_mode=dev; service_args=() ;;
  zk) session_mode=risc0_batch; service_args=(--prove)
      command -v docker >/dev/null || { echo "Docker Engine is required for zk mode" >&2; exit 1; }
      docker info >/dev/null || { echo "Docker engine is unavailable; start Docker before zk mode" >&2; exit 1; }
      ;;
  *) echo "usage: $0 [risc0-computation|trusted-rpc|fast|zk] [session-directory]" >&2; exit 2 ;;
esac
"$python_bin" scripts/local-session.py --dir "$session_dir" --mode "$session_mode" start
cleanup() { "$python_bin" scripts/local-session.py --dir "$session_dir" --mode "$session_mode" stop; }
trap cleanup EXIT
if [[ "$mode" == zk ]]; then
  "$python_bin" - "$session_dir" <<'PY'
from pathlib import Path
import importlib.util,sys
spec=importlib.util.spec_from_file_location('launcher_session',Path('scripts/local-session.py'))
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
module.Session(Path(sys.argv[1])).prover_host()
PY
fi
"$python_bin" scripts/local-session.py --dir "$session_dir" --mode "$session_mode" deploy
"$python_bin" scripts/proof-service.py --session "$session_dir" --confirmations 2 "${service_args[@]}"
