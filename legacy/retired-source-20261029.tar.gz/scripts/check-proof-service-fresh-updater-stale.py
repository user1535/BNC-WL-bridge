#!/usr/bin/env python3
"""Fresh SDK proofs cannot be delivered after destination updater advancement."""
import importlib.util,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('fresh_stale_api',ROOT/'scripts/proof-service.py')
api=importlib.util.module_from_spec(spec);spec.loader.exec_module(api)
out=ROOT/'results/prototype-header-steps'
service=api.Service.__new__(api.Service);service.session=api.local.Session(out);service.manifest=api.manifest(service.session);service.directory=out/'proof-jobs';service.confirmations=2
cases=[]
for savedfile in ('request.json','fresh-burn-request.json'):
 saved=json.loads((out/savedfile).read_text());job=json.loads((service.directory/(saved['id']+'.json')).read_text())
 h=json.loads((service.directory/'headers'/(saved['id']+'.json')).read_text())
 try:service.validate_header(job,h)
 except ValueError as e:assert 'stale' in str(e);cases.append(dict(action=job['request']['action'],sdkReverified=True,sourceRequeried=True,staleUpdaterRejected=True))
 else:raise ValueError('already advanced updater accepted old header package')
result=dict(passed=True,cases=cases,newProofs=0,serverBroadcasts=0,midProvingUpdaterMutationMeasured=False,chainAuthenticated=False,realAssetDeploymentAllowed=False)
(out/'fresh-updater-stale-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
