#!/usr/bin/env python3
"""Compare saved actual BLS guest cycles for identical native statements; no proving."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(directory, binding):
    summary = json.loads((directory / "summary.json").read_text())
    metadata = json.loads((directory / "metadata.json").read_text())
    if summary.get("status") != "PASS" or summary.get("headerBinding") != binding:
        raise ValueError("completed actual guest evidence and explicit binding required")
    if sha(directory / "risc0-host") != metadata["hostSHA256"]:
        raise ValueError("frozen host changed")
    for row in summary["results"]:
        if row.get("passed") is not True or sha(directory / (row["case"] + "-input.json")) != row["inputSHA256"]:
            raise ValueError("case or saved input differs")
    return summary, metadata


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--baseline", type=Path, required=True)
    p.add_argument("--candidate", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    args = p.parse_args()
    base, bm = load(args.baseline, "bnb-vote-native-rlp-supplied-epoch")
    candidate, cm = load(args.candidate, "bnb-vote-native-rlp-supplied-epoch-hinted")
    if (candidate.get("coordinateHintsChecked") is not True or base["imageId"] == candidate["imageId"]
            or len(candidate["results"]) != 19 or len(base["results"]) != 9
            or any(bm[k] != cm[k] for k in ("serverSHA256", "segmentPo2", "threads", "sessionCycleLimit"))):
        raise ValueError("candidate guards or pinned measurement configuration differ")
    rows = []
    for label in ("parent", "latest"):
        left = next(r for r in base["results"] if r["case"] == label)
        right = next(r for r in candidate["results"] if r["case"] == label)
        original = json.loads((args.baseline / (label + "-input.json")).read_text())
        hinted = json.loads((args.candidate / (label + "-input.json")).read_text())
        hinted.pop("key_coordinates")
        hinted.pop("signature_coordinates")
        if original != hinted or left["execution"]["journal"] != right["execution"]["journal"]:
            raise ValueError("native bytes/metadata or full journal changed")
        for row in (left, right):
            e = row["execution"]
            if (e.get("guestExecuted") is not True or e.get("suppliedEpochBlsMathVerified") is not True
                    or any(e.get(k) is not False for k in ("proofGenerated", "evmAcceptanceMeasured",
                                                          "chainAuthenticated", "realAssetDeploymentAllowed"))):
                raise ValueError("execution scope differs")
        b, c = left["execution"]["executionCycles"], right["execution"]["executionCycles"]
        rows.append({"case": label, "nativeStatementAndJournalEqual": True,
                     "baselineUserCycles": b, "candidateUserCycles": c,
                     "cycleReductionPercent": (b-c)/b*100,
                     "baselineSegments": left["execution"]["executionSegments"],
                     "candidateSegments": right["execution"]["executionSegments"]})
    report = {"measuredAt": datetime.now(timezone.utc).isoformat(), "localVerdict": "PASS",
              "baselineImageId": base["imageId"], "candidateImageId": candidate["imageId"],
              "baselineSummarySHA256": sha(args.baseline / "summary.json"),
              "candidateSummarySHA256": sha(args.candidate / "summary.json"), "results": rows,
              "candidateNegativeCasesPassed": 17, "proofGenerationMeasuredHere": False,
              "provingSpeedImprovementEstablished": False, "productionThroughputMeasured": False,
              "chainAuthenticated": False, "realAssetDeploymentAllowed": False}
    with args.output.open("x") as output:
        output.write(json.dumps(report, indent=2) + "\n")
    print(args.output)


if __name__ == "__main__":
    main()
