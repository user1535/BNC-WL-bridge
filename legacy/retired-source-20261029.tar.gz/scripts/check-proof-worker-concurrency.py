#!/usr/bin/env python3
"""Read-only HTTP idempotency and actual held builder lock integration check."""
import concurrent.futures,json,os,subprocess,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
out=ROOT/'results/prototype-header-steps'
saved=json.loads((out/'fresh-burn-request.json').read_text())
url='http://127.0.0.1:8580/api/jobs'
def submit(_):
 req=urllib.request.Request(url,json.dumps(saved['request']).encode(),headers={'Content-Type':'application/json','X-Bridge-Request':'1'},method='POST')
 return json.load(urllib.request.urlopen(req,timeout=10))
existing=set((out/'proof-jobs').glob(saved['id']+'-proof-*'))
assert len(existing)==1,'must run while one owned burn proof is active'
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
 jobs=list(pool.map(submit,range(8)))
assert all(j['id']==saved['id'] and j['state'] in ('running','waiting_prover') for j in jobs)
package=json.loads(next(iter(existing)).joinpath('source-package.json').read_text())
blocked=out/'blocked-concurrent-attempt'
assert not blocked.exists()
r=subprocess.run(['/usr/bin/python3',str(ROOT/'scripts/build-unsigned-headers.py'),'--session',str(out),'--action','burn','--start',str(package['startBlock']),'--count',str(package['endBlock']-package['startBlock']+1),'--output-dir',str(blocked)],capture_output=True,text=True,timeout=10)
assert r.returncode!=0 and 'BlockingIOError' in r.stderr and not blocked.exists(),'active worker must hold its real cross-process lock'
assert existing==set((out/'proof-jobs').glob(saved['id']+'-proof-*'))
report=dict(passed=True,concurrentRequests=8,sameJob=True,duplicateBuilderRejected=True,newProofAttempts=0,serverBroadcasts=0,chainAuthenticated=False,realAssetDeploymentAllowed=False)
(out/'concurrency-summary.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
