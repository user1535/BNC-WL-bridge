#!/usr/bin/env bash
set -euo pipefail

# DEV ONLY: the mock operator copies event data between two ephemeral Anvil chains.
# Anvil's unlocked accounts sign transactions. This script does not handle keys.

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
WORLDLAND_RPC="http://127.0.0.1:8545"
BNB_RPC="http://127.0.0.1:8546"

if cast chain-id --rpc-url "$WORLDLAND_RPC" >/dev/null 2>&1 || cast chain-id --rpc-url "$BNB_RPC" >/dev/null 2>&1; then
    echo "Ports 8545 or 8546 are already in use; refusing to reuse an unknown chain." >&2
    exit 1
fi

anvil --silent --host 127.0.0.1 --port 8545 --chain-id 31337 >"$ROOT_DIR/.anvil-worldland.log" 2>&1 &
WORLDLAND_PID=$!
anvil --silent --host 127.0.0.1 --port 8546 --chain-id 31338 >"$ROOT_DIR/.anvil-bnb.log" 2>&1 &
BNB_PID=$!
cleanup() {
    kill "$WORLDLAND_PID" "$BNB_PID" 2>/dev/null || true
    wait "$WORLDLAND_PID" "$BNB_PID" 2>/dev/null || true
}
trap cleanup EXIT

for _ in $(seq 1 50); do
    if cast chain-id --rpc-url "$WORLDLAND_RPC" >/dev/null 2>&1 && cast chain-id --rpc-url "$BNB_RPC" >/dev/null 2>&1; then
        break
    fi
    sleep 0.2
done
[[ "$(cast chain-id --rpc-url "$WORLDLAND_RPC")" == "31337" ]]
[[ "$(cast chain-id --rpc-url "$BNB_RPC")" == "31338" ]]

USER_ADDRESS="$(cast rpc eth_accounts --rpc-url "$WORLDLAND_RPC" | python3 -c 'import json,sys; print(json.load(sys.stdin)[0])')"
OTHER_ADDRESS="$(cast rpc eth_accounts --rpc-url "$BNB_RPC" | python3 -c 'import json,sys; print(json.load(sys.stdin)[1])')"
AMOUNT=25000000000000000000
INITIAL=100000000000000000000

deploy() {
    local rpc="$1" contract="$2"
    shift 2
    forge create --root "$ROOT_DIR/contracts" "$contract" --rpc-url "$rpc" \
        --unlocked --from "$USER_ADDRESS" --broadcast --json --constructor-args "$@" \
        | python3 -c 'import json,sys; print(json.load(sys.stdin)["deployedTo"])'
}
send_tx() {
    local rpc="$1" sender="$2" contract="$3" signature="$4"
    shift 4
    cast send "$contract" "$signature" "$@" --rpc-url "$rpc" --unlocked --from "$sender" --json
}
event_id() {
    python3 -c 'import json,sys; x=json.load(sys.stdin); print(x["logs"][-1]["topics"][1])'
}
call_uint() {
    local rpc="$1" contract="$2" signature="$3"
    shift 3
    cast call "$contract" "$signature" "$@" --rpc-url "$rpc" | cut -d' ' -f1
}

ORIGINAL="$(deploy "$WORLDLAND_RPC" src/token/BridgeLockableToken.sol:BridgeLockableToken "WorldLand local" WL "$INITIAL" 31338)"
WRAPPED="$(deploy "$BNB_RPC" src/token/BridgeWrappedToken.sol:BridgeWrappedToken "Wrapped WorldLand local" wWL 31337 "$ORIGINAL")"
send_tx "$WORLDLAND_RPC" "$USER_ADDRESS" "$ORIGINAL" 'bindDestinationWrappedToken(address)' "$WRAPPED" >/dev/null
MINT_RECEIVER="$(deploy "$BNB_RPC" src/bridge/DevMockLockMintReceiver.sol:DevMockLockMintReceiver "$WRAPPED")"
UNLOCK_RECEIVER="$(deploy "$WORLDLAND_RPC" src/bridge/DevMockBurnUnlockReceiver.sol:DevMockBurnUnlockReceiver "$ORIGINAL" 31338 "$WRAPPED")"

send_tx "$BNB_RPC" "$USER_ADDRESS" "$WRAPPED" 'bindMintReceiver(address)' "$MINT_RECEIVER" >/dev/null
send_tx "$WORLDLAND_RPC" "$USER_ADDRESS" "$ORIGINAL" 'bindUnlockReceiver(address)' "$UNLOCK_RECEIVER" >/dev/null

LOCK_ID="$(send_tx "$WORLDLAND_RPC" "$USER_ADDRESS" "$ORIGINAL" 'bridgeLock(uint256,address,uint256)' "$AMOUNT" "$USER_ADDRESS" 31338 | event_id)"
[[ "$(call_uint "$WORLDLAND_RPC" "$ORIGINAL" 'lockedBalanceOf(address)(uint256)' "$USER_ADDRESS")" == "$AMOUNT" ]]

# Mock registration stands in for a verified cross-chain event in this stage only.
send_tx "$BNB_RPC" "$USER_ADDRESS" "$MINT_RECEIVER" 'recordLock(bytes32,address,uint256)' "$LOCK_ID" "$USER_ADDRESS" "$AMOUNT" >/dev/null
send_tx "$BNB_RPC" "$OTHER_ADDRESS" "$MINT_RECEIVER" 'claimLock(bytes32)' "$LOCK_ID" >/dev/null
[[ "$(call_uint "$BNB_RPC" "$WRAPPED" 'balanceOf(address)(uint256)' "$USER_ADDRESS")" == "$AMOUNT" ]]
[[ "$(call_uint "$BNB_RPC" "$WRAPPED" 'balanceOf(address)(uint256)' "$OTHER_ADDRESS")" == "0" ]]

BURN_ID="$(send_tx "$BNB_RPC" "$USER_ADDRESS" "$WRAPPED" 'bridgeBurn(uint256,address,uint256)' "$AMOUNT" "$USER_ADDRESS" 31337 | event_id)"
send_tx "$WORLDLAND_RPC" "$USER_ADDRESS" "$UNLOCK_RECEIVER" 'recordBurn(bytes32,address,uint256)' "$BURN_ID" "$USER_ADDRESS" "$AMOUNT" >/dev/null
send_tx "$WORLDLAND_RPC" "$OTHER_ADDRESS" "$UNLOCK_RECEIVER" 'claimBurn(bytes32)' "$BURN_ID" >/dev/null

[[ "$(call_uint "$WORLDLAND_RPC" "$ORIGINAL" 'balanceOf(address)(uint256)' "$USER_ADDRESS")" == "$INITIAL" ]]
[[ "$(call_uint "$WORLDLAND_RPC" "$ORIGINAL" 'lockedBalanceOf(address)(uint256)' "$USER_ADDRESS")" == "0" ]]
[[ "$(call_uint "$BNB_RPC" "$WRAPPED" 'totalSupply()(uint256)')" == "0" ]]

echo "WorldLand-local balance: initial = final = $INITIAL"
echo "lockedBalance: 0"
echo "BNB Smart Chain-local wrapped supply: 0"
echo "lock: success; mint: success; burn: success; unlock: success"
echo "mock event registration: DEV ONLY; no receipt MPT or header authentication in this stage"
echo "proof generator: none; transaction signer: Anvil unlocked test accounts"
