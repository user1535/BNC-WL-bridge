import {chromium,launchOptions} from './browser-runtime.mjs';
import fs from 'node:fs';
const browser=await chromium.launch(launchOptions);
try{
 const page=await browser.newPage();await page.goto('http://127.0.0.1:8580/');
 await page.locator('#demo-wallet').click();await page.locator('#status').getByText('데모 지갑 연결 완료.',{exact:false}).waitFor();
 await page.locator('#switch-wl').click();await page.locator('#status').getByText('네트워크를 전환했습니다.',{exact:true}).waitFor();await page.locator('#demo-forward').click();await page.locator('#status').getByText('시연 설정 완료.',{exact:false}).waitFor();await page.locator('#prepare-action').click();await page.locator('#status').getByText('거래 확인 완료. 검토 내용을 확인한 뒤 지갑에서 승인 요청을 누르세요.',{exact:true}).waitFor();
 if(await page.locator('#submit').isDisabled())throw Error(await page.locator('#status').textContent());
 page.once('dialog',d=>d.dismiss());await page.locator('#submit').click();await page.locator('#status').getByText('지갑에서 요청을 거절했습니다.',{exact:true}).waitFor();
 const result=await page.evaluate(async()=>{
  const {DemoWallet}=await import('/demo-wallet.mjs');const {Transaction}=await import('/vendor/ethers-6.15.0.min.mjs');
  const manifest=await (await fetch('/api/manifest')).json();const provider=new DemoWallet(manifest);
  let rejected=false;try{new DemoWallet({...manifest,publicOrigin:'https://example.org'});}catch{rejected=true;}
  if(!rejected)throw Error('public demo allowed');
  const originalFetch=window.fetch,confirm=window.confirm;let signed;
  window.confirm=()=>true;
  window.fetch=async(url,options)=>{const b=JSON.parse(options.body);if(b.method==='eth_sendRawTransaction'){signed=Transaction.from(b.params[0]);return new Response(JSON.stringify({result:'0x'+'a'.repeat(64)}));}return originalFetch(url,options);};
  try{await provider.request({method:'eth_sendTransaction',params:[{from:provider.wallet.address,to:manifest.contracts.original,data:'0x',value:'0x0',chainId:'0x7a69',nonce:'0x0',gas:'0x5208'}]});}
  finally{window.fetch=originalFetch;window.confirm=confirm;}
  if(signed.from!==provider.wallet.address||signed.chainId!==31337n)throw Error('signature mismatch');
  return {account:provider.wallet.address,signatureRecovered:true,publicOriginRejected:true};
 });
 fs.writeFileSync(new URL('../results/demo-wallet-summary.json',import.meta.url),JSON.stringify({passed:true,...result,checks:['connection','real RPC token balance and simulation','approval rejection','browser signature recovery','public deployment disabled'],transactionsBroadcast:0},null,2));console.log('demo wallet PASS');
}finally{await browser.close();}
