#!/usr/bin/env bash
set -euo pipefail

# Actual cryptographic RISC0 header verification, then receipt MPT claims, on local chains only.
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
WL_RPC=http://127.0.0.1:8558
BNB_RPC=http://127.0.0.1:8559
HOST="${RISC0_HOST_PATH:-$ROOT_DIR/risc0/target/release/bridge-header-benchmark}"
HEADER_BINDING="${HEADER_BINDING:-minimal-link}"
if [[ -z "${RESULT_DIR:-}" ]]; then
    RESULT_DIR="$ROOT_DIR/results/local-risc0"
    [[ "$HEADER_BINDING" == "canonical-rlp" ]] && RESULT_DIR="$ROOT_DIR/results/local-risc0-bound"
    [[ ! -e "$RESULT_DIR" ]] || RESULT_DIR="$RESULT_DIR-$(date -u +%Y%m%dT%H%M%SZ)-$$"
fi
[[ ! -e "$RESULT_DIR/summary.json" ]] || { echo "Existing evidence preserved; choose a new RESULT_DIR" >&2; exit 1; }
[[ -x "$HOST" ]] || { echo "Build RISC0 host first" >&2; exit 1; }
docker info >/dev/null 2>&1 || { echo "Groth16 requires running Docker with WSL integration" >&2; exit 1; }
for rpc in "$WL_RPC" "$BNB_RPC"; do
    if cast chain-id --rpc-url "$rpc" >/dev/null 2>&1; then echo "Local port already in use" >&2; exit 1; fi
done
mkdir -p "$ROOT_DIR/.bin" "$RESULT_DIR"
# Proving and re-verification must use the same immutable binary even during another build.
if [[ -e "$RESULT_DIR/risc0-host" ]]; then
    echo "Existing prover snapshot preserved; choose a new RESULT_DIR" >&2; exit 1
fi
cp "$HOST" "$RESULT_DIR/risc0-host"
chmod 700 "$RESULT_DIR/risc0-host"
HOST="$RESULT_DIR/risc0-host"
python3 - "$HOST" "$RESULT_DIR" <<'PY'
import hashlib,json,subprocess,sys
from pathlib import Path
host=Path(sys.argv[1])
metadata={'hostSHA256':hashlib.sha256(host.read_bytes()).hexdigest(),
          'imageId':subprocess.check_output([str(host),'--image-id'],text=True).strip(),
          'headerBinding':subprocess.check_output([str(host),'--header-binding'],text=True).strip()}
(Path(sys.argv[2])/'host-metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
PY
anvil --silent --host 127.0.0.1 --port 8558 --chain-id 31337 >"$RESULT_DIR/worldland-anvil.log" 2>&1 &
WL_PID=$!
anvil --silent --host 127.0.0.1 --port 8559 --chain-id 31338 >"$RESULT_DIR/bnb-anvil.log" 2>&1 &
BNB_PID=$!
cleanup() {
    kill "$WL_PID" "$BNB_PID" 2>/dev/null || true
    wait "$WL_PID" "$BNB_PID" 2>/dev/null || true
    unset USER_KEY
}
trap cleanup EXIT
for _ in $(seq 1 50); do
    if cast chain-id --rpc-url "$WL_RPC" >/dev/null 2>&1 && cast chain-id --rpc-url "$BNB_RPC" >/dev/null 2>&1; then break; fi
    sleep 0.2
done
[[ "$(cast chain-id --rpc-url "$WL_RPC")" == "31337" ]]
[[ "$(cast chain-id --rpc-url "$BNB_RPC")" == "31338" ]]
go -C "$ROOT_DIR/proof-generator" build -o "$ROOT_DIR/.bin/bridge-proof" ./cmd/bridge-proof
go -C "$ROOT_DIR/proof-generator" build -o "$ROOT_DIR/.bin/bridge-header-data" ./cmd/bridge-header-data
export RISC0_SERVER_PATH="${RISC0_SERVER_PATH:-$HOME/.cargo/bin/r0vm}"
DEV="$(cast rpc eth_accounts --rpc-url "$WL_RPC" | python3 -c 'import json,sys; print(json.load(sys.stdin)[0])')"
wallet="$(cast wallet new --json)"
USER="$(printf '%s' "$wallet" | python3 -c 'import json,sys; print(json.load(sys.stdin)[0]["address"])')"
USER_KEY="$(printf '%s' "$wallet" | python3 -c 'import json,sys; print(json.load(sys.stdin)[0]["private_key"])')"
unset wallet
AMOUNT=25000000000000000000
INITIAL=100000000000000000000
field() { python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))[sys.argv[2]])' "$1" "$2"; }
deploy() {
    local rpc="$1" contract="$2"; shift 2
    local args=()
    if (( $# > 0 )); then args=(--constructor-args "$@"); fi
    forge create --root "$ROOT_DIR/contracts" "$contract" --rpc-url "$rpc" --unlocked --from "$DEV" --broadcast --json "${args[@]}" \
        | python3 -c 'import json,sys; print(json.load(sys.stdin)["deployedTo"])'
}
dev_send() { local rpc="$1" contract="$2"; shift 2; cast send "$contract" "$@" --rpc-url "$rpc" --unlocked --from "$DEV" --json; }
user_send() { local rpc="$1" contract="$2"; shift 2; cast send "$contract" "$@" --rpc-url "$rpc" --private-key "$USER_KEY" --json; }
call_uint() { local rpc="$1" contract="$2"; shift 2; cast call "$contract" "$@" --rpc-url "$rpc" | cut -d' ' -f1; }
event_id() { python3 -c 'import json,sys; print(json.load(sys.stdin)["logs"][-1]["topics"][1])'; }
ORIGINAL="$(deploy "$WL_RPC" src/token/BridgeLockableToken.sol:BridgeLockableToken "WorldLand local" WL "$INITIAL" 31338)"
WRAPPED="$(deploy "$BNB_RPC" src/token/BridgeWrappedToken.sol:BridgeWrappedToken "Wrapped WorldLand local" wWL 31337 "$ORIGINAL")"
dev_send "$WL_RPC" "$ORIGINAL" 'bindDestinationWrappedToken(address)' "$WRAPPED" >/dev/null
cast send "$USER" --value 1ether --rpc-url "$WL_RPC" --unlocked --from "$DEV" >/dev/null
cast send "$USER" --value 1ether --rpc-url "$BNB_RPC" --unlocked --from "$DEV" >/dev/null
dev_send "$WL_RPC" "$ORIGINAL" 'transfer(address,uint256)' "$USER" "$INITIAL" >/dev/null
user_send "$WL_RPC" "$ORIGINAL" 'bridgeLock(uint256,address,uint256)' "$AMOUNT" "$USER" 31338 >"$RESULT_DIR/lock-receipt.json"
LOCK_ID="$(cat "$RESULT_DIR/lock-receipt.json" | event_id)"
LOCK_BLOCK="$(python3 -c 'import json,sys; print(int(json.load(open(sys.argv[1]))["blockNumber"],16))' "$RESULT_DIR/lock-receipt.json")"
echo "Generating lock header Groth16 proof for local block $LOCK_BLOCK"
"$ROOT_DIR/.bin/bridge-header-data" --rpc "$WL_RPC" --chain-id 31337 --start "$LOCK_BLOCK" --count 1 \
    --risc0-host "$HOST" --header-binding "$HEADER_BINDING" --proof-cache "$RESULT_DIR/proof-cache" --receipt-kind groth16 --proof-timeout 45m >"$RESULT_DIR/lock-header.json"
IMAGE_ID="$(field "$RESULT_DIR/lock-header.json" imageId)"
BNB_VERIFIER="$(deploy "$BNB_RPC" src/bridge/LocalRiscZeroGroth16Verifier.sol:LocalRiscZeroGroth16Verifier)"
BNB_HEADERS="$(deploy "$BNB_RPC" src/bridge/Risc0HeaderUpdater.sol:Risc0HeaderUpdater 31337 "$BNB_VERIFIER" "$IMAGE_ID" "$((LOCK_BLOCK-1))" "$(field "$RESULT_DIR/lock-header.json" anchorHash)")"
MINT_RECEIVER="$(deploy "$BNB_RPC" src/bridge/LockMintReceiver.sol:LockMintReceiver "$WRAPPED" "$BNB_HEADERS")"
dev_send "$BNB_RPC" "$WRAPPED" 'bindMintReceiver(address)' "$MINT_RECEIVER" >/dev/null
"$ROOT_DIR/.bin/bridge-proof" --rpc "$WL_RPC" --chain-id 31337 --token "$ORIGINAL" --destination-token "$WRAPPED" \
    --id "$LOCK_ID" --action lock --from-block "$LOCK_BLOCK" --destination-rpc "$BNB_RPC" --header-source "$BNB_HEADERS" \
    --receiver "$MINT_RECEIVER" --header-mode risc0_batch --risc0-host "$HOST" --header-package "$RESULT_DIR/lock-header.json" >"$RESULT_DIR/lock-package.json"
HEADER_DATA="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["headerTransaction"]["data"])' "$RESULT_DIR/lock-package.json")"
user_send "$BNB_RPC" "$BNB_HEADERS" --data "$HEADER_DATA" >"$RESULT_DIR/lock-header-accepted.json"
[[ "$(call_uint "$BNB_RPC" "$BNB_HEADERS" 'latestBlock()(uint256)')" == "$LOCK_BLOCK" ]]
"$ROOT_DIR/.bin/bridge-proof" --rpc "$WL_RPC" --chain-id 31337 --token "$ORIGINAL" --destination-token "$WRAPPED" \
    --id "$LOCK_ID" --action lock --from-block "$LOCK_BLOCK" --destination-rpc "$BNB_RPC" --header-source "$BNB_HEADERS" \
    --receiver "$MINT_RECEIVER" --header-mode risc0_batch --risc0-host "$HOST" >"$RESULT_DIR/lock-covered.json"
[[ "$(field "$RESULT_DIR/lock-covered.json" headerCovered)" == "True" ]]
user_send "$BNB_RPC" "$MINT_RECEIVER" --data "$(field "$RESULT_DIR/lock-covered.json" calldata)" >"$RESULT_DIR/mint-receipt.json"
[[ "$(call_uint "$BNB_RPC" "$WRAPPED" 'balanceOf(address)(uint256)' "$USER")" == "$AMOUNT" ]]
user_send "$BNB_RPC" "$WRAPPED" 'bridgeBurn(uint256,address,uint256)' "$AMOUNT" "$USER" 31337 >"$RESULT_DIR/burn-receipt.json"
BURN_ID="$(cat "$RESULT_DIR/burn-receipt.json" | event_id)"
BURN_BLOCK="$(python3 -c 'import json,sys; print(int(json.load(open(sys.argv[1]))["blockNumber"],16))' "$RESULT_DIR/burn-receipt.json")"
echo "Generating burn header Groth16 proof for local block $BURN_BLOCK"
"$ROOT_DIR/.bin/bridge-header-data" --rpc "$BNB_RPC" --chain-id 31338 --start "$BURN_BLOCK" --count 1 \
    --risc0-host "$HOST" --header-binding "$HEADER_BINDING" --proof-cache "$RESULT_DIR/proof-cache" --receipt-kind groth16 --proof-timeout 45m >"$RESULT_DIR/burn-header.json"
WL_VERIFIER="$(deploy "$WL_RPC" src/bridge/LocalRiscZeroGroth16Verifier.sol:LocalRiscZeroGroth16Verifier)"
WL_HEADERS="$(deploy "$WL_RPC" src/bridge/Risc0HeaderUpdater.sol:Risc0HeaderUpdater 31338 "$WL_VERIFIER" "$IMAGE_ID" "$((BURN_BLOCK-1))" "$(field "$RESULT_DIR/burn-header.json" anchorHash)")"
UNLOCK_RECEIVER="$(deploy "$WL_RPC" src/bridge/BurnUnlockReceiver.sol:BurnUnlockReceiver "$ORIGINAL" "$WL_HEADERS" "$WRAPPED")"
dev_send "$WL_RPC" "$ORIGINAL" 'bindUnlockReceiver(address)' "$UNLOCK_RECEIVER" >/dev/null
"$ROOT_DIR/.bin/bridge-proof" --rpc "$BNB_RPC" --chain-id 31338 --token "$WRAPPED" --destination-token "$ORIGINAL" \
    --id "$BURN_ID" --action burn --from-block "$BURN_BLOCK" --destination-rpc "$WL_RPC" --header-source "$WL_HEADERS" \
    --receiver "$UNLOCK_RECEIVER" --header-mode risc0_batch --risc0-host "$HOST" --header-package "$RESULT_DIR/burn-header.json" >"$RESULT_DIR/burn-package.json"
HEADER_DATA="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["headerTransaction"]["data"])' "$RESULT_DIR/burn-package.json")"
user_send "$WL_RPC" "$WL_HEADERS" --data "$HEADER_DATA" >"$RESULT_DIR/burn-header-accepted.json"
user_send "$WL_RPC" "$UNLOCK_RECEIVER" --data "$(field "$RESULT_DIR/burn-package.json" calldata)" >"$RESULT_DIR/unlock-receipt.json"
[[ "$(call_uint "$WL_RPC" "$ORIGINAL" 'balanceOf(address)(uint256)' "$USER")" == "$INITIAL" ]]
[[ "$(call_uint "$WL_RPC" "$ORIGINAL" 'lockedBalanceOf(address)(uint256)' "$USER")" == "0" ]]
[[ "$(call_uint "$BNB_RPC" "$WRAPPED" 'totalSupply()(uint256)')" == "0" ]]
python3 - "$RESULT_DIR" "$BNB_VERIFIER" "$WL_VERIFIER" <<'PY'
import datetime,json,sys
from pathlib import Path
root=Path(sys.argv[1])
summary={'measured_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'header_mode':'risc0_batch',
    'receipt_kind':'groth16','real_evm_header_acceptance':True,'mpt_roundtrip':True,
    'user_signed_header_and_claims':True,'chain_authenticated':False,'real_asset_deployment_allowed':False,
    'verifiers':sys.argv[2:],'proof_artifacts':['lock-header.json','burn-header.json']}
proofs=[json.loads((root/f'{direction}-header.json').read_text()) for direction in ('lock','burn')]
summary['header_binding']=proofs[0]['headerBinding']
summary['hash_binding_verified']=all(p.get('hashBindingVerified') is True for p in proofs)
summary['image_id']=proofs[0]['imageId']
assert all(p['headerBinding']==summary['header_binding'] and p['imageId']==summary['image_id'] for p in proofs)
if summary['header_binding']=='canonical-rlp': assert summary['hash_binding_verified']
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
PY
echo "real Groth16 header EVM acceptance: both directions; MPT lock/mint/burn/unlock: success"
echo "initial original = final; locked = 0; wrapped supply = 0; chain authentication: not implemented"
echo "Evidence: $RESULT_DIR"
