#!/usr/bin/env python3
"""Bounded offline local-header receipt export with owned Docker compression."""
import argparse
from datetime import datetime, timezone
import importlib.util
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess

ROOT = Path(__file__).resolve().parents[1]


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec); spec.loader.exec_module(result)
    return result


def main():
    def interrupted(signum, frame): raise KeyboardInterrupt('local proof interrupted')
    signal.signal(signal.SIGTERM, interrupted)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--host', type=Path, required=True)
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--binding', choices=('minimal-link', 'canonical-rlp'), default='minimal-link')
    parser.add_argument('--legacy-minimal-host', action='store_true',
        help='historical image92a4 host omits --header-binding and receipt binding metadata')
    parser.add_argument('--kind', choices=('composite', 'groth16'), required=True)
    parser.add_argument('--profile-phases', action='store_true', help='requires a profile-prover feature host; verify and save all three SDK receipt phases')
    parser.add_argument('--resume-receipt', type=Path,
        help='explicit saved actual composite/succinct; SDK reverify and reexecute input journal before remaining compression')
    parser.add_argument('--diagnostic-max-headers', type=int, choices=(4, 8, 16, 32, 64, 128), default=4,
        help='explicit larger minimal-link profiling experiment only; normal generator export cap stays4')
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--timeout-seconds', type=int, default=1800)
    parser.add_argument('--threads', type=int, default=4)
    parser.add_argument('--compression-threads', type=int, default=4, help='separate owned Docker CPU limit')
    parser.add_argument('--segment-po2', type=int, choices=(18, 19, 20), default=18,
        help='explicit SDK segment ceiling for measured memory/recursion trade-off; RSS/time limits stay enforced')
    args = parser.parse_args()
    if args.profile_phases and args.kind != 'groth16':
        parser.error('phase profiling ends in an actual Groth16 receipt')
    if args.legacy_minimal_host and args.binding != 'minimal-link':
        parser.error('historical host compatibility is limited to minimal-link')
    if args.resume_receipt and not args.profile_phases:
        parser.error('saved compression recovery requires explicit Groth16 phase profiling')
    if args.resume_receipt and args.resume_receipt.stat().st_size > 64 * 1024 * 1024:
        parser.error('saved receipt cap is64MiB')
    if args.diagnostic_max_headers != 4 and (not args.profile_phases or args.binding != 'minimal-link'):
        parser.error('larger diagnostic cap requires opt-in minimal-link phase profiling')
    if (not 1 <= args.threads <= (os.cpu_count() or 1)
        or not 1 <= args.compression_threads <= (os.cpu_count() or 1) or args.timeout_seconds < 1):
        parser.error('invalid CPU/timeout budget')
    if args.input.stat().st_size > 64 * 1024:
        parser.error('local input cap is64KiB')
    inp = json.loads(args.input.read_bytes())
    count = len(inp.get('headers', []))
    if inp.get('chain_id') not in (31337, 31338) or not 1 <= count <= (1 if args.binding == 'canonical-rlp' else args.diagnostic_max_headers):
        parser.error('local source31337/31338 required; batch exceeds chosen strict1/minimal4 or explicit diagnostic cap')
    native = module('bounded_docker_helpers', ROOT / 'scripts/run-native-proof.py')
    monitor = module('bounded_proof_monitor', ROOT / 'scripts/benchmark-header.py')
    out = args.output_dir.resolve(); out.mkdir(parents=True, exist_ok=False)
    host = out / 'risc0-host'; shutil.copy2(args.host, host)
    input_path = out / 'input.json'; shutil.copy2(args.input, input_path)
    saved_receipt = None
    if args.resume_receipt:
        saved_receipt = out / 'resume-input-receipt.json'
        shutil.copy2(args.resume_receipt, saved_receipt)
    runtime=module('proof_runtime',ROOT/'scripts/runtime-config.py')
    server=runtime.r0vm()
    if args.threads>runtime.cpus() or args.compression_threads>runtime.cpus():
        raise ValueError('thread count exceeds CPU12/available host or cgroup cap')
    env = dict(os.environ, RISC0_DEV_MODE='0', RISC0_PROVER='ipc', RISC0_SERVER_PATH=str(server),
        BRIDGE_RISC0_SEGMENT_PO2=str(args.segment_po2), RAYON_NUM_THREADS=str(args.threads))
    physical = runtime.memory_bytes()
    report = {'measuredAt': datetime.now(timezone.utc).isoformat(), 'localVerdict': 'FAIL',
        'workState': 'initializing', 'headerBinding': args.binding, 'sourceChainId': inp['chain_id'],
        'batchSize': count, 'requestedReceiptKind': args.kind, 'segmentPo2': args.segment_po2, 'threads': args.threads,
        'hostSHA256': native.sha(host), 'serverSHA256': native.sha(server), 'inputSHA256': native.sha(input_path),
        'memoryLimitKiB': int(physical * .7) // 1024, 'timeoutSeconds': args.timeout_seconds,
        'dockerImage': native.DOCKER_IMAGE, 'dockerDigest': native.DOCKER_DIGEST,
        'chainAuthenticated': False, 'realAssetDeploymentAllowed': False, 'proofGenerationAttempted': True,
        'rpcRequests': 0, 'evmAcceptanceMeasured': False, 'assetClaimsSubmitted': 0,
        'profilePhasesRequested': args.profile_phases,
        'diagnosticMaxHeaders': args.diagnostic_max_headers, 'compressionThreads': args.compression_threads,
        'normalGeneratorExportCapChanged': False,
        'freshCompositeGenerationRequested': saved_receipt is None,
        'legacyMinimalHostRequested': args.legacy_minimal_host,
        'fullGenerationWallMeasured': saved_receipt is None,
        'memoryScope': 'owned process-group sampled sum RSS; Docker separately hard-capped70% physical/no-swap'}
    if saved_receipt:
        report.update(resumeSourceReceipt=str(args.resume_receipt.resolve()),
            resumeInputReceiptSHA256=native.sha(saved_receipt))
    scope = None
    try:
        report['imageId'] = subprocess.check_output([host, '--image-id'], env=env, text=True, timeout=30).strip()
        if args.legacy_minimal_host:
            if (report['imageId'] != '0x92a4a70bc2bbde4c4627363ee596f8c6cf9beaa79635f90703a8dad4a4afe5de'
                or report['hostSHA256'] != 'df67c541072ca742259ca6fb1d5053accdd7a270326cd34a6b45b42610386209'):
                raise ValueError('historical minimal host image/binary pin mismatch')
        elif subprocess.check_output([host, '--header-binding'], env=env, text=True, timeout=30).strip() != args.binding:
            raise ValueError('compiled guest binding mismatch')
        if args.kind == 'groth16':
            subprocess.run(['docker', 'info'], capture_output=True, check=True, timeout=30)
            digests = json.loads(subprocess.check_output(['docker', 'image', 'inspect', '--format', '{{json .RepoDigests}}',
                native.DOCKER_IMAGE], text=True, timeout=15))
            if not any(d.endswith('@' + native.DOCKER_DIGEST) for d in digests):
                raise ValueError('installed compressor digest differs from pinned artifact')
            scope = native.docker_scope(out, env, int(physical * .7), args.compression_threads, '5GiB', 50)
            report['dockerScope'] = scope
        report['workState'] = 'proving'
        (out / 'summary.json').write_text(json.dumps(report, indent=2) + '\n')
        command = [str(host), '--resume-profile-receipt' if saved_receipt else
            ('--profile-receipt' if args.profile_phases else '--prove-receipt'), '--input', str(input_path)]
        if saved_receipt: command += ['--receipt-input', str(saved_receipt)]
        command += ['--receipt-output', str(out / 'receipt.json')]
        if not args.profile_phases:
            command += ['--receipt-kind', args.kind]
        elif args.diagnostic_max_headers != 4:
            command += ['--diagnostic-max-headers', str(args.diagnostic_max_headers)]
        process, resources = monitor.run_with_memory_limit(command, env,
            report['memoryLimitKiB'], args.timeout_seconds)
        (out / 'prove.stdout.json').write_text(process.stdout)
        (out / 'prove.stderr.txt').write_text(process.stderr)
        report.update(exitCode=process.returncode, resources=resources)
        if process.returncode: raise ValueError('bounded local prover failed: ' + str(process.returncode))
        metadata = json.loads(process.stdout)
        verified = subprocess.run([host, '--verify-receipt', out / 'receipt.json'], env=env, text=True,
            capture_output=True, check=True, timeout=120)
        (out / 'verified.stdout.json').write_text(verified.stdout)
        (out / 'verified.stderr.txt').write_text(verified.stderr)
        check = json.loads(verified.stdout)
        for row in (metadata, check):
            if (row.get('verified') is not True or row.get('image_id') != report['imageId']
                or (row.get('header_binding', 'minimal-link' if args.legacy_minimal_host else None) != args.binding)
                or row.get('receipt_kind') != args.kind
                or row.get('chain_authenticated') is not False or row.get('evm_compatible') != (args.kind == 'groth16')
                or len(bytes.fromhex(row.get('journal', '')[2:])) != 224):
                raise ValueError('local receipt metadata scope mismatch')
        if metadata['journal'] != check['journal'] or metadata['seal'] != check['seal']:
            raise ValueError('reverified seal/journal mismatch')
        if args.profile_phases:
            phases = metadata.get('phases', [])
            expected_kinds = ['composite', 'succinct', 'groth16']
            if saved_receipt:
                resumed_kind = metadata.get('resumed_from_kind')
                if (resumed_kind not in ('composite', 'succinct')
                    or metadata.get('reused_receipt_cryptographically_verified') is not True
                    or metadata.get('input_journal_reexecuted_and_matched') is not True
                    or metadata.get('full_generation_wall_measured') is not False
                    or native.sha(saved_receipt) != report['resumeInputReceiptSHA256']):
                    raise ValueError('saved compression recovery scope mismatch')
                expected_kinds = expected_kinds[expected_kinds.index(resumed_kind):]
            if ([p.get('receipt_kind') for p in phases] != expected_kinds
                or metadata.get('fresh_composite_generated') is not (saved_receipt is None)
                or metadata.get('diagnostic_max_headers') != args.diagnostic_max_headers
                or any(p.get('cryptographically_verified') is not True or p.get('journal_matches') is not True
                    or not isinstance(p.get('duration_ms'), int) or p['duration_ms'] < 0 for p in phases)
                or len({p.get('claim_digest') for p in phases}) != 1):
                raise ValueError('actual verified compression phase evidence missing')
            artifacts = {}
            for kind in expected_kinds:
                path = out / 'phases' / (kind + '.json')
                if path.stat().st_size > 64 * 1024 * 1024:
                    raise ValueError('phase artifact cap exceeded')
                artifacts[kind] = native.sha(path)
            if artifacts['groth16'] != native.sha(out / 'receipt.json'):
                raise ValueError('final phase/export receipt differs')
            report.update(phaseProfile=phases, phaseReceiptSHA256=artifacts, profileTotalMs=metadata['profile_total_ms'])
            if saved_receipt:
                report.update(resumedFromKind=resumed_kind, reusedReceiptCryptographicallyVerified=True,
                    inputJournalReexecutedAndMatched=True)
            else:
                report.update(sessionStats=metadata['session_stats'], compositeSegments=metadata['composite_segments'],
                    compositeAssumptions=metadata['composite_assumptions'])
        if (native.sha(host) != report['hostSHA256'] or native.sha(server) != report['serverSHA256']
            or native.sha(input_path) != report['inputSHA256']):
            raise ValueError('pinned binary/input changed')
        report.update(localVerdict='PASS', workState='complete', cryptographicallyReverified=True,
            receiptSHA256=native.sha(out / 'receipt.json'), proof=metadata)
    except BaseException as error:
        report.update(workState='failed', error=str(error)); raise
    finally:
        try: report['dockerCleanup'] = native.clean_docker_scope(scope)
        except Exception as error:
            report.update(localVerdict='FAIL', cleanupError=str(error)); raise
        finally: (out / 'summary.json').write_text(json.dumps(report, indent=2) + '\n')
    print('PASS', args.kind, report['imageId'], 'no EVM/asset submission')


if __name__ == '__main__': main()
