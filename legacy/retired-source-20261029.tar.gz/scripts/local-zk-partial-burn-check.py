#!/usr/bin/env python3
"""Fault-check wallet recovery on a cloned, historically proven local RISC0 session."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import time

spec = importlib.util.spec_from_file_location('local_client', Path(__file__).with_name('local-session.py'))
client = importlib.util.module_from_spec(spec)
spec.loader.exec_module(client)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--evidence', type=Path, default=client.ROOT / 'results/session-zk-multiblock')
    parser.add_argument('--dir', type=Path, default=client.ROOT / 'results/session-zk-partial-burn-wallet-faults')
    args = parser.parse_args()
    source = args.evidence.resolve()
    out = args.dir.resolve()
    if out.exists():
        parser.error('fresh output directory required; existing work is preserved')
    original = json.loads((source / 'session.json').read_text())
    existing = json.loads((source / 'summary.json').read_text())
    worker = json.loads((source / 'worker-summary.json').read_text())
    if (original.get('mode') != 'risc0_batch' or original.get('phase') != 'ready'
        or len(original.get('events', [])) != 6 or any(e.get('claimed') is not True for e in original['events'])
        or existing.get('receipt_kind') != 'groth16' or existing.get('claims') != 3
        or existing.get('wrapped_supply') != str(75 * 10**18) or existing.get('total_locked') != str(75 * 10**18)
        or existing.get('chain_authenticated') is not False
        or worker.get('real_groth16_generated') is not True
        or worker.get('user_submitted_header_and_claims') is not True
        or worker.get('event_blocks') != [13, 14, 15]
        or worker.get('chain_authenticated') is not False):
        parser.error('completed historical local Groth16 lock and worker session required')
    started = time.monotonic()
    out.mkdir(parents=True)
    clone = out / 'session'
    shutil.copytree(source, clone)
    host = clone / 'risc0-host'
    host_sha = hashlib.sha256(host.read_bytes()).hexdigest()
    if host_sha != original['host_sha256']:
        raise RuntimeError('historical proof host changed')
    package = json.loads((clone / 'lock-10-3-headers.json').read_text())
    proof_path = out / 'source-lock-proof.json'
    client.write_json(proof_path, package['proofReceipt'])
    verified = json.loads(subprocess.check_output([host, '--verify-receipt', proof_path], text=True, timeout=120))
    if (verified.get('verified') is not True or verified.get('receipt_kind') != 'groth16'
        or verified.get('image_id') != original['image_id'] or verified.get('journal') != package['journal']
        or verified.get('seal') != package['seal'] or verified.get('chain_authenticated') is not False):
        raise RuntimeError('historical lock Groth16 SDK receipt verification failed')
    session = client.Session(clone)
    session.start('risc0_batch')
    try:
        session.setup()
        contracts = session.data['contracts']
        user = session.data['users'][0]

        def restart():
            nonlocal session
            session.stop()
            session = client.Session(clone)
            session.start('risc0_batch')

        def check(wrapped_expected, pending_expected):
            locked = sum(int(session.view('wl', contracts['original'], 'lockedBalanceOf(address)(uint256)', u))
                         for u in session.data['users'])
            wrapped = int(session.view('bnb', contracts['wrapped'], 'totalSupply()(uint256)'))
            assert locked == 78 * 10**18 and wrapped == wrapped_expected * 10**18
            assert locked == wrapped + pending_expected * 10**18
            return {'locked': locked, 'wrapped_supply': wrapped, 'pending_burn': pending_expected * 10**18}

        def interrupted_send(*arguments):
            if fault_phase == 'before':
                raise RuntimeError('injected before broadcast')
            receipt = original_send(*arguments)
            mined.append(receipt)
            raise RuntimeError('injected after mined partial burn')

        states = [check(78, 0)]
        original_send = session.send
        mined = []
        fault_phase = 'after'
        session.send = interrupted_send
        try:
            session.action('burn', 0, 10 * 10**18)
        except RuntimeError as exc:
            assert str(exc) == 'injected after mined partial burn'
        else:
            raise AssertionError('mined partial burn fault missing')
        finally:
            session.send = original_send
        durable = json.loads((clone / 'session.json').read_text())
        assert durable['pending_action']['amount'] == 10 * 10**18 and len(durable['events']) == 6 and len(mined) == 1
        states.append(check(68, 10))
        mined_nonce = int(session.rpc('bnb', 'eth_getTransactionCount', [user, 'latest']), 16)
        mined_tip = session.rpc('bnb', 'eth_blockNumber', [])
        restart()
        session.recover()
        assert session.rpc('bnb', 'eth_blockNumber', []) == mined_tip
        assert int(session.rpc('bnb', 'eth_getTransactionCount', [user, 'latest']), 16) == mined_nonce
        assert session.data['events'][-1]['tx_hash'] == mined[0]['transactionHash'] and len(session.data['events']) == 7
        states.append(check(68, 10))
        original_send = session.send
        fault_phase = 'before'
        session.send = interrupted_send
        nonce_before = int(session.rpc('bnb', 'eth_getTransactionCount', [user, 'latest']), 16)
        try:
            session.action('burn', 0, 15 * 10**18)
        except RuntimeError as exc:
            assert str(exc) == 'injected before broadcast'
        else:
            raise AssertionError('unbroadcast remaining burn fault missing')
        finally:
            session.send = original_send
        durable = json.loads((clone / 'session.json').read_text())
        assert durable['pending_action']['wallet_nonce'] == nonce_before and len(durable['events']) == 7
        assert int(session.rpc('bnb', 'eth_getTransactionCount', [user, 'latest']), 16) == nonce_before
        states.append(check(68, 10))
        restart()
        session.recover()
        assert int(session.rpc('bnb', 'eth_getTransactionCount', [user, 'latest']), 16) == nonce_before + 1
        assert session.data['pending_action'] is None and len(session.data['events']) == 8
        states.append(check(53, 25))
        lock = next(e for e in session.data['events'] if e['action'] == 'lock' and e['user'] == user)
        receipt_path = clone / (lock['id'] + '-claim.json')
        expected_receipt = json.loads(receipt_path.read_text())
        receipt_path.unlink()
        lock['claimed'] = False
        session.save()
        restart()
        lock = next(e for e in session.data['events'] if e['action'] == 'lock' and e['user'] == user)
        destination_nonce = int(session.rpc('bnb', 'eth_getTransactionCount', [user, 'latest']), 16)
        destination_tip = session.rpc('bnb', 'eth_blockNumber', [])
        session.claim(lock)
        assert session.rpc('bnb', 'eth_blockNumber', []) == destination_tip
        assert int(session.rpc('bnb', 'eth_getTransactionCount', [user, 'latest']), 16) == destination_nonce
        assert json.loads(receipt_path.read_text())['transactionHash'] == expected_receipt['transactionHash']
        assert lock['claimed'] is True
        states.append(check(53, 25))
        report = {'localVerdict': 'PASS', 'mode': 'risc0_batch', 'historicalRisc0ImageId': original['image_id'],
                  'historicalHostSHA256': host_sha, 'historicalLockGroth16SDKReverified': True,
                  'historicalLockEvmAcceptanceRecorded': True, 'partialBurnNewProofGenerated': False,
                  'newBurnClaimsSubmitted': 0, 'newGroth16Generated': 0,
                  'additionalWalletTransactions': {'minedPartialBurnRecovery': 0, 'unbroadcastRemainingBurnRecovery': 1,
                                                   'consumedLockClaimRecovery': 0},
                  'burnTransactionHashes': [mined[0]['transactionHash'], session.data['events'][-1]['tx_hash']],
                  'states': states, 'wallSeconds': time.monotonic() - started,
                  'chainAuthenticated': False, 'realAssetDeploymentAllowed': False,
                  'historicalSummaryWasIntermediate75': True,
                  'currentWorkerStateStartedLockedAndWrapped': 78 * 10**18,
                  'remaining':'Actual partial-burn header Groth16 and unlock claims not produced; 25 units remain pending unlock'}
        client.write_json(out / 'summary.json', report)
        print('historical actual Groth16 session partial-burn wallet recovery: PASS')
    finally:
        session.stop()
        summary_path = out / 'summary.json'
        if summary_path.exists():
            completed = json.loads(summary_path.read_text())
            completed['ownedAnvilStopped'] = True
            client.write_json(summary_path, completed)


if __name__ == '__main__':
    main()
