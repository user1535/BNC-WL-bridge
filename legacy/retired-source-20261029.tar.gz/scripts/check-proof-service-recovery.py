#!/usr/bin/env python3
"""Actual local API crash recovery check; no test wallet broadcasts."""
import importlib.util
import json
from pathlib import Path
import time
import sys
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('proof_service_test',ROOT/'scripts/proof-service.py')
api=importlib.util.module_from_spec(spec);spec.loader.exec_module(api)

def ready(service, identifier):
    for _ in range(80):
        job=service.get(identifier)
        if job['state']=='ready':
            return job
        if job['state']=='failed':
            raise ValueError(job['detail'])
        time.sleep(.1)
    raise ValueError('recovery timeout')

def main():
    directory=ROOT/(sys.argv[1] if len(sys.argv)>1 else 'results/prototype-api-session-v3')
    session=api.local.Session(directory);session.start('dev')
    user=session.data['users'][0]
    def nonces():
        return {chain:session.rpc(chain,'eth_getTransactionCount',[user,'latest']) for chain in ('wl','bnb')}
    before=nonces()
    report=json.loads((directory/'api-browser-summary.json').read_text())
    assert report['passed'] is True
    jobs=[json.loads(p.read_text()) for p in (directory/'proof-jobs').glob('*.json')]
    burn=max((j for j in jobs if j['request']['action']=='burn'),key=lambda j:j['createdAt'])
    service=api.Service(directory,confirmations=2)
    try:
        request=burn['request']
        identifier=service.submit(request)['id']
        ready(service,identifier)
        package=service.get(identifier,True)
        assert package['action']=='burn' and package['amount']=='25000000000000000000'
        service.stop.set();service.worker.join(timeout=70)
        job=service.read(service.directory/(identifier+'.json'))
        job.update(state='running',detail='injected crash after durable request')
        service.save(job)
    finally:
        service.stop.set();service.worker.join(timeout=70)
    restored=api.Service(directory,confirmations=2)
    try:
        ready(restored,identifier)
        assert restored.get(identifier,True)==package
        assert restored.submit(request)['id']==identifier
        ready(restored,identifier)
        assert before==nonces()
        result=dict(passed=True,actualGoReceiptMpt=True,interruptedRunningJobRecovered=True,
                    restartPackageEqual=True,idempotentJob=True,newWalletBroadcasts=0,
                    chainAuthenticated=False,realAssetDeploymentAllowed=False)
        api.local.write_json(directory/'restart-summary.json',result)
        print(json.dumps(result))
    finally:
        restored.stop.set();restored.worker.join(timeout=70)
        session.stop()
if __name__=='__main__':
    main()
