#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
LOCK_PREFIX_FILLERS=31 LOCK_SUFFIX_FILLERS=69 exec "$ROOT_DIR/scripts/local-roundtrip.sh"
