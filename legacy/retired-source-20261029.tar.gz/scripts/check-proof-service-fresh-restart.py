#!/usr/bin/env python3
"""Reverify fresh SDK receipts, owned node/API restart and final settlement."""
import importlib.util,json,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('fresh_restart_api',ROOT/'scripts/proof-service.py')
api=importlib.util.module_from_spec(spec);spec.loader.exec_module(api)
out=ROOT/'results/prototype-header-steps';s=api.local.Session(out);s.guard()
browser=json.loads((out/'fresh-browser-summary.json').read_text());assert browser['passed']
owner=s.data['users'][0]
lock=json.loads((out/'request.json').read_text());burn=json.loads((out/'fresh-burn-request.json').read_text())
def nonces():return {c:s.rpc(c,'eth_getTransactionCount',[owner,'latest']) for c in ('wl','bnb')}
def balances():return dict(original=s.view('wl',s.data['contracts']['original'],'balanceOf(address)(uint256)',owner),locked=s.view('wl',s.data['contracts']['original'],'lockedBalanceOf(address)(uint256)',owner),wrapped=s.view('bnb',s.data['contracts']['wrapped'],'balanceOf(address)(uint256)',owner))
assert balances()==browser['after']
before=nonces();attempts=set((out/'proof-jobs').glob('*-proof-*'));proofs=[]
for f in sorted((out/'proof-jobs').glob('*-proof-*/header-package.json')):
 h=json.loads(f.read_text());report=json.loads((f.parent/'proof/summary.json').read_text());assert report['localVerdict']=='PASS'
 checked=json.loads(subprocess.check_output([str(s.prover_host()),'--verify-receipt',str(f.parent/'proof/receipt.json')],text=True,timeout=30))
 assert checked['verified'] and checked['journal']==h['journal'] and checked['seal']==h['seal']
 source='wl' if h['sourceChainId']==31337 else 'bnb'
 raw=json.loads(subprocess.check_output([str(api.local.HEADER),'--rpc',s.data['chains'][source]['rpc'],'--chain-id',str(h['sourceChainId']),'--start',str(h['startBlock']),'--count',str(h['endBlock']-h['startBlock']+1),'--confirmations','2','--header-binding','minimal-link'],text=True,timeout=30))
 assert all(raw[k]==h[k] for k in ('guestInput','journal','batchData','anchorHash','endHash','batchRoot'))
 proofs.append(dict(sourceChainId=h['sourceChainId'],range=[h['startBlock'],h['endBlock']],sdkVerified=True,sourceRequeried=True,resources=report['resources'],artifact=str(f.relative_to(ROOT))))
assert len(proofs)==2
# Reboot only owned local nodes; preserve their actual chain state.
s.stop();s.start('risc0_batch','minimal-link');assert before==nonces() and balances()==browser['after']
for saved in (lock,burn):
 path=out/'proof-jobs'/(saved['id']+'.json');j=json.loads(path.read_text());j.update(state='running',detail='fresh settlement restart injection');api.local.write_json(path,j)
service=api.Service(out,confirmations=2,prove=False)
try:
 for saved in (lock,burn):
  for _ in range(150):
   j=service.get(saved['id'])
   if j['state']=='ready':break
   if j['state']=='failed':raise ValueError(j['detail'])
   time.sleep(.1)
  else:raise ValueError('actual restart package timeout')
  p=service.get(saved['id'],True);assert p['headerCovered'] and p['transferId']==saved['request']['transferId']
 assert before==nonces() and balances()==browser['after']
 assert attempts==set((out/'proof-jobs').glob('*-proof-*'))
 assert s.view('bnb',s.data['contracts']['mint'],'claimedTransfer(bytes32)(bool)',lock['request']['transferId'])=='true'
 assert s.view('wl',s.data['contracts']['unlock'],'claimedWithdrawal(bytes32)(bool)',burn['request']['transferId'])=='true'
 transactions=[]
 for file in ('fresh-browser-summary-receipt-pending.json','fresh-browser-summary-mint-recovery-failure.json','fresh-browser-summary.json'):
  report=json.loads((out/file).read_text())
  for tx in report['walletSends']:
   receipt=s.rpc(tx['chain'],'eth_getTransactionReceipt',[tx['hash']]);assert receipt and int(receipt['status'],16)==1
   transactions.append(dict(**tx,gasUsed=int(receipt['gasUsed'],16)))
 assert len({t['hash'] for t in transactions})==5
 result=dict(passed=True,freshProofs=proofs,actualWalletTransactions=transactions,balances=balances(),
  nodesRestarted=True,apiRunningJobsRecovered=True,finalReplayFlags=True,additionalWalletBroadcasts=0,newProofsDuringRestart=0,
  orphanCompletedProofRecoveredWithoutDuplicate=True,externalExtensionTested=False,chainAuthenticated=False,realAssetDeploymentAllowed=False)
 (out/'fresh-integration-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
finally:
 service.stop.set();service.worker.join(timeout=70)
