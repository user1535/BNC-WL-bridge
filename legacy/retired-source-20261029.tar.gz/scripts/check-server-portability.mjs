import fs from 'node:fs';
import {Wallet,Interface} from '../wallet/vendor/ethers-6.15.0.min.mjs';
import {validateManifest,validatePackage,WalletClient} from '../wallet/client.mjs';
const base=process.env.BNC_TEST_URL||'http://127.0.0.1:8680';
const out=new URL('../results/server-portability-summary.json',import.meta.url);
async function request(path,body,headers={}) {
 const response=await fetch(base+path,{method:body?'POST':'GET',headers:body?{'Content-Type':'application/json',...headers}:headers,body:body?JSON.stringify(body):undefined});
 return {status:response.status,data:await response.json()};
}
async function rpc(chain,method,params=[]) {
 const v=await request('/rpc/'+chain,{jsonrpc:'2.0',id:1,method,params});
 if(v.status!==200||v.data.error)throw new Error(JSON.stringify(v.data));return v.data.result;
}
async function privateRpc(port,method,params=[]) {
 const r=await fetch('http://127.0.0.1:'+port,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({jsonrpc:'2.0',id:1,method,params})});const v=await r.json();if(v.error)throw new Error(v.error.message);return v.result;
}
const report={passed:false,awsDeployed:false,newGroth16Proofs:0,proofWorkerSignsOrBroadcasts:false,cases:[]};
try {
 const m=validateManifest((await request('/api/manifest')).data);
 if(m.chains.wl.rpc!==base+'/rpc/wl'||m.chains.bnb.rpc!==base+'/rpc/bnb')throw new Error('private loopback leaked to public manifest');
 report.cases.push('public manifest and portable RPC URLs');
 if(await rpc('wl','eth_chainId')!=='0x7a69'||await rpc('bnb','eth_chainId')!=='0x7a6a')throw new Error('wrong chain');
 for(const method of ['eth_sendTransaction','eth_sign','personal_sign','anvil_setBalance','admin_peers']) {
  const v=await request('/rpc/wl',{jsonrpc:'2.0',id:2,method,params:[]});if(v.status!==400)throw new Error('unsafe RPC accepted '+method);
 }
 for(const mutate of [m=>m.chains.wl.rpc='http://evil.test',m=>m.publicOrigin='http://evil.test',m=>m.chains.wl.id=1]) {
  const v=structuredClone(m);mutate(v);let rejected=false;try{validateManifest(v);}catch{rejected=true;}if(!rejected)throw new Error('unsafe manifest accepted');
 }
 const bad=await request('/api/manifest',null,{Origin:'https://evil.test'});if(bad.status!==403)throw new Error('bad Origin accepted');
 const spoof=await request('/api/jobs',{action:'lock',transferId:'0x'+'00'.repeat(32),fromBlock:0},{'X-Bridge-Request':'1',Origin:'https://evil.test','X-Forwarded-Host':new URL(base).host,'X-Forwarded-Proto':'https'});if(spoof.status!==403)throw new Error('proxy header trust bypass');
 report.cases.push('Origin, forwarded header, unsafe methods and manifest tamper blocked');
 // This key is generated and held only by this test client, never sent to API.
 const wallet=Wallet.createRandom();await privateRpc(8665,'anvil_setBalance',[wallet.address,'0xde0b6b3a7640000']);
 const raw=await wallet.signTransaction({to:wallet.address,value:0,chainId:31337,nonce:0,gasLimit:21000,gasPrice:1000000000});
 const tx=await rpc('wl','eth_sendRawTransaction',[raw]);let receipt;
 for(let n=0;n<100;n++){receipt=await rpc('wl','eth_getTransactionReceipt',[tx]);if(receipt)break;await new Promise(r=>setTimeout(r,50));}
 if(!receipt||receipt.status!=='0x1')throw new Error('wallet-signed raw RPC failed');
 report.walletSignedRpc={hash:tx,privateKeyCollected:false,serverSigned:false};report.cases.push('client-only signing, actual signed raw RPC and receipt');
 // Local explicit test wallet lock; API generator is read-only.
 const accounts=await privateRpc(8665,'eth_accounts'),token=new Interface(['function bridgeLock(uint256,address,uint256)']);
 const hash=await privateRpc(8665,'eth_sendTransaction',[{from:accounts[1],to:m.contracts.original,data:token.encodeFunctionData('bridgeLock',[1000000000000000000n,accounts[1],31338])}]);
 let lock;for(let n=0;n<100;n++){lock=await privateRpc(8665,'eth_getTransactionReceipt',[hash]);if(lock)break;await new Promise(r=>setTimeout(r,50));}
 const event=lock.logs.find(l=>l.address.toLowerCase()===m.contracts.original.toLowerCase()&&l.topics.length===4);
 await privateRpc(8665,'evm_mine');await privateRpc(8665,'evm_mine');
 const job=await request('/api/jobs',{action:'lock',transferId:event.topics[1],fromBlock:Number(BigInt(lock.blockNumber))},{'X-Bridge-Request':'1'});
 if(job.status!==202)throw new Error('job rejected');
 let state;for(let n=0;n<100;n++){state=await request('/api/jobs/'+job.data.id);if(state.data.state==='ready')break;if(state.data.state==='failed')throw new Error(state.data.detail);await new Promise(r=>setTimeout(r,100));}
 let p=(await request('/api/jobs/'+job.data.id+'/package')).data;
 if(!p.headerCovered) {
  const registry=new Interface(['function registerHeader(uint256,bytes32,bytes32)']);
  const operatorHash=await privateRpc(8666,'eth_sendTransaction',[{from:accounts[0],to:m.contracts.bnb_headers,data:registry.encodeFunctionData('registerHeader',[p.blockNumber,p.blockHash,p.receiptRoot])}]);
  for(let n=0;n<100;n++){if(await privateRpc(8666,'eth_getTransactionReceipt',[operatorHash]))break;await new Promise(r=>setTimeout(r,50));}
  await request('/api/jobs',job.data.request,{'X-Bridge-Request':'1'});
  for(let n=0;n<100;n++){state=await request('/api/jobs/'+job.data.id);if(state.data.state==='ready')break;await new Promise(r=>setTimeout(r,100));}
  p=(await request('/api/jobs/'+job.data.id+'/package')).data;
  report.devOperatorHeader={hash:operatorHash,explicitLocalTest:true,proofServiceSubmitted:false};
 }
 validatePackage(p,m);
 report.cases.push('relocated actual Anvil lock -> unsigned Go MPT package validation');
 let added;const fake={request:async({method,params})=>{if(method==='wallet_switchEthereumChain'&&!added)throw Object.assign(new Error('unknown chain'),{code:4902});if(method==='wallet_addEthereumChain'){added=params[0];return null;}return null;}};
 await new WalletClient(fake,m).switchChain(31337);if(added.rpcUrls[0]!==m.chains.wl.rpc)throw new Error('wrong network RPC');
 report.cases.push('unknown wallet network registration uses configured public RPC');
 report.passed=true;console.log(JSON.stringify(report));
}catch(e){report.error=e.message;throw e;}
finally{fs.writeFileSync(out,JSON.stringify(report,null,2)+'\n');}
