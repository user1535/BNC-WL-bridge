#!/usr/bin/env python3
"""Compare one explicit parameter in fresh same-input profiles; no sustained throughput claim."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path


def read_profile(path):
    directory = path.resolve()
    data = json.loads((directory / 'summary.json').read_text())
    if (data.get('localVerdict') != 'PASS' or data.get('workState') != 'complete'
        or data.get('profilePhasesRequested') is not True
        or data.get('proof', {}).get('fresh_composite_generated') is not True
        or data.get('fullGenerationWallMeasured', True) is not True
        or data.get('chainAuthenticated') is not False or data.get('realAssetDeploymentAllowed') is not False):
        raise ValueError('completed fresh local phase profile required; resumed compression is not a full-generation benchmark')
    for filename, key in [('risc0-host', 'hostSHA256'), ('input.json', 'inputSHA256'), ('receipt.json', 'receiptSHA256')]:
        if hashlib.sha256((directory / filename).read_bytes()).hexdigest() != data[key]:
            raise ValueError('profile artifact SHA changed: ' + filename)
    phases = data['phaseProfile']
    if [r['receipt_kind'] for r in phases] != ['composite', 'succinct', 'groth16']:
        raise ValueError('all three actual verified phases required')
    if len({r['claim_digest'] for r in phases}) != 1 or not all(
        r['cryptographically_verified'] is True and r['journal_matches'] is True for r in phases):
        raise ValueError('phase cryptographic evidence mismatch')
    for kind, expected in data['phaseReceiptSHA256'].items():
        if hashlib.sha256((directory / 'phases' / (kind + '.json')).read_bytes()).hexdigest() != expected:
            raise ValueError('intermediate phase artifact changed')
    wall = data['resources']['wall_seconds']
    if wall <= 0 or data['resources']['stop_reason'] is not None:
        raise ValueError('completed bounded timing required')
    row = {'directory': str(directory), 'imageId': data['imageId'], 'inputSHA256': data['inputSHA256'],
        'hostSHA256': data['hostSHA256'], 'serverSHA256': data['serverSHA256'],
        'batchSize': data['batchSize'], 'segmentPo2': data['segmentPo2'],
        'threads': data['threads'], 'compressionThreads': data.get('compressionThreads', data['dockerScope']['cpuLimit']),
        'dockerDigest': data['dockerDigest'], 'memoryLimitKiB': data['memoryLimitKiB'],
        'dockerHardMemoryLimitBytes': data['dockerScope']['memoryLimitBytes'],
        'wallSeconds': wall, 'offlineGeneratedHeadersPerSecond': data['batchSize'] / wall,
        'phaseMilliseconds': {r['receipt_kind']: r['duration_ms'] for r in phases},
        'compositeSegments': data.get('compositeSegments'), 'sessionStats': data.get('sessionStats'),
        'sampledProcessGroupPeakRssKiB': data['resources']['peak_group_rss_kb']}
    memory = directory / 'docker-memory-samples.json'
    if memory.exists():
        sampled = json.loads(memory.read_text())
        row['dockerRoundedMemoryObservation'] = {'sampleCount': len(sampled['samples']),
            'approxPeakBytes': sampled['peakObservedApproxBytes'],
            'measurementComplete': sampled.get('measurementComplete'), 'error': sampled.get('error'),
            'scope': 'rounded sampled Docker CLI observation; not exact peak allocation'}
    return row


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline', type=Path, required=True)
    parser.add_argument('--candidate', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--vary', choices=('segment','threads'), default='segment',
                        help='the sole selected parameter; thread comparisons also pin identical host and segment')
    args = parser.parse_args()
    baseline = read_profile(args.baseline); candidate = read_profile(args.candidate)
    comparable = ('imageId', 'inputSHA256', 'serverSHA256', 'batchSize',
        'compressionThreads', 'dockerDigest', 'memoryLimitKiB', 'dockerHardMemoryLimitBytes')
    comparable += ('threads',) if args.vary == 'segment' else ('segmentPo2','hostSHA256')
    mismatches = [key for key in comparable if baseline[key] != candidate[key]]
    if mismatches: raise ValueError('same-input '+args.vary+' comparison has confounders: ' + ', '.join(mismatches))
    result = {'measuredAt': datetime.now(timezone.utc).isoformat(), 'localVerdict': 'PASS',
        'scope': 'single fresh same-input SDK generation profile per '+args.vary+' configuration; not a causal speed claim',
        'variedParameter': 'segmentPo2' if args.vary == 'segment' else 'threads',
        'baseline': baseline, 'candidate': candidate,
        'wallSpeedupRatio': baseline['wallSeconds'] / candidate['wallSeconds'],
        'wallPercentChange': 100 * (candidate['wallSeconds'] / baseline['wallSeconds'] - 1),
        'chainAuthenticated': False, 'realAssetDeploymentAllowed': False,
        'sustainedAcceptedThroughputMeasuredHere': False, 'varianceAndP95Measured': False,
        'previousAcceptedThroughputFailureCleared': False}
    with args.output.open('x') as output: output.write(json.dumps(result, indent=2) + '\n')
    print('Saved same-input segment comparison; offline timing only; prior accepted failure remains')


if __name__ == '__main__': main()
