#!/usr/bin/env python3
"""Exercise actual HTTP main SIGINT/SIGTERM cleanup with harmless owned children."""
import importlib.util,json,os,signal,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'results/prototype-header-steps/shutdown-fixture'
OUT.mkdir(exist_ok=True)
if len(sys.argv)>1 and sys.argv[1]=='child':
 import threading
 spec=importlib.util.spec_from_file_location('shutdown_api',ROOT/'scripts/proof-service.py')
 api=importlib.util.module_from_spec(spec);spec.loader.exec_module(api)
 class HarmlessService:
  def __init__(self,*a,**kw):
   self.stop=threading.Event()
   # This is a sleeping process, not a prover. Main's real signal branch owns it.
   self.prover_process=subprocess.Popen([sys.executable,'-c','import time; time.sleep(60)'],start_new_session=True)
   (OUT/'owned-child.json').write_text(json.dumps(dict(pid=self.prover_process.pid)))
   self.worker=threading.Thread(target=self.prover_process.wait,daemon=True);self.worker.start()
 api.Service=HarmlessService
 sys.argv=['proof-service.py','--session',str(OUT),'--port','8581']
 api.main()
 sys.exit(0)
results=[]
for sig in (signal.SIGINT,signal.SIGTERM):
 (OUT/'owned-child.json').unlink(missing_ok=True)
 with (OUT/('signal-'+str(sig)+'.log')).open('w') as log:
  parent=subprocess.Popen([sys.executable,__file__,'child'],stdout=log,stderr=log)
  try:
   for _ in range(100):
    if (OUT/'owned-child.json').exists() and 'http://' in (OUT/('signal-'+str(sig)+'.log')).read_text():break
    if parent.poll() is not None:raise RuntimeError('fixture server failed')
    time.sleep(.05)
   else:raise RuntimeError('fixture server timeout')
   owned=json.loads((OUT/'owned-child.json').read_text())['pid']
   parent.send_signal(sig);parent.wait(timeout=10)
   assert parent.returncode==0
   assert not Path('/proc',str(owned)).exists(),'owned sleeping worker was not reaped'
   results.append(dict(signal=sig.name,serverExited=True,ownedChildReaped=True))
  finally:
   if parent.poll() is None:parent.kill();parent.wait()
report=dict(passed=True,cases=results,fixture='harmless sleeping owned process; actual HTTP main signal handler',freshProverCancellationMeasured=False,newProofs=0,serverBroadcasts=0)
(OUT.parent/'shutdown-summary.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
