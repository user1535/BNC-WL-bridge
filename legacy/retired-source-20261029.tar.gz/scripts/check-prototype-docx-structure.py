"""Bundled Python OOXML checks; never substitutes for page rendering."""
from pathlib import Path
from zipfile import ZipFile
from docx import Document
import datetime,hashlib,json
ROOT=Path(__file__).resolve().parents[1]
import argparse,os
parser=argparse.ArgumentParser();parser.add_argument('--source',type=Path,default=Path(os.environ.get('BNC_DOCX_SOURCE',ROOT/'docs/source/bridge-design.docx')))
source=parser.parse_args().source
target=ROOT/'docs/private_keyless_Bridge.docx'
doc=Document(target)
with ZipFile(source) as a,ZipFile(target) as b:preserved=a.read('word/media/image1.png')==b.read('word/media/image1.png')
assert preserved and doc.paragraphs[0].style.name=='Title'
assert any(p.text=='새 증명 생성과 사용자 자산 청구' for p in doc.paragraphs)
assert any('원본 100000000000000000000, 잠금 0, wrapped 0' in p.text for p in doc.paragraphs)
qa=dict(updatedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),contentUpdated=True,titleStyle='Title',diagramPreserved=True,paragraphs=len(doc.paragraphs),sha256=hashlib.sha256(target.read_bytes()).hexdigest(),freshRoundtripDocumented=True,renderVerified=False,renderError='bundled renderer soffice.exe not found')
(ROOT/'results/prototype-docx-qa.json').write_text(json.dumps(qa,indent=2)+'\n',encoding='utf-8');print(json.dumps(qa))
