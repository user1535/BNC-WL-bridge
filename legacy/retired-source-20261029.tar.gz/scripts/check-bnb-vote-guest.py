#!/usr/bin/env python3
"""Bounded execution of the separate supplied-epoch BNB BLS guest; no proof/RPC."""
import argparse
import copy
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

from importlib.util import module_from_spec, spec_from_file_location

ROOT = Path(__file__).resolve().parent.parent
WORK = ROOT / "risc0/bnb-vote"
WITNESSES = ROOT / "results/gates/parlia-seals-snapshot-both-paths/bls-sealed-header-prague"
BINDING = "bnb-vote-native-rlp-supplied-epoch"
spec = spec_from_file_location("bounded_execution", ROOT / "scripts/benchmark-header.py")
monitor = module_from_spec(spec)
spec.loader.exec_module(monitor)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def keccak(value):
    # Foundry's offline Keccak is independent of the Rust native journal code.
    return bytes.fromhex(subprocess.check_output(
        ["cast", "keccak", "0x" + value.hex()], text=True, timeout=10).strip()[2:])


def word(value):
    return value.to_bytes(32, "big")


def expected_journal(value, witness):
    b = value["batch"]
    headers = b["headers"]
    level = [keccak(word(56) + word(h["number"]) + bytes(h["block_hash"])
                    + bytes(h["parent_hash"]) + bytes(h["receipt_root"])) for h in headers]
    while len(level) > 1:
        level = [keccak(level[i] + (level[i + 1] if i + 1 < len(level) else level[i]))
                 for i in range(0, len(level), 2)]
    w = witness["signedVote"]["evmWitness"]
    return (word(56) + word(headers[0]["number"]) + word(headers[-1]["number"])
            + word(3) + bytes(b["anchor_hash"]) + bytes(headers[-1]["block_hash"])
            + level[0] + bytes(value["epoch"]["block_hash"])
            + bytes.fromhex(w["voteDataHash"][2:]) + word(w["voteBitmap"])
            + word(w["validatorCount"]))


def replace_header_bytes(header, needle, replacement):
    raw = bytes(header["canonical_rlp"])
    if len(needle) != len(replacement) or raw.count(needle) != 1:
        raise ValueError("one equal-width public mutation required")
    raw = raw.replace(needle, replacement)
    header["canonical_rlp"] = list(raw)
    header["block_hash"] = list(keccak(raw))


def main():
    global WORK, BINDING
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--dir", type=Path, required=True)
    p.add_argument("--host", type=Path)
    p.add_argument("--coordinate-hints", action="store_true",
                   help="separate candidate; checked uncompressed hints must rebind original raw slots")
    p.add_argument("--timeout-seconds", type=int, default=600)
    args = p.parse_args()
    if not 1 <= args.timeout_seconds <= 600:
        p.error("timeout bound1..600 seconds per execution")
    if args.coordinate_hints:
        WORK = ROOT / "risc0/bnb-vote-hinted"
        BINDING = "bnb-vote-native-rlp-supplied-epoch-hinted"
    host_source = args.host or WORK / ("target/release/bridge-bnb-vote-hinted-host" if args.coordinate_hints
                                      else "target/release/bridge-bnb-vote-host")
    out = args.dir.resolve()
    out.mkdir(parents=True, exist_ok=False)
    host = out / "risc0-host"
    shutil.copyfile(host_source.resolve(), host)
    host.chmod(0o700)
    server = Path.home() / ".cargo/bin/r0vm"
    env = os.environ.copy()
    env.update(RISC0_DEV_MODE="0", RISC0_PROVER="ipc", RISC0_SERVER_PATH=str(server),
               RAYON_NUM_THREADS="4", BRIDGE_RISC0_SEGMENT_PO2="18")
    binding = subprocess.check_output([str(host), "--header-binding"], env=env,
                                      text=True, timeout=10).strip()
    if binding != BINDING:
        raise ValueError("distinct BNB vote binding required")
    image = subprocess.check_output([str(host), "--image-id"], env=env,
                                    text=True, timeout=10).strip()
    manifest = json.loads((WORK / "fixture-manifest.json").read_text())
    for item in manifest["files"]:
        if sha(ROOT / item["path"]) != item["sha256"]:
            raise ValueError("immutable fixture changed")
    sources = [*WORK.glob("**/src/*.rs"), *WORK.glob("**/Cargo.toml"),
               WORK / "Cargo.lock", WORK / "methods/guest/Cargo.lock",
               WORK / "methods/build.rs", ROOT / "risc0/native/types/src/lib.rs",
               * (ROOT / "risc0/native-binding/src").glob("*.rs")]
    sources = sorted(set(x for x in sources if "/target/" not in str(x)))
    physical = os.sysconf("SC_PHYS_PAGES") * os.sysconf("SC_PAGE_SIZE") // 1024
    metadata = {"imageId": image, "headerBinding": binding,
                "hostSHA256": sha(host), "serverSHA256": sha(server),
                "r0vmVersion": subprocess.check_output([str(server), "--version"],
                                                        text=True, timeout=10).strip(),
                "sourceSHA256": {str(x.relative_to(ROOT)): sha(x) for x in sources},
                "fixtureManifestSHA256": sha(WORK / "fixture-manifest.json"),
                "segmentPo2": 18, "threads": 4, "sessionCycleLimit": 1 << 27,
                "timeoutSeconds": args.timeout_seconds, "physicalKB": physical,
                "memoryLimitKB": int(physical * .7),
                "memoryMeasurement": "sampled process group RSS sum; shared pages may be counted twice",
                "proofGenerated": False, "evmAcceptanceMeasured": False,
                "chainAuthenticated": False, "realAssetDeploymentAllowed": False}
    save(out / "metadata.json", metadata)
    originals = {label: json.loads((WORK / f"types/fixtures/{label}.json").read_text())
                 for label in ("parent", "latest")}
    witnesses = {label: json.loads((WITNESSES / f"{label}-witness.json").read_text())
                 for label in originals}
    tests = []
    for name in ("wrong-domain", "wrong-receipt-root", "wrong-epoch-hash", "short-batch"):
        value = copy.deepcopy(originals["parent"])
        if name == "wrong-domain":
            value["batch"]["chain_id"] = 103
        elif name == "wrong-receipt-root":
            value["batch"]["headers"][1]["receipt_root"][0] ^= 1
        elif name == "wrong-epoch-hash":
            value["epoch"]["block_hash"][0] ^= 1
        else:
            value["batch"]["headers"].pop()
        tests.append((name, value, "supplied epoch BLS/native binding failed", None))
    for name in ("parent", "latest"):
        tests.append((name, originals[name], None, expected_journal(originals[name], witnesses[name])))
    value = copy.deepcopy(originals["parent"])
    left = witnesses["parent"]["signedVote"]["inspection"]["vote"]["aggregateSignature"]
    right = witnesses["latest"]["signedVote"]["inspection"]["vote"]["aggregateSignature"]
    replace_header_bytes(value["batch"]["headers"][2], bytes.fromhex(left[2:]), bytes.fromhex(right[2:]))
    if args.coordinate_hints:
        value["signature_coordinates"] = originals["latest"]["signature_coordinates"][:]
    tests.append(("other-valid-signature", value, "BLS pairing mismatch", None))
    supplied = witnesses["parent"]["signedVote"]["inspection"]["suppliedEpoch"]["validators"]
    bitmap = witnesses["parent"]["signedVote"]["evmWitness"]["voteBitmap"]
    nonparticipant = next(i for i in range(len(supplied)) if bitmap & (1 << i) == 0)
    public_key = bytes.fromhex(supplied[nonparticipant]["publicKey"][2:])
    for name, flag, failure in (("nonparticipant-infinity", 0xc0, "BLS key infinity"),
                               ("nonparticipant-torsion", 0x80, "BLS key subgroup/canonicality")):
        value = copy.deepcopy(originals["parent"])
        replace_header_bytes(value["epoch"], public_key, bytes([flag]) + bytes(47))
        if args.coordinate_hints:
            coordinates = bytearray(96)
            if flag == 0xc0:
                coordinates[0] = 0x40
            else:
                coordinates[-1] = 2  # G1(0,2) is on curve but not in prime subgroup.
            value["key_coordinates"][nonparticipant] = list(coordinates)
        tests.append((name, value, failure, None))
    if args.coordinate_hints:
        for name, failure in (("hint-count", "key coordinate count"),
                              ("hint-key-width", "key coordinate width"),
                              ("hint-key-order", "key compressed binding"),
                              ("hint-nonparticipant-other-key", "key compressed binding"),
                              ("hint-key-noncanonical", "BLS key subgroup/canonicality"),
                              ("hint-key-off-curve", "BLS key subgroup/canonicality"),
                              ("hint-signature-width", "signature coordinate width"),
                              ("hint-other-signature", "signature compressed binding"),
                              ("hint-signature-noncanonical", "signature subgroup/canonicality"),
                              ("hint-signature-off-curve", "signature subgroup/canonicality")):
            value = copy.deepcopy(originals["parent"])
            if name == "hint-count": value["key_coordinates"].pop()
            elif name == "hint-key-width": value["key_coordinates"][0].pop()
            elif name == "hint-key-order":
                value["key_coordinates"][0], value["key_coordinates"][1] = value["key_coordinates"][1], value["key_coordinates"][0]
            elif name == "hint-nonparticipant-other-key": value["key_coordinates"][nonparticipant] = value["key_coordinates"][0][:]
            elif name == "hint-key-noncanonical": value["key_coordinates"][0][0] |= 0x80
            elif name == "hint-key-off-curve": value["key_coordinates"][0][-1] ^= 1
            elif name == "hint-signature-width": value["signature_coordinates"].pop()
            elif name == "hint-other-signature": value["signature_coordinates"] = originals["latest"]["signature_coordinates"][:]
            elif name == "hint-signature-noncanonical": value["signature_coordinates"][0] |= 0x80
            else: value["signature_coordinates"][-1] ^= 1
            tests.append((name, value, failure, None))
    summary = {"recordedAt": datetime.now(timezone.utc).isoformat(), "status": "RUNNING",
               "imageId": image, "headerBinding": binding, "coordinateHintsChecked": args.coordinate_hints, "results": [],
               "proofGenerated": False, "evmAcceptanceMeasured": False,
               "snapshotAuthenticated": False, "ecdsaSealVerified": False,
               "finalityVerified": False, "chainAuthenticated": False,
               "realAssetDeploymentAllowed": False}
    for name, value, failure, expected in tests:
        (out / f"{name}-input.json").write_text(json.dumps(value, separators=(",", ":")) + "\n")
        if sha(host) != metadata["hostSHA256"] or sha(server) != metadata["serverSHA256"]:
            raise ValueError("pinned execution runtime changed")
        result, resources = monitor.run_with_memory_limit(
            [str(host), "--execute-input", str(out / f"{name}-input.json")], env,
            metadata["memoryLimitKB"], args.timeout_seconds)
        (out / f"{name}.stdout.txt").write_text(result.stdout)
        (out / f"{name}.stderr.txt").write_text(result.stderr)
        save(out / f"{name}.resources.json", resources)
        row = {"case": name, "inputSHA256": sha(out / f"{name}-input.json"),
               "returncode": result.returncode, "resources": resources}
        if failure:
            ok = result.returncode != 0 and resources["stop_reason"] is None and failure in result.stderr
            row.update(expectedRejection=failure, passed=ok)
        else:
            output = json.loads(result.stdout) if result.returncode == 0 else {}
            ok = (result.returncode == 0 and output.get("imageId") == image
                  and output.get("headerBinding") == BINDING
                  and output.get("journal") == "0x" + expected.hex()
                  and output.get("guestExecuted") is True
                  and output.get("suppliedEpochBlsMathVerified") is True
                  and output.get("nativeHeadersBound") == 3
                  and output.get("sourceChainId") == 56
                  and all(output.get(k) is False for k in ("proofGenerated", "evmAcceptanceMeasured",
                      "snapshotAuthenticated", "ecdsaSealVerified", "finalityVerified",
                      "chainAuthenticated", "realAssetDeploymentAllowed")))
            row.update(passed=ok, execution=output,
                       independentGoWitnessSHA256=sha(WITNESSES / f"{name}-witness.json"))
        summary["results"].append(row)
        summary["status"] = "RUNNING" if ok else "FAIL"
        save(out / "summary.json", summary)
        print(f"{name}: {'PASS' if ok else 'FAIL'} wall={resources['wall_seconds']:.3f}s", flush=True)
        if not ok:
            return 1
    summary["status"] = "PASS"
    save(out / "summary.json", summary)
    print(out / "summary.json", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
