#!/usr/bin/env python3
"""Stress actual Groth16 accepted heads on independent clones of a local session."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import time
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
SOURCE = 'http://127.0.0.1:8575'
DEST = 'http://127.0.0.1:8576'
USER = '0x70997970c51812dc3a010c7d01b50e0d17dc79c8'


def rpc(url, method, params=None):
    req = urllib.request.Request(url, json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params or []}).encode(), {'Content-Type': 'application/json'})
    with urllib.request.urlopen(req, timeout=15) as response:
        result = json.load(response)
    if 'error' in result:
        raise RuntimeError(result['error'])
    return result['result']


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--session', type=Path, default=ROOT / 'results/session-zk-multiblock')
    parser.add_argument('--output-dir', type=Path, default=ROOT / 'results/paced-groth16')
    parser.add_argument('--seconds', type=int, default=300)
    parser.add_argument('--block-time', type=int, default=1)
    parser.add_argument('--max-lag', type=int, default=8)
    args = parser.parse_args()
    if args.seconds < 300 or args.block_time <= 0 or args.max_lag < 0:
        raise ValueError('requires >=300 seconds, positive local block interval and nonnegative lag limit')
    for port in (8575, 8576):
        with socket.socket() as sock:
            if sock.connect_ex(('127.0.0.1', port)) == 0:
                raise RuntimeError('port already in use; unknown service preserved')
    manifest = json.loads((args.session / 'session.json').read_text())
    host = args.session.resolve() / 'risc0-host'
    if manifest['mode'] != 'risc0_batch' or hashlib.sha256(host.read_bytes()).hexdigest() != manifest['host_sha256']:
        raise ValueError('requires an intact, pinned, genuine local-zk session')
    args.output_dir.mkdir(parents=True, exist_ok=False)
    output = args.output_dir.resolve()
    processes, logs = [], []
    samples, accepted, handled = [], [], set()
    worker = None
    summary = {'chainAuthenticated': False, 'realAssetDeploymentAllowed': False, 'generatorTransactionsSent': 0,
               'sourceRole': 'WorldLand local clone', 'sourceChainId': 31337, 'destinationChainId': 31338,
               'configuredLocalBlockIntervalSeconds': args.block_time, 'imageId': manifest['image_id'],
               'hostSHA256': manifest['host_sha256'], 'acceptedBatches': accepted, 'verdict': 'INCONCLUSIVE'}
    env = dict(os.environ, RISC0_DEV_MODE='0', RISC0_PROVER='ipc', RISC0_SERVER_PATH=str(Path.home() / '.cargo/bin/r0vm'))
    try:
        for chain, port, ident in (('wl', 8575, 31337), ('bnb', 8576, 31338)):
            source_state = args.session / f'{chain}-state.json'
            snapshot = output / f'{chain}-initial-state.json'
            snapshot.write_bytes(source_state.read_bytes())
            summary[f'{chain}InitialStateSHA256'] = hashlib.sha256(snapshot.read_bytes()).hexdigest()
            log = (output / f'{chain}-anvil.log').open('w'); logs.append(log)
            proc = subprocess.Popen(['anvil', '--silent', '--host', '127.0.0.1', '--port', str(port), '--chain-id', str(ident),
                                     '--load-state', str(snapshot), '--preserve-historical-states'], stdout=log, stderr=log)
            processes.append(proc)
        for url, ident in ((SOURCE, 31337), (DEST, 31338)):
            for _ in range(50):
                try:
                    if int(rpc(url, 'eth_chainId'), 16) == ident: break
                except OSError: pass
                time.sleep(.2)
            else: raise RuntimeError('clone did not start')
        contract = manifest['contracts']['bnb_headers']
        monitor = [str(ROOT / '.bin/bridge-monitor'), '--source-rpc', SOURCE, '--destination-rpc', DEST,
                   '--source-chain-id', '31337', '--header-source', contract]
        # Capture a preproduction baseline before enabling interval mining.
        initial = json.loads(subprocess.check_output(monitor, env=env, text=True, timeout=65))
        if initial['acceptedHead'] is None:
            raise RuntimeError('fixture needs actual accepted coverage, not an initial anchor')
        samples.append(dict(initial, elapsedSeconds=0.0))
        rpc(SOURCE, 'evm_setIntervalMining', [int(args.block_time)])
        log = (output / 'worker.log').open('w'); logs.append(log)
        worker = subprocess.Popen([str(ROOT / '.bin/bridge-header-worker'), '--source-rpc', SOURCE, '--destination-rpc', DEST,
                                   '--source-chain-id', '31337', '--header-source', contract, '--risc0-host', str(host),
                                   '--proof-cache', str(output / 'proof-cache'), '--output-dir', str(output / 'proposals'),
                                   '--max-batch', '4', '--max-age', '10s', '--watch'], env=env, stdout=log, stderr=log,
                                  start_new_session=True)
        started, next_sample = time.monotonic(), 10
        print('actual Groth16 worker + separate local wallet; 1-second source production; 300-second measurement', flush=True)
        while True:
            elapsed = time.monotonic()-started
            for proposal in sorted((output / 'proposals').glob('*.json')):
                if proposal.name in handled: continue
                p = json.loads(proposal.read_text())
                handled.add(proposal.name)
                tx = p.get('headerTransaction')
                if p['status'] != 'pending_acceptance' or not tx: continue
                if tx['role'] != 'user' or tx['chainId'] != 31338 or tx['to'].lower() != contract.lower():
                    raise ValueError('unexpected unsigned header transaction')
                # The local demo wallet is separate from the generator; no private keys are stored.
                result = subprocess.run(['cast', 'send', contract, '--data', tx['data'], '--rpc-url', DEST, '--unlocked',
                                         '--from', USER, '--json'], env=env, capture_output=True, text=True, timeout=30)
                (output / f'{proposal.stem}-wallet.stderr').write_text(result.stderr)
                if result.returncode: raise RuntimeError('user header submission failed')
                receipt = json.loads(result.stdout)
                if int(receipt['status'], 16) != 1: raise RuntimeError('user header reverted')
                (output / f'{proposal.stem}-accepted.json').write_text(json.dumps(receipt, indent=2)+'\n')
                accepted.append({'start': p['headerPackage']['startBlock'], 'end': p['headerPackage']['endBlock'],
                                 'transactionHash': receipt['transactionHash']})
                print(f'user accepted actual Groth16 batch ending {accepted[-1]["end"]}', flush=True)
            if elapsed >= next_sample or elapsed >= args.seconds:
                sample = json.loads(subprocess.check_output(monitor, env=env, text=True, timeout=65))
                sample['elapsedSeconds'] = time.monotonic()-started
                samples.append(sample)
                (output / 'samples.json').write_text(json.dumps(samples, indent=2)+'\n')
                next_sample += 10
                if sample['elapsedSeconds'] >= args.seconds: break
            if worker.poll() is not None: raise RuntimeError('header worker terminated early; see worker.log')
            time.sleep(.5)
        evaluated = subprocess.check_output([str(ROOT / '.bin/bridge-rate-verdict')], input=json.dumps({'samples': samples, 'maxLag': args.max_lag}),
                                            text=True, timeout=10)
        summary.update(json.loads(evaluated))
        summary['maximumLagPolicy'] = args.max_lag
        summary['sampleCount'] = len(samples)
        summary['sourceHeads'] = [samples[0]['sourceHead'], samples[-1]['sourceHead']]
        summary['acceptedHeads'] = [samples[0]['acceptedHead'], samples[-1]['acceptedHead']]
        print(json.dumps(summary), flush=True)
    except BaseException as error:
        summary['error'] = str(error)
        raise
    finally:
        # SIGTERM reaches worker context, which cancels scoped r0vm/Docker children.
        if worker and worker.poll() is None:
            worker.send_signal(signal.SIGTERM)
            try: worker.wait(timeout=30)
            except subprocess.TimeoutExpired:
                os.killpg(worker.pid, signal.SIGKILL); worker.wait()
        for proc in processes:
            proc.terminate()
            try: proc.wait(timeout=10)
            except subprocess.TimeoutExpired: proc.kill(); proc.wait()
        for log in logs: log.close()
        (output / 'summary.json').write_text(json.dumps(summary, indent=2)+'\n')


if __name__ == '__main__': main()
