#!/usr/bin/env python3
"""Pace a local BNB-like Anvil chain and prove real linked header input for 5 minutes."""
import argparse
import csv
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request

ROOT = Path(__file__).resolve().parent.parent
HOST = ROOT / "risc0/target/release/bridge-header-benchmark"
RPC = "http://127.0.0.1:8546"


def rpc(method, params=None):
    body = json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params or []}).encode()
    request = urllib.request.Request(RPC, data=body, headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(request, timeout=10) as response:
        result = json.load(response)
    if "error" in result:
        raise RuntimeError(result["error"])
    return result["result"]


def bytes32(hex_string):
    if len(hex_string) != 66:
        raise ValueError("expected bytes32")
    return list(bytes.fromhex(hex_string[2:]))


def port_available():
    with socket.socket() as connection:
        return connection.connect_ex(("127.0.0.1", 8546)) != 0


def run(seconds):
    if not HOST.is_file():
        raise RuntimeError("build RISC0 host first")
    if not port_available():
        raise RuntimeError("port 8546 is already in use")
    output = ROOT / "results/bnb-rate"
    output.mkdir(parents=True, exist_ok=True)
    log_path = output / "anvil.log"
    with log_path.open("w") as logfile:
        anvil = subprocess.Popen(["anvil", "--silent", "--host", "127.0.0.1", "--port", "8546",
                                  "--chain-id", "31338", "--block-time", "1"], stdout=logfile, stderr=logfile)
        try:
            for _ in range(50):
                try:
                    if int(rpc("eth_chainId"), 16) == 31338:
                        break
                except Exception:
                    time.sleep(0.2)
            else:
                raise RuntimeError("local chain did not start")
            return measure(seconds, output)
        finally:
            anvil.terminate()
            try:
                anvil.wait(timeout=5)
            except subprocess.TimeoutExpired:
                anvil.kill()
                anvil.wait()


def measure(seconds, output):
    samples_path = output / "samples.csv"
    fields = ["elapsed_s", "source_head", "proof_head", "accepted_head", "header_lag",
              "accepted_lag", "prove_ms", "execute_ms", "peak_kb", "user_cpu_s", "batch_size"]
    start = time.monotonic()
    proof_head = 0
    previous_hash = rpc("eth_getBlockByNumber", ["0x0", False])["hash"]
    lag_samples = []
    lag_observations = []
    peak_kb = 0
    total_prove_ms = 0
    total_cpu_s = 0.0
    env = os.environ.copy()
    env["RISC0_SERVER_PATH"] = str(Path.home() / ".cargo/bin/r0vm")
    env["RISC0_RECEIPT_KIND"] = "composite"
    with samples_path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        while time.monotonic() - start < seconds:
            source_head = int(rpc("eth_blockNumber"), 16)
            if source_head <= proof_head:
                time.sleep(0.5)
                continue
            target = proof_head + 1
            header = rpc("eth_getBlockByNumber", [hex(target), False])
            if header is None:
                raise RuntimeError(f"missing header {target}")
            if header["parentHash"].lower() != previous_hash.lower():
                raise RuntimeError(f"source header continuity failed at {target}")
            batch = {"chain_id": 31338, "anchor_hash": bytes32(header["parentHash"]), "headers": [{
                "number": target,
                "block_hash": bytes32(header["hash"]),
                "parent_hash": bytes32(header["parentHash"]),
                "receipt_root": bytes32(header["receiptsRoot"]),
            }]}
            with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as temp:
                json.dump(batch, temp)
                input_path = temp.name
            try:
                process = subprocess.run(["/usr/bin/time", "-f", "peak_kb=%M user_cpu_s=%U",
                    str(HOST), "--input", input_path], env=env, text=True, capture_output=True, timeout=240)
            finally:
                os.unlink(input_path)
            if process.returncode != 0:
                raise RuntimeError(f"RISC0 proof failed: {process.stderr}")
            result = json.loads(process.stdout.strip())
            if not result["verified"] or result["synthetic_input"] or result["receipt_kind"] != "composite" or result["end_block"] != target:
                raise RuntimeError("unverified or mismatched RISC0 result")
            resource_line = next(line for line in process.stderr.splitlines() if line.startswith("peak_kb="))
            measurements = dict(item.split("=", 1) for item in resource_line.split())
            proof_head = target
            previous_hash = header["hash"]
            source_head = int(rpc("eth_blockNumber"), 16)
            lag = max(0, source_head - proof_head)
            lag_samples.append(lag)
            lag_observations.append((time.monotonic() - start, lag))
            peak_kb = max(peak_kb, int(measurements["peak_kb"]))
            total_prove_ms += result["prove_ms"]
            total_cpu_s += float(measurements["user_cpu_s"])
            row = {"elapsed_s": round(time.monotonic()-start, 3), "source_head": source_head,
                "proof_head": proof_head, "accepted_head": 0, "header_lag": lag,
                "accepted_lag": source_head, "prove_ms": result["prove_ms"],
                "execute_ms": result["execute_ms"], "peak_kb": measurements["peak_kb"],
                "user_cpu_s": measurements["user_cpu_s"], "batch_size": 1}
            writer.writerow(row)
            handle.flush()
            print(f"elapsed={row['elapsed_s']}s source={source_head} proofed={proof_head} lag={lag}", flush=True)
    elapsed = time.monotonic() - start
    source_head = int(rpc("eth_blockNumber"), 16)
    proof_rate = proof_head / elapsed
    source_rate = source_head / elapsed
    lag_growth = ((lag_observations[-1][1] - lag_observations[0][1]) /
                  (lag_observations[-1][0] - lag_observations[0][0])) if len(lag_observations) >= 2 else None
    summary = {
        "receipt_kind": "composite", "duration_s": round(elapsed, 3), "source_block_interval_s": elapsed/source_head if source_head else None,
        "generated_blocks": source_head, "proofed_blocks": proof_head, "accepted_blocks": 0,
        "accepted_note": "No on-chain RISC0 header updater is connected; acceptance was not tested",
        "headers_per_second": proof_rate, "source_headers_per_second": source_rate,
        "lag_growth_per_second": lag_growth, "average_header_lag": sum(lag_samples)/len(lag_samples) if lag_samples else None,
        "maximum_header_lag": max(lag_samples) if lag_samples else None,
        "ending_header_lag": max(0, source_head-proof_head), "batch_size": 1,
        "average_prove_ms": total_prove_ms/proof_head if proof_head else None,
        "peak_kb": peak_kb, "proving_user_cpu_s": total_cpu_s,
        "verdict": "FAIL" if len(lag_samples) >= 3 and lag_growth is not None and lag_growth > 0 and proof_rate < source_rate else "INCONCLUSIVE",
        "complete_five_minute_run": elapsed >= 300,
    }
    (output / "summary.json").write_text(json.dumps(summary, indent=2)+"\n")
    print(json.dumps(summary, ensure_ascii=False), flush=True)
    return 0


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--seconds", type=int, default=300)
    args = parser.parse_args()
    if args.seconds < 1:
        parser.error("--seconds must be positive")
    try:
        sys.exit(run(args.seconds))
    except Exception as error:
        print(error, file=sys.stderr)
        sys.exit(1)
