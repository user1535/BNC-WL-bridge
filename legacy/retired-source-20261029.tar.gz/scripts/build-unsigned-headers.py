#!/usr/bin/env python3
"""Generate one bounded, unsigned local Groth16 header package; never broadcast."""
import argparse
import fcntl
import base64
import hashlib
import importlib.util
import json
from pathlib import Path
import struct
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
def module(name,file):
    spec=importlib.util.spec_from_file_location(name,ROOT/'scripts'/file)
    result=importlib.util.module_from_spec(spec);spec.loader.exec_module(result);return result
local=module('unsigned_header_session','local-session.py')
def bounded_file(path, limit=64*1024*1024):
    if not path.is_file() or path.is_symlink() or path.stat().st_size>limit:
        raise ValueError('invalid artifact or file cap exceeded')
    return path.read_bytes()

def build(session, action, start, count, output):
    session.guard()
    if session.data['mode']!='risc0_batch':
        raise ValueError('Groth16 session required')
    binding=session.data.get('header_binding','minimal-link')
    if not 1<=count<=(1 if binding=='canonical-rlp' else 4):
        raise ValueError('normal strict1/minimal4 proving cap')
    source,destination,_,_,updater,_=session.route(action)
    host=session.prover_host()
    image=session.data['image_id']
    if (int(session.view(destination,updater,'latestBlock()(uint256)'))+1!=start
        or session.view(destination,updater,'guestImageId()(bytes32)').lower()!=image.lower()):
        raise ValueError('destination updater head/image changed')
    out=Path(output).resolve();out.mkdir(parents=True,exist_ok=False)
    cmd=[str(local.HEADER),'--rpc',session.data['chains'][source]['rpc'],'--chain-id',str(session.data['chains'][source]['id']),
         '--start',str(start),'--count',str(count),'--header-binding',binding]
    raw=json.loads(subprocess.check_output(cmd,text=True,timeout=60))
    if raw['anchorHash'].lower()!=session.view(destination,updater,'latestHash()(bytes32)').lower():
        raise ValueError('source anchor differs from destination updater')
    local.write_json(out/'source-package.json',raw)
    local.write_json(out/'input.json',raw['guestInput'])
    subprocess.run([sys.executable,str(ROOT/'scripts/run-local-proof.py'),'--host',str(host),
        '--input',str(out/'input.json'),'--binding',binding,'--kind','groth16','--output-dir',str(out/'proof'),
        '--threads',str(local.runtime.cpus()),'--compression-threads',str(local.runtime.cpus()),'--segment-po2','19','--timeout-seconds','1800'],check=True)
    report=json.loads(bounded_file(out/'proof/summary.json'))
    receipt=bounded_file(out/'proof/receipt.json')
    if (report.get('localVerdict')!='PASS' or report.get('cryptographicallyReverified') is not True
        or report.get('imageId')!=image or report.get('receiptSHA256')!=hashlib.sha256(receipt).hexdigest()):
        raise ValueError('bounded actual Groth16 evidence required')
    key=dict(sourceChainId=raw['sourceChainId'],startBlock=raw['startBlock'],endBlock=raw['endBlock'],
             startAnchorHash=raw['anchorHash'],endBlockHash=raw['endHash'],batchRoot=raw['batchRoot'],imageId=image)
    key_bytes=b''.join(struct.pack('>Q',key[k]) for k in ('sourceChainId','startBlock','endBlock'))
    key_bytes+=b''.join(bytes.fromhex(key[k][2:]) for k in ('startAnchorHash','endBlockHash','batchRoot','imageId'))
    cache=out/'cache/groth16';cache.mkdir(parents=True)
    local.write_json(cache/(hashlib.sha256(key_bytes).hexdigest()+'.json'),
        dict(version=1,key=key,proofData=base64.b64encode(receipt).decode(),journal=base64.b64encode(bytes.fromhex(raw['journal'][2:])).decode()))
    checked=json.loads(subprocess.check_output(cmd+['--risc0-host',str(host),'--proof-cache',str(out/'cache'),
        '--receipt-kind','groth16','--proof-timeout','10s'],text=True,timeout=30))
    if (checked.get('cacheHit') is not True or checked.get('proofVerified') is not True
        or checked.get('imageId')!=image or checked.get('receiptKind')!='groth16'):
        raise ValueError('cryptographically verified cache hit required')
    for field in ('guestInput','journal','batchData','anchorHash','endHash'):
        if checked[field]!=raw[field]:
            raise ValueError('source changed during proving')
    session.guard()
    if (int(session.view(destination,updater,'latestBlock()(uint256)'))+1!=start
        or session.view(destination,updater,'latestHash()(bytes32)').lower()!=checked['anchorHash'].lower()):
        raise ValueError('destination changed during proving; resample before retry')
    local.write_json(out/'header-package.json',checked)
    return checked

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--session',type=Path,required=True)
    parser.add_argument('--action',choices=['lock','burn'],required=True)
    parser.add_argument('--start',type=int,required=True)
    parser.add_argument('--count',type=int,required=True)
    parser.add_argument('--output-dir',type=Path,required=True)
    args=parser.parse_args()
    session=local.Session(args.session)
    with (session.root/'proof-worker.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        build(session,args.action,args.start,args.count,args.output_dir)
    print('unsigned actual Groth16 header package ready; broadcasts 0')
if __name__=='__main__':
    main()
