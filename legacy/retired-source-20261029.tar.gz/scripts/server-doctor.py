#!/usr/bin/env python3
"""Read-only deployment preflight. No deployments, signing or proving."""
import argparse,hashlib,importlib.util,json,os,platform,shutil,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('doctor_runtime',ROOT/'scripts/runtime-config.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
def main():
 p=argparse.ArgumentParser();p.add_argument('--mode',choices=('risc0-computation','trusted-rpc','fast','zk'),default='risc0-computation');args=p.parse_args();checks={}
 for tool in ('anvil','forge','cast'):
  checks[tool]=shutil.which(tool) is not None
 for env,default in (('BNC_PROOF_BIN',ROOT/'.bin/bridge-proof'),('BNC_HEADER_BIN',ROOT/'.bin/bridge-header-data')):
  checks[env]=r.binary(env,default).is_file() or shutil.which('go') is not None
 if args.mode=='risc0-computation':
  host=ROOT/'risc0/receipt-computation/target/release/bridge-receipt-host'
  checks['receiptComputationHost']=host.is_file();checks['r0vm']=r.r0vm().is_file()
  if host.is_file():
   try:
    with __import__('tempfile').TemporaryDirectory(prefix='bnc-receipt-preflight-') as directory:
     env=os.environ.copy();env.pop('RISC0_DEV_MODE',None);env['RISC0_SERVER_PATH']=str(r.r0vm())
     receipt=ROOT/'results/receipt-computation-lock-proof/receipt.bin'
     if receipt.is_file():
      shutil.copy2(receipt,Path(directory)/'receipt.bin')
      result=subprocess.run([str(host),'verify',str(ROOT/'risc0/receipt-computation/core/fixture.json'),directory],capture_output=True,timeout=30,env=env)
      summary=json.loads((Path(directory)/'summary.json').read_text()) if result.returncode==0 else {}
      checks['pinnedGuestReceiptVerified']=summary.get('sdkVerified') is True and summary.get('imageId')==json.loads((ROOT/'configs/receipt-computation.json').read_text())['imageId']
     else:checks['pinnedGuestReceiptVerified']=False
   except (OSError,ValueError,subprocess.SubprocessError):checks['pinnedGuestReceiptVerified']=False
 if args.mode=='zk':
  host=r.binary('BNC_PROVER_HOST',ROOT/'.bin/risc0-host' if (ROOT/'.bin/risc0-host').exists() else ROOT/'risc0/target/release/bridge-header-benchmark')
  checks['proverHost']=host.is_file();checks['r0vm']=r.r0vm().is_file()
  try:checks['docker']=subprocess.run(['docker','info'],capture_output=True,timeout=20).returncode==0
  except (OSError,subprocess.TimeoutExpired):checks['docker']=False
  image='risczero/risc0-groth16-prover:v2025-04-03.1'
  digest='sha256:a4f80ce2e0b8e2bb7637a93c37136a6776ac00ec843a3fdf1c67b1d5ffea64ee'
  try:checks['pinnedCompressor']=any(x.endswith('@'+digest) for x in json.loads(subprocess.check_output(['docker','image','inspect','--format','{{json .RepoDigests}}',image],text=True,timeout=10)))
  except (OSError,subprocess.SubprocessError):checks['pinnedCompressor']=False
 release=ROOT/'release-manifest.json'
 if release.exists():
  m=json.loads(release.read_text());checks['releasePlatform']=platform.machine()==m['machine']
  checks['releaseHashes']=all((ROOT/f).is_file() and hashlib.sha256((ROOT/f).read_bytes()).hexdigest()==sha for f,sha in m['sha256'].items())
 result=dict(passed=all(checks.values()),checks=checks,projectRoot=str(ROOT),effectiveProofCpuLimit=r.cpus(),effectiveMemoryLimitBytes=int(r.memory_bytes()*.7),timeoutSeconds=1800,fileCapBytes=64*1024*1024)
 print(json.dumps(result,indent=2));raise SystemExit(0 if result['passed'] else 1)
if __name__=='__main__':main()
