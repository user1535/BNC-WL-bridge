#!/usr/bin/env python3
"""Local historical claim recovery rejects inconsistent RPC records without rebroadcasting."""
import argparse
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil

spec = importlib.util.spec_from_file_location('claim_recovery_client', Path(__file__).with_name('local-session.py'))
client = importlib.util.module_from_spec(spec); spec.loader.exec_module(client)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--evidence', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--additional-fields-only', action='store_true',
        help='check top-level transaction/block identifiers after the main16 RPC consistency checks')
    args = parser.parse_args()
    source = args.evidence.resolve(); out = args.output_dir.resolve(); out.mkdir(parents=True, exist_ok=False)
    clone = out / 'session'; shutil.copytree(source, clone)
    session = client.Session(clone)
    report = {'localVerdict': 'FAIL', 'scope': 'owned actual completed local state with injected claim RPC inconsistencies',
        'freshProofsGenerated': 0, 'transactionsBroadcast': 0, 'chainAuthenticated': False,
        'realAssetDeploymentAllowed': False, 'checks': [],
        'clientSHA256': hashlib.sha256(Path(client.__file__).read_bytes()).hexdigest()}
    before = {c: json.loads((clone / f'{c}-state.json').read_text()) for c in ('wl', 'bnb')}
    original_rpc = session.rpc
    try:
        session.start('risc0_batch')
        for action in ('lock', 'burn'):
            event = next(e for e in session.data['events'] if e['action'] == action)
            _, destination, _, _, _, _ = session.route(action)
            receipt_path = clone / (event['id'] + '-claim.json')
            expected_receipt = json.loads(receipt_path.read_text()); receipt_path.unlink()
            faults = ('wrong-transaction-hash', 'wrong-block-number', 'wrong-transaction-index') if args.additional_fields_only else (
                'duplicate-log', 'removed-log', 'wrong-recipient', 'wrong-status',
                'wrong-block-hash', 'missing-receipt', 'missing-receipt-log', 'excess-history')
            for fault in faults:
                event['claimed'] = False; session.save()

                def faulty_rpc(chain, method, params):
                    if chain == destination and method == 'eth_blockNumber' and fault == 'excess-history':
                        return hex(10001)
                    value = original_rpc(chain, method, params)
                    if chain != destination: return value
                    value = copy.deepcopy(value)
                    if method == 'eth_getLogs':
                        if fault == 'duplicate-log': value += copy.deepcopy(value)
                        if fault == 'removed-log': value[0]['removed'] = True
                        if fault == 'wrong-recipient': value[0]['topics'][2] = '0x' + '00' * 32
                    if method == 'eth_getTransactionReceipt':
                        if fault == 'wrong-status': value['status'] = '0x0'
                        if fault == 'wrong-block-hash': value['blockHash'] = '0x' + '00' * 32
                        if fault == 'wrong-transaction-hash': value['transactionHash'] = '0x' + '00' * 32
                        if fault == 'wrong-block-number': value['blockNumber'] = '0x0'
                        if fault == 'wrong-transaction-index': value['transactionIndex'] = '0xffffff'
                        if fault == 'missing-receipt': value = None
                        if fault == 'missing-receipt-log': value['logs'] = []
                    return value

                session.rpc = faulty_rpc
                try: session.claim(event)
                except RuntimeError as error:
                    if receipt_path.exists() or event.get('claimed') is True:
                        raise ValueError('failed recovery changed durable receipt/flag')
                    report['checks'].append({'action': action, 'fault': fault, 'rejected': True, 'error': str(error)})
                else: raise ValueError('inconsistent claim RPC incorrectly recovered: ' + fault)
            session.rpc = original_rpc; session.claim(event)
            recovered = json.loads(receipt_path.read_text())
            for key in ('transactionHash', 'blockHash', 'blockNumber', 'status', 'logs', 'from', 'to'):
                if recovered[key] != expected_receipt[key]: raise ValueError('honest recovery receipt differs: ' + key)
            if event.get('claimed') is not True: raise ValueError('honest recovery did not restore durable flag')
        report.update(localVerdict='PASS', honestReceiptsRecovered=2)
    except BaseException as error:
        report['error'] = str(error); raise
    finally:
        session.rpc = original_rpc
        try:
            session.stop(); report['ownedNodesStopped'] = True
        except Exception as error: report.update(localVerdict='FAIL', cleanupError=str(error))
        for chain in ('wl', 'bnb'):
            after = json.loads((clone / f'{chain}-state.json').read_text())
            unchanged = before[chain]['accounts'] == after['accounts'] and before[chain]['best_block_number'] == after['best_block_number']
            unchanged &= sorted(json.dumps(t, sort_keys=True) for t in before[chain]['transactions']) == sorted(
                json.dumps(t, sort_keys=True) for t in after['transactions'])
            if not unchanged: report.update(localVerdict='FAIL', chainStateChanged=chain)
        (out / 'summary.json').write_text(json.dumps(report, indent=2) + '\n')
    if report['localVerdict'] != 'PASS': raise ValueError('claim recovery fault checks failed')
    print('PASS actual-state claim recovery:', len(report['checks']), 'RPC failures refused/honest2 restored; newproof0/broadcast0')


if __name__ == '__main__': main()
