#!/usr/bin/env python3
"""Bounded local SDK segment-cache preparation, proof waves and read-only audit."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess

ROOT = Path(__file__).resolve().parent.parent


def regular(path, cap):
    if any(p.is_symlink() for p in (path, *path.parents)):
        raise ValueError("symlink artifact/path forbidden")
    if not stat.S_ISREG(path.stat().st_mode) or path.stat().st_size > cap:
        raise ValueError("regular bounded artifact required")
    return path


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--host", type=Path, required=True)
    p.add_argument("--input", type=Path, required=True)
    p.add_argument("--cache", type=Path, required=True)
    p.add_argument("--prepare-evidence", type=Path, help="required external PREPARED summary pin for prove/audit")
    p.add_argument("--dir", type=Path, required=True)
    p.add_argument("--action", choices=("prepare", "prove", "audit"), required=True)
    p.add_argument("--stage", choices=("segment", "compression"), default="segment")
    p.add_argument("--receipt", type=Path, help="verified composite required for compression prepare only")
    p.add_argument("--max-new-units", type=int, default=4096)
    p.add_argument("--segment-po2", type=int, choices=(16, 17, 18, 19), default=19)
    p.add_argument("--keccak-max-po2", type=int, choices=(14, 15, 16), default=16,
                   help="segment stage only; explicit lower batching cap, default16, never higher")
    p.add_argument("--diagnostic-max-headers", type=int, choices=(4, 8, 16, 32, 64, 128), default=4,
                   help="explicit local minimal-link experiment; normal export cap stays4")
    p.add_argument("--timeout-seconds", type=int, default=1800)
    args = p.parse_args()
    if not 1 <= args.timeout_seconds <= 1800 or not 0 <= args.max_new_units <= 4096:
        p.error("timeout1..1800, proof units0..4096")
    if args.stage != "segment" and args.keccak_max_po2 != 16:
        p.error("lower Keccak batching cap applies only to segment stage")
    needs_receipt = args.stage == "compression" and args.action == "prepare"
    if bool(args.receipt) != needs_receipt:
        p.error("--receipt required only for --stage compression --action prepare")
    receipt = regular(args.receipt.absolute(), 64 * 1024 * 1024) if needs_receipt else None
    host = regular(args.host.absolute(), 256 * 1024 * 1024)
    if args.diagnostic_max_headers != 4:
        if subprocess.check_output([str(host), "--header-binding"], text=True, timeout=10).strip() != "minimal-link":
            p.error("larger diagnostic requires explicit minimal-link host")
    source_input = regular(args.input.absolute(), 64 * 1024)
    server = regular((Path.home() / ".cargo/bin/r0vm").resolve(strict=True), 256 * 1024 * 1024)
    # Compare the server to the preserved genuine SDK execution metadata.
    pinned = json.loads((ROOT / "results/bnb-vote-risc0-accelerated-execution/metadata.json").read_text())
    expected_server = pinned["server_sha256"] if "server_sha256" in pinned else pinned["serverSHA256"]
    if digest(server) != expected_server:
        raise ValueError("pinned local SDK server mismatch")
    cache = args.cache.absolute()
    if any(x.is_symlink() for x in (cache, *cache.parents)):
        raise ValueError("cache symlink forbidden")
    if args.action == "prepare" and cache.exists():
        p.error("prepare requires a new cache")
    if args.action != "prepare" and not cache.is_dir():
        p.error("existing regular cache required")
    pin = None
    if args.action != "prepare":
        if not args.prepare_evidence:
            p.error("prove/audit requires --prepare-evidence <external prepared directory>")
        prepared = json.loads(regular(args.prepare_evidence.absolute() / "summary.json", 64 * 1024).read_text())
        if prepared.get("status") != "PREPARED" or prepared.get("result", {}).get("status") != "PREPARED":
            raise ValueError("completed preparation evidence required")
        if prepared.get("stage", "segment") != args.stage:
            raise ValueError("preparation stage mismatch")
        if (prepared.get("keccakMaxPo2", 16) != args.keccak_max_po2
                or prepared.get("diagnosticMaxHeaders", 4) != args.diagnostic_max_headers):
            p.error("Keccak/diagnostic configuration must match frozen preparation")
        pin = prepared["result"]["manifestSHA256"]
        if digest(regular(cache / "manifest.json", 64 * 1024 * 1024)) != pin:
            raise ValueError("preparation manifest pin mismatch")
    out = args.dir.absolute()
    out.mkdir(parents=True, exist_ok=False)
    snapshot = out / "risc0-host"
    shutil.copy2(host, snapshot)
    shutil.copy2(source_input, out / "input.json")
    env = dict(os.environ, RISC0_DEV_MODE="0", RISC0_PROVER="ipc", RISC0_SERVER_PATH=str(server),
               BRIDGE_RISC0_SEGMENT_PO2=str(args.segment_po2), RAYON_NUM_THREADS="12")
    env.update(BRIDGE_RISC0_KECCAK_PO2=str(args.keccak_max_po2),
               BRIDGE_RISC0_DIAGNOSTIC_MAX_HEADERS=str(args.diagnostic_max_headers))
    if pin:
        env["BRIDGE_RISC0_CACHE_MANIFEST_SHA256"] = pin
    prefix = "--compression-" if args.stage == "compression" else "--segments-"
    command = [str(snapshot), prefix + args.action, str(out / "input.json")]
    if receipt:
        shutil.copy2(receipt, out / "source-composite.json")
        command.append(str(out / "source-composite.json"))
    command.append(str(cache))
    if args.action == "prove":
        command.append(str(args.max_new_units))
    physical = os.sysconf("SC_PHYS_PAGES") * os.sysconf("SC_PAGE_SIZE")
    report = {"measuredAt": datetime.now(timezone.utc).isoformat(), "status": "RUNNING",
              "action": args.action, "stage": args.stage, "cache": str(cache), "command": command,
              "hostSHA256": digest(snapshot), "inputSHA256": digest(out / "input.json"),
              "serverSHA256": digest(server), "timeoutSeconds": args.timeout_seconds,
              "memoryLimitKiB": int(physical * .7) // 1024, "threads": 12,
              "segmentPo2": args.segment_po2, "keccakMaxPo2": args.keccak_max_po2,
              "diagnosticMaxHeaders": args.diagnostic_max_headers,
              "rpcRequests": 0, "dockerInvocations": 0, "evmAcceptanceMeasured": False,
              "chainAuthenticated": False, "realAssetDeploymentAllowed": False,
              "fullGenerationWallMeasured": False}
    summary = out / "summary.json"
    summary.write_text(json.dumps(report, indent=2) + "\n")
    spec = importlib.util.spec_from_file_location("segment_memory", ROOT / "scripts/benchmark-header.py")
    monitor = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(monitor)
    result, resources = monitor.run_with_memory_limit(command, env, report["memoryLimitKiB"], args.timeout_seconds)
    (out / "stdout.json").write_text(result.stdout)
    (out / "stderr.txt").write_text(result.stderr)
    report.update(exitCode=result.returncode, resources=resources)
    if result.returncode == 0:
        report["result"] = json.loads(result.stdout)
        report["status"] = report["result"]["status"]
        if args.stage == "segment":
            actual = json.loads(regular(cache / "manifest.json", 64 * 1024 * 1024).read_text())
            if actual.get("keccak_po2") != args.keccak_max_po2:
                report.update(status="FAIL", reason="compiled host ignored requested Keccak configuration")
    else:
        report["status"] = "FAIL"
        report["reason"] = resources.get("stop_reason") or "host error; see stderr"
    summary.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report))
    if result.returncode or report["status"] == "FAIL":
        raise SystemExit(result.returncode or 1)


if __name__ == "__main__":
    main()
