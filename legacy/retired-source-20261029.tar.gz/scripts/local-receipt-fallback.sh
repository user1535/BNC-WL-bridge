#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BRIDGE_FORCE_PER_TX_RECEIPTS=1 exec "$ROOT_DIR/scripts/local-roundtrip.sh"
