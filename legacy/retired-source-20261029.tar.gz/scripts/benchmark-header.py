#!/usr/bin/env python3
"""Benchmark verified synthetic composite proofs; never an EVM acceptance-rate test."""
import argparse
import csv
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent.parent
HOST = ROOT / "risc0/target/release/bridge-header-benchmark"
PROFILES = {
    "worldland": (31337, [1, 2, 4, 8, 16, 32, 64]),
    "bnb": (31338, [1, 2, 4, 8, 16, 32, 64, 128]),
}


def group_resident_kb(group_id):
    resident = 0
    for path in Path('/proc').glob('[0-9]*/stat'):
        try:
            fields = path.read_text().rsplit(')', 1)[1].split()
            if int(fields[2]) != group_id:
                continue
            status = path.with_name('status').read_text()
            resident += next((int(line.split()[1]) for line in status.splitlines()
                              if line.startswith('VmRSS:')), 0)
        except (OSError, ValueError, IndexError):
            pass
    return resident


def run_with_memory_limit(command, env, limit_kb, timeout_seconds):
    process = subprocess.Popen(command, env=env, text=True, stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE, start_new_session=True)
    peak_group_kb, samples = 0, 0
    reason = None
    start = time.monotonic()
    try:
        while True:
            resident = group_resident_kb(process.pid)
            peak_group_kb = max(peak_group_kb, resident)
            samples += 1
            if reason is None:
                if resident > limit_kb:
                    reason = 'CAPACITY_LIMIT: sampled process-group sum RSS exceeded RAM limit'
                elif time.monotonic() - start > timeout_seconds:
                    reason = 'TIME_LIMIT: benchmark exceeded configured timeout'
                if reason is not None:
                    try:
                        os.killpg(process.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
            try:
                stdout, stderr = process.communicate(timeout=.25)
                code = (3 if reason.startswith('CAPACITY') else 124) if reason else process.returncode
                result = subprocess.CompletedProcess(command, code, stdout,
                    stderr + ('\n' + reason + '\n' if reason else ''))
                return result, {'peak_group_rss_kb': peak_group_kb, 'rss_samples': samples,
                                'wall_seconds': time.monotonic() - start, 'stop_reason': reason}
            except subprocess.TimeoutExpired:
                pass
    finally:
        # Keyboard interruption must not leave an IPC prover running.
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        process.wait()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('profile', choices=PROFILES)
    parser.add_argument('--output-dir', type=Path)
    parser.add_argument('--host', type=Path, default=HOST)
    parser.add_argument('--guest-source', type=Path, default=ROOT/'risc0/methods/guest/src/main.rs')
    parser.add_argument('--guest-lock', type=Path, default=ROOT/'risc0/methods/guest/Cargo.lock')
    parser.add_argument('--sizes', type=int, nargs='+')
    parser.add_argument('--segment-po2', type=int, choices=range(16, 21), default=20)
    parser.add_argument('--threads', type=int, default=os.cpu_count() or 1)
    parser.add_argument('--timeout-seconds', type=int, default=1200)
    parser.add_argument('--memory-policy', choices=['projected', 'observed'], default='projected')
    args = parser.parse_args()
    if args.threads < 1 or args.threads > (os.cpu_count() or 1) or args.timeout_seconds < 1:
        parser.error('threads must be within available CPU count; timeout must be positive')
    source_host = args.host.resolve()
    if not source_host.is_file():
        parser.error('build a release host first')
    profile = args.profile
    chain_id, sizes = PROFILES[profile]
    sizes = args.sizes or sizes
    if any(size < 1 or size > 128 for size in sizes) or sizes != sorted(set(sizes)):
        parser.error('sizes must be strictly increasing within 1..128')
    output_dir = args.output_dir or ROOT / 'results' / ('header-benchmark-' +
        datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ'))
    output_dir.mkdir(parents=True, exist_ok=False)
    host = output_dir.resolve() / 'risc0-host'
    shutil.copyfile(source_host, host)
    host.chmod(0o700)
    env = os.environ.copy()
    server = Path.home() / '.cargo/bin/r0vm'
    env.update(RISC0_SERVER_PATH=str(server), RISC0_RECEIPT_KIND='composite',
               RISC0_PROVER='ipc', RISC0_DEV_MODE='0',
               BRIDGE_RISC0_SEGMENT_PO2=str(args.segment_po2), RAYON_NUM_THREADS=str(args.threads))
    image_id = subprocess.check_output([str(host), '--image-id'], env=env, text=True).strip()
    binding = subprocess.check_output([str(host), '--header-binding'], env=env, text=True).strip()
    if binding != 'minimal-link':
        parser.error('synthetic benchmark requires a minimal-link host')
    metadata = {'image_id': image_id, 'header_binding': binding, 'host_sha256': sha(host),
        'server_sha256': sha(server), 'host_snapshot': str(host),
        'guest_source_path': str(args.guest_source.resolve()),
        'guest_lock_path': str(args.guest_lock.resolve()),
        'source_at_invocation_sha256': sha(args.guest_source),
        'guest_lock_at_invocation_sha256': sha(args.guest_lock),
        'receipt_kind': 'composite', 'profile': profile, 'sizes': sizes,
        'segment_limit_po2': args.segment_po2, 'rayon_num_threads': args.threads,
        'timeout_seconds': args.timeout_seconds, 'memory_policy': args.memory_policy,
        'chain_authenticated': False, 'evm_acceptance_measured': False,
        'real_asset_deployment_allowed': False, 'synthetic_input': True}
    physical_kb = os.sysconf('SC_PHYS_PAGES') * os.sysconf('SC_PAGE_SIZE') // 1024
    memory_limit_kb = int(physical_kb * .7)
    metadata.update(physical_kb=physical_kb, memory_limit_kb=memory_limit_kb,
                    memory_measurement='sampled sum RSS of process group; shared pages may be counted twice')
    output = output_dir / f'header-{profile}.csv'
    output.with_suffix('.metadata.json').write_text(json.dumps(metadata, indent=2)+'\n')
    fields = ['profile', 'chain_id', 'receipt_kind', 'batch_size', 'start_block', 'end_block',
              'execute_ms', 'prove_ms', 'total_ms', 'proof_bytes', 'journal_bytes', 'peak_kb',
              'peak_group_rss_kb', 'wall_seconds', 'rss_samples', 'segment_limit_po2',
              'headers_per_second', 'end_to_end_headers_per_second', 'verified', 'synthetic_input']
    with output.open('x', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        handle.flush()
        previous = None
        for size in sizes:
            if previous and args.memory_policy == 'projected':
                projected_kb = int(previous[1] * size / previous[0])
                if projected_kb > memory_limit_kb:
                    print(f'CAPACITY_LIMIT: projected {projected_kb} KiB for batch {size}; remaining sizes unmeasured', file=sys.stderr)
                    return 3
            if sha(host) != metadata['host_sha256'] or sha(server) != metadata['server_sha256']:
                raise RuntimeError('pinned host or SDK server changed before measurement')
            result, resources = run_with_memory_limit(
                ['/usr/bin/time', '-f', 'peak_kb=%M', str(host), str(chain_id), str(size)],
                env, memory_limit_kb, args.timeout_seconds)
            (output_dir / f'{profile}-{size}.stdout.json').write_text(result.stdout)
            (output_dir / f'{profile}-{size}.stderr.txt').write_text(result.stderr)
            (output_dir / f'{profile}-{size}.resources.json').write_text(json.dumps(resources, indent=2)+'\n')
            if result.returncode:
                print(result.stderr, file=sys.stderr)
                return result.returncode
            row = json.loads(result.stdout.strip())
            if row.get('receipt_kind') != 'composite' or row.get('synthetic_input') is not True or row.get('verified') is not True:
                raise RuntimeError('unexpected benchmark receipt or verification status')
            if row.get('segment_limit_po2') != args.segment_po2:
                raise RuntimeError('host does not report the requested segment configuration')
            peak_line = next((line for line in result.stderr.splitlines() if line.startswith('peak_kb=')), None)
            if not peak_line:
                raise RuntimeError('missing peak memory measurement')
            resources.pop('stop_reason')
            row.update(profile=profile, peak_kb=int(peak_line.split('=', 1)[1]), **resources)
            writer.writerow(row)
            handle.flush()
            previous = (size, row['peak_group_rss_kb'])
            print(f"{profile} batch={size} segment={args.segment_po2} prove_ms={row['prove_ms']} "
                  f"rate={row['end_to_end_headers_per_second']:.4f}/s group_rss_kb={row['peak_group_rss_kb']}", flush=True)
    print(output)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
