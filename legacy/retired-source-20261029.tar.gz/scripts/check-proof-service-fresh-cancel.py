#!/usr/bin/env python3
"""Actual API SIGTERM while a bounded SDK prover runs in an isolated clone."""
import importlib.util,json,os,shutil,signal,subprocess,sys,time,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('fresh_cancel_api',ROOT/'scripts/proof-service.py')
api=importlib.util.module_from_spec(spec);spec.loader.exec_module(api)
base=api.local.Session(ROOT/'results/prototype-header-steps');base.guard();base.stop()
out=ROOT/'results/prototype-fresh-cancel-fault';out.mkdir(exist_ok=False)
for name in ('session.json','wl-state.json','bnb-state.json','risc0-host'):shutil.copy2(base.root/name,out/name)
s=api.local.Session(out);s.start('risc0_batch','minimal-link');server=None
try:
 snapshot=s.rpc('wl','evm_snapshot',[]);s.action('lock',0,10**18);event=s.data['events'][-1]
 s.rpc('wl','evm_mine',[]);s.rpc('wl','evm_mine',[])
 with (out/'api.log').open('w') as log:
  server=subprocess.Popen([sys.executable,str(ROOT/'scripts/proof-service.py'),'--session',str(out),'--confirmations','2','--prove','--port','8582'],stdout=log,stderr=log)
  for _ in range(100):
   try:urllib.request.urlopen('http://127.0.0.1:8582/api/manifest',timeout=1).close();break
   except OSError:time.sleep(.1)
  else:raise ValueError('fault API did not start')
  request=dict(action='lock',transferId=event['id'],fromBlock=event['block'])
  req=urllib.request.Request('http://127.0.0.1:8582/api/jobs',json.dumps(request).encode(),headers={'Content-Type':'application/json','X-Bridge-Request':'1'},method='POST')
  identifier=json.load(urllib.request.urlopen(req,timeout=5))['id']
  host=None
  for _ in range(300):
   for proc in Path('/proc').iterdir():
    if not proc.name.isdigit():continue
    try:
     argv=(proc/'cmdline').read_bytes().split(b'\0')
     if argv and os.fsencode(str(out/'proof-jobs')) in argv[0] and argv[0].endswith(b'/risc0-host') and b'--prove-receipt' in argv:host=int(proc.name);break
    except OSError:pass
   if host:break
   time.sleep(.1)
  else:raise ValueError('actual prover did not start')
  server.send_signal(signal.SIGTERM);server.wait(timeout=130);assert server.returncode==0
  for _ in range(100):
   if not Path('/proc',str(host)).exists():break
   time.sleep(.1)
  assert not Path('/proc',str(host)).exists(),'API left owned SDK host alive'
  job=json.loads((out/'proof-jobs'/(identifier+'.json')).read_text());assert job['state']=='failed' and 'package' not in job
  attempts=list((out/'proof-jobs').glob(identifier+'-proof-*'));assert len(attempts)==1
  for _ in range(100):
   report=json.loads((attempts[0]/'proof/summary.json').read_text())
   if report['workState']=='failed':break
   time.sleep(.1)
  assert report['workState']=='failed' and report['localVerdict']=='FAIL'
  ids=subprocess.check_output(['docker','ps','-aq','--filter','label=worldland-bnb.prover='+report['dockerScope']['label']],text=True).strip();assert not ids
  assert s.rpc('wl','evm_revert',[snapshot]) is True
  result=dict(passed=True,actualApiSigtermDuringSdkProving=True,ownedSdkHostReaped=True,ownedDockerContainersRemaining=0,jobState=job['state'],packageBlocked=True,validNewProofs=0,proofAttempts=1,serverBroadcasts=0,localTestWalletLockReverted=True,chainAuthenticated=False,realAssetDeploymentAllowed=False)
  (out/'summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
finally:
 if server and server.poll() is None:server.send_signal(signal.SIGTERM);server.wait(timeout=130)
 s.stop();base.start('risc0_batch','minimal-link')
