#!/usr/bin/env python3
"""Serve only the static local wallet client on loopback; no RPC signing backend."""
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import argparse

class Handler(SimpleHTTPRequestHandler):
    def __init__(self,*args,**kwargs): super().__init__(*args,directory=str(Path(__file__).resolve().parents[1]/'wallet'),**kwargs)
    def end_headers(self):
        self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Cache-Control','no-store')
        super().end_headers()
    def guess_type(self,path): return 'text/javascript' if path.endswith('.mjs') else super().guess_type(path)
parser=argparse.ArgumentParser();parser.add_argument('--port',type=int,default=8580);args=parser.parse_args()
with ThreadingHTTPServer(('127.0.0.1',args.port),Handler) as server:
    print(f'http://127.0.0.1:{args.port}',flush=True)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
