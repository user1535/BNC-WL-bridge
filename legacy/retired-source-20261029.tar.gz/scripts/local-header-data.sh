#!/usr/bin/env bash
set -euo pipefail

# Local-only data-path check. It creates no proof seal and submits no header transaction.
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
RPC=http://127.0.0.1:8555
if cast chain-id --rpc-url "$RPC" >/dev/null 2>&1; then
    echo "Port 8555 is already in use" >&2; exit 1
fi
HOST="$ROOT_DIR/risc0/target/release/bridge-header-benchmark"
if [[ ! -x "$HOST" ]]; then
    echo "Build the RISC0 host first: cargo build --manifest-path risc0/Cargo.toml --release --offline" >&2; exit 1
fi
anvil --silent --host 127.0.0.1 --port 8555 --chain-id 31337 >"$ROOT_DIR/.anvil-header-data.log" 2>&1 &
ANVIL_PID=$!
PACKAGE="$(mktemp)"
GUEST_INPUT="$(mktemp)"
cleanup() {
    kill "$ANVIL_PID" 2>/dev/null || true
    wait "$ANVIL_PID" 2>/dev/null || true
    rm -f "$PACKAGE" "$GUEST_INPUT"
}
trap cleanup EXIT
for _ in $(seq 1 50); do
    if [[ "$(cast chain-id --rpc-url "$RPC" 2>/dev/null || true)" == "31337" ]]; then break; fi
    sleep 0.2
done
[[ "$(cast chain-id --rpc-url "$RPC")" == "31337" ]]
cast rpc anvil_mine 4 --rpc-url "$RPC" >/dev/null
mkdir -p "$ROOT_DIR/.bin"
go -C "$ROOT_DIR/proof-generator" build -o "$ROOT_DIR/.bin/bridge-header-data" ./cmd/bridge-header-data
"$ROOT_DIR/.bin/bridge-header-data" --rpc "$RPC" --chain-id 31337 --start 1 --count 3 >"$PACKAGE"
python3 - "$PACKAGE" "$GUEST_INPUT" <<'PY'
import json, sys
from pathlib import Path
package=json.loads(Path(sys.argv[1]).read_text())
assert package['kind']=='unsigned-header-data'
assert package['startBlock']==1 and package['endBlock']==3 and package['headerCount']==3
assert package['sealAvailable'] is False and package['chainAuthenticated'] is False
Path(sys.argv[2]).write_text(json.dumps(package['guestInput']))
PY
GUEST_JOURNAL="$(RISC0_SERVER_PATH="$HOME/.cargo/bin/r0vm" "$HOST" --journal-only --input "$GUEST_INPUT")"
python3 - "$PACKAGE" "$GUEST_JOURNAL" <<'PY'
import json, sys
from pathlib import Path
package=json.loads(Path(sys.argv[1]).read_text())
assert package['journal'].lower()==sys.argv[2].strip().lower(), 'Go journal differs from actual RISC0 guest'
assert len(bytes.fromhex(package['batchData'][2:]))==64+3*128
print('three real local headers: Go journal matches actual RISC0 guest')
print('ABI batch data: 3 headers; seal available: false; chain authenticated: false')
PY
