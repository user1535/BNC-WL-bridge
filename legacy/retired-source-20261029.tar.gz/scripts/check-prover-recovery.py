#!/usr/bin/env python3
"""Exercise real generator CLI cancellation/cache recovery with an injected host fault.

Reuses a genuine composite receipt; never starts r0vm or claims EVM acceptance.
"""
import argparse
import base64
from collections import Counter
from datetime import datetime, timezone
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import shutil
import subprocess
import threading
import time

ROOT = Path(__file__).resolve().parents[1]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--evidence', type=Path, required=True, help='phase profile with genuine composite.json and fixed host/input')
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    source = args.evidence.resolve(); out = args.output_dir.resolve()
    out.mkdir(parents=True, exist_ok=False)
    host = out / 'risc0-host'; shutil.copy2(source / 'risc0-host', host)
    receipt = out / 'composite.json'; shutil.copy2(source / 'phases/composite.json', receipt)
    inp = json.loads((source / 'input.json').read_text())
    env = dict(os.environ, RISC0_DEV_MODE='0', RISC0_PROVER='ipc')
    report = {'measuredAt': datetime.now(timezone.utc).isoformat(), 'localVerdict': 'FAIL',
        'rpcSimulated': True, 'hostProvingFaultInjected': True, 'genuineReceiptReused': True,
        'freshProofsGenerated': 0, 'r0vmExecutions': 0, 'realEvmAcceptanceTestedHere': False,
        'chainAuthenticated': False, 'realAssetDeploymentAllowed': False, 'cases': [],
        'hostSHA256': sha(host), 'receiptSHA256': sha(receipt)}
    binary = out / 'bridge-header-data'
    subprocess.run(['go', '-C', str(ROOT / 'proof-generator'), 'build', '-o', str(binary), './cmd/bridge-header-data'], check=True)
    report['generatorSHA256'] = sha(binary)
    verified = json.loads(subprocess.check_output([host, '--verify-receipt', receipt], env=env, text=True, timeout=30))
    assert verified['verified'] and verified['receipt_kind'] == 'composite' and not verified['evm_compatible']
    assert not verified['chain_authenticated']
    report['imageId'] = verified['image_id']
    proxy = out / 'fault-host'
    proxy.write_text('''#!/usr/bin/env python3
import json,os,shutil,subprocess,sys,time
from pathlib import Path
root=Path(__file__).resolve().parent
with (root/'host-commands.log').open('a') as f:f.write(sys.argv[1]+'\\n')
if sys.argv[1]=='--prove-receipt':
    mode=(root/'fault-mode').read_text().strip()
    if mode=='hang':
        child=subprocess.Popen([sys.executable,'-c','import time; time.sleep(120)'])
        (root/'fault-pids.json').write_text(json.dumps([os.getpid(),child.pid]))
        time.sleep(120);sys.exit(2)
    if mode=='reuse':
        requested=json.loads(Path(sys.argv[sys.argv.index('--input')+1]).read_text())
        assert requested==json.loads((root/'input.json').read_text())
        shutil.copyfile(root/'composite.json',sys.argv[sys.argv.index('--receipt-output')+1]);sys.exit(0)
    sys.exit('proving intentionally forbidden')
os.execv(str(root/'risc0-host'),[str(root/'risc0-host')]+sys.argv[1:])
''')
    proxy.chmod(0o700); (out / 'input.json').write_text(json.dumps(inp))
    counts = Counter(); changed = False

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_): pass
        def do_POST(self):
            request = json.loads(self.rfile.read(int(self.headers['Content-Length'])))
            method = request['method']; counts[method] += 1
            response = {'jsonrpc': '2.0', 'id': request['id']}
            if method == 'eth_chainId': result = hex(inp['chain_id'])
            elif method == 'eth_blockNumber': result = hex(inp['headers'][-1]['number'])
            elif method == 'eth_getBlockByNumber':
                number = int(request['params'][0], 16)
                if number == inp['headers'][0]['number'] - 1:
                    result = {'number': hex(number), 'hash': '0x' + bytes(inp['anchor_hash']).hex(),
                        'parentHash': '0x' + '01' * 32, 'receiptsRoot': '0x' + '02' * 32}
                else:
                    h = next(h for h in inp['headers'] if h['number'] == number)
                    result = {'number': hex(number), 'hash': '0x' + bytes(h['block_hash']).hex(),
                        'parentHash': '0x' + bytes(h['parent_hash']).hex(), 'receiptsRoot': '0x' + bytes(h['receipt_root']).hex()}
                    if changed and number == inp['headers'][-1]['number']: result['hash'] = '0x' + 'de' * 32
            else: result = None; response['error'] = {'code': -32000, 'message': 'unexpected method'}
            if 'error' not in response: response['result'] = result
            encoded = json.dumps(response).encode()
            self.send_response(200); self.send_header('Content-Type', 'application/json'); self.end_headers(); self.wfile.write(encoded)

    server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True); thread.start()
    cache = out / 'proof-cache/composite'
    command = [str(binary), '--rpc', f'http://127.0.0.1:{server.server_port}', '--chain-id', str(inp['chain_id']),
        '--start', str(inp['headers'][0]['number']), '--count', str(len(inp['headers'])), '--risc0-host', str(proxy),
        '--proof-cache', str(out / 'proof-cache'), '--receipt-kind', 'composite']

    def run(name, mode, succeeds, extra=()):
        (out / 'fault-mode').write_text(mode)
        result = subprocess.run(command + ['--proof-timeout', '1500ms' if mode == 'hang' else '20s'] + list(extra),
            env=env, capture_output=True, text=True, timeout=30)
        (out / (name + '.stdout')).write_text(result.stdout)
        (out / (name + '.stderr')).write_text(result.stderr)
        assert (result.returncode == 0) == succeeds, (name, result.stderr)
        if succeeds:
            row = json.loads(result.stdout)
            assert row['proofVerified'] and row['imageId'] == verified['image_id']
            assert not row['evmCompatible'] and not row['chainAuthenticated']
        else: assert result.stdout == ''
        report['cases'].append({'name': name, 'passed': True, 'exitCode': result.returncode})
        return json.loads(result.stdout) if succeeds else result

    try:
        failed = run('timeout', 'hang', False)
        assert 'deadline exceeded' in failed.stderr and not list(cache.glob('*.json'))
        for pid in json.loads((out / 'fault-pids.json').read_text()):
            for _ in range(20):
                path = Path(f'/proc/{pid}/stat')
                if not path.exists() or path.read_text().rsplit(')', 1)[1].split()[0] == 'Z': break
                time.sleep(.05)
            else: raise ValueError('timed-out owned host/child remains running')
        report['ownedFaultHostAndChildStopped'] = True
        assert run('retry-after-timeout', 'reuse', True)['cacheHit'] is False
        paths = list(cache.glob('*.json')); assert len(paths) == 1
        artifact = paths[0]; before = sha(artifact)
        assert run('cache-hit-proving-forbidden', 'forbid', True)['cacheHit'] is True
        assert sha(artifact) == before
        data = json.loads(artifact.read_text())
        inner = json.loads(base64.b64decode(data['proofData']))
        inner['journal']['bytes'][0] ^= 1
        data['proofData'] = base64.b64encode(json.dumps(inner).encode()).decode()
        artifact.write_text(json.dumps(data)); corrupted = sha(artifact)
        run('corrupted-cache-fails-closed', 'forbid', False)
        assert sha(artifact) == corrupted
        assert run('explicit-repair-reuses-genuine-receipt', 'reuse', True, ('--repair-cache',))['cacheHit'] is False
        rejected = list(cache.glob('*.rejected')); assert len(rejected) == 1 and sha(rejected[0]) == corrupted
        assert run('repaired-cache-hit', 'forbid', True)['cacheHit'] is True
        before = sha(artifact); changed = True
        run('changed-source-key-does-not-reuse', 'forbid', False)
        assert sha(artifact) == before
        report.update(localVerdict='PASS', timeoutLockReleased=True, corruptArtifactPreserved=True,
            cryptographicallyReverified=True, rpcMethods=dict(counts), originalEvidenceUnchanged=sha(receipt) == report['receiptSHA256'])
    finally:
        server.shutdown(); server.server_close(); thread.join(timeout=3)
        (out / 'summary.json').write_text(json.dumps(report, indent=2) + '\n')
    print('PASS real CLI timeout/child cleanup/retry/cache hit/tamper/explicit repair/source-key7; new proofs0')


if __name__ == '__main__': main()
