#!/usr/bin/env python3
"""Reproduce local restart, delayed claims and partial-burn conservation checks."""
import argparse
import hashlib
import importlib.util
import json
import time
from pathlib import Path

spec = importlib.util.spec_from_file_location('client', Path(__file__).with_name('local-session.py'))
client = importlib.util.module_from_spec(spec)
spec.loader.exec_module(client)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dir', type=Path, default=client.ROOT / 'results/session-fast-check')
    parser.add_argument('--delay-seconds', type=float, default=0, help='actual elapsed delay before the partial claim (0..600 seconds)')
    args = parser.parse_args()
    if not 0 <= args.delay_seconds <= 600:
        parser.error('--delay-seconds must be between 0 and 600')
    session = client.Session(args.dir)
    if session.data:
        raise RuntimeError('verification requires a fresh session directory; existing user work is preserved')
    started = time.monotonic()
    session.start('dev')
    try:
        session.setup()
        contracts = session.data['contracts']

        def restart():
            nonlocal session
            session.stop()
            session = client.Session(args.dir)
            session.start('dev')

        def interrupted_send(*arguments):
            if fault_phase == 'before':
                raise RuntimeError('injected before broadcast')
            receipt = original_send(*arguments)
            mined_receipts.append(receipt)
            raise RuntimeError('injected after mined burn')

        def check(locked_expected, supply_expected, pending_burn=0):
            locked = sum(int(session.view('wl', contracts['original'], 'lockedBalanceOf(address)(uint256)', u)) for u in session.data['users'])
            supply = int(session.view('bnb', contracts['wrapped'], 'totalSupply()(uint256)'))
            assert locked == locked_expected * 10**18 and supply == supply_expected * 10**18
            assert locked >= supply + pending_burn * 10**18
            return {'locked': locked, 'wrapped_supply': supply, 'pending_burn': pending_burn * 10**18}

        session.action('lock', 0, 25 * 10**18)
        restart()
        session.claim(session.data['events'][-1])
        states = [check(25, 25)]
        original_send = session.send
        mined_receipts = []
        fault_phase = 'after'
        session.send = interrupted_send
        try:
            session.action('burn', 0, 10 * 10**18)
        except RuntimeError as exc:
            assert str(exc) == 'injected after mined burn'
        else:
            raise AssertionError('mined burn interruption did not fire')
        finally:
            session.send = original_send
        durable = json.loads((session.root / 'session.json').read_text())
        assert durable['pending_action']['amount'] == 10 * 10**18 and len(durable['events']) == 1
        assert len(mined_receipts) == 1
        states.append(check(25, 15, 10))
        user = session.data['users'][0]
        mined_nonce = int(session.rpc('bnb', 'eth_getTransactionCount', [user, 'latest']), 16)
        mined_tip = session.rpc('bnb', 'eth_blockNumber', [])
        restart()
        session.recover()
        assert session.rpc('bnb', 'eth_blockNumber', []) == mined_tip
        assert int(session.rpc('bnb', 'eth_getTransactionCount', [user, 'latest']), 16) == mined_nonce
        assert session.data['events'][-1]['tx_hash'] == mined_receipts[0]['transactionHash']
        assert session.data['pending_action'] is None and len(session.data['events']) == 2
        delay_started = time.monotonic()
        if args.delay_seconds:
            time.sleep(args.delay_seconds)
        observed_delay = time.monotonic() - delay_started
        assert observed_delay >= args.delay_seconds
        delay_before = int(session.rpc('bnb', 'eth_blockNumber', []), 16)
        session.rpc('bnb', 'anvil_mine', [hex(128)])
        assert int(session.rpc('bnb', 'eth_blockNumber', []), 16) - delay_before == 128
        session.claim(session.data['events'][-1])
        states.append(check(15, 15))
        partial_event = session.data['events'][-1]
        partial_id = partial_event['id']
        claim_path = session.root / (partial_id + '-claim.json')
        accepted_claim = json.loads(claim_path.read_text())
        claim_path.unlink()
        partial_event['claimed'] = False
        session.save()
        restart()
        partial_event = next(event for event in session.data['events'] if event['id'] == partial_id)
        claim_nonce = int(session.rpc('wl', 'eth_getTransactionCount', [user, 'latest']), 16)
        claim_tip = session.rpc('wl', 'eth_blockNumber', [])
        session.claim(partial_event)
        assert session.rpc('wl', 'eth_blockNumber', []) == claim_tip
        assert int(session.rpc('wl', 'eth_getTransactionCount', [user, 'latest']), 16) == claim_nonce
        assert json.loads(claim_path.read_text())['transactionHash'] == accepted_claim['transactionHash']
        assert partial_event['claimed'] is True
        states.append(check(15, 15))
        original_send = session.send
        fault_phase = 'before'
        session.send = interrupted_send
        before_nonce = int(session.rpc('bnb', 'eth_getTransactionCount', [user, 'latest']), 16)
        try:
            session.action('burn', 0, 15 * 10**18)
        except RuntimeError as exc:
            assert str(exc) == 'injected before broadcast'
        else:
            raise AssertionError('unbroadcast burn interruption did not fire')
        finally:
            session.send = original_send
        durable = json.loads((session.root / 'session.json').read_text())
        assert durable['pending_action']['wallet_nonce'] == before_nonce and len(durable['events']) == 2
        assert int(session.rpc('bnb', 'eth_getTransactionCount', [user, 'latest']), 16) == before_nonce
        states.append(check(15, 15))
        restart()
        session.recover()
        recovered_nonce = int(session.rpc('bnb', 'eth_getTransactionCount', [user, 'latest']), 16)
        assert recovered_nonce == before_nonce + 1
        assert session.data['pending_action'] is None and len(session.data['events']) == 3
        states.append(check(15, 0, 15))
        restart()
        session.claim(session.data['events'][-1])
        states.append(check(0, 0))
        height = session.rpc('wl', 'eth_blockNumber', [])
        session.claim(session.data['events'][-1])
        assert height == session.rpc('wl', 'eth_blockNumber', [])
        session.action('lock', 1, 7 * 10**18)
        first = session.data['events'][-1]
        session.action('lock', 2, 13 * 10**18)
        second = session.data['events'][-1]
        states.append(check(20, 0))
        session.claim(second)
        states.append(check(20, 13))
        session.claim(first)
        states.append(check(20, 20))
        for index, amount in [(2, 13), (1, 7)]:
            session.action('burn', index, amount * 10**18)
            session.claim(session.data['events'][-1])
        states.append(check(0, 0))
        for user in session.data['users']:
            assert int(session.view('wl', contracts['original'], 'balanceOf(address)(uint256)', user)) == 100 * 10**18
        summary = {'localVerdict': 'PASS', 'mode': 'dev', 'restart_between_lock_and_claim': True, 'restart_between_burn_and_unlock': True,
            'partial_burn_delayed_claim_conservation': True, 'reverse_order_claims_different_users': True,
            'repeat_claim_no_transaction': True, 'final_original_per_user': str(100 * 10**18),
            'mined_partial_burn_durable_recovery': True, 'unbroadcast_remaining_burn_durable_recovery': True,
            'lost_partial_claim_receipt_and_flag_recovered': True, 'delayed_local_blocks': 128,
            'requestedDelaySeconds': args.delay_seconds, 'observedDelaySeconds': observed_delay,
            'recovery_additional_wallet_transactions': {'mined_partial_burn': 0, 'unbroadcast_remaining_burn': recovered_nonce - before_nonce, 'consumed_partial_claim': 0},
            'recovery_transactions': {'partial_burn': mined_receipts[0]['transactionHash'], 'partial_claim': accepted_claim['transactionHash'], 'remaining_burn': session.data['events'][2]['tx_hash']},
            'risc0Required': False, 'newProofsGenerated': 0, 'wallSeconds': time.monotonic() - started,
            'scriptSHA256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'chain_authenticated': False, 'real_asset_deployment_allowed': False, 'states': states}
        client.write_json(session.root / 'summary.json', summary)
        print('persistent session partial burn faults/delayed claim/receipt recovery: PASS')
    finally:
        session.stop()


if __name__ == '__main__':
    main()
