#!/usr/bin/env python3
"""Actual supplied-epoch BLS Groth16 local EVM acceptance; stateless/no assets."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import socket
import subprocess
import time
import urllib.request

ROOT = Path(__file__).resolve().parent.parent
URL = "http://127.0.0.1:8580"
BINDING = "bnb-vote-native-rlp-supplied-epoch"
IMAGE = "0x9aab5eba7939ee001357aeb9b0e084314270174e3956109eef87f961f5db50f6"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    global BINDING, IMAGE
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--evidence", type=Path, required=True)
    p.add_argument("--dir", type=Path, required=True)
    p.add_argument("--coordinate-hints", action="store_true",
                   help="explicit ee7d checked-coordinate diagnostic; original9aab stays separate")
    args = p.parse_args()
    if args.coordinate_hints:
        BINDING = "bnb-vote-native-rlp-supplied-epoch-hinted"
        IMAGE = "0xee7d7ec0047419866b74142713542217b4122daeb9c098e5cec8730d956c2909"
    evidence = args.evidence.resolve()
    out = args.dir.resolve()
    out.mkdir(parents=True, exist_ok=False)
    host = out / "risc0-host"
    shutil.copy2(evidence / "risc0-host", host)
    report = {"measuredAt": datetime.now(timezone.utc).isoformat(), "localVerdict": "FAIL",
              "sourceEvidence": str(evidence), "headerBinding": BINDING, "imageId": IMAGE,
              "coordinateHintsChecked": args.coordinate_hints,
              "destinationFork": "cancun", "requiresEip2537": False, "freshProofGeneratedHere": False,
              "assetClaimsSubmitted": 0, "rootRegistryUpdated": False, "snapshotAuthenticated": False,
              "ecdsaSealVerified": False, "finalityVerified": False, "chainAuthenticated": False,
              "realAssetDeploymentAllowed": False, "negativeChecks": []}
    env = dict(os.environ, RISC0_DEV_MODE="0", RISC0_PROVER="ipc")
    node = None

    def command(cmd):
        return subprocess.check_output([str(x) for x in cmd], cwd=ROOT, env=env,
                                       text=True, stderr=subprocess.PIPE, timeout=120).strip()

    def rpc(method, params):
        req = urllib.request.Request(URL, json.dumps({"jsonrpc": "2.0", "id": 1,
                                      "method": method, "params": params}).encode(),
                                     {"Content-Type": "application/json"})
        response = json.load(urllib.request.urlopen(req, timeout=15))
        if "error" in response:
            raise ValueError(str(response["error"]))
        return response["result"]

    def calldata(seal, journal):
        return command(["cast", "calldata", "verifyVote(bytes,bytes)", seal, journal])

    def deploy(contract, sender, *arguments):
        cmd = ["forge", "create", "--root", ROOT / "contracts", contract, "--rpc-url", URL,
               "--unlocked", "--from", sender, "--broadcast", "--json"]
        if arguments:
            cmd.extend(["--constructor-args", *arguments])
        return json.loads(command(cmd))["deployedTo"]

    try:
        summary = json.loads((evidence / "summary.json").read_text())
        if summary.get("localVerdict") != "PASS" or summary.get("genuineGroth16Verified") is not True:
            raise ValueError("actual completed BLS Groth16 evidence required before EVM work")
        if (summary.get("imageId") != IMAGE or summary.get("headerBinding") != BINDING
                or summary.get("coordinateHintsChecked") is not args.coordinate_hints):
            raise ValueError("explicit selected image/binding differs from Groth16 evidence")
        if sha(host) != summary["hostSHA256"] or sha(evidence / "proof/groth16.json") != summary["receiptSHA256"]:
            raise ValueError("immutable host/receipt evidence differs")
        verified = json.loads(command([host, "--verify-receipt", evidence / "proof/groth16.json"]))
        if (verified.get("verified") is not True or verified.get("receiptKind") != "groth16"
                or verified.get("imageId") != IMAGE or verified.get("headerBinding") != BINDING
                or verified.get("suppliedEpochBlsMathVerified") is not True
                or verified.get("evmCompatible") is not True
                or verified.get("chainAuthenticated") is not False
                or verified.get("realAssetDeploymentAllowed") is not False):
            raise ValueError("distinct compiled BLS Groth16 crypto metadata required")
        journal = verified["journal"]
        seal = verified["seal"]
        if len(bytes.fromhex(journal[2:])) != 352 or len(bytes.fromhex(seal[2:])) != 260:
            raise ValueError("BLS journal or Groth16 seal width")
        for source in json.loads((ROOT / "docs/risc0-verifier-sources.json").read_text()):
            if sha(ROOT / source["path"]) != source["local_sha256"]:
                raise ValueError("pinned official verifier source differs")
        with socket.socket() as probe:
            probe.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            probe.bind(("127.0.0.1", 8580))
            probe.listen(1)
        with (out / "anvil.log").open("w") as log:
            node = subprocess.Popen(["anvil", "--silent", "--host", "127.0.0.1", "--port", "8580",
                                     "--chain-id", "31337", "--hardfork", "cancun"], stdout=log, stderr=log)
        for _ in range(50):
            if node.poll() is not None:
                raise RuntimeError("owned Anvil exited")
            try:
                if int(rpc("eth_chainId", []), 16) != 31337:
                    raise ValueError("local chain required")
                break
            except OSError:
                time.sleep(.1)
        else:
            raise RuntimeError("owned Anvil startup timeout")
        sender = rpc("eth_accounts", [])[0]
        verifier = deploy("src/bridge/LocalRiscZeroGroth16Verifier.sol:LocalRiscZeroGroth16Verifier", sender)
        name = "BNBRiscZeroHintedVoteDiagnostic" if args.coordinate_hints else "BNBRiscZeroVoteDiagnostic"
        diagnostic = deploy("test/BNBRiscZeroVoteDiagnostic.sol:" + name, sender, verifier)
        pinned_image = rpc("eth_call", [{"to": diagnostic,
            "data": command(["cast", "calldata", "BLS_IMAGE()"]), "value": "0x0"}, "latest"])
        if pinned_image != IMAGE:
            raise ValueError("diagnostic image differs from cryptographic receipt")
        data = calldata(seal, journal)
        tx = {"from": sender, "to": diagnostic, "data": data, "value": "0x0"}
        # ABI-static return struct must equal all11 public journal words.
        if rpc("eth_call", [tx, "latest"]) != journal:
            raise ValueError("EVM decoded BLS journal differs")
        receipt = json.loads(command(["cast", "send", diagnostic, "--data", data, "--rpc-url", URL,
                                      "--unlocked", "--from", sender, "--json"]))
        if int(receipt["status"], 16) != 1:
            raise ValueError("actual BLS Groth16 transaction failed")
        (out / "verified-transaction.json").write_text(json.dumps(receipt, indent=2) + "\n")
        raw = bytes.fromhex(journal[2:])
        altered_seal = bytearray.fromhex(seal[2:])
        altered_seal[-1] ^= 1
        negatives = [("altered-seal", "0x" + altered_seal.hex(), journal),
                     ("old224byte-journal", seal, "0x" + raw[:224].hex())]
        for name, offset in (("wrong-anchor", 128), ("wrong-epoch", 224), ("wrong-vote-data", 256)):
            changed = bytearray(raw)
            changed[offset + 31] ^= 1
            negatives.append((name, seal, "0x" + changed.hex()))
        for name, offset, value in (("wrong-domain", 0, 103), ("wrong-count", 96, 2),
                                    ("zero-bitmap", 288, 0), ("excess-key-count", 320, 65),
                                    ("valid-other-bitmap", 288, 2097151)):
            changed = bytearray(raw)
            changed[offset:offset + 32] = value.to_bytes(32, "big")
            negatives.append((name, seal, "0x" + changed.hex()))
        for name, s, j in negatives:
            try:
                rpc("eth_call", [dict(tx, data=calldata(s, j)), "latest"])
            except ValueError as error:
                if "execution reverted" not in str(error).lower():
                    raise
                report["negativeChecks"].append({"name": name, "rejected": True})
            else:
                raise ValueError(f"{name} incorrectly accepted")
        # A genuine receipt must fail with a different compiled guest image,
        # even though its public journal shape and BLS statement are identical.
        changed_image = "0x" + (int(IMAGE, 16) ^ 1).to_bytes(32, "big").hex()
        direct = command(["cast", "calldata", "verify(bytes,bytes32,bytes32)", seal,
                          changed_image, "0x" + hashlib.sha256(raw).hexdigest()])
        try:
            rpc("eth_call", [{"to": verifier, "data": direct, "value": "0x0"}, "latest"])
        except ValueError as error:
            if "execution reverted" not in str(error).lower():
                raise
            report["negativeChecks"].append({"name": "wrong-image", "rejected": True})
        else:
            raise ValueError("wrong-image incorrectly accepted")
        if args.coordinate_hints:
            original = deploy("test/BNBRiscZeroVoteDiagnostic.sol:BNBRiscZeroVoteDiagnostic", sender, verifier)
            original_image = rpc("eth_call", [{"to": original,
                "data": command(["cast", "calldata", "BLS_IMAGE()"]), "value": "0x0"}, "latest"])
            if original_image != "0x9aab5eba7939ee001357aeb9b0e084314270174e3956109eef87f961f5db50f6":
                raise ValueError("original diagnostic image changed")
            try:
                rpc("eth_call", [dict(tx, to=original), "latest"])
            except ValueError as error:
                if "execution reverted" not in str(error).lower():
                    raise
                report["negativeChecks"].append({"name": "original9aab-rejects-ee7d", "rejected": True})
            else:
                raise ValueError("original9aab accepted ee7d")
            report.update(originalDiagnostic=original, originalImageId=original_image)
        # Repetition is valid for this view-only diagnostic; no consumed state.
        if rpc("eth_call", [tx, "latest"]) != journal:
            raise ValueError("stateless repeated verification differs")
        for name, address in (("verifier", verifier), ("diagnostic", diagnostic)):
            runtime = rpc("eth_getCode", [address, "latest"])
            (out / f"{name}-runtime.hex").write_text(runtime + "\n")
            report[f"{name}RuntimeKeccak"] = command(["cast", "keccak", runtime])
        report.update(localVerdict="PASS", realEvmVerifierAcceptance=True,
                      suppliedEpochBlsGroth16Acceptance=True, verifier=verifier, diagnostic=diagnostic,
                      statelessRepeatedVerification=True, sourceChainId=56, journal=journal,
                      transactionHash=receipt["transactionHash"], gasUsed=int(receipt["gasUsed"], 16),
                      calldataBytes=len(bytes.fromhex(data[2:])), hostSHA256=sha(host),
                      receiptSHA256=sha(evidence / "proof/groth16.json"),
                      diagnosticSourceSHA256=sha(ROOT / "contracts/test/BNBRiscZeroVoteDiagnostic.sol"))
    except BaseException as error:
        report["error"] = str(error)
        raise
    finally:
        if node and node.poll() is None:
            node.terminate()
            try:
                node.wait(timeout=10)
            except subprocess.TimeoutExpired:
                node.kill()
                node.wait()
        report["ownedAnvilStopped"] = node is None or node.poll() is not None
        (out / "summary.json").write_text(json.dumps(report, indent=2) + "\n")
    print(out / "summary.json", flush=True)


if __name__ == "__main__":
    def interrupted(signum, frame):
        raise KeyboardInterrupt("owned BLS EVM verification interrupted")
    signal.signal(signal.SIGTERM, interrupted)
    main()
