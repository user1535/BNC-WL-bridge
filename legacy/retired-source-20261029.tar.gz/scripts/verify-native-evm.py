#!/usr/bin/env python3
"""Verify a genuine native Groth16 seal on an owned local EVM; no asset adapter."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import socket
import subprocess
import time
import urllib.request

ROOT=Path(__file__).resolve().parents[1]


def main():
    def interrupted(signum,frame):raise KeyboardInterrupt('native EVM diagnostic interrupted')
    signal.signal(signal.SIGTERM,interrupted)
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--evidence',type=Path,required=True)
    parser.add_argument('--output-dir',type=Path,required=True)
    parser.add_argument('--receipt-proof',type=Path,help='optional saved native MPT/log fixture; diagnostic only, no asset claim')
    args=parser.parse_args()
    out=args.output_dir.resolve();out.mkdir(parents=True,exist_ok=False)
    evidence=args.evidence.resolve();host=out/'native-host';shutil.copy2(evidence/'native-host',host)
    env=dict(os.environ,RISC0_DEV_MODE='0',RISC0_PROVER='ipc')
    report={'measuredAt':datetime.now(timezone.utc).isoformat(),'localVerdict':'FAIL',
            'sourceEvidence':str(evidence),'chainAuthenticated':False,'realAssetDeploymentAllowed':False,
            'nativeAdapterDeployed':False,'assetClaimsSubmitted':0,'freshProofGeneratedHere':False,'negativeChecks':[]}
    node=None

    def command(args):
        return subprocess.check_output([str(a) for a in args],cwd=ROOT,env=env,text=True,stderr=subprocess.PIPE,timeout=120).strip()

    def rpc(method,params):
        req=urllib.request.Request('http://127.0.0.1:8574',json.dumps({'jsonrpc':'2.0','id':1,'method':method,'params':params}).encode(),{'Content-Type':'application/json'})
        response=json.load(urllib.request.urlopen(req,timeout=15))
        if 'error' in response:raise ValueError(str(response['error']))
        return response['result']

    def calldata(seal,image,digest):
        return command(['cast','calldata','verify(bytes,bytes32,bytes32)',seal,image,digest])

    try:
        verified=json.loads(command([host,'--verify-receipt',evidence/'receipt.json']))
        if (verified.get('verified') is not True or verified.get('receiptKind')!='groth16' or verified.get('headerBinding')!='native-rlp'
            or verified.get('sourceChainId') not in (103,56) or verified.get('evmCompatible') is not True
            or verified.get('chainAuthenticated') is not False or verified.get('realAssetDeploymentAllowed') is not False):
            raise ValueError('genuine compiled native Groth16 receipt required')
        journal=bytes.fromhex(verified['journal'][2:]);seal=verified['seal'];image=verified['imageId']
        if len(journal)!=224 or len(bytes.fromhex(seal[2:]))!=260:raise ValueError('journal/seal width')
        digest='0x'+hashlib.sha256(journal).hexdigest()
        for item in json.loads((ROOT/'docs/risc0-verifier-sources.json').read_text()):
            if hashlib.sha256((ROOT/item['path']).read_bytes()).hexdigest()!=item['local_sha256']:
                raise ValueError('pinned verifier source changed')
        # A stopped owned node can leave TIME_WAIT sockets. Reuse that state,
        # while bind+listen still rejects another live listener on this port.
        with socket.socket() as probe:
            probe.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
            probe.bind(('127.0.0.1',8574));probe.listen(1)
        with (out/'anvil.log').open('w') as log:
            node=subprocess.Popen(['anvil','--silent','--host','127.0.0.1','--port','8574','--chain-id','31337'],stdout=log,stderr=log)
        for _ in range(50):
            if node.poll() is not None:raise RuntimeError('owned Anvil exited')
            try:
                if int(rpc('eth_chainId',[]),16)!=31337:raise ValueError('local chain required')
                break
            except OSError:time.sleep(.1)
        else:raise RuntimeError('Anvil startup timeout')
        sender=rpc('eth_accounts',[])[0]
        deployed=json.loads(command(['forge','create','--root',ROOT/'contracts','src/bridge/LocalRiscZeroGroth16Verifier.sol:LocalRiscZeroGroth16Verifier',
                                    '--rpc-url','http://127.0.0.1:8574','--unlocked','--from',sender,'--broadcast','--json']))
        verifier=deployed['deployedTo'];data=calldata(seal,image,digest)
        tx={'from':sender,'to':verifier,'data':data,'value':'0x0'}
        if rpc('eth_call',[tx,'latest'])!='0x':raise ValueError('unexpected verifier call return')
        receipt=json.loads(command(['cast','send',verifier,'--data',data,'--rpc-url','http://127.0.0.1:8574','--unlocked','--from',sender,'--json']))
        if int(receipt['status'],16)!=1:raise ValueError('verifier transaction failed')
        (out/'verified-transaction.json').write_text(json.dumps(receipt,indent=2)+'\n')
        def flip(h):
            raw=bytearray.fromhex(h[2:]);raw[-1]^=1;return '0x'+raw.hex()
        for name,s,i,d in [('altered-seal',flip(seal),image,digest),('wrong-image',seal,flip(image),digest),('wrong-journal',seal,image,flip(digest))]:
            try:rpc('eth_call',[dict(tx,data=calldata(s,i,d)),'latest'])
            except ValueError as error:
                if 'execution reverted' not in str(error).lower():raise
                report['negativeChecks'].append({'name':name,'rejected':True})
            else:raise ValueError(f'{name} incorrectly accepted')
        if args.receipt_proof:
            fixture=json.loads(args.receipt_proof.read_text())
            number=int.from_bytes(journal[32:64],'big');block='0x'+journal[160:192].hex();parent='0x'+journal[128:160].hex()
            if fixture['blockNumber']!=number or fixture['blockHash'].lower()!=block.lower():
                raise ValueError('native receipt fixture is not covered by the proved header')
            diagnostic=json.loads(command(['forge','create','--root',ROOT/'contracts','test/NativeProofDiagnostic.sol:NativeProofDiagnostic',
                '--rpc-url','http://127.0.0.1:8574','--unlocked','--from',sender,'--broadcast','--json','--constructor-args',verifier,image]))['deployedTo']
            header=f'({number},{block},{parent},{fixture["root"]})'
            signature='verifyHeaderLog(bytes,bytes,(uint64,bytes32,bytes32,bytes32),uint256,uint256,bytes[])'
            def composition_data(index,nodes):
                return command(['cast','calldata',signature,seal,verified['journal'],header,str(index),str(fixture['logIndex']),'['+','.join(nodes)+']'])
            data_combined=composition_data(fixture['txIndex'],fixture['proofNodes'])
            combined_tx=dict(tx,to=diagnostic,data=data_combined)
            result=rpc('eth_call',[combined_tx,'latest'])
            decoded=json.loads(command(['cast','abi-decode','f()((address,bytes32[],bytes))',result,'--json']))[0]
            if (decoded[0].lower()!=fixture['emitter'].lower() or [t.lower() for t in decoded[1]]!=[t.lower() for t in fixture['topics']]
                or decoded[2].lower()!=fixture['data'].lower()):raise ValueError('native EVM decoded log differs from captured receipt')
            combined_receipt=json.loads(command(['cast','send',diagnostic,'--data',data_combined,'--rpc-url','http://127.0.0.1:8574','--unlocked','--from',sender,'--json']))
            if int(combined_receipt['status'],16)!=1:raise ValueError('native proof/MPT diagnostic transaction failed')
            (out/'native-mpt-transaction.json').write_text(json.dumps(combined_receipt,indent=2)+'\n')
            for name,index,nodes in [('wrong-native-mpt-key',fixture['txIndex']+1,fixture['proofNodes']),
                                    ('trailing-native-proof',fixture['txIndex'],fixture['proofNodes']+[fixture['proofNodes'][-1]])]:
                try:rpc('eth_call',[dict(combined_tx,data=composition_data(index,nodes)),'latest'])
                except ValueError as error:
                    if 'execution reverted' not in str(error).lower():raise
                    report['negativeChecks'].append({'name':name,'rejected':True})
                else:raise ValueError('invalid native MPT accepted')
            report.update(realNativeHeaderAndMptDiagnostic=True,diagnosticContract=diagnostic,nativeMptGasUsed=int(combined_receipt['gasUsed'],16),
                nativeMptCalldataBytes=len(bytes.fromhex(data_combined[2:])),decodedNativeLog=decoded,
                receiptFixtureSHA256=hashlib.sha256(args.receipt_proof.read_bytes()).hexdigest())
        code=rpc('eth_getCode',[verifier,'latest'])
        (out/'verifier-runtime.hex').write_text(code+'\n')
        report.update(localVerdict='PASS',realEvmVerifierAcceptance=True,verifier=verifier,imageId=image,
            sourceChainId=verified['sourceChainId'],journal=verified['journal'],journalDigest=digest,
            transactionHash=receipt['transactionHash'],gasUsed=int(receipt['gasUsed'],16),calldataBytes=len(bytes.fromhex(data[2:])),
            receiptSHA256=hashlib.sha256((evidence/'receipt.json').read_bytes()).hexdigest(),
            hostSHA256=hashlib.sha256(host.read_bytes()).hexdigest(),runtimeKeccak=command(['cast','keccak',code]))
    except BaseException as error:
        report['error']=str(error);raise
    finally:
        if node and node.poll() is None:
            node.terminate()
            try:node.wait(timeout=10)
            except subprocess.TimeoutExpired:node.kill();node.wait()
        report['ownedAnvilStopped']=node is None or node.poll() is not None
        (out/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
    print('actual native Groth16 local verifier transaction: PASS; no native updater/asset claim')


if __name__=='__main__':main()
