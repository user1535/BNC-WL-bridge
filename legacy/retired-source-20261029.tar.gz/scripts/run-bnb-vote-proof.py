#!/usr/bin/env python3
"""Bounded separate BNB BLS proof profile; saved actual guest execution required."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess

ROOT = Path(__file__).resolve().parent.parent
BINDING = "bnb-vote-native-rlp-supplied-epoch"


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    global BINDING
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--host", type=Path)
    p.add_argument("--coordinate-hints", action="store_true",
                   help="explicit separate checked-coordinate guest; requires matching actual execution")
    p.add_argument("--input", type=Path, required=True)
    p.add_argument("--execution-evidence", type=Path, required=True)
    p.add_argument("--dir", type=Path, required=True)
    p.add_argument("--resume-receipt", type=Path)
    p.add_argument("--timeout-seconds", type=int, default=1800)
    args = p.parse_args()
    if args.coordinate_hints:
        BINDING = "bnb-vote-native-rlp-supplied-epoch-hinted"
    args.host = args.host or ROOT / ("risc0/bnb-vote/target/release/bridge-bnb-vote-hinted-host" if args.coordinate_hints
                                    else "risc0/bnb-vote/target/release/bridge-bnb-vote-host")
    if not 1 <= args.timeout_seconds <= 1800 or args.input.stat().st_size > 64 * 1024:
        p.error("timeout bound1..1800 seconds; input64KiB")
    if args.resume_receipt and args.resume_receipt.stat().st_size > 64 * 1024 * 1024:
        p.error("resume artifact bound64MiB")
    # Require this actual input to have completed the distinct guest, with the
    # independent Go journal oracle and recorded software execution guards.
    evidence = args.execution_evidence.resolve()
    execution = json.loads((evidence / "summary.json").read_text())
    metadata = json.loads((evidence / "metadata.json").read_text())
    input_sha = sha(args.input)
    matching = [r for r in execution["results"] if r.get("inputSHA256") == input_sha
                and r.get("passed") is True and r.get("execution", {}).get("guestExecuted") is True]
    if (execution.get("status") != "PASS" or execution.get("headerBinding") != BINDING
            or (args.coordinate_hints and execution.get("coordinateHintsChecked") is not True)
            or len(matching) != 1 or matching[0]["execution"].get("suppliedEpochBlsMathVerified") is not True):
        p.error("successful actual guest input and distinct BLS binding required")
    for path, digest in metadata["sourceSHA256"].items():
        if "/host/" not in path and sha(ROOT / path) != digest:
            p.error("guest/source dependency differs from measured input")
    expected_journal = matching[0]["execution"]["journal"]
    native = module("owned_docker", ROOT / "scripts/run-native-proof.py")
    monitor = module("owned_proof_memory", ROOT / "scripts/benchmark-header.py")
    out = args.dir.resolve()
    out.mkdir(parents=True, exist_ok=False)
    host = out / "risc0-host"
    shutil.copy2(args.host, host)
    source_input = out / "input.json"
    shutil.copy2(args.input, source_input)
    resume = None
    if args.resume_receipt:
        resume = out / "resume-input-receipt.json"
        shutil.copy2(args.resume_receipt, resume)
    server = Path.home() / ".cargo/bin/r0vm"
    env = dict(os.environ, RISC0_DEV_MODE="0", RISC0_PROVER="ipc", RISC0_SERVER_PATH=str(server),
               BRIDGE_RISC0_SEGMENT_PO2="19", RAYON_NUM_THREADS="12")
    image = subprocess.check_output([host, "--image-id"], env=env, text=True, timeout=10).strip()
    if image != execution["imageId"] or subprocess.check_output(
            [host, "--header-binding"], env=env, text=True, timeout=10).strip() != BINDING:
        raise ValueError("compiled guest differs from measured BLS execution")
    if sha(server) != metadata["serverSHA256"]:
        raise ValueError("SDK server differs from measured execution")
    physical = os.sysconf("SC_PHYS_PAGES") * os.sysconf("SC_PAGE_SIZE")
    report = {"measuredAt": datetime.now(timezone.utc).isoformat(), "localVerdict": "FAIL",
              "workState": "initializing", "imageId": image, "headerBinding": BINDING,
              "coordinateHintsChecked": args.coordinate_hints,
              "sourceChainId": 56, "nativeHeadersBound": 3, "journalBytes": 352,
              "hostSHA256": sha(host), "inputSHA256": sha(source_input), "serverSHA256": sha(server),
              "executionEvidence": str(evidence), "executionSummarySHA256": sha(evidence / "summary.json"),
              "proofGenerationAttempted": resume is None, "compressionRecoveryAttempted": resume is not None,
              "fullGenerationWallMeasured": False, "segmentPo2": 19, "threads": 12,
              "compressionThreads": 4, "sessionCycleLimit": 1 << 27,
              "memoryLimitKiB": int(physical * .7) // 1024, "timeoutSeconds": args.timeout_seconds,
              "memoryScope": "sampled owned process group RSS; Docker separately hard capped70% physical/no swap",
              "rpcRequests": 0, "assetClaimsSubmitted": 0, "evmAcceptanceMeasured": False,
              "snapshotAuthenticated": False, "ecdsaSealVerified": False, "finalityVerified": False,
              "chainAuthenticated": False, "realAssetDeploymentAllowed": False}
    scope = None
    try:
        subprocess.run(["docker", "info"], capture_output=True, check=True, timeout=30)
        digests = json.loads(subprocess.check_output(["docker", "image", "inspect", "--format",
                            "{{json .RepoDigests}}", native.DOCKER_IMAGE], text=True, timeout=15))
        if not any(d.endswith("@" + native.DOCKER_DIGEST) for d in digests):
            raise ValueError("installed official compressor digest mismatch")
        scope = native.docker_scope(out, env, int(physical * .7), 4, "5GiB", 50)
        report.update(dockerScope=scope, dockerImage=native.DOCKER_IMAGE, dockerDigest=native.DOCKER_DIGEST)
        command = [str(host), "--resume-profile" if resume else "--prove-profile", str(source_input)]
        if resume:
            command.append(str(resume))
        command.append(str(out / "proof"))
        report["workState"] = "proving" if resume is None else "recovering_compression"
        (out / "summary.json").write_text(json.dumps(report, indent=2) + "\n")
        result, resources = monitor.run_with_memory_limit(command, env, report["memoryLimitKiB"], args.timeout_seconds)
        (out / "prove.stdout.json").write_text(result.stdout)
        (out / "prove.stderr.txt").write_text(result.stderr)
        report.update(resources=resources, exitCode=result.returncode)
        if result.returncode:
            raise RuntimeError(f"bounded BLS prover failed with {result.returncode}")
        output = json.loads(result.stdout)
        verified = subprocess.check_output([host, "--verify-receipt", out / "proof/groth16.json"],
                                            env=env, text=True, timeout=120)
        (out / "verified.json").write_text(verified)
        check = json.loads(verified)
        for row in (output, check):
            if (row.get("verified") is not True or row.get("receiptKind") != "groth16"
                    or row.get("imageId") != image or row.get("headerBinding") != BINDING
                    or row.get("journal") != expected_journal or row.get("evmCompatible") is not True
                    or row.get("chainAuthenticated") is not False or row.get("realAssetDeploymentAllowed") is not False):
                raise ValueError("actual Groth16 SDK/image/BLS journal mismatch")
        phases = output["phases"]
        if resume and output.get("resumedFromKind") not in ("composite", "succinct"):
            raise ValueError("unknown saved cryptographic phase")
        expected_kinds = (["succinct", "groth16"] if resume and output["resumedFromKind"] == "succinct"
                          else ["composite", "succinct", "groth16"])
        if ([p["receiptKind"] for p in phases] != expected_kinds or not phases
                or phases[-1]["receiptKind"] != "groth16"
                or not all(p["cryptographicallyVerified"] and p["journalMatches"] for p in phases)
                or len({p["claimDigest"] for p in phases}) != 1
                or output.get("freshCompositeGenerated") is not (resume is None)):
            raise ValueError("missing verified profile phases or incorrect recovery provenance")
        report.update(localVerdict="PASS", workState="complete", output=output,
                      genuineGroth16Verified=True, fullGenerationWallMeasured=resume is None,
                      receiptSHA256=sha(out / "proof/groth16.json"))
    except BaseException as error:
        report.update(workState="failed", error=str(error))
        raise
    finally:
        try:
            report["dockerCleanup"] = native.clean_docker_scope(scope)
        finally:
            report["savedVerifiedPhases"] = json.loads((out / "proof/phases.json").read_text()) if (out / "proof/phases.json").is_file() else []
            (out / "summary.json").write_text(json.dumps(report, indent=2) + "\n")
    print(out / "summary.json", flush=True)


if __name__ == "__main__":
    def interrupted(signum, frame):
        raise KeyboardInterrupt("owned BLS proof interrupted")
    signal.signal(signal.SIGTERM, interrupted)
    main()
