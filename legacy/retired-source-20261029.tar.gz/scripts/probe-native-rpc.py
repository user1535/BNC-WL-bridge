#!/usr/bin/env python3
"""Bounded read-only RPC capabilities on fixed official-documented endpoints."""
import argparse,datetime,hashlib,json,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SOURCES={'worldland':('https://seoul.worldland.foundation/',103,'native-header-rpc-capture'),'bnb':('https://bsc-dataseed.nariox.org/',56,'native-header-bnb-nariox')}
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--output-dir',type=Path,required=True);args=parser.parse_args()
 out=args.output_dir.resolve();out.mkdir(parents=True,exist_ok=False)
 report={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'readOnly':True,'chainAuthenticated':False,'realAssetDeploymentAllowed':False,'proofsGenerated':0,'transactionsSent':0,'rpcCalls':0,'targets':{}}
 for name,(endpoint,chain,capture) in SOURCES.items():
  directory=out/name;directory.mkdir();header=json.loads((ROOT/'results'/capture/name/'parent-response.json').read_text())['result'];row={'endpoint':endpoint,'expectedChainId':chain,'blockNumber':int(header['number'],16),'blockHash':header['hash'],'capabilities':{}}
  report['targets'][name]=row
  def query(label,method,params):
   if method not in ('eth_chainId','eth_getBlockByNumber','eth_getBlockReceipts','eth_getLogs'):raise ValueError('not read-only diagnostic')
   payload={'jsonrpc':'2.0','id':1,'method':method,'params':params};(directory/(label+'-request.json')).write_text(json.dumps(payload)+'\n')
   req=urllib.request.Request(endpoint,json.dumps(payload).encode(),{'Content-Type':'application/json','User-Agent':'WorldLand-BNB-read-only-compatibility'});report['rpcCalls']+=1
   with urllib.request.urlopen(req,timeout=15) as response:raw=response.read(8*1024*1024+1)
   if len(raw)>8*1024*1024:raise ValueError('response limit exceeded')
   (directory/(label+'-response.json')).write_bytes(raw);obj=json.loads(raw)
   if obj.get('error'):raise ValueError(str(obj['error']))
   return obj['result']
  try:
   if int(query('chain-id','eth_chainId',[]),16)!=chain:raise ValueError('unexpected chain ID')
  except Exception as error:row['error']=str(error);continue
  for tag in ['safe','finalized']:
   try:
    result=query(tag,'eth_getBlockByNumber',[tag,False]);row['capabilities'][tag]={'supported':result is not None,'blockNumber':int(result['number'],16) if result else None,'rpcReportedFinalityOnly':True}
   except Exception as error:row['capabilities'][tag]={'supported':False,'error':str(error)}
  try:
   receipts=query('block-receipts','eth_getBlockReceipts',[header['number']])
   if not isinstance(receipts,list) or len(receipts)!=len(header['transactions']):raise ValueError('receipt count differs from transactions')
   types={}
   for index,receipt in enumerate(receipts):
    if receipt['blockHash'].lower()!=header['hash'].lower() or int(receipt['transactionIndex'],16)!=index or receipt['transactionHash'].lower()!=header['transactions'][index].lower():raise ValueError('receipt metadata differs from captured block')
    type_id=int(receipt.get('type','0x0'),16);types[str(type_id)]=types.get(str(type_id),0)+1
   row['capabilities']['blockReceipts']={'supported':True,'receiptCount':len(receipts),'types':types,'metadataChecked':True,'mptRootRecomputed':False,'unknownCurrentCodecTypes':[t for t in types if int(t)>3]}
  except Exception as error:row['capabilities']['blockReceipts']={'supported':False,'error':str(error)}
  try:
   logs=query('narrow-logs','eth_getLogs',[{'fromBlock':header['number'],'toBlock':header['number'],'address':'0x0000000000000000000000000000000000000000'}]);row['capabilities']['narrowLogs']={'supported':isinstance(logs,list),'count':len(logs) if isinstance(logs,list) else None,'scope':'one historical block and zero-address filter; no bridge event tested'}
  except Exception as error:row['capabilities']['narrowLogs']={'supported':False,'error':str(error)}
 report['artifactSha256']={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.rglob('*') if p.is_file()}
 (out/'summary.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report['targets'],indent=2))
if __name__=='__main__':main()
