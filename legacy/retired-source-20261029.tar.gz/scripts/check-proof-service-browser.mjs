import {chromium,launchOptions,runLocalPython} from './browser-runtime.mjs';
import fs from 'node:fs';
import http from 'node:http';
import {execFileSync} from 'node:child_process';
import {Interface} from '../wallet/vendor/ethers-6.15.0.min.mjs';
const root=new URL('../'+(process.argv[2]||'results/prototype-api-session')+'/',import.meta.url);
const session=JSON.parse(fs.readFileSync(new URL('session.json',root)));
const base='http://127.0.0.1:8580',checks=[],sent=[];
let chain='wl';
const owner=session.users[0];
async function rpc(method,params=[],network=chain) {
  const response=await fetch(session.chains[network].rpc,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({jsonrpc:'2.0',id:1,method,params})});
  const body=await response.json();if(body.error) throw new Error(body.error.message);return body.result;
}
async function api(path,body,extra={}) {
  const response=await fetch(base+path,{method:body?'POST':'GET',headers:body?{'Content-Type':'application/json','X-Bridge-Request':'1',...extra}:extra,body:body?JSON.stringify(body):undefined});
  return {status:response.status,data:await response.json()};
}
const browser=await chromium.launch(launchOptions);
const report={passed:false,externalExtensionTested:false,serverSignsOrBroadcasts:false,chainAuthenticated:false,realAssetDeploymentAllowed:false};
try {
  const context=await browser.newContext(),page=await context.newPage(),errors=[];
  page.on('pageerror',error=>errors.push(error.message));
  await page.exposeFunction('__wallet',async({method,params=[]})=>{
    if(method==='eth_requestAccounts'||method==='eth_accounts') return [owner];
    if(method==='wallet_switchEthereumChain') {chain=BigInt(params[0].chainId)===31337n?'wl':'bnb';return null;}
    const value=await rpc(method,params);if(method==='eth_sendTransaction') sent.push({chain,hash:value});return value;
  });
  await page.addInitScript(()=>{window.ethereum={on(){},request:args=>window.__wallet(args)};});
  const connect=async()=>{
    await page.locator('#load-service').click();await page.waitForFunction(()=>!document.getElementById('connect').disabled);
    await page.locator('#connect').click();await page.waitForFunction(()=>document.getElementById('account').textContent.startsWith('0x'));
  };
  await page.goto(base);await connect();
  const snapshot=await rpc('evm_snapshot',[],'wl');
  const waitReady=async()=>{
    for(let i=0;i<40;i++) {
      await page.locator('#poll-proof').click();
      const status=await page.locator('#proof-status').innerText();
      if(status.startsWith('ready')) return;
      if(status.startsWith('failed')) throw new Error(status);
      await page.waitForTimeout(500);
    }
    throw new Error('package timeout');
  };
  let firstJob;
  for(const action of ['lock','burn']) {
    await page.locator(action==='lock'?'#switch-wl':'#switch-bnb').click();
    await page.locator('#action').selectOption(action);await page.locator('#amount').fill('25000000000000000000');
    await page.locator('#prepare-action').click();await page.waitForFunction(()=>!document.getElementById('submit').disabled);
    await page.locator('#submit').click();await page.waitForFunction(()=>document.getElementById('status').textContent.includes('지갑이 전송한 거래:'));
    await page.locator('#recover').click();await page.waitForFunction(()=>document.getElementById('status').textContent==='거래가 수락됐습니다.');
    await page.locator('#request-proof').click();await page.waitForFunction(()=>document.getElementById('status').textContent.includes('요청을 저장했습니다.'));
    const saved=await page.evaluate(()=>JSON.parse(localStorage.getItem('worldland-bnb-proof-request-v1')));
    if(action==='lock') firstJob=saved;
    await page.waitForTimeout(2300);
    const before=await api('/api/jobs/'+saved.id);
    if(before.data.state!=='waiting_confirmations') throw new Error('confirmation policy bypassed: '+before.data.state);
    checks.push(action+' confirmation wait');
    const duplicate=await api('/api/jobs',saved.request);
    if(duplicate.data.id!==saved.id) throw new Error('non-idempotent request');
    const source=action==='lock'?'wl':'bnb',destination=action==='lock'?'bnb':'wl';
    await rpc('evm_mine',[],source);await rpc('evm_mine',[],source);await waitReady();
    let result=await api('/api/jobs/'+saved.id+'/package');
    if(result.status!==200 || result.data.headerCovered) throw new Error('expected unsigned uncovered dev header');
    const proof=result.data;
    runLocalPython(['scripts/register-prototype-dev-header.py','--session',process.argv[2]||'results/prototype-api-session','--job',saved.id]);
    await page.locator('#request-proof').click();await waitReady();
    await page.reload();await connect();await page.locator('#poll-proof').click();
    await page.waitForFunction(()=>!document.getElementById('prepare-claim').disabled);
    await page.locator(destination==='wl'?'#switch-wl':'#switch-bnb').click();
    await page.locator('#prepare-claim').click();await page.waitForFunction(()=>!document.getElementById('submit').disabled);
    await page.locator('#submit').click();await page.waitForFunction(()=>document.getElementById('status').textContent.includes('지갑이 전송한 거래:'));
    await page.locator('#recover').click();await page.waitForFunction(()=>document.getElementById('status').textContent==='거래가 수락됐습니다.');
    checks.push(action+' API package + browser claim + reload recovery');
  }
  const tokenAbi=new Interface(['function balanceOf(address) view returns(uint256)','function lockedBalanceOf(address) view returns(uint256)']);
  const call=async(network,to,name)=>tokenAbi.decodeFunctionResult(name,await rpc('eth_call',[{to,data:tokenAbi.encodeFunctionData(name,[owner])},'latest'],network))[0].toString();
  const balances={original:await call('wl',session.contracts.original,'balanceOf'),locked:await call('wl',session.contracts.original,'lockedBalanceOf'),wrapped:await call('bnb',session.contracts.wrapped,'balanceOf')};
  if(balances.original!=='100000000000000000000'||balances.locked!=='0'||balances.wrapped!=='0') throw new Error('conservation failed');
  const bad=await api('/api/jobs',{...firstJob.request,rpc:'http://evil'});
  if(bad.status!==400) throw new Error('accepted caller RPC override');
  const cross=await api('/api/jobs',firstJob.request,{Origin:'http://evil.example'});
  if(cross.status!==403) throw new Error('accepted cross-origin request');
  const dns=await new Promise((resolve,reject)=>{
    const request=http.get(base+'/api/manifest',{headers:{Host:'evil.example:8580'}},response=>{
      response.resume();response.on('end',()=>resolve({status:response.statusCode}));
    });request.on('error',reject);
  });
  if(dns.status!==403) throw new Error('accepted invalid Host');
  await rpc('evm_revert',[snapshot],'wl');
  const stale=await api('/api/jobs/'+firstJob.id+'/package');
  if(stale.status!==409) throw new Error('delivered stale reorg proof');
  checks.push('request policy + source reorg rejection');
  if(errors.length) throw new Error(errors.join(';'));
  await page.screenshot({path:(await import('node:url')).fileURLToPath(new URL('prototype-screen.png',root)),fullPage:true});
  Object.assign(report,{passed:true,checks,balances,walletTransactions:sent,firstJob});
} catch(error) {report.error=error.message;report.checks=checks;report.walletTransactions=sent;report.screenStatus=await (await browser.contexts()[0]?.pages()[0]?.locator('#status'))?.innerText();throw error;}
finally {
  fs.writeFileSync(new URL('api-browser-summary.json',root),JSON.stringify(report,null,2)+'\n');
  await browser.close();
}
