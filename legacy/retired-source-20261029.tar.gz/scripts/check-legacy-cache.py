#!/usr/bin/env python3
"""Verify the current generator reuses a legacy schema/image without proving.

Uses copied public Anvil state and copied proof cache. Original sessions stay stopped.
"""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import time
import urllib.request

ROOT=Path(__file__).resolve().parents[1]


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--session',type=Path,default=ROOT/'results/session-zk-multiblock')
    parser.add_argument('--output-dir',type=Path,default=ROOT/'results/legacy-cache-reuse')
    args=parser.parse_args()
    source=args.session.resolve();output=args.output_dir.resolve();output.mkdir(parents=True,exist_ok=False)
    original_package=json.loads((source/'lock-10-3-headers.json').read_text())
    host=output/'risc0-host';shutil.copy2(source/'risc0-host',host)
    state=output/'wl-state.json';shutil.copy2(source/'wl-state.json',state)
    shutil.copytree(source/'proof-cache',output/'proof-cache')
    original_state_hash=hashlib.sha256((source/'wl-state.json').read_bytes()).hexdigest()
    hashes=lambda directory:{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (directory/'proof-cache/groth16').glob('*.json')}
    before=hashes(output);original_cache=hashes(source)
    matching=[json.loads(p.read_text()) for p in (output/'proof-cache/groth16').glob('*.json')
              if json.loads(p.read_text())['key']['startBlock']==10 and json.loads(p.read_text())['key']['endBlock']==12]
    assert len(matching)==1 and matching[0].get('version',0)==0 and matching[0]['key']['imageId']==original_package['imageId']
    # Proving is blocked even if an unexpected cache miss occurs.
    proxy=output/'verify-only-host'
    proxy.write_text('#!/usr/bin/env python3\nimport os,sys\nfrom pathlib import Path\n'
        +f'root=Path({str(output)!r})\n'
        +'with (root/"host-commands.log").open("a") as log: log.write(sys.argv[1]+"\\n")\n'
        +'if sys.argv[1]=="--prove-receipt": (root/"unexpected-proving").write_text("blocked"); sys.exit(1)\n'
        +'os.execv(str(root/"risc0-host"),[str(root/"risc0-host")]+sys.argv[1:])\n')
    proxy.chmod(0o700)
    url='http://127.0.0.1:8572'

    def rpc(method,params):
        request=urllib.request.Request(url,json.dumps({'jsonrpc':'2.0','id':1,'method':method,'params':params}).encode(),{'Content-Type':'application/json'})
        result=json.load(urllib.request.urlopen(request,timeout=15))
        if 'error' in result:raise RuntimeError(str(result['error']))
        return result['result']

    try:rpc('eth_chainId',[])
    except OSError:pass
    else:raise RuntimeError('legacy-cache clone port is already in use')
    report={'localVerdict':'FAIL','sourceSessionUnchanged':False,'proofGeneratedHere':False,
            'chainAuthenticated':False,'realAssetDeploymentAllowed':False}
    with (output/'anvil.log').open('w') as log:
        node=subprocess.Popen(['anvil','--silent','--host','127.0.0.1','--port','8572','--chain-id','31337',
                               '--state',str(state),'--preserve-historical-states'],stdout=log,stderr=log)
    try:
        for _ in range(50):
            if node.poll() is not None:raise RuntimeError('owned clone failed to start')
            try:assert int(rpc('eth_chainId',[]),16)==31337;break
            except OSError:time.sleep(.1)
        else:raise RuntimeError('clone startup timeout')
        for header in original_package['guestInput']['headers']:
            actual=rpc('eth_getBlockByNumber',[hex(header['number']),False])
            assert actual['hash'].lower()=='0x'+bytes(header['block_hash']).hex()
            assert actual['receiptsRoot'].lower()=='0x'+bytes(header['receipt_root']).hex()
        binary=ROOT/'.bin/bridge-header-data'
        subprocess.run(['go','-C',str(ROOT/'proof-generator'),'build','-o',str(binary),'./cmd/bridge-header-data'],check=True)
        run=subprocess.run([str(binary),'--rpc',url,'--chain-id','31337','--start','10','--count','3',
                            '--risc0-host',str(proxy),'--proof-cache',str(output/'proof-cache'),'--receipt-kind','groth16'],capture_output=True,text=True,timeout=120)
        (output/'stdout.json').write_text(run.stdout);(output/'stderr.log').write_text(run.stderr)
        if run.returncode:raise RuntimeError(run.stderr)
        package=json.loads(run.stdout)
        assert package['cacheHit'] and package['proofVerified'] and package['imageId']==original_package['imageId']
        assert package['headerBinding']=='minimal-link' and not package['hashBindingVerified'] and not package['chainAuthenticated']
        assert not (output/'unexpected-proving').exists() and hashes(output)==before
        assert hashes(source)==original_cache and hashlib.sha256((source/'wl-state.json').read_bytes()).hexdigest()==original_state_hash
        report.update({'localVerdict':'PASS','sourceSessionUnchanged':True,'cacheHit':True,'schema':0,'imageId':package['imageId'],
                       'headerBinding':'minimal-link','cacheFilesUnchanged':True,'hostSHA256':hashlib.sha256(host.read_bytes()).hexdigest()})
        print('current Go generator + legacy schema0/image + actual Groth16 cache hit: PASS; proof generation blocked')
    except Exception as error:report['error']=str(error);raise
    finally:
        if node.poll() is None:node.terminate()
        try:node.wait(timeout=10)
        except subprocess.TimeoutExpired:node.kill();node.wait(timeout=5)
        (output/'summary.json').write_text(json.dumps(report,indent=2)+'\n')


if __name__=='__main__':main()
