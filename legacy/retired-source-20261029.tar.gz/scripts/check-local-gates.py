#!/usr/bin/env python3
"""Reproducible local checks. Never declares source authentication or live readiness."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[1]


def evidence(directory, host, binding='minimal-link'):
    summary = json.loads((directory / 'summary.json').read_text())
    for key in ('real_evm_header_acceptance', 'mpt_roundtrip', 'user_signed_header_and_claims'):
        if summary.get(key) is not True:
            raise ValueError(f'missing genuine local evidence: {key}')
    if summary.get('chain_authenticated') is not False or summary.get('real_asset_deployment_allowed') is not False:
        raise ValueError('local evidence must not claim authenticated/live deployment')
    if summary.get('header_binding', 'minimal-link') != binding:
        raise ValueError('evidence header binding does not match requested predicate')
    if binding == 'canonical-rlp' and summary.get('hash_binding_verified') is not True:
        raise ValueError('missing canonical-RLP hash binding evidence')
    receipts = []
    for direction in ('lock', 'burn'):
        package = json.loads((directory / f'{direction}-header.json').read_text())
        accepted = json.loads((directory / f'{direction}-header-accepted.json').read_text())
        if int(accepted['status'], 16) != 1:
            raise ValueError('header transaction did not succeed')
        if package.get('receiptKind') != 'groth16' or package.get('chainAuthenticated') is not False:
            raise ValueError('not the genuine local Groth16 path')
        receipt = directory / f'.gate-{direction}-receipt.json'
        receipt.write_text(json.dumps(package['proofReceipt']))
        try:
            env = dict(os.environ, RISC0_DEV_MODE='0', RISC0_PROVER='ipc')
            verified = json.loads(subprocess.check_output([str(host), '--verify-receipt', str(receipt)], env=env, text=True, timeout=120))
        finally:
            receipt.unlink(missing_ok=True)
        if (verified.get('verified') is not True or verified.get('receipt_kind') != 'groth16'
                or verified.get('evm_compatible') is not True or verified.get('chain_authenticated') is not False
                or verified.get('image_id') != package['imageId'] or verified.get('journal') != package['journal']
                or verified.get('seal') != package['seal']):
            raise ValueError('host/image/journal/seal evidence mismatch')
        if verified.get('header_binding', 'minimal-link') != binding or package.get('headerBinding', 'minimal-link') != binding:
            raise ValueError('cryptographically verified header binding mismatch')
        if binding == 'canonical-rlp' and package.get('hashBindingVerified') is not True:
            raise ValueError('canonical-RLP package did not verify hash binding')
        receipts.append({'direction': direction, 'imageId': verified['image_id'], 'headerBinding': binding,
                         'cryptographicallyReverified': True})
    return receipts


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', choices=('fast', 'zk', 'all'), default='fast')
    parser.add_argument('--evidence-only', action='store_true', help='zk: reverify historical receipts instead of a fresh proof generation/roundtrip')
    parser.add_argument('--zk-evidence', type=Path, default=ROOT / 'results/local-risc0-current')
    parser.add_argument('--host', type=Path, default=ROOT / 'risc0/target/release/bridge-header-benchmark')
    parser.add_argument('--header-binding', choices=('minimal-link', 'canonical-rlp'), default='minimal-link')
    parser.add_argument('--bound-evidence', type=Path, help='also reverify an existing strict Groth16 roundtrip')
    parser.add_argument('--native-worldland-evidence', type=Path, help='genuine native Groth16; fresh local verifier transaction, no asset claim')
    parser.add_argument('--native-bnb-evidence', type=Path, help='genuine native Groth16 covering saved type4 block; fresh EVM/MPT diagnostic')
    parser.add_argument('--local-updater-evidence', type=Path, action='append', default=[],
                        help='optional bounded local Groth16 batch: reverify SDK proof and fresh actual updater/root/negative checks; no asset claim')
    parser.add_argument('--local-updater-max-headers', type=int, choices=(4, 8, 16, 32, 64, 128), default=4,
                        help='explicit ceiling for optional larger phase-profile diagnostics; normal generator cap stays4')
    parser.add_argument('--large-user-evidence', type=Path,
                        help='completed actual16 shared3user scenario; recheck SDK, MPT and balances on copied state, broadcasts0')
    parser.add_argument('--wallet-node', type=Path, help='optional Node executable for offline wallet tests; no wallet or RPC signing')
    parser.add_argument('--coverage', action='store_true', help='collect instrumentation coverage, separate from deployment bytecode')
    parser.add_argument('--bls-evm-diagnostic', action='store_true', help='optional RISC0-free local actual BNB BLS and missing-precompile checks; unauthenticated keys')
    parser.add_argument('--bls-raw-header-diagnostic', action='store_true',
                        help='optional RISC0-free actual source/target raw commitments and BLS; no finality/asset authority')
    parser.add_argument('--bls-attesting-header-diagnostic', action='store_true',
                        help='optional supplied-key BLS with extracted non-epoch attesting payload and compressed signature binding')
    parser.add_argument('--bls-epoch-header-diagnostic', action='store_true',
                        help='also bind supplied post-Bohr raw epoch key slots; no authenticated eligibility or transition')
    parser.add_argument('--bls-sealed-header-diagnostic', action='store_true',
                        help='also bind pinned BNB56 ECDSA seals to supplied epoch members; no active snapshot/finality')
    parser.add_argument('--bnb-snapshot-schedule-diagnostic', action='store_true',
                        help='optional supplied fixed-epoch delay/role arithmetic; no actual snapshot replay/authentication')
    parser.add_argument('--bnb-fork-predicate-diagnostic', action='store_true',
                        help='optional pinned config block/time predicates; no native fork/consensus authentication')
    parser.add_argument('--bnb-risc0-vote-guest', action='store_true',
                        help='optional fresh distinct352byte BNB BLS guest execution; no proof generation/finality')
    parser.add_argument('--bnb-risc0-vote-evidence', type=Path,
                        help='optional actual352byte BNB BLS Groth16 evidence; fresh stateless Cancun EVM checks')
    parser.add_argument('--bnb-risc0-vote-coordinate-hints', action='store_true',
                        help='explicit ee7d hinted Groth16 EVM candidate; requires matching BNB vote evidence')
    parser.add_argument('--output-dir', type=Path)
    args = parser.parse_args()
    if args.bnb_risc0_vote_coordinate_hints and not args.bnb_risc0_vote_evidence:
        parser.error('hinted EVM candidate requires explicit BNB vote Groth16 evidence')
    if args.mode == 'fast' and (args.bound_evidence or args.header_binding != 'minimal-link' or args.native_worldland_evidence or args.native_bnb_evidence or args.local_updater_evidence or args.large_user_evidence or args.bnb_risc0_vote_guest or args.bnb_risc0_vote_evidence):
        parser.error('fast gate does not use RISC0; use zk/all for strict evidence')
    if bool(args.native_worldland_evidence) != bool(args.native_bnb_evidence):
        parser.error('native gate requires independent WorldLand and BNB evidence together')
    if args.local_updater_max_headers != 4 and not args.local_updater_evidence:
        parser.error('larger local diagnostic ceiling requires explicit local updater evidence')
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    output = (args.output_dir or ROOT / 'results/gates' / stamp).resolve()
    output.mkdir(parents=True, exist_ok=False)
    report = {'measuredAt': stamp, 'requestedMode': args.mode, 'checks': [], 'localVerdict': 'FAIL',
              'chainAuthenticated': False, 'realAssetDeploymentAllowed': False,
              'productionVerdict': 'INCOMPLETE', 'performanceVerdict': 'INCONCLUSIVE',
              'remainingGates': ['source consensus/finality authentication', 'sustained accepted throughput',
                                 'actual asset integration', 'external security audit', 'live RPC compatibility']}
    env = dict(os.environ, RISC0_DEV_MODE='0', RISC0_PROVER='ipc')

    def check(name, command, timeout=600, extra_env=None):
        with (output / f'{name}.log').open('w') as log:
            result = subprocess.run(command, cwd=ROOT, env=dict(env, **(extra_env or {})), stdout=log,
                                    stderr=subprocess.STDOUT, timeout=timeout)
        report['checks'].append({'name': name, 'command': command, 'exitCode': result.returncode})
        if result.returncode:
            raise ValueError(f'{name} failed; see {output / (name + ".log")}')

    try:
        for item in json.loads((ROOT / 'docs/risc0-verifier-sources.json').read_text()):
            if hashlib.sha256((ROOT / item['path']).read_bytes()).hexdigest() != item['local_sha256']:
                raise ValueError(f'vendored source changed: {item["path"]}')
        report['checks'].append({'name': 'pinned_verifier_sources', 'passed': True})
        reference_dir = ROOT / 'docs/protocol-sources'
        for item in json.loads((reference_dir / 'manifest.json').read_text()):
            if hashlib.sha256((reference_dir / item['file']).read_bytes()).hexdigest() != item['sha256']:
                raise ValueError(f'protocol reference changed: {item["file"]}')
        for item in json.loads((reference_dir / 'oracle-manifest.json').read_text()):
            if hashlib.sha256((ROOT / item['path']).read_bytes()).hexdigest() != item['localSHA256']:
                raise ValueError(f'protocol oracle changed: {item["path"]}')
        report['checks'].append({'name': 'pinned_protocol_encoders', 'passed': True})
        for manifest_path in ('wallet/vendor/manifest.json', 'wallet/testdata/manifest.json',
                              'docs/native-receipt-fixtures.json', 'docs/native-proof-fixtures.json'):
            for item in json.loads((ROOT / manifest_path).read_text())['files']:
                if hashlib.sha256((ROOT / item['path']).read_bytes()).hexdigest() != item['sha256']:
                    raise ValueError(f'wallet source/fixture changed: {item["path"]}')
        report['checks'].append({'name': 'pinned_wallet_and_native_receipt_sources_and_fixtures', 'passed': True})
        captured = ROOT / 'proof-generator/internal/chain/testdata/native-live-captured'
        for item in json.loads((captured / 'manifest.json').read_text())['fixtures']:
            if hashlib.sha256((captured / item['file']).read_bytes()).hexdigest() != item['sha256']:
                raise ValueError(f'captured native header changed: {item["file"]}')
        report['checks'].append({'name': 'pinned_captured_native_headers', 'passed': True})
        check('go-race', ['go', '-C', 'proof-generator', 'test', '-race', './...'])
        check('go-vet', ['go', '-C', 'proof-generator', 'vet', './...'])
        check('foundry', ['forge', 'test', '--root', 'contracts'])
        if args.wallet_node:
            check('wallet-unit', [str(args.wallet_node), '--test', 'wallet/client.test.mjs'])
        if args.bls_evm_diagnostic:
            report['blsEvmDiagnostics'] = []
            for fork in ('prague', 'cancun'):
                directory = output / ('bls-evm-' + fork)
                check('bls-evm-' + fork, ['python3', str(ROOT / 'scripts/verify-bnb-bls-evm.py'),
                    '--hardfork', fork, '--output-dir', str(directory)])
                diagnostic = json.loads((directory / 'summary.json').read_text())
                if (diagnostic.get('localVerdict') != 'PASS' or diagnostic.get('risc0Used') is not False
                    or diagnostic.get('chainAuthenticated') is not False or diagnostic.get('realAssetDeploymentAllowed') is not False
                    or diagnostic.get('validatorSetAuthenticated') is not False or diagnostic.get('assetClaimsSubmitted') != 0
                    or diagnostic.get('ownedNodeStopped') is not True
                    or (fork == 'prague' and diagnostic.get('actualEvmBlsPairingMeasured') is not True)
                    or (fork == 'cancun' and diagnostic.get('missingPrecompilesFailClosedMeasured') is not True)):
                    raise ValueError('BLS diagnostic scope mismatch')
                report['blsEvmDiagnostics'].append({'hardfork': fork, 'directory': str(directory),
                    'actualEvmBlsPairingMeasured': fork == 'prague', 'chainAuthenticated': False})
        for variant, enabled in [('raw', args.bls_raw_header_diagnostic), ('attesting', args.bls_attesting_header_diagnostic),
                                 ('epoch', args.bls_epoch_header_diagnostic), ('sealed', args.bls_sealed_header_diagnostic)]:
            if not enabled: continue
            key = {'raw':'blsRawHeaderDiagnostics','attesting':'blsAttestingHeaderDiagnostics',
                   'epoch':'blsEpochHeaderDiagnostics', 'sealed':'blsSealedHeaderDiagnostics'}[variant]
            report[key] = []
            for fork in ('prague', 'cancun'):
                directory = output / ('bls-' + variant + '-header-' + fork)
                check('bls-' + variant + '-header-' + fork, ['python3', str(ROOT / 'scripts/verify-bnb-raw-header-vote.py'),
                    '--hardfork', fork, '--output-dir', str(directory)] + (['--attesting-header'] if variant != 'raw' else [])
                    + (['--epoch-header'] if variant in ('epoch','sealed') else [])
                    + (['--ecdsa-seals'] if variant == 'sealed' else []))
                raw = json.loads((directory / 'summary.json').read_text())
                if (raw.get('localVerdict') != 'PASS' or raw.get('risc0Used') is not False
                    or raw.get('proofsGenerated') != 0 or raw.get('assetClaimsSubmitted') != 0
                    or raw.get('rawHeaderCommitmentsMeasured') is not True or raw.get('ownedNodeStopped') is not True
                    or raw.get('validatorSetAuthenticated') is not False or raw.get('finalityVerified') is not False
                    or raw.get('nativeForkPolicyValidated') is not False or raw.get('chainAuthenticated') is not False
                    or raw.get('realAssetDeploymentAllowed') is not False
                    or (fork == 'prague' and raw.get('actualEvmSignedRawHeaderPairing') is not True)
                    or (fork == 'cancun' and raw.get('missingPrecompilesFailClosed') is not True)):
                    raise ValueError('raw header/supplied-vote diagnostic scope mismatch')
                if variant != 'raw' and (raw.get('attestingHeaderPayloadBoundHere') is not True
                    or raw.get('compressedSignatureBoundToPairingInput') is not True
                    or raw.get('attestingEcdsaSealVerified') is not (variant == 'sealed') or raw.get('validatorTransitionVerified') is not False
                    or raw.get('publicPointCompressionOracleCases') != 4 or raw.get('compressionOracleSortBits') != [False, True]):
                    raise ValueError('attesting diagnostic did not bind raw signature or exceeded its authentication scope')
                if variant in ('epoch','sealed') and (raw.get('suppliedEpochKeysBoundHere') is not True
                    or raw.get('epochEligibilityAuthenticated') is not False or raw.get('epochOptionalVotePayloadValidated') is not True
                    or raw.get('epochOptionalVoteSignatureVerified') is not False
                    or raw.get('epochVoteSchemaOracleCases') != 37 or raw.get('epochVoteSchemaPositiveCases') != 7
                    or raw.get('epochVoteSchemaNegativeCases') != 30 or len(raw.get('epochVoteSchemaChecks',[])) != 37
                    or not all(c.get('evmAgreement') is True and c.get('bothSchemaAndCommitmentPathChecked') is True
                               for c in raw.get('epochVoteSchemaChecks',[]))):
                    raise ValueError('epoch key binding was missing or claimed authenticated native policy')
                if variant in ('epoch','sealed'):
                    artifact = directory / 'epoch-vote-schema-oracle.json'
                    if hashlib.sha256(artifact.read_bytes()).hexdigest() != raw.get('epochVoteSchemaOracleSHA256'):
                        raise ValueError('epoch schema oracle artifact changed')
                if variant == 'sealed':
                    if (raw.get('ecdsaSealMathMeasured') is not True
                        or raw.get('ecdsaSignerMembershipAgainstSuppliedEpoch') is not True
                        or raw.get('sourceChainIdForSeal') != 56 or raw.get('supportedSealRecoveryIds') != [0,1]
                        or raw.get('snapshotAuthenticated') is not False
                        or raw.get('recentSignerAndTurnPolicyVerified') is not False
                        or raw.get('timingDifficultyPolicyVerified') is not False
                        or raw.get('epochSealSignerMembershipInOwnAnnouncedSetRequired') is not False
                        or len(raw.get('ecdsaSealChecks',[])) != 5
                        or not all(c.get('goEvmAgreement') is True and c.get('signerMatchesCoinbase') is True
                                   for c in raw.get('ecdsaSealChecks',[]))
                        or raw.get('ecdsaSealCodecOracleCases') != 29
                        or raw.get('ecdsaSealRecoveryPositiveCases') != 7 or raw.get('ecdsaSealRecoveryNegativeCases') != 22
                        or len(raw.get('ecdsaSealCodecChecks',[])) != 29
                        or not all(c.get('goEvmAgreement') is True for c in raw.get('ecdsaSealCodecChecks',[]))
                        or raw.get('unsupportedSourceDomainsRejected') != [0,57,31337]
                        or raw.get('publicHighSMalleationAccepted') is not True):
                        raise ValueError('ECDSA seal oracle or unauthenticated snapshot scope mismatch')
                    artifact = directory / 'ecdsa-seal-codec-oracle.json'
                    if hashlib.sha256(artifact.read_bytes()).hexdigest() != raw.get('ecdsaSealCodecOracleSHA256'):
                        raise ValueError('ECDSA seal codec oracle artifact changed')
                report[key].append({'hardfork': fork, 'directory': str(directory),
                    'rawHeaderCommitmentsMeasured': True, 'freshProofGeneration': False,
                    'attestingHeaderPayloadBoundHere': variant != 'raw', 'suppliedEpochKeysBoundHere': variant in ('epoch','sealed'),
                    'ecdsaSealMathMeasured': variant == 'sealed',
                    'assetClaimsSubmitted': 0, 'chainAuthenticated': False})
        if args.bnb_snapshot_schedule_diagnostic:
            directory = output / 'bnb-snapshot-schedule'
            check('bnb-snapshot-schedule', ['python3', str(ROOT / 'scripts/verify-bnb-snapshot-schedule.py'),
                '--output-dir', str(directory)])
            schedule = json.loads((directory / 'summary.json').read_text())
            if (schedule.get('localVerdict') != 'PASS' or schedule.get('risc0Used') is not False
                or schedule.get('proofsGenerated') != 0 or schedule.get('assetClaimsSubmitted') != 0
                or schedule.get('ownedNodeStopped') is not True or schedule.get('chainAuthenticated') is not False
                or schedule.get('realAssetDeploymentAllowed') is not False
                or schedule.get('profileAssumption') != 'supplied-post-bohr-fixed-epoch1000'
                or schedule.get('actualSnapshotReplayMeasured') is not False or schedule.get('snapshotAuthenticated') is not False
                or schedule.get('forkPolicyAuthenticated') is not False or schedule.get('oldConfigurationsAuthenticated') is not False
                or schedule.get('finalityVerified') is not False or schedule.get('scheduleOracleCases') != 67
                or schedule.get('schedulePositiveCases') != 54 or schedule.get('scheduleNegativeCases') != 13
                or schedule.get('actualRoleCases') != 2 or schedule.get('roleNegativeCases') != 4
                or len(schedule.get('scheduleChecks',[])) != 67
                or not all(c.get('goEvmAgreement') is True for c in schedule.get('scheduleChecks',[]))):
                raise ValueError('supplied snapshot arithmetic evidence/scope mismatch')
            if hashlib.sha256((directory/'snapshot-schedule-oracle.json').read_bytes()).hexdigest() != schedule.get('oracleSHA256'):
                raise ValueError('snapshot arithmetic oracle artifact changed')
            report['bnbSnapshotScheduleDiagnostic'] = {'directory':str(directory),'scheduleOracleCases':67,
                'actualRoleCases':2,'actualSnapshotReplayMeasured':False,'chainAuthenticated':False}
        if args.bnb_fork_predicate_diagnostic:
            directory = output / 'bnb-fork-predicates'
            check('bnb-fork-predicates', ['python3', str(ROOT / 'scripts/verify-bnb-fork-predicates.py'),
                '--output-dir', str(directory)])
            forks = json.loads((directory/'summary.json').read_text())
            if (forks.get('localVerdict') != 'PASS' or forks.get('risc0Used') is not False
                or forks.get('proofsGenerated') != 0 or forks.get('assetClaimsSubmitted') != 0
                or forks.get('ownedNodeStopped') is not True or forks.get('chainAuthenticated') is not False
                or forks.get('realAssetDeploymentAllowed') is not False or forks.get('forkPolicyAuthenticated') is not False
                or forks.get('snapshotAuthenticated') is not False or forks.get('finalityVerified') is not False
                or forks.get('nativeForkPolicyValidated') is not False or forks.get('forkPredicatesCompared') is not True
                or forks.get('scalarOracleCases') != 48 or forks.get('scalarPositiveCases') != 42
                or forks.get('scalarNegativeCases') != 6 or forks.get('actualRawCases') != 5 or forks.get('rawNegativeCases') != 6
                or forks.get('flagOrder') != ['London','Luban','Bohr','Lorentz','Maxwell','Fermi','Osaka','Mendel','Pasteur']
                or len(forks.get('scalarChecks',[])) != 48 or len(forks.get('actualRawChecks',[])) != 5
                or not all(c.get('goEvmAgreement') is True for c in forks.get('scalarChecks',[])+forks.get('actualRawChecks',[]))):
                raise ValueError('pinned config fork predicate evidence/scope mismatch')
            if hashlib.sha256((directory/'fork-predicate-oracle.json').read_bytes()).hexdigest() != forks.get('oracleSHA256'):
                raise ValueError('fork predicate oracle artifact changed')
            report['bnbForkPredicateDiagnostic'] = {'directory':str(directory),'scalarOracleCases':48,
                'actualRawCases':5,'nativeForkPolicyValidated':False,'chainAuthenticated':False}
        if args.coverage:
            check('foundry-coverage', ['forge', 'coverage', '--root', 'contracts', '--ir-minimum',
                                     '--report', 'lcov', '--report-file', str(output / 'coverage.lcov')])
            report['coverageScope'] = 'instrumented Solidity; not the deployed proof-verifier bytecode'
        if args.mode in ('fast', 'all'):
            fast_directory = output / 'fresh-fast'
            check('fast-roundtrip', [str(ROOT / 'scripts/run-local.sh'), 'fast'],
                  extra_env={'FAST_RESULT_DIR': str(fast_directory)})
            report['fastEvidence'] = json.loads((fast_directory / 'summary.json').read_text())
        if args.mode in ('zk', 'all'):
            directory = args.zk_evidence
            if not args.evidence_only:
                directory = output / 'fresh-zk'
                route = 'zk-bound' if args.header_binding == 'canonical-rlp' else 'zk'
                check('zk-roundtrip', [str(ROOT / 'scripts/run-local.sh'), route], timeout=6000,
                      extra_env={'RESULT_DIR': str(directory)})
            # A fresh run pins its own compiled image. Historical legacy runs may
            # use --host; never overwrite a snapshot to fit a newer guest.
            host = directory / 'risc0-host' if (directory / 'risc0-host').exists() else args.host
            report['zkEvidence'] = {'directory': str(directory), 'freshGeneration': not args.evidence_only,
                                    'receipts': evidence(directory, host, args.header_binding)}
            if args.bound_evidence:
                bound_host = args.bound_evidence / 'risc0-host'
                report['boundEvidence'] = {'directory': str(args.bound_evidence), 'freshGeneration': False,
                                          'receipts': evidence(args.bound_evidence, bound_host, 'canonical-rlp')}
            if args.large_user_evidence:
                directory = output / 'large-user-state-rechecked'
                check('large-user-state-rechecked', ['python3', str(ROOT / 'scripts/verify-large-local-session.py'),
                    '--evidence', str(args.large_user_evidence), '--output-dir', str(directory)])
                large = json.loads((directory / 'summary.json').read_text())
                if (large.get('localVerdict') != 'PASS' or large.get('persistedStateRechecked') is not True
                    or large.get('originalEvidenceUnchanged') is not True or large.get('ownedNodesStopped') is not True
                    or large.get('mptClaimsRegenerated') != 6 or large.get('fullHeaderRootsChecked') != 32
                    or large.get('consumedClaimReplaysRejected') != 6 or large.get('transactionsBroadcast') != 0
                    or large.get('freshProofGenerated') is not False or large.get('chainAuthenticated') is not False
                    or large.get('realAssetDeploymentAllowed') is not False):
                    raise ValueError('large-user persisted evidence scope mismatch')
                report['largeUserEvidence'] = {'source': str(args.large_user_evidence), 'directory': str(directory),
                    'persistedStateRechecked': True, 'mptClaimsRegenerated': 6, 'consumedClaimReplaysRejected': 6,
                    'freshProofGeneration': False, 'transactionsBroadcast': 0, 'chainAuthenticated': False}
            if args.bnb_risc0_vote_guest:
                directory = output / 'bnb-risc0-vote-guest'
                check('bnb-risc0-vote-guest', ['python3', str(ROOT / 'scripts/check-bnb-vote-guest.py'),
                      '--dir', str(directory)], timeout=600)
                guest = json.loads((directory / 'summary.json').read_text())
                positives = [r for r in guest['results'] if 'execution' in r]
                negatives = [r for r in guest['results'] if 'expectedRejection' in r]
                if (guest.get('status') != 'PASS' or guest.get('headerBinding') != 'bnb-vote-native-rlp-supplied-epoch'
                    or len(positives) != 2 or len(negatives) != 7
                    or not all(r.get('passed') is True for r in guest['results'])
                    or not all(r['execution'].get('guestExecuted') is True
                               and r['execution'].get('suppliedEpochBlsMathVerified') is True for r in positives)
                    or any(guest.get(k) is not False for k in ('proofGenerated', 'evmAcceptanceMeasured',
                            'snapshotAuthenticated', 'finalityVerified', 'chainAuthenticated', 'realAssetDeploymentAllowed'))):
                    raise ValueError('separate BNB BLS guest execution scope mismatch')
                report['bnbRisc0VoteGuest'] = {'directory':str(directory), 'imageId':guest['imageId'],
                    'actualGuestPositives':2, 'actualGuestNegatives':7, 'proofGeneratedHere':False,
                    'evmAcceptanceMeasured':False, 'chainAuthenticated':False}
            if args.bnb_risc0_vote_evidence:
                directory = output / 'bnb-risc0-vote-evm'
                command = ['python3', str(ROOT / 'scripts/verify-bnb-vote-risc0-evm.py'),
                           '--evidence', str(args.bnb_risc0_vote_evidence), '--dir', str(directory)]
                if args.bnb_risc0_vote_coordinate_hints:
                    command.append('--coordinate-hints')
                check('bnb-risc0-vote-evm', command)
                vote = json.loads((directory / 'summary.json').read_text())
                expected_image = ('0xee7d7ec0047419866b74142713542217b4122daeb9c098e5cec8730d956c2909'
                                  if args.bnb_risc0_vote_coordinate_hints else
                                  '0x9aab5eba7939ee001357aeb9b0e084314270174e3956109eef87f961f5db50f6')
                expected_binding = 'bnb-vote-native-rlp-supplied-epoch' + ('-hinted' if args.bnb_risc0_vote_coordinate_hints else '')
                if (vote.get('localVerdict') != 'PASS' or vote.get('suppliedEpochBlsGroth16Acceptance') is not True
                    or vote.get('realEvmVerifierAcceptance') is not True or vote.get('sourceChainId') != 56
                    or vote.get('imageId') != expected_image or vote.get('headerBinding') != expected_binding
                    or vote.get('coordinateHintsChecked') is not args.bnb_risc0_vote_coordinate_hints
                    or vote.get('requiresEip2537') is not False or vote.get('destinationFork') != 'cancun'
                    or len(vote.get('negativeChecks', [])) != (12 if args.bnb_risc0_vote_coordinate_hints else 11)
                    or not all(r.get('rejected') is True for r in vote['negativeChecks'])
                    or vote.get('statelessRepeatedVerification') is not True
                    or vote.get('ownedAnvilStopped') is not True or vote.get('assetClaimsSubmitted') != 0
                    or vote.get('rootRegistryUpdated') is not False
                    or any(vote.get(k) is not False for k in ('snapshotAuthenticated', 'finalityVerified',
                            'chainAuthenticated', 'realAssetDeploymentAllowed'))):
                    raise ValueError('actual BNB BLS Groth16 EVM scope mismatch')
                report['bnbRisc0VoteEvm'] = {'directory':str(directory), 'imageId':vote['imageId'],
                    'actualGroth16Acceptance':True, 'freshProofGenerationHere':False,
                    'requiresEip2537':False, 'rootRegistryUpdated':False, 'assetClaimsSubmitted':0,
                    'chainAuthenticated':False}
            if args.native_worldland_evidence:
                report['nativeEvidence'] = []
                for name, source, chain in [('worldland', args.native_worldland_evidence, 103), ('bnb', args.native_bnb_evidence, 56)]:
                    directory = output / ('native-' + name + '-evm')
                    command = ['python3', str(ROOT / 'scripts/verify-native-evm.py'), '--evidence', str(source), '--output-dir', str(directory)]
                    if chain == 56:
                        command.extend(['--receipt-proof', str(ROOT / 'contracts/test/fixtures/native-type4-index16.json')])
                    check('native-' + name + '-evm', command)
                    native = json.loads((directory / 'summary.json').read_text())
                    if (native.get('localVerdict') != 'PASS' or native.get('realEvmVerifierAcceptance') is not True
                        or native.get('sourceChainId') != chain or native.get('assetClaimsSubmitted') != 0
                        or native.get('chainAuthenticated') is not False or native.get('realAssetDeploymentAllowed') is not False
                        or (chain == 56 and native.get('realNativeHeaderAndMptDiagnostic') is not True)):
                        raise ValueError('native verifier/MPT diagnostic evidence scope mismatch')
                    report['nativeEvidence'].append({'sourceChainId': chain, 'directory': str(directory),
                        'imageId': native['imageId'], 'realEvmVerifierAcceptance': True, 'freshProofGeneration': False,
                        'assetClaimsSubmitted': 0, 'chainAuthenticated': False})
            if args.local_updater_evidence:
                report['localUpdaterEvidence'] = []
                for index, source in enumerate(args.local_updater_evidence):
                    directory = output / ('local-updater-' + str(index))
                    command = ['python3', str(ROOT / 'scripts/verify-local-proof-evm.py'),
                        '--evidence', str(source), '--output-dir', str(directory)]
                    source_summary = json.loads((source / 'summary.json').read_text())
                    if source_summary.get('batchSize', 0) > 4:
                        chosen = source_summary.get('diagnosticMaxHeaders', 0)
                        if chosen not in (8, 16, 32, 64, 128) or chosen > args.local_updater_max_headers:
                            raise ValueError('larger local updater evidence exceeds explicit diagnostic ceiling')
                        command += ['--diagnostic-max-headers', str(chosen)]
                    check('local-updater-' + str(index), command)
                    local = json.loads((directory / 'summary.json').read_text())
                    negatives = local.get('negativeChecks', [])
                    if (local.get('localVerdict') != 'PASS' or local.get('realEvmHeaderAcceptance') is not True
                        or local.get('acceptedCoverageAndRootsChecked') is not True
                        or local.get('sourceChainId') not in (31337, 31338)
                        or local.get('assetClaimsSubmitted') != 0 or local.get('freshProofGeneratedHere') is not False
                        or local.get('chainAuthenticated') is not False or local.get('realAssetDeploymentAllowed') is not False
                        or local.get('ownedNodeStopped') is not True
                        or {n.get('name') for n in negatives} != {'altered-seal', 'wrong-journal', 'wrong-image', 'already-accepted-batch'}
                        or not all(n.get('rejected') is True for n in negatives)):
                        raise ValueError('local updater diagnostic evidence scope mismatch')
                    report['localUpdaterEvidence'].append({'source': str(source), 'directory': str(directory),
                        'imageId': local['imageId'], 'batchSize': local['batchSize'],
                        'headerBinding': local['headerBinding'], 'realEvmHeaderAcceptance': True,
                        'freshProofGeneration': False, 'mptAssetRoundtripCheckedHere': False,
                        'chainAuthenticated': False, 'assetClaimsSubmitted': 0})
        # No Git repository exists here: preserve hashes of the exact checked source tree.
        paths = []
        for base in ('contracts/src', 'contracts/test', 'proof-generator', 'risc0/guest', 'risc0/host', 'risc0/methods',
                     'risc0/header-binding', 'risc0/methods-bound', 'risc0/host-bound', 'risc0/methods-accelerated', 'risc0/host-accelerated', 'risc0/native', 'risc0/native-binding', 'risc0/bnb-vote', 'scripts', 'configs', 'wallet', '.github'):
            for path in (ROOT / base).rglob('*'):
                if path.is_file() and '__pycache__' not in path.parts and 'target' not in path.parts:
                    paths.append(path)
        paths.extend(ROOT / name for name in ('risc0/Cargo.toml', 'risc0/Cargo.lock'))
        manifest = {str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(paths)}
        (output / 'source-sha256.json').write_text(json.dumps(manifest, indent=2) + '\n')
        report['localVerdict'] = 'PASS'
    except Exception as error:
        report['error'] = str(error)
        raise
    finally:
        (output / 'summary.json').write_text(json.dumps(report, indent=2) + '\n')
        print(f'{output}: local={report["localVerdict"]}; production=INCOMPLETE')


if __name__ == '__main__':
    main()
