#!/usr/bin/env python3
"""Submit a bounded current-image Groth16 header proof on owned local Anvil."""
import argparse
import base64
import hashlib
import importlib.util
import json
from pathlib import Path
import struct
import subprocess
import time

spec = importlib.util.spec_from_file_location('local_client', Path(__file__).with_name('local-session.py'))
client = importlib.util.module_from_spec(spec)
spec.loader.exec_module(client)
IMAGE = '0x4f612b40d3aa2c81542ca04f91042e59c9acab41334837ef7396e9f9feb47e98'
HOST_SHA = 'eb536a6d21df0a8ac30a09d9677c3dcdaa9a8f7c94071901b0a6243cb692be16'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def cache_key(package):
    key = {'sourceChainId': package['sourceChainId'], 'startBlock': package['startBlock'],
           'endBlock': package['endBlock'], 'startAnchorHash': package['anchorHash'],
           'endBlockHash': package['endHash'], 'batchRoot': package['batchRoot'], 'imageId': IMAGE}
    raw = b''.join(struct.pack('>Q', key[field]) for field in ('sourceChainId', 'startBlock', 'endBlock'))
    raw += b''.join(bytes.fromhex(key[field][2:]) for field in
                    ('startAnchorHash', 'endBlockHash', 'batchRoot', 'imageId'))
    return key, hashlib.sha256(raw).hexdigest() + '.json'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dir', type=Path, default=client.ROOT / 'results/session-zk-current-partial-burn')
    parser.add_argument('--start', type=int, required=True)
    parser.add_argument('--count', type=int, choices=(1, 2, 3, 4), required=True)
    parser.add_argument('--action', choices=('lock', 'burn'), required=True)
    parser.add_argument('--claim-event', action='store_true', help='claim the one matching event after actual header acceptance')
    args = parser.parse_args()
    out = args.dir.resolve()
    result = out / f'accepted-{args.start}.json'
    if result.exists():
        parser.error('batch already accepted; refusing repeat user transaction')
    source = json.loads((out / f'package-{args.start}.json').read_text())
    proof = out / f'proof-{args.start}'
    report = json.loads((proof / 'summary.json').read_text())
    if (report.get('localVerdict') != 'PASS' or report.get('cryptographicallyReverified') is not True
        or report.get('requestedReceiptKind') != 'groth16' or report.get('batchSize') != args.count
        or report.get('imageId') != IMAGE or report.get('hostSHA256') != HOST_SHA
        or report.get('legacyMinimalHostRequested') is not False
        or report.get('chainAuthenticated') is not False or report.get('realAssetDeploymentAllowed') is not False
        or report.get('inputSHA256') != sha(out / f'input-{args.start}.json')
        or report.get('receiptSHA256') != sha(proof / 'receipt.json')):
        parser.error('pinned current-image SDK Groth16 proof required')
    session = client.Session(out / 'session')
    source_chain, destination, _, _, updater, _ = session.route(args.action)
    source_id = session.data['chains'][source_chain]['id']
    if source['sourceChainId'] != source_id or source['startBlock'] != args.start or source['endBlock'] != args.start + args.count - 1:
        parser.error('source package differs from action and range')
    started = time.monotonic()
    session.start('risc0_batch')
    try:
        session.setup()
        host = session.prover_host()
        if (session.data['image_id'] != IMAGE or session.data['host_sha256'] != HOST_SHA or sha(host) != HOST_SHA
            or int(session.view(destination, updater, 'latestBlock()(uint256)')) != args.start - 1
            or session.view(destination, updater, 'latestHash()(bytes32)').lower() != source['anchorHash'].lower()
            or session.view(destination, updater, 'guestImageId()(bytes32)').lower() != IMAGE):
            raise RuntimeError('local source/destination session changed before submission')
        command = [client.HEADER, '--rpc', session.data['chains'][source_chain]['rpc'], '--chain-id', str(source_id),
                   '--start', str(args.start), '--count', str(args.count), '--header-binding', 'minimal-link']
        fresh = json.loads(subprocess.check_output([str(value) for value in command], text=True, timeout=60))
        for field in ('sourceChainId', 'startBlock', 'endBlock', 'anchorHash', 'endHash',
                      'batchRoot', 'journal', 'batchData', 'guestInput'):
            if fresh[field] != source[field]:
                raise RuntimeError(f'source header batch changed: {field}')
        verified = json.loads(subprocess.check_output([host, '--verify-receipt', proof / 'receipt.json'],
                                                     text=True, timeout=120))
        if (verified.get('verified') is not True or verified.get('receipt_kind') != 'groth16'
            or verified.get('evm_compatible') is not True or verified.get('chain_authenticated') is not False
            or verified.get('image_id') != IMAGE or verified.get('journal') != source['journal']
            or verified.get('seal') != report['proof']['seal']):
            raise RuntimeError('SDK receipt differs from Go journal/image/seal')
        key, filename = cache_key(source)
        encoded = {'version': 1, 'key': key,
                   'proofData': base64.b64encode((proof / 'receipt.json').read_bytes()).decode(),
                   'journal': base64.b64encode(bytes.fromhex(source['journal'][2:])).decode()}
        cache = session.root / 'proof-cache/groth16' / filename
        if cache.exists() and json.loads(cache.read_text()) != encoded:
            raise RuntimeError('existing proof cache key differs')
        if not cache.exists():
            client.write_json(cache, encoded)
        checked = json.loads(subprocess.check_output([str(value) for value in command] +
            ['--risc0-host', str(host), '--proof-cache', str(session.root / 'proof-cache'),
             '--receipt-kind', 'groth16', '--proof-timeout', '10s'], text=True, timeout=25))
        if (checked.get('cacheHit') is not True or checked.get('proofVerified') is not True
            or checked.get('evmCompatible') is not True or checked.get('receiptKind') != 'groth16'
            or checked.get('imageId') != IMAGE or checked.get('journal') != source['journal']
            or checked.get('seal') != verified['seal'] or checked.get('batchData') != source['batchData']):
            raise RuntimeError('Go generator did not cryptographically accept cached batch')
        client.write_json(session.root / f'{args.action}-{args.start}-{args.count}-headers.json', checked)
        event = next((e for e in session.data['events'] if e['action'] == args.action and
                      args.start <= e['block'] <= args.start + args.count - 1 and e.get('claimed') is not True), None)
        sender = event['user'] if event else session.data['users'][0]
        tx = session.send(destination, sender, updater, 'submitHeaderProof(bytes,bytes,bytes)',
                          checked['seal'], checked['journal'], checked['batchData'])
        client.write_json(session.root / f'{args.action}-{args.start}-accepted.json', tx)
        if (int(session.view(destination, updater, 'latestBlock()(uint256)')) != args.start + args.count - 1
            or session.view(destination, updater, 'latestHash()(bytes32)').lower() != source['endHash'].lower()):
            raise RuntimeError('local updater did not accept requested header range')
        claim_id = None
        if args.claim_event:
            if event is None:
                raise RuntimeError('claim requested without one unclaimed event in batch')
            session.claim(event)
            claim_id = event['id']
            if event.get('claimed') is not True:
                raise RuntimeError('claim did not persist')
        client.write_json(result, {'localVerdict': 'PASS', 'imageId': IMAGE, 'sourceChainId': source_id,
            'startBlock': args.start, 'endBlock': args.start + args.count - 1, 'action': args.action,
            'actualSdkGroth16Verified': True, 'goCacheHit': True, 'localUpdaterAccepted': True,
            'transactionHash': tx['transactionHash'], 'claimId': claim_id, 'proofSource': str(proof),
            'chainAuthenticated': False, 'realAssetDeploymentAllowed': False,
            'wallSeconds': time.monotonic() - started})
        print(f'current-image local Groth16 {args.action} headers {args.start}..{args.start + args.count - 1}: PASS')
    finally:
        session.stop()


if __name__ == '__main__':
    main()
