#!/usr/bin/env python3
"""Replay historical genuine proofs against current contracts on fresh Anvils.

This generates no new proof and does not authenticate the fresh source blocks.
Anvil impersonation supplies the historical fixture owner's test wallet.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time
import urllib.request

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--evidence', type=Path, default=ROOT / 'results/local-risc0-bound-pinned')
    parser.add_argument('--output-dir', type=Path, default=ROOT / 'results/replayed-strict-current-contracts')
    parser.add_argument('--wallet-client', action='store_true', help='exercise browser header/claim UI with an unlocked local test provider; static server must be running')
    args = parser.parse_args()
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=False)
    source = args.evidence.resolve()
    host = output / 'risc0-host'
    shutil.copy2(source / 'risc0-host', host)
    env = dict(os.environ, RISC0_DEV_MODE='0', RISC0_PROVER='ipc')
    packages, claims = {}, {}
    report = {'historicalProofReplay': True, 'freshHeaderProofGenerated': False,
              'freshSourceBlocksAuthenticated': False, 'userSignedFreshRoundtrip': False,
              'fixtureOwnerWallet': 'local-Anvil-impersonation', 'chainAuthenticated': False,
              'realAssetDeploymentAllowed': False, 'localVerdict': 'FAIL', 'sourceEvidence': str(source)}

    def command(cmd):
        return subprocess.check_output([str(a) for a in cmd], cwd=ROOT, env=env, text=True, stderr=subprocess.PIPE).strip()

    for direction in ('lock', 'burn'):
        package = json.loads((source / f'{direction}-header.json').read_text())
        path = output / f'{direction}-receipt-proof.json'
        path.write_text(json.dumps(package['proofReceipt']) + '\n')
        verified = json.loads(command([host, '--verify-receipt', path]))
        if (verified.get('verified') is not True or verified.get('receipt_kind') != 'groth16'
                or verified.get('evm_compatible') is not True or verified.get('chain_authenticated') is not False
                or any(verified[key] != package[other] for key, other in [('image_id','imageId'),('journal','journal'),('seal','seal')])):
            raise ValueError('not the expected genuine compiled guest proof')
        packages[direction] = package
        claims[direction] = json.loads((source / f'{direction}-package.json').read_text())
    owner = claims['lock']['recipient']
    amount = int(claims['lock']['amount'])
    if (amount != int(claims['burn']['amount']) or owner.lower() != claims['burn']['recipient'].lower()
            or packages['lock']['sourceChainId'] != 31337 or packages['burn']['sourceChainId'] != 31338
            or packages['lock']['imageId'] != packages['burn']['imageId']):
        raise ValueError('replay requires matching local same-owner roundtrip evidence')
    ports = {'wl': 8565, 'bnb': 8566} if args.wallet_client else {'wl': 8578, 'bnb': 8579}
    urls = {chain: f'http://127.0.0.1:{port}' for chain, port in ports.items()}
    nodes = []

    def rpc(chain, method, params):
        request = urllib.request.Request(urls[chain], json.dumps({'jsonrpc':'2.0','id':1,'method':method,'params':params}).encode(), {'Content-Type':'application/json'})
        response = json.load(urllib.request.urlopen(request, timeout=15))
        if 'error' in response: raise RuntimeError(str(response['error']))
        return response['result']

    for chain in urls:
        try:
            rpc(chain, 'eth_chainId', [])
        except Exception:
            continue
        raise RuntimeError('replay port already responds; refuse to adopt an unknown node')
    try:
        for chain, chain_id in [('wl',31337),('bnb',31338)]:
            port = ports[chain]
            with (output / f'{chain}-anvil.log').open('w') as log:
                node = subprocess.Popen(['anvil','--silent','--host','127.0.0.1','--port',str(port),'--chain-id',str(chain_id)], stdout=log, stderr=log)
            nodes.append(node)
            for _ in range(50):
                if node.poll() is not None: raise RuntimeError('owned Anvil exited during startup')
                try:
                    assert int(rpc(chain,'eth_chainId',[]),16) == chain_id
                    break
                except OSError: time.sleep(.1)
            else: raise RuntimeError('owned Anvil startup timeout')
        accounts = rpc('wl','eth_accounts',[])
        operator, submitter = accounts[:2]
        if owner.lower() in (operator.lower(), submitter.lower()): raise ValueError('fixture owner must be distinct from replay test accounts')

        def deploy(chain, contract, *params):
            cmd = ['forge','create','--root',ROOT/'contracts',contract,'--rpc-url',urls[chain],'--unlocked','--from',operator,'--broadcast','--json']
            if params: cmd += ['--constructor-args', *params]
            return json.loads(command(cmd))['deployedTo']

        def send(chain, sender, to, *params, filename=None):
            receipt = json.loads(command(['cast','send',to,*params,'--rpc-url',urls[chain],'--unlocked','--from',sender,'--json']))
            if int(receipt['status'],16) != 1: raise RuntimeError('replay transaction failed')
            if filename: (output/filename).write_text(json.dumps(receipt,indent=2)+'\n')
            return receipt

        def view(chain, to, signature, *params):
            return command(['cast','call',to,signature,*params,'--rpc-url',urls[chain]]).split()[0]

        initial = amount * 4
        original = deploy('wl','src/token/BridgeLockableToken.sol:BridgeLockableToken','Replay WL','WL',str(initial),'31338')
        wrapped = deploy('bnb','src/token/BridgeWrappedToken.sol:BridgeWrappedToken','Replay Wrapped WL','wWL','31337',original)
        if (original.lower() != claims['lock']['sourceToken'].lower() or wrapped.lower() != claims['lock']['destinationToken'].lower()
                or wrapped.lower() != claims['burn']['sourceToken'].lower() or original.lower() != claims['burn']['destinationToken'].lower()):
            raise RuntimeError('fixture token identities do not match deterministic fresh deployment')
        send('wl',operator,original,'bindDestinationWrappedToken(address)',wrapped)
        send('wl',operator,original,'transfer(address,uint256)',owner,str(initial))
        for chain in urls:
            rpc(chain,'anvil_impersonateAccount',[owner])
            rpc(chain,'anvil_setBalance',[owner,hex(10**18)])
        locked = send('wl',owner,original,'bridgeLock(uint256,address,uint256)',str(amount),owner,'31338',filename='new-local-lock.json')
        assert locked['logs'][-1]['topics'][1].lower() == claims['lock']['transferId'].lower()
        contracts = {'original':original,'wrapped':wrapped}
        for chain, direction, source_id in [('bnb','lock',31337),('wl','burn',31338)]:
            package = packages[direction]
            verifier = deploy(chain,'src/bridge/LocalRiscZeroGroth16Verifier.sol:LocalRiscZeroGroth16Verifier')
            updater = deploy(chain,'src/bridge/Risc0HeaderUpdater.sol:Risc0HeaderUpdater',str(source_id),verifier,package['imageId'],str(package['startBlock']-1),package['anchorHash'])
            contracts[chain+'_verifier'], contracts[chain+'_headers'] = verifier, updater
        mint = deploy('bnb','src/bridge/LockMintReceiver.sol:LockMintReceiver',wrapped,contracts['bnb_headers'])
        unlock = deploy('wl','src/bridge/BurnUnlockReceiver.sol:BurnUnlockReceiver',original,contracts['wl_headers'],wrapped)
        contracts['mint_receiver'],contracts['unlock_receiver']=mint,unlock
        send('bnb',operator,wrapped,'bindMintReceiver(address)',mint)
        send('wl',operator,original,'bindUnlockReceiver(address)',unlock)

        def browser_phase(phase):
            node = '/mnt/c/Users/yebeen/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe'
            subprocess.run([node, 'scripts/check-wallet-browser.mjs', str(output.relative_to(ROOT)), phase], cwd=ROOT, check=True, timeout=120)
            return json.loads((output/(phase+'-receipt.json')).read_text())

        if args.wallet_client:
            names = {'original':'original','wrapped':'wrapped','mint':'mint_receiver','unlock':'unlock_receiver',
                     'wl_headers':'wl_headers','bnb_headers':'bnb_headers'}
            manifest = {'version':1,'mode':'risc0_batch','headerBinding':packages['lock'].get('headerBinding','minimal-link'),
                        'imageId':packages['lock']['imageId'],'chainAuthenticated':False,'realAssetDeploymentAllowed':False,
                        'users':[owner],'chains':{c:{'id':31337 if c=='wl' else 31338,'rpc':urls[c]} for c in urls},
                        'contracts':{},'runtimeCode':{}}
            for alias, name in names.items():
                chain = 'bnb' if alias in ('wrapped','mint','bnb_headers') else 'wl'
                manifest['contracts'][alias]=contracts[name]
                manifest['runtimeCode'][alias]=rpc(chain,'eth_getCode',[contracts[name],'latest'])
            (output/'wallet-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
            for direction, destination, receiver in [('lock','bnb',mint),('burn','wl',unlock)]:
                claim = claims[direction]
                claim['headerTransaction']['to']=contracts[destination+'_headers']
                claim['claimTransaction']['to']=receiver
                (output/(direction+'-package.json')).write_text(json.dumps(claim)+'\n')
            report.update(browserWalletClient=True,externalExtensionTested=False,
                          testWallet='controlled EIP-1193 provider backed by Anvil impersonation',browserWalletRequests=5)

        def accept(direction, chain):
            p = packages[direction]; updater=contracts[chain+'_headers']
            damaged=bytearray.fromhex(p['seal'][2:]);damaged[-1]^=1
            check=subprocess.run(['cast','call',updater,'submitHeaderProof(bytes,bytes,bytes)','0x'+damaged.hex(),p['journal'],p['batchData'],'--rpc-url',urls[chain]],capture_output=True,text=True)
            if check.returncode==0 or 'revert' not in check.stderr.lower(): raise RuntimeError('invalid seal was not rejected by the current updater')
            if args.wallet_client:
                accepted = browser_phase('header-'+direction)
                (output/(direction+'-header-accepted.json')).write_text(json.dumps(accepted,indent=2)+'\n')
            else:
                send(chain,submitter,updater,'submitHeaderProof(bytes,bytes,bytes)',p['seal'],p['journal'],p['batchData'],filename=direction+'-header-accepted.json')
            assert view(chain,updater,'latestBlock()(uint256)') == str(p['endBlock'])

        accept('lock','bnb')
        if args.wallet_client: browser_phase('mint')
        else: send('bnb',submitter,mint,'--data',claims['lock']['calldata'],filename='mint-accepted.json')
        assert int(view('bnb',wrapped,'balanceOf(address)(uint256)',owner))==amount
        assert int(view('bnb',wrapped,'balanceOf(address)(uint256)',submitter))==0
        burned = browser_phase('burn') if args.wallet_client else send('bnb',owner,wrapped,'bridgeBurn(uint256,address,uint256)',str(amount),owner,'31337',filename='new-local-burn.json')
        assert burned['logs'][-1]['topics'][1].lower()==claims['burn']['transferId'].lower()
        accept('burn','wl')
        if args.wallet_client: browser_phase('unlock')
        else: send('wl',submitter,unlock,'--data',claims['burn']['calldata'],filename='unlock-accepted.json')
        assert int(view('wl',original,'balanceOf(address)(uint256)',owner))==initial
        assert view('wl',original,'lockedBalanceOf(address)(uint256)',owner)=='0'
        assert view('bnb',wrapped,'totalSupply()(uint256)')=='0'
        runtime={}
        for name,address in contracts.items():
            chain='bnb' if name in ('wrapped','mint_receiver') or name.startswith('bnb_') else 'wl'
            code=rpc(chain,'eth_getCode',[address,'latest'])
            (output/(name+'-runtime.hex')).write_text(code+'\n')
            runtime[name]={'address':address,'codeHash':command(['cast','keccak',code])}
        report.update({'localVerdict':'PASS','realGroth16EvmAcceptance':True,'mptClaimsAccepted':True,
                       'wrongSealsRejected':True,'thirdPartySubmitterDidNotChangeRecipient':not args.wallet_client,
                       'thirdPartyClaimTested':not args.wallet_client,
                       'finalOriginal':str(initial),'finalLocked':'0','finalWrappedSupply':'0',
                       'imageId':packages['lock']['imageId'],'headerBinding':packages['lock'].get('headerBinding','minimal-link'),
                       'hostSHA256':hashlib.sha256(host.read_bytes()).hexdigest(),'runtime':runtime})
        print('historical genuine Groth16 replay against current EVM/MPT contracts: PASS; new proof generation: 0')
    except Exception as error:
        report['error']=str(error)
        raise
    finally:
        for node in nodes:
            if node.poll() is None: node.terminate()
        for node in nodes:
            try: node.wait(timeout=10)
            except subprocess.TimeoutExpired: node.kill(); node.wait(timeout=5)
        (output/'summary.json').write_text(json.dumps(report,indent=2)+'\n')


if __name__ == '__main__': main()
