#!/usr/bin/env python3
"""Check strict session deployment, pinned image, immutable mode and restart.

No proof is generated here; the independent zk-bound roundtrip covers claims.
"""
import argparse
import fcntl
import hashlib
import importlib.util
import os
from pathlib import Path

spec = importlib.util.spec_from_file_location('client', Path(__file__).with_name('local-session.py'))
client = importlib.util.module_from_spec(spec)
spec.loader.exec_module(client)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', type=Path, default=client.ROOT / 'results/session-bound-setup')
    args = parser.parse_args()
    directory = args.output_dir.resolve()
    directory.mkdir(parents=True, exist_ok=False)
    os.environ['RISC0_DEV_MODE'] = '0'
    with (directory / 'client.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        session = client.Session(directory)
        running = False
        try:
            try:
                session.start('dev', 'canonical-rlp')
                raise AssertionError('dev strict binding accepted')
            except RuntimeError as error:
                assert 'requires a RISC0 mode' in str(error)
                assert not session.data
            session.start('risc0_batch', 'canonical-rlp')
            running = True
            session.setup()
            original = dict(session.data['contracts'])
            host_hash = hashlib.sha256(session.prover_host().read_bytes()).hexdigest()
            image = session.data['image_id']
            for chain in ('wl', 'bnb'):
                assert session.view(chain, original[chain + '_headers'], 'guestImageId()(bytes32)') == image
            for mode, binding, message in [('dev', 'canonical-rlp', 'requires a RISC0 mode'),
                    ('risc0_batch', 'minimal-link', 'binding is immutable'),
                    ('risc0_composite', 'canonical-rlp', 'mode is immutable')]:
                try:
                    session.start(mode, binding)
                    raise AssertionError('session changed its predicate')
                except RuntimeError as error:
                    assert message in str(error)
            before = {chain: session.rpc(chain, 'eth_blockNumber', []) for chain in ('wl', 'bnb')}
            session.stop()
            running = False
            session = client.Session(directory)
            session.start('risc0_batch', 'canonical-rlp')
            running = True
            session.setup()
            assert original == session.data['contracts']
            assert host_hash == hashlib.sha256(session.prover_host().read_bytes()).hexdigest()
            for chain in ('wl', 'bnb'):
                assert before[chain] == session.rpc(chain, 'eth_blockNumber', [])
                assert session.view(chain, original[chain + '_headers'], 'guestImageId()(bytes32)') == image
            assert not session.data['events']
            client.write_json(directory / 'summary.json', {
                'headerBinding': 'canonical-rlp', 'imageId': image, 'hostSHA256': host_hash,
                'constructorImagesMatch': True, 'predicateChangesRejected': True,
                'restartPreservedContractsAndHeads': True, 'proofGeneratedHere': False,
                'userClaimsTestedHere': False, 'chainAuthenticated': False,
                'realAssetDeploymentAllowed': False,
            })
            print('strict session deployment, pinned image, immutable binding, restart: PASS')
        finally:
            if running:
                session.stop()


if __name__ == '__main__':
    main()
