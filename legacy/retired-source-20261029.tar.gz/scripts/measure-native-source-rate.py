#!/usr/bin/env python3
"""Bounded public header interval observation; no proof, signing or asset action."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import statistics
import subprocess
import time
import urllib.request

ROOT=Path(__file__).resolve().parents[1]
TARGETS={
    'worldland':('https://seoul.worldland.foundation/',103,'worldland-v1.1.3'),
    'bnb':('https://bsc-dataseed.nariox.org/',56,'bnb-v1.7.8'),
}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--chain',choices=('worldland','bnb','both'),default='both')
    parser.add_argument('--headers',type=int,default=32)
    parser.add_argument('--output-dir',type=Path,required=True)
    args=parser.parse_args()
    if not 4<=args.headers<=64:parser.error('header sample must be 4..64')
    out=args.output_dir.resolve();out.mkdir(parents=True,exist_ok=False)
    inspector=ROOT/'.bin/bridge-header-inspect'
    report={'measuredAt':datetime.now(timezone.utc).isoformat(),'readOnly':True,'requestedHeaders':args.headers,
        'localVerdict':'INCOMPLETE','scope':'RPC-reported header intervals, not authenticated/accepted throughput',
        'chainAuthenticated':False,'realAssetDeploymentAllowed':False,'proofsGenerated':0,'transactionsSent':0,
        'inspectorSHA256':hashlib.sha256(inspector.read_bytes()).hexdigest(),'rpcCalls':0,'targets':{}}
    last_request=0

    def query(directory,endpoint,label,method,params):
        nonlocal last_request
        if method not in ('eth_chainId','web3_clientVersion','eth_getBlockByNumber','eth_getBlockByHash'):
            raise ValueError('unsupported read-only method')
        time.sleep(max(0,.5-(time.monotonic()-last_request)))
        request={'jsonrpc':'2.0','id':1,'method':method,'params':params}
        (directory/(label+'-request.json')).write_text(json.dumps(request)+'\n')
        last_request=time.monotonic();report['rpcCalls']+=1
        with urllib.request.urlopen(urllib.request.Request(endpoint,json.dumps(request).encode(),
            {'Content-Type':'application/json','User-Agent':'WorldLand-BNB-read-only-interval-diagnostic'}),timeout=15) as response:
            raw=response.read(2*1024*1024+1)
        if len(raw)>2*1024*1024:raise ValueError('RPC response size limit')
        (directory/(label+'-response.json')).write_bytes(raw);data=json.loads(raw)
        if data.get('error') or data.get('result') is None:raise ValueError(str(data.get('error','null result')))
        return data['result']

    try:
        for name,(endpoint,chain,profile) in TARGETS.items():
            if args.chain not in ('both',name):continue
            directory=out/name;directory.mkdir()
            row={'endpoint':endpoint,'sourceChainId':chain,'profile':profile,'verdict':'INCOMPLETE','headers':[]}
            report['targets'][name]=row
            try:
                if int(query(directory,endpoint,'chain-id','eth_chainId',[]),16)!=chain:raise ValueError('unexpected source chain ID')
                row['clientVersion']=query(directory,endpoint,'client','web3_clientVersion',[])
                header=query(directory,endpoint,'head','eth_getBlockByNumber',['latest',False])
                timestamps=[];prior=None
                for i in range(args.headers):
                    if i:
                        wanted=prior['parentHash'];header=query(directory,endpoint,str(i),'eth_getBlockByHash',[wanted,False])
                        if header['hash'].lower()!=wanted.lower() or int(header['number'],16)+1!=int(prior['number'],16):
                            raise ValueError('RPC header ancestry mismatch')
                    path=directory/(str(i)+'-header.json');path.write_text(json.dumps(header,indent=2)+'\n')
                    result=subprocess.run([inspector,'--input',path,'--encoding-profile',profile],capture_output=True,text=True,timeout=30)
                    (directory/(str(i)+'-inspection.json')).write_text(result.stdout)
                    (directory/(str(i)+'-inspection.stderr.txt')).write_text(result.stderr)
                    if result.returncode or json.loads(result.stdout).get('hashMatchesRpc') is not True:
                        raise ValueError('offline native header hash/profile inspection failed')
                    # The codec validates BNB MilliTimestamp derived metadata;
                    # this value is a timestamp observation, not a signed clock.
                    if name=='bnb':
                        if 'milliTimestamp' not in header:raise ValueError('millisecond metadata required for BNB interval observation')
                        ms=int(header['milliTimestamp'],16)
                    else:ms=int(header['timestamp'],16)*1000
                    timestamps.append(ms)
                    row['headers'].append({'number':int(header['number'],16),'hash':header['hash'],'timestampMs':ms,
                        'headerSHA256':hashlib.sha256(path.read_bytes()).hexdigest(),'fullHashRecomputed':True})
                    prior=header
                intervals=[timestamps[i]-timestamps[i+1] for i in range(len(timestamps)-1)]
                if min(intervals)<0 or sum(intervals)<=0:raise ValueError('nonmonotonic or zero source timestamp span')
                reread=query(directory,endpoint,'rechecked-head','eth_getBlockByNumber',[hex(row['headers'][0]['number']),False])
                if reread['hash'].lower()!=row['headers'][0]['hash'].lower():raise ValueError('head changed during observation')
                row.update(verdict='PASS',intervalsMs=intervals,observedIntervalCount=len(intervals),
                    meanIntervalMs=statistics.mean(intervals),medianIntervalMs=statistics.median(intervals),
                    minIntervalMs=min(intervals),maxIntervalMs=max(intervals),
                    observedHeadersPerSecond=len(intervals)*1000/sum(intervals),headUnchangedDuringCapture=True,
                    timestampPrecision='milliseconds' if name=='bnb' else 'whole seconds',
                    limitations=['one recent historical window; not long-term variance/finality',
                        'RPC-reported timestamps and chain ID are unauthenticated',
                        'no prover or destination accepted head observations'])
            except Exception as error:row['error']=str(error)
        report['localVerdict']='PASS' if all(r['verdict']=='PASS' for r in report['targets'].values()) else 'INCOMPLETE'
    finally:
        report['artifactSHA256']={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest()
            for p in out.rglob('*') if p.is_file()}
        (out/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
    for name,row in report['targets'].items():
        print(name,row['verdict'],row.get('observedHeadersPerSecond'),row.get('error',''))
    return 0 if report['localVerdict']=='PASS' else 1


if __name__=='__main__':raise SystemExit(main())
