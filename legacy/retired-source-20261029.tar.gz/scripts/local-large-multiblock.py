#!/usr/bin/env python3
"""Three local users share genuine 16-header proofs in both asset directions.

Uses explicit diagnostic profiling; normal generator/host export caps stay4.
Transactions use Anvil unlocked user accounts, not an external wallet extension.
"""
import argparse
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import time

spec = importlib.util.spec_from_file_location('large_batch_local_client', Path(__file__).with_name('local-session.py'))
client = importlib.util.module_from_spec(spec); spec.loader.exec_module(client)
IMAGE = '0x4f612b40d3aa2c81542ca04f91042e59c9acab41334837ef7396e9f9feb47e98'


def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()


class LargeSession(client.Session):
    def __init__(self, directory, host):
        super().__init__(directory)
        self.selected_host = host.resolve()

    def prover_host(self):
        snapshot = self.root / 'risc0-host'
        if not snapshot.exists():
            assert client.command([self.selected_host, '--image-id']) == IMAGE
            assert client.command([self.selected_host, '--header-binding']) == 'minimal-link'
            shutil.copy2(self.selected_host, snapshot)
            self.data.update(image_id=IMAGE, host_sha256=sha(snapshot)); self.save()
        result = super().prover_host()
        assert client.command([result, '--image-id']) == IMAGE
        return result

    def mine_until(self, chain, height):
        current = int(self.rpc(chain, 'eth_blockNumber', []), 16)
        if current > height: raise ValueError('local source passed the planned event height')
        for _ in range(height - current): self.rpc(chain, 'evm_mine', [])

    def deploy(self, key, chain, contract, *args):
        if key == 'bnb_headers' and key not in self.data['contracts']:
            self.mine_until('wl', 95)
            anchor = self.rpc('wl', 'eth_getBlockByNumber', ['0x5f', False])
            args = (*args[:-2], '95', anchor['hash'])
        return super().deploy(key, chain, contract, *args)

    def make_headers(self, action, start, count):
        if count != 16: raise ValueError('this diagnostic requires exactly16 headers')
        source, _, _, _, _, _ = self.route(action)
        path = self.root / f'{action}-{start}-16-headers.json'
        raw_command = [client.HEADER, '--rpc', self.data['chains'][source]['rpc'],
            '--chain-id', self.data['chains'][source]['id'], '--start', start, '--count', count]
        raw = json.loads(client.command(raw_command))
        directory = self.root / f'{action}-{start}-16-profile'
        if not directory.exists():
            input_path = self.root / f'{action}-{start}-16-input.json'
            client.write_json(input_path, raw['guestInput'])
            command = ['python3', str(client.ROOT / 'scripts/run-local-proof.py'), '--host', str(self.prover_host()),
                '--input', str(input_path), '--kind', 'groth16', '--profile-phases', '--diagnostic-max-headers', '16',
                '--threads', '12', '--compression-threads', '4', '--timeout-seconds', '1800', '--output-dir', str(directory)]
            print(f'actual local {action} batch{start}..{start+15}: proving', flush=True)
            with (self.root / f'{action}-{start}-profile.log').open('w') as log:
                process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
                sampler = None
                sample_log = (self.root / f'{action}-{start}-memory.log').open('w')
                try:
                    for _ in range(300):
                        if (directory / 'docker-scope/ownership.json').exists():
                            sampler = subprocess.Popen(['python3', str(client.ROOT / 'scripts/sample-owned-prover-memory.py'),
                                '--evidence', str(directory), '--timeout-seconds', '1800'],
                                stdout=sample_log, stderr=subprocess.STDOUT)
                            break
                        if process.poll() is not None: break
                        time.sleep(.1)
                    if process.wait(timeout=2000): raise ValueError('bounded diagnostic proof failed; preserve artifacts')
                except BaseException:
                    if process.poll() is None:
                        os.killpg(process.pid, signal.SIGTERM)
                        try: process.wait(timeout=30)
                        except subprocess.TimeoutExpired:
                            os.killpg(process.pid, signal.SIGKILL); process.wait()
                    raise
                finally:
                    if sampler and sampler.poll() is None:
                        try: sampler.wait(timeout=20)
                        except subprocess.TimeoutExpired:
                            sampler.terminate(); sampler.wait(timeout=30)
                    sample_log.close()
        summary = json.loads((directory / 'summary.json').read_text())
        if summary.get('localVerdict') != 'PASS':
            raise ValueError('previous diagnostic proof failed; recovery decision required, artifacts retained')
        for filename, key in [('risc0-host','hostSHA256'),('input.json','inputSHA256'),('receipt.json','receiptSHA256')]:
            assert sha(directory / filename) == summary[key]
        assert summary['imageId'] == IMAGE and summary['batchSize'] == 16 and summary['diagnosticMaxHeaders'] == 16
        metadata = json.loads(client.command([directory / 'risc0-host', '--verify-receipt', directory / 'receipt.json']))
        assert metadata['verified'] and metadata['receipt_kind'] == 'groth16' and metadata['image_id'] == IMAGE
        assert metadata['journal'].lower() == raw['journal'].lower() and not metadata['chain_authenticated']
        assert metadata['header_binding'] == 'minimal-link' and metadata['evm_compatible']
        # Actual RPC commitments must still equal the proved batch after compression.
        fresh = json.loads(client.command(raw_command))
        assert fresh['guestInput'] == raw['guestInput'] and fresh['journal'] == raw['journal']
        raw.update(kind='local-groth16-header-proof',receiptKind='groth16',imageId=IMAGE,
            proofReceipt=json.loads((directory / 'receipt.json').read_text()),proofVerified=True,
            cacheHit=False,evmCompatible=True,sealAvailable=True,seal=metadata['seal'],
            verifierParameters=metadata['verifier_parameters'],headerBinding='minimal-link',hashBindingVerified=False)
        client.write_json(path, raw)
        return path, raw

    def headers(self, event):
        source, destination, _, _, updater, _ = self.route(event['action'])
        block = self.rpc(source, 'eth_getBlockByNumber', [hex(event['block']), False])
        if self.view(destination, updater, 'isBlockCovered(uint256,uint256,bytes32)(bool)',
            str(self.data['chains'][source]['id']), str(event['block']), block['hash']) == 'true': return
        start = int(self.view(destination, updater, 'latestBlock()(uint256)')) + 1
        path, package = self.make_headers(event['action'], start, 16)
        combined = self.package(event, path)
        assert not combined['headerCovered'] and combined['headerTransaction']['to'].lower() == updater.lower()
        assert int(self.view(destination, updater, 'latestBlock()(uint256)')) == start - 1
        assert self.view(destination, updater, 'latestHash()(bytes32)').lower() == package['anchorHash'].lower()
        transaction = self.send(destination, event['user'], updater, 'submitHeaderProof(bytes,bytes,bytes)',
            package['seal'], package['journal'], package['batchData'])
        client.write_json(self.root / f'{event["action"]}-{start}-accepted.json', transaction)
        for h in package['guestInput']['headers']:
            root = self.view(destination, updater, 'getReceiptRoot(uint256,uint256,bytes32)(bytes32)',
                str(package['sourceChainId']), str(h['number']), '0x' + bytes(h['block_hash']).hex())
            assert root.lower() == '0x' + bytes(h['receipt_root']).hex()

    def proof_hashes(self):
        return {str(path.relative_to(self.root)):sha(path) for directory in self.root.glob('*-16-profile')
            for path in directory.rglob('*') if path.is_file()}


def main():
    def interrupted(*_): raise KeyboardInterrupt('large local user scenario interrupted')
    signal.signal(signal.SIGTERM, interrupted)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--host', type=Path, required=True)
    parser.add_argument('--dir', type=Path, required=True)
    args = parser.parse_args()
    session = LargeSession(args.dir, args.host)
    session_lock = (session.root / 'client.lock').open('a')
    try:
        fcntl.flock(session_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        session_lock.close()
        raise RuntimeError('another local wallet operation owns this session; no duplicate scenario started')
    session = LargeSession(args.dir, args.host)  # Read durable state after acquiring the wallet lock.
    report = {'localVerdict':'FAIL','batchSize':16,'users':3,'headerMode':'risc0_batch',
        'receiptKind':'groth16','imageId':IMAGE,'headerBinding':'minimal-link','syntheticHeaders':False,
        'source':'actual owned local Anvil headers/receipts/events','chainAuthenticated':False,
        'realAssetDeploymentAllowed':False,'normalGeneratorExportCapChanged':False,
        'walletBackend':'Anvil unlocked user accounts; external extension not tested','privateKeysSaved':False}
    try:
        session.start('risc0_batch'); session.setup()
        if session.data.get('pending_action'):
            session.recover()  # Resolve durable wallet intent before mining another planned event block.
        report['workState']='running'
        client.write_json(session.root/'summary.json',report)
        events = [e for e in session.data['events'] if e['action']=='lock']
        for index in range(len(events),3):
            session.mine_until('wl',[99,103,106][index]); session.action('lock',index,25*10**18)
        events = [e for e in session.data['events'] if e['action']=='lock']
        assert [e['block'] for e in events] == [100,104,107]
        if int(session.rpc('wl','eth_blockNumber',[]),16)<111: session.mine_until('wl',111)
        session.headers(events[-1]); proofs = session.proof_hashes()
        session.stop(); session.start('risc0_batch')
        for event in reversed(events):
            session.claim(event)
            package = json.loads((session.root / (event['id']+'-package.json')).read_text())
            assert package['headerCovered'] and 'headerTransaction' not in package and 'headerProof' not in package
        assert session.proof_hashes()==proofs
        existing_burns = {e['user']:e for e in session.data['events'] if e['action']=='burn'}
        expected_supply = 0
        for user in session.data['users']:
            burn = existing_burns.get(user)
            unlocked = burn and session.view('wl',session.data['contracts']['unlock'],
                'claimedWithdrawal(bytes32)(bool)',burn['id'])=='true'
            expected_wrapped = 0 if burn else 25*10**18
            expected_supply += expected_wrapped
            assert int(session.view('wl',session.data['contracts']['original'],'lockedBalanceOf(address)(uint256)',user))==(0 if unlocked else 25*10**18)
            assert int(session.view('bnb',session.data['contracts']['wrapped'],'balanceOf(address)(uint256)',user))==expected_wrapped
        assert int(session.view('bnb',session.data['contracts']['wrapped'],'totalSupply()(uint256)'))==expected_supply
        if 'large_return_batch' not in session.data:
            start=int(session.view('wl',session.data['contracts']['wl_headers'],'latestBlock()(uint256)'))+1
            first=max(start+4,int(session.rpc('bnb','eth_blockNumber',[]),16)+1)
            assert first+7<=start+15
            session.data['large_return_batch']={'start':start,'end':start+15,'events':[first,first+4,first+7]};session.save()
        plan=session.data['large_return_batch']; burns=[e for e in session.data['events'] if e['action']=='burn']
        for index in range(len(burns),3):
            session.mine_until('bnb',plan['events'][index]-1);session.action('burn',index,25*10**18)
        burns=[e for e in session.data['events'] if e['action']=='burn']
        assert [e['block'] for e in burns]==plan['events']
        assert int(session.view('bnb',session.data['contracts']['wrapped'],'totalSupply()(uint256)'))==0
        expected_locked = sum(0 if session.view('wl',session.data['contracts']['unlock'],
            'claimedWithdrawal(bytes32)(bool)',e['id'])=='true' else 25*10**18 for e in burns)
        assert sum(int(session.view('wl',session.data['contracts']['original'],'lockedBalanceOf(address)(uint256)',user))
            for user in session.data['users'])==expected_locked
        if int(session.rpc('bnb','eth_blockNumber',[]),16)<plan['end']:session.mine_until('bnb',plan['end'])
        session.headers(burns[-1]);proofs=session.proof_hashes()
        session.stop();session.start('risc0_batch')
        for event in reversed(burns):session.claim(event)
        assert session.proof_hashes()==proofs
        for user in session.data['users']:
            assert int(session.view('wl',session.data['contracts']['original'],'balanceOf(address)(uint256)',user))==100*10**18
            assert int(session.view('wl',session.data['contracts']['original'],'lockedBalanceOf(address)(uint256)',user))==0
            assert int(session.view('bnb',session.data['contracts']['wrapped'],'balanceOf(address)(uint256)',user))==0
        assert int(session.view('bnb',session.data['contracts']['wrapped'],'totalSupply()(uint256)'))==0
        report.update(localVerdict='PASS',workState='complete',actualGroth16EvmAcceptance=True,mptRoundtrip=True,
            lockEventBlocks=[100,104,107],lockAcceptedRange=[96,111],burnEventBlocks=plan['events'],
            burnAcceptedRange=[plan['start'],plan['end']],acceptedSharedBatches=2,mptClaims=6,
            additionalProvingForClaims=0,proofArtifactsUnchangedDuringClaims=True,restartBeforeBothClaimGroups=True,
            finalOriginalPerUser=str(100*10**18),finalTotalLocked='0',finalWrappedSupply='0')
        print('PASS actual16-header shared3user both-direction Groth16/MPT/restart; normal export cap4 stays')
    except BaseException as error:
        report.update(error=str(error),workState='failed');raise
    finally:
        if session.data.get('chains'):
            try:session.stop();report['ownedNodesStopped']=True
            except Exception as error:report.update(cleanupError=str(error),localVerdict='FAIL')
        client.write_json(session.root/'summary.json',report)
        fcntl.flock(session_lock, fcntl.LOCK_UN)
        session_lock.close()


if __name__=='__main__':main()
