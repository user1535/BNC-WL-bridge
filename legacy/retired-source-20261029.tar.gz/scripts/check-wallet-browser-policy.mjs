import {chromium,launchOptions} from './browser-runtime.mjs';
import {Interface} from '../wallet/vendor/ethers-6.15.0.min.mjs';
import fs from 'node:fs';
const p=JSON.parse(fs.readFileSync(new URL('../wallet/testdata/lock-package.json',import.meta.url))),owner=p.recipient;
const h=new Interface(['function getReceiptRoot(uint256,uint256,bytes32) view returns(bytes32)','function guestImageId() view returns(bytes32)']);
const r=new Interface(['function claimedTransfer(bytes32) view returns(bool)']);
const m={version:1,mode:'risc0_batch',headerBinding:'canonical-rlp',chainAuthenticated:false,realAssetDeploymentAllowed:false,imageId:p.headerProof.imageId,
  chains:{wl:{id:31337,rpc:'http://127.0.0.1:8565'},bnb:{id:31338,rpc:'http://127.0.0.1:8566'}},contracts:{original:p.sourceToken,wrapped:p.destinationToken,mint:p.claimTransaction.to,unlock:'0x'+'11'.repeat(20),wl_headers:'0x'+'22'.repeat(20),bnb_headers:p.headerTransaction.to},runtimeCode:Object.fromEntries(['original','wrapped','mint','unlock','wl_headers','bnb_headers'].map(k=>[k,'0x6000']))};
const directory=new URL('../'+(process.argv[2]||'results/wallet-browser-policy')+'/',import.meta.url);fs.mkdirSync(directory,{recursive:false});
const report={localVerdict:'FAIL',provider:'simulated policy provider; browser UI actual',realEvmMeasured:false,chainAuthenticated:false,realAssetDeploymentAllowed:false,cases:[]};
const browser=await chromium.launch(launchOptions);
try {
  for(const scenario of ['connect-rejected-preserves-prior-intent','send-rejected-clears-own-intent','send-unknown-preserves-intent','account-event-invalidates-preview','other-tab-invalidates-preview']) {
    const context=await browser.newContext(),page=await context.newPage();let sends=0;
    await page.exposeFunction('__policyRpc',async({method,params})=>{
      if(method==='eth_requestAccounts' && scenario.startsWith('connect-')) return {error:{message:'rejected',code:4001}};
      if(method==='eth_accounts'||method==='eth_requestAccounts') return {result:[owner]};
      if(method==='eth_chainId') return {result:'0x7a6a'};
      if(method==='eth_getCode') return {result:'0x6000'};
      if(method==='eth_getBalance') return {result:'0xde0b6b3a7640000'};
      if(method==='eth_gasPrice') return {result:'0x1'};
      if(method==='eth_estimateGas') return {result:'0xf4240'};
      if(method==='eth_getTransactionCount') return {result:'0x0'};
      if(method==='eth_sendTransaction'){sends++;return {error:{message:scenario.startsWith('send-rejected')?'rejected':'connection lost',code:scenario.startsWith('send-rejected')?4001:4900}};}
      if(method==='eth_call') {
        const data=params[0].data;
        if(data.startsWith(h.getFunction('guestImageId').selector)) return {result:h.encodeFunctionResult('guestImageId',[m.imageId])};
        if(data.startsWith(h.getFunction('getReceiptRoot').selector)) return {result:h.encodeFunctionResult('getReceiptRoot',[p.receiptRoot])};
        if(data.startsWith(r.getFunction('claimedTransfer').selector)) return {result:r.encodeFunctionResult('claimedTransfer',[false])};
        return {result:'0x'};
      }
      throw new Error('unexpected RPC '+method);
    });
    await page.addInitScript(()=>{
      const events={};window.__emit=(name,value)=>(events[name]??[]).forEach(fn=>fn(value));
      window.ethereum={on:(name,fn)=>(events[name]??=[]).push(fn),request:async args=>{const v=await window.__policyRpc(args);if(v.error)throw Object.assign(new Error(v.error.message),v.error);return v.result;}};
    });
    await page.goto('http://127.0.0.1:8580');
    const pendingKey='worldland-bnb-local-pending-v1';
    if(scenario.startsWith('connect-')) await page.evaluate(key=>localStorage.setItem(key,'existing-unresolved-intent'),pendingKey);
    await page.locator('#manifest').setInputFiles({name:'manifest.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(m))});
    await page.waitForFunction(()=>!document.getElementById('connect').disabled);await page.locator('#connect').click();
    if(scenario.startsWith('connect-')) {
      await page.waitForFunction(()=>document.getElementById('status').textContent.includes('거절'));
      if(await page.evaluate(key=>localStorage.getItem(key),pendingKey)!=='existing-unresolved-intent')throw new Error('connect rejection erased prior intent');
    } else {
      await page.waitForFunction(()=>document.getElementById('account').textContent.startsWith('0x'));
      await page.locator('#package').setInputFiles({name:'package.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(p))});
      await page.waitForFunction(()=>!document.getElementById('prepare-claim').disabled);await page.locator('#prepare-claim').click();
      await page.waitForFunction(()=>!document.getElementById('submit').disabled);
      if(scenario.startsWith('send-')) {
        await page.locator('#submit').click();
        await page.waitForFunction(()=>document.getElementById('status').textContent.includes('거절')||document.getElementById('status').textContent.includes('connection lost'));
        const raw=await page.evaluate(key=>localStorage.getItem(key),pendingKey);
        if(scenario.startsWith('send-rejected')?raw!==null:JSON.parse(raw).status!=='awaiting_wallet') throw new Error('incorrect pending policy');
        if(sends!==1)throw new Error('unexpected send count');
        if(scenario.startsWith('send-unknown') && !await page.locator('#submit').isDisabled()) throw new Error('unknown send allowed retry');
      } else if(scenario.startsWith('account-')) {
        await page.evaluate(()=>window.__emit('accountsChanged',['0x'+'33'.repeat(20)]));
        if(!await page.locator('#submit').isDisabled()) throw new Error('account event kept preview');
      } else {
        const other=await context.newPage();await other.goto('http://127.0.0.1:8580');
        await other.evaluate(key=>localStorage.setItem(key,'other-tab-intent'),pendingKey);
        await page.waitForFunction(()=>document.getElementById('submit').disabled);
        if(sends!==0)throw new Error('unexpected cross-tab send');
      }
    }
    report.cases.push({scenario,passed:true,sendRequests:sends});await context.close();
  }
  report.localVerdict='PASS';
} catch(error) {report.error=error.message;throw error;}
finally {fs.writeFileSync(new URL('summary.json',directory),JSON.stringify(report,null,2)+'\n');await browser.close();}
