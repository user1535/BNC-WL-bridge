#!/usr/bin/env python3
"""Self-contained source + Linux prover host release; excludes runtime state."""
import argparse,hashlib,json,platform,subprocess,tarfile,tempfile,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--prover-host',type=Path);a=p.parse_args()
a.output=a.output.resolve();a.output.parent.mkdir(parents=True,exist_ok=True)
if a.output.exists():p.error('output already exists')
if platform.machine()!='x86_64':p.error('this release targets Linux x86_64')
with tempfile.TemporaryDirectory(prefix='bnc-release-') as temp:
 root=Path(temp)/'bnc-wl';root.mkdir()
 for folder in ('scripts','wallet','configs','proof-generator','contracts','deploy'):
  for f in (ROOT/folder).rglob('*'):
   rel=f.relative_to(ROOT)
   if not f.is_file() or f.is_symlink() or any(x in rel.parts for x in ('__pycache__','out','cache','broadcast','.git','node_modules','target')):continue
   target=root/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,target)
 for name in ('README.md','.gitignore','docs/current-status-report.md','docs/implementation-details.md','docs/plan-gap-analysis.md','docs/source/bridge-design.docx','docs/private_keyless_Bridge.docx'):
  target=root/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/name,target)
 for src in (ROOT/'docs').rglob('*.md'):
  dest=root/src.relative_to(ROOT);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dest)
 hashes={}
 for name in ('bridge-proof','bridge-header-data'):
  src=ROOT/'.bin'/name
  if src.is_file():
   dest=root/'.bin'/name;dest.parent.mkdir(exist_ok=True);shutil.copy2(src,dest)
   hashes[str(dest.relative_to(root))]=hashlib.sha256(dest.read_bytes()).hexdigest()
 if a.prover_host:
  src=a.prover_host.resolve();dest=root/'.bin/risc0-host'
  if not src.is_file() or src.stat().st_size>64*1024*1024:p.error('invalid prover host')
  dest.parent.mkdir(exist_ok=True);shutil.copy2(src,dest)
  hashes[str(dest.relative_to(root))]=hashlib.sha256(dest.read_bytes()).hexdigest()
  image=subprocess.check_output([str(src),'--image-id'],text=True,timeout=30).strip()
 else:image=None
 manifest=dict(version=1,machine=platform.machine(),os='Linux',proverImageId=image,sha256=hashes,excluded=['results','session.json','chain state','personal config','private keys'],requirements=dict(python='3.12',foundry='1.7.1',solc='0.8.24',risc0SDK='3.0.5',go='1.22 only when rebuilding',docker='Engine for Groth16'))
 (root/'release-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 with tarfile.open(a.output,'w:gz') as archive:archive.add(root,arcname='bnc-wl')
 if a.output.stat().st_size>64*1024*1024:a.output.unlink();p.error('release exceeds64MiB; reduce selected files')
print(json.dumps(dict(output=str(a.output),bytes=a.output.stat().st_size,sha256=hashlib.sha256(a.output.read_bytes()).hexdigest())))
