#!/usr/bin/env python3
"""Generate reviewable server config; does not install or contact AWS."""
import argparse,importlib.util,json,re,shlex
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('deploy_http',ROOT/'scripts/http-config.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
p=argparse.ArgumentParser();p.add_argument('--project',type=Path,required=True);p.add_argument('--state',type=Path,required=True);p.add_argument('--origin',required=True);p.add_argument('--user',default='bnc');p.add_argument('--output',type=Path,required=True);p.add_argument('--mode',choices=('fast','zk'),default='zk');a=p.parse_args()
h.origin(a.origin)
if not a.project.is_absolute() or not a.state.is_absolute():p.error('project/state must be absolute paths')
if not re.fullmatch('[a-z_][a-z0-9_-]*',a.user):p.error('invalid service user')
if any(any(c in str(v) for c in '\n\r%"\\') for v in (a.project,a.state)):p.error('unsupported service path characters')
if any(c.isspace() for c in str(a.output.resolve())):p.error('systemd config output path must not contain whitespace; project/state may')
a.output.mkdir(parents=True,exist_ok=True)
from urllib.parse import urlsplit
u=urlsplit(a.origin)
if u.scheme!="https":p.error("nginx deployment template requires HTTPS public origin")
env='\n'.join(k+'='+shlex.quote(v) for k,v in {'BNC_MODE':a.mode,'BNC_STATE_DIR':str(a.state),'BNC_PUBLIC_ORIGIN':a.origin,'BNC_API_PORT':'8580','BNC_BIND':'127.0.0.1','BNC_WL_PORT':'8565','BNC_BNB_PORT':'8566'}.items())+'\n'
(a.output/'server.env').write_text(env)
# EnvironmentFile format and shell env assignments are deliberately restricted.
service=f'''[Unit]
Description=BNC WL prototype unsigned proof service
After=network-online.target docker.service
Wants=network-online.target
[Service]
Type=simple
User={a.user}
WorkingDirectory={a.project}
EnvironmentFile={a.output.resolve()}/server.env
Environment="PATH={a.project}/.bin:/usr/local/bin:/usr/bin:/bin"
ExecStart=/usr/bin/bash "{a.project}/scripts/run-server.sh"
Restart=on-failure
RestartSec=5
KillMode=mixed
TimeoutStopSec=150
UMask=0077
LimitNOFILE=4096
[Install]
WantedBy=multi-user.target
'''
(a.output/'bnc-wl.service').write_text(service)
nginx=f'''# Include in nginx http context. Supply your own certificate/key.
limit_req_zone $binary_remote_addr zone=bnc_requests:10m rate=10r/s;
limit_conn_zone $binary_remote_addr zone=bnc_connections:10m;
server {{
    listen {u.port or 443} ssl;
    server_name {u.hostname};
    ssl_certificate /etc/bnc-wl/tls/fullchain.pem;
    ssl_certificate_key /etc/bnc-wl/tls/privkey.pem;
    client_max_body_size 64k;
    limit_req zone=bnc_requests burst=30 nodelay;
    limit_conn bnc_connections 20;
    location / {{
        proxy_pass http://127.0.0.1:8580;
        proxy_set_header Host {u.netloc};
        proxy_set_header Connection "";
        proxy_read_timeout 60s;
    }}
}}
'''
(a.output/'nginx.conf').write_text(nginx)
print(json.dumps(dict(output=str(a.output),installed=False,awsResourcesCreated=False)))
