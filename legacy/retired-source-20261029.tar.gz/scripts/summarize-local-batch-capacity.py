#!/usr/bin/env python3
"""Reverify a local batch-size experiment matrix; not a sustained throughput verdict."""
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import runpy

read_profile = runpy.run_path(str(Path(__file__).with_name('compare-local-proof-profiles.py')))['read_profile']


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--evidence', type=Path, action='append', required=True)
    parser.add_argument('--evm-evidence', type=Path, action='append', required=True,
                        help='one completed historical updater check for each proof, in the same order')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if len(args.evidence) != len(args.evm_evidence): parser.error('paired proof and EVM evidence required')
    rows = []
    for proof_dir, evm_dir in zip(args.evidence, args.evm_evidence):
        row = read_profile(proof_dir)
        directory = proof_dir.resolve()
        data = json.loads((directory / 'summary.json').read_text())
        verified = json.loads(subprocess.check_output([str(directory / 'risc0-host'), '--verify-receipt',
            str(directory / 'receipt.json')], text=True, timeout=120,
            env=dict(os.environ, RISC0_DEV_MODE='0', RISC0_PROVER='ipc')))
        if (verified.get('verified') is not True or verified.get('receipt_kind') != 'groth16'
            or verified.get('evm_compatible') is not True or verified.get('chain_authenticated') is not False
            or any(verified.get(key) != data['proof'].get(key) for key in ('image_id', 'journal', 'seal', 'header_binding'))):
            raise ValueError('SDK cryptographic recheck differs from profile')
        evm = json.loads((evm_dir / 'summary.json').read_text())
        negatives = evm.get('negativeChecks', [])
        if (evm.get('localVerdict') != 'PASS' or evm.get('realEvmHeaderAcceptance') is not True
            or evm.get('acceptedCoverageAndRootsChecked') is not True or evm.get('ownedNodeStopped') is not True
            or evm.get('sourceEvidence') != str(directory) or evm.get('receiptSHA256') != data['receiptSHA256']
            or evm.get('batchSize') != row['batchSize'] or evm.get('imageId') != row['imageId']
            or evm.get('chainAuthenticated') is not False or evm.get('realAssetDeploymentAllowed') is not False
            or evm.get('assetClaimsSubmitted') != 0
            or {n.get('name') for n in negatives} != {'altered-seal','wrong-journal','wrong-image','already-accepted-batch'}
            or not all(n.get('rejected') is True for n in negatives)):
            raise ValueError('historical EVM evidence is missing or belongs to another proof')
        row.update(sdkCryptographicallyReverified=True, historicalEvmAcceptanceRecorded=True,
                   historicalEvmEvidence=str(evm_dir.resolve()), gasUsed=evm['gasUsed'], calldataBytes=evm['calldataBytes'])
        rows.append(row)
    result = {'measuredAt': datetime.now(timezone.utc).isoformat(), 'localVerdict': 'PASS', 'profiles': rows,
        'scope': 'individual offline generation measurements; historical EVM evidence, SDK rechecked here',
        'sameInputControlledComparison': False, 'isolatedLatencyAssumed': False,
        'freshProofsGenerated': 0, 'transactionsBroadcast': 0, 'p95Measured': False,
        'sustainedAcceptedThroughputMeasuredHere': False, 'previousAcceptedThroughputFailureCleared': False,
        'chainAuthenticated': False, 'realAssetDeploymentAllowed': False}
    with args.output.open('x') as f: f.write(json.dumps(result, indent=2)+'\n')
    print('PASS offline batch matrix; SDK rechecked, historical EVM only, prior accepted failure remains')


if __name__ == '__main__': main()
