#!/usr/bin/env python3
"""Submit a bounded, SDK verified historical Groth16 batch to owned local Anvil."""
import argparse
import base64
import hashlib
import importlib.util
import json
from pathlib import Path
import struct
import subprocess
import time

spec = importlib.util.spec_from_file_location('local_client', Path(__file__).with_name('local-session.py'))
client = importlib.util.module_from_spec(spec)
spec.loader.exec_module(client)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def cache_key(package, image):
    key = {'sourceChainId': 31338, 'startBlock': package['startBlock'], 'endBlock': package['endBlock'],
           'startAnchorHash': package['anchorHash'], 'endBlockHash': package['endHash'],
           'batchRoot': package['batchRoot'], 'imageId': image}
    raw = b''.join(struct.pack('>Q', key[field]) for field in ('sourceChainId', 'startBlock', 'endBlock'))
    raw += b''.join(bytes.fromhex(key[field][2:]) for field in
                    ('startAnchorHash', 'endBlockHash', 'batchRoot', 'imageId'))
    return key, hashlib.sha256(raw).hexdigest() + '.json'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dir', type=Path, default=client.ROOT / 'results/session-zk-partial-burn-settlement')
    parser.add_argument('--start', type=int, choices=(6, 10, 14), required=True)
    args = parser.parse_args()
    out = args.dir.resolve()
    start = args.start
    count = 3 if start == 14 else 4
    proof = out / f'proof-{start}'
    result = out / f'accepted-{start}.json'
    if result.exists():
        parser.error('batch already recorded; do not repeat user transaction')
    source = json.loads((out / f'package-{start}.json').read_text())
    report = json.loads((proof / 'summary.json').read_text())
    if (report.get('localVerdict') != 'PASS' or report.get('cryptographicallyReverified') is not True
        or report.get('requestedReceiptKind') != 'groth16' or report.get('batchSize') != count
        or report.get('sourceChainId') != 31338 or report.get('legacyMinimalHostRequested') is not True
        or report.get('chainAuthenticated') is not False or report.get('realAssetDeploymentAllowed') is not False
        or report.get('imageId') != '0x92a4a70bc2bbde4c4627363ee596f8c6cf9beaa79635f90703a8dad4a4afe5de'
        or report.get('hostSHA256') != 'df67c541072ca742259ca6fb1d5053accdd7a270326cd34a6b45b42610386209'
        or report.get('inputSHA256') != sha(out / f'input-{start}.json')
        or report.get('receiptSHA256') != sha(proof / 'receipt.json')):
        parser.error('bounded actual Groth16 proof and frozen input required')
    session = client.Session(out / 'session')
    started = time.monotonic()
    session.start('risc0_batch')
    try:
        session.setup()
        updater = session.data['contracts']['wl_headers']
        if (session.data['image_id'] != report['imageId']
            or session.data['host_sha256'] != report['hostSHA256']
            or sha(session.prover_host()) != report['hostSHA256']
            or int(session.view('wl', updater, 'latestBlock()(uint256)')) != start - 1
            or session.view('wl', updater, 'latestHash()(bytes32)').lower() != source['anchorHash'].lower()
            or session.view('wl', updater, 'guestImageId()(bytes32)').lower() != report['imageId'].lower()):
            raise RuntimeError('source or destination state changed before Groth16 submission')
        command = [client.HEADER, '--rpc', session.data['chains']['bnb']['rpc'], '--chain-id', '31338',
                   '--start', str(start), '--count', str(count), '--header-binding', 'minimal-link']
        fresh = json.loads(subprocess.check_output([str(value) for value in command], text=True, timeout=60))
        for field in ('sourceChainId', 'startBlock', 'endBlock', 'anchorHash', 'endHash',
                      'batchRoot', 'journal', 'batchData', 'guestInput'):
            if fresh[field] != source[field]:
                raise RuntimeError(f'source batch changed: {field}')
        check = json.loads(subprocess.check_output([session.prover_host(), '--verify-receipt', proof / 'receipt.json'],
                                                  text=True, timeout=120))
        if (check.get('verified') is not True or check.get('receipt_kind') != 'groth16'
            or check.get('evm_compatible') is not True or check.get('chain_authenticated') is not False
            or check.get('image_id') != report['imageId'] or check.get('journal') != source['journal']
            or check.get('seal') != report['proof']['seal']):
            raise RuntimeError('actual SDK Groth16 receipt does not match the fresh Go journal')
        key, name = cache_key(source, report['imageId'])
        encoded = {'version': 1, 'key': key,
                   'proofData': base64.b64encode((proof / 'receipt.json').read_bytes()).decode(),
                   'journal': base64.b64encode(bytes.fromhex(source['journal'][2:])).decode()}
        cache = session.root / 'proof-cache/groth16' / name
        if cache.exists() and json.loads(cache.read_text()) != encoded:
            raise RuntimeError('existing proof cache key differs')
        if not cache.exists():
            client.write_json(cache, encoded)
        checked = json.loads(subprocess.check_output([str(value) for value in command] +
            ['--risc0-host', str(session.prover_host()), '--proof-cache', str(session.root / 'proof-cache'),
             '--receipt-kind', 'groth16', '--proof-timeout', '10s'], text=True, timeout=25))
        if (checked.get('cacheHit') is not True or checked.get('proofVerified') is not True
            or checked.get('evmCompatible') is not True or checked.get('receiptKind') != 'groth16'
            or checked.get('imageId') != report['imageId'] or checked.get('journal') != source['journal']
            or checked.get('seal') != check['seal'] or checked.get('batchData') != source['batchData']):
            raise RuntimeError('cached Go package is not the same SDK Groth16 batch')
        client.write_json(session.root / f'burn-{start}-{count}-headers.json', checked)
        user = next(e['user'] for e in session.data['events'] if e['action'] == 'burn')
        tx = session.send('wl', user, updater, 'submitHeaderProof(bytes,bytes,bytes)',
                          checked['seal'], checked['journal'], checked['batchData'])
        client.write_json(session.root / f'burn-{start}-accepted.json', tx)
        if (int(session.view('wl', updater, 'latestBlock()(uint256)')) != start + count - 1
            or session.view('wl', updater, 'latestHash()(bytes32)').lower() != source['endHash'].lower()):
            raise RuntimeError('local updater did not accept the requested header range')
        claimed = []
        if start == 14:
            for event in session.data['events']:
                if event['action'] == 'burn' and event.get('claimed') is not True:
                    session.claim(event)
                    claimed.append(event['id'])
            locked = sum(int(session.view('wl', session.data['contracts']['original'],
                                          'lockedBalanceOf(address)(uint256)', user)) for user in session.data['users'])
            wrapped = int(session.view('bnb', session.data['contracts']['wrapped'], 'totalSupply()(uint256)'))
            if len(claimed) != 2 or locked != 53 * 10**18 or wrapped != 53 * 10**18:
                raise RuntimeError('partial burn unlock settlement balance mismatch')
        client.write_json(result, {'localVerdict': 'PASS', 'sourceChainId': 31338,
            'imageId': report['imageId'], 'startBlock': start, 'endBlock': start + count - 1,
            'actualSdkGroth16Verified': True, 'goCacheHit': True,
            'localUpdaterAccepted': True, 'transactionHash': tx['transactionHash'],
            'burnClaims': claimed, 'newProofThisStage': False, 'proofSource': str(proof),
            'chainAuthenticated': False, 'realAssetDeploymentAllowed': False,
            'wallSeconds': time.monotonic() - started})
        print(f'local historical Groth16 burn header {start}..{start + count - 1}: PASS')
    finally:
        session.stop()


if __name__ == '__main__':
    main()
