#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
case "${1:-fast}" in
    fast) source "$ROOT_DIR/configs/local-fast.env"; export HEADER_MODE; exec "$ROOT_DIR/scripts/local-roundtrip.sh" ;;
    composite) source "$ROOT_DIR/configs/local-composite.env"; export HEADER_MODE; exec "$ROOT_DIR/scripts/local-roundtrip.sh" ;;
    zk) source "$ROOT_DIR/configs/local-zk.env"; export HEADER_MODE; exec "$ROOT_DIR/scripts/local-risc0-roundtrip.sh" ;;
    zk-bound) source "$ROOT_DIR/configs/local-zk-bound.env"; RISC0_HOST_PATH="$ROOT_DIR/risc0/target/release/bridge-header-bound-host"; export HEADER_MODE HEADER_BINDING RISC0_HOST_PATH; exec "$ROOT_DIR/scripts/local-risc0-roundtrip.sh" ;;
    paced) source "$ROOT_DIR/configs/local-paced.env"; exec python3 "$ROOT_DIR/scripts/local-paced-groth16.py" --seconds "$LOCAL_PACE_SECONDS" --block-time "$LOCAL_BLOCK_INTERVAL_SECONDS" --max-lag "$LOCAL_MAX_ACCEPTED_LAG" ;;
    *) echo "usage: run-local.sh fast|composite|zk|zk-bound|paced" >&2; exit 2 ;;
esac
