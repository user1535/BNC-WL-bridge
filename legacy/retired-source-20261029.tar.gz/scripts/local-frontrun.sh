#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FRONTRUN_CLAIMS=1 exec "$ROOT_DIR/scripts/local-roundtrip.sh"
