import {chromium,launchOptions} from './browser-runtime.mjs';
import fs from 'node:fs';
const browser=await chromium.launch(launchOptions);
try{
 const page=await browser.newPage();await page.goto('http://127.0.0.1:8581/');
 const result=await page.evaluate(async()=>{
  const {DemoWallet}=await import('/demo-wallet.mjs');const {WalletClient,validatePackage}=await import('/client.mjs');const {Interface}=await import('/vendor/ethers-6.15.0.min.mjs');
  const m=await (await fetch('/api/manifest')).json();if(m.proofPolicy!=='trusted-rpc-receipt-root')throw Error('wrong proof policy');
  const provider=new DemoWallet(m),client=new WalletClient(provider,m),owner=(await client.connect())[0];window.confirm=()=>true;
  const iface=new Interface(['function balanceOf(address) view returns(uint256)','function availableBalanceOf(address) view returns(uint256)']);
  async function balances(){await client.switchChain(31337);const original=String(await client.call(m.contracts.original,iface,'balanceOf',[owner])),available=String(await client.call(m.contracts.original,iface,'availableBalanceOf',[owner]));await client.switchChain(31338);return {original,available,wrapped:String(await client.call(m.contracts.wrapped,iface,'balanceOf',[owner]))};}
  const before=await balances(),steps=[];
  for(const action of ['lock','burn']){
   await client.switchChain(action==='lock'?31337:31338);const p=await client.action(action,'1000000000000000000',owner);const hash=await client.submitAction(p,async()=>{});const receipt=await client.rpc('eth_getTransactionReceipt',[hash]);
   const event=receipt.logs.find(x=>x.topics.length===4);if(!event)throw Error('event missing');
   const request={action,transferId:event.topics[1],fromBlock:Number(BigInt(receipt.blockNumber))};
   const j=await (await fetch('/api/jobs',{method:'POST',headers:{'Content-Type':'application/json','X-Bridge-Request':'1'},body:JSON.stringify(request)})).json();let job;
   for(let i=0;i<30;i++){await new Promise(r=>setTimeout(r,1000));job=await (await fetch('/api/jobs/'+j.id)).json();if(job.state==='failed')throw Error(job.detail);if(job.state==='ready')break;}
   if(job.state!=='ready')throw Error('job did not complete');
   const pkg=await (await fetch('/api/jobs/'+j.id+'/package')).json();validatePackage(pkg,m);
   await client.switchChain(action==='lock'?31338:31337);const preview=await client.preview(pkg,'claim');if(preview.headerRequired)throw Error('manual header required');
   const claim=await client.submit(preview,async()=>{});const claimed=await client.rpc('eth_getTransactionReceipt',[claim]);if(BigInt(claimed.status)!==1n)throw Error('claim failed');
   let replayRejected=false;try{await client.preview(pkg,'claim');}catch{replayRejected=true;}if(!replayRejected)throw Error('replay allowed');
   steps.push({action,sourceBlock:request.fromBlock,job:j.id,sourceTransaction:hash,claimTransaction:claim,manualHeaders:0,replayRejected});
  }
  const after=await balances();if(JSON.stringify(before)!==JSON.stringify(after))throw Error('balance conservation failed');return {before,after,steps,proofPolicy:m.proofPolicy,newRisc0Proofs:0};
 });
 fs.writeFileSync(new URL('../results/trusted-rpc-demo-summary.json',import.meta.url),JSON.stringify({passed:true,...result},null,2));console.log(JSON.stringify(result));
}finally{await browser.close();}
