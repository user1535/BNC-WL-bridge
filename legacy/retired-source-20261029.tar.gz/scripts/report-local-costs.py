#!/usr/bin/env python3
"""Report actual recorded wallet tx gas/calldata, without RPC or fee projections."""
import argparse,hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--output-dir',type=Path,required=True);args=parser.parse_args()
 out=args.output_dir.resolve();out.mkdir(parents=True,exist_ok=False)
 report={'chainAuthenticated':False,'realAssetDeploymentAllowed':False,'scope':'actual recorded local wallet-provider transactions only; deployment/operator header costs excluded','rpcCalls':0,'rows':[],'unmeasured':['batch128 header storage/gas','live fees','proof compression cost','external wallet extension signing']}
 for directory,phases,mode in [('wallet-client-fast-verified',['lock','mint','burn','unlock'],'dev'),('wallet-client-strict-replay',['header-lock','mint','burn','header-burn','unlock'],'canonical-rlp historical Groth16 replay')]:
  source=ROOT/'results'/directory
  for phase in phases:
   browser_path=source/(phase+'-browser.json');receipt_path=source/(phase+'-receipt.json')
   browser=json.loads(browser_path.read_text());receipt=json.loads(receipt_path.read_text())
   if not browser['passed'] or int(receipt['status'],16)!=1 or len(browser['transactions'])!=1:raise ValueError('not accepted browser wallet transaction')
   tx=browser['transactions'][0]
   if tx['hash'].lower()!=receipt['transactionHash'].lower():raise ValueError('browser/receipt hash mismatch')
   data=bytes.fromhex(tx['transaction']['data'][2:]);gas=int(receipt['gasUsed'],16);price=int(receipt['effectiveGasPrice'],16)
   row={'sourceDirectory':str(source.relative_to(ROOT)),'phase':phase,'mode':mode,'chainId':int(tx['transaction']['chainId'],16),'transactionHash':tx['hash'],'to':tx['transaction']['to'],'gasUsed':gas,'effectiveGasPriceWei':str(price),'actualGasChargeWei':str(gas*price),'calldataBytes':len(data),'calldataZeroBytes':data.count(0),'calldataNonzeroBytes':len(data)-data.count(0),'receiptSha256':hashlib.sha256(receipt_path.read_bytes()).hexdigest(),'browserRecordSha256':hashlib.sha256(browser_path.read_bytes()).hexdigest()}
   if phase.startswith('header-'):
    package=json.loads((source/('lock-package.json' if phase=='header-lock' else 'burn-package.json')).read_text())['headerProof']
    row.update(batchSize=package['endBlock']-package['startBlock']+1,sealBytes=len(bytes.fromhex(package['seal'][2:])),journalBytes=len(bytes.fromhex(package['journal'][2:])))
   report['rows'].append(row)
 (out/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
 lines=['# 실측 local wallet transaction 비용','', '실제 로컬 receipt의 gasUsed·effectiveGasPrice와 browser 요청의 calldata 크기다. 현재 live 가격·전체 브리지 비용·batch128 비용을 추정하지 않는다.','', '| 경로 | 동작 | gasUsed | calldata bytes |','|---|---|---:|---:|']
 lines += [f"| {row['mode']} | {row['phase']} | {row['gasUsed']} | {row['calldataBytes']} |" for row in report['rows']]
 (out/'report.md').write_text('\n'.join(lines)+'\n');print('\n'.join(lines[4:]))
if __name__=='__main__':main()
