#!/usr/bin/env python3
"""Fault-inject local RPC responses around actual archived receipts/proofs.

Destination RPC is simulated: this is CLI rejection coverage, not EVM evidence.
The zk positives cryptographically reverify existing genuine Groth16 receipts.
"""
import argparse
from collections import Counter
import copy
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import subprocess
import threading

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--evidence',type=Path,default=ROOT/'results/local-risc0-bound-pinned')
    parser.add_argument('--output-dir',type=Path,default=ROOT/'results/generator-rpc-faults')
    args=parser.parse_args()
    evidence=args.evidence.resolve();output=args.output_dir.resolve();output.mkdir(parents=True,exist_ok=False)
    binary=ROOT/'.bin/bridge-proof'
    subprocess.run(['go','-C',str(ROOT/'proof-generator'),'build','-o',str(binary),'./cmd/bridge-proof'],check=True)
    signatures=['headerSource()','sourceChainId()','sourceToken()','wrappedToken()','sourceWrappedToken()','originalToken()',
                'guestImageId()','latestBlock()','latestHash()','isBlockCovered(uint256,uint256,bytes32)','getReceiptRoot(uint256,uint256,bytes32)']
    selectors={s:subprocess.check_output(['cast','sig',s],text=True).strip() for s in signatures}
    report={'localVerdict':'FAIL','cases':[],'destinationRpcSimulated':True,'freshProofsGenerated':0,
            'realEvmAcceptanceTestedHere':False,'chainAuthenticated':False,'realAssetDeploymentAllowed':False}
    env=dict(os.environ,RISC0_DEV_MODE='0',RISC0_PROVER='ipc')
    scenarios=[('dev','valid',''),('dev','late-reorg','source block changed'),('dev','late-root-change','source block changed'),
               ('dev','safe-regression','no longer satisfies confirmations'),('dev','forged-filter-tx','target receipt'),
               ('dev','removed-filter','removed event'),('dev','missing-receipt','fetch receipt'),
               ('risc0_batch','valid',''),('risc0_batch','late-reorg','header package changed'),
               ('risc0_batch','late-root-change','header package changed'),('risc0_batch','safe-regression','safe height'),
               ('risc0_batch','wrong-image','image ID differs'),('risc0_batch','stale-head','does not extend'),
               ('risc0_batch','wrong-anchor','anchor differs'),('risc0_batch','covered-root-mismatch','destination receipt root')]
    try:
        for direction in ('lock','burn'):
            package=json.loads((evidence/(direction+'-package.json')).read_text())
            header=json.loads((evidence/(direction+'-header.json')).read_text())
            receipt=json.loads((evidence/(direction+'-receipt.json')).read_text())
            source_id=package['sourceChainId'];destination_id=package['destinationChainId'];height=package['blockNumber']
            target=receipt['logs'][package['logIndex']]
            receiver=package['claimTransaction']['to']
            updater=package['headerTransaction']['to']
            for mode,scenario,expected_error in scenarios:
                name=direction+'-'+mode+'-'+scenario
                counts=Counter();methods=Counter()
                filtered=copy.deepcopy(target)
                if scenario=='forged-filter-tx':filtered['transactionHash']='0x'+'de'*32
                if scenario=='removed-filter':filtered['removed']=True

                def word(value):
                    if isinstance(value,int):return '0x'+format(value,'064x')
                    return '0x'+value.removeprefix('0x').rjust(64,'0')

                def handle(role,method,params):
                    methods[role+':'+method]+=1
                    if method=='eth_chainId':return hex(source_id if role=='source' else destination_id)
                    if role=='source':
                        if method=='eth_blockNumber':
                            counts['tip']+=1
                            return hex(height-1 if scenario=='safe-regression' and counts['tip']>=2 else height)
                        if method=='eth_getLogs':return [filtered]
                        if method=='eth_getBlockReceipts':return [] if scenario=='missing-receipt' else [receipt]
                        if method=='eth_getTransactionReceipt':return None if scenario=='missing-receipt' else receipt
                        if method=='eth_getBlockByNumber':
                            number=int(params[0],16)
                            if number==height:
                                counts['eventHeader']+=1
                                changed=counts['eventHeader']>=6
                                block_hash='0x'+'de'*32 if scenario=='late-reorg' and changed else package['blockHash']
                                root='0x'+'ab'*32 if scenario=='late-root-change' and changed else package['receiptRoot']
                            else:block_hash=header['anchorHash'];root='0x'+'00'*32
                            return {'number':hex(number),'hash':block_hash,'parentHash':header['anchorHash'],
                                    'receiptsRoot':root,'transactions':[receipt['transactionHash']]}
                    else:
                        if method=='eth_getCode':return '0x6000'
                        if method=='eth_call':
                            data=params[0].get('input',params[0].get('data',''));selector=data[:10]
                            values={'headerSource()':updater,'sourceChainId()':source_id,'sourceToken()':package['sourceToken'],
                                    'sourceWrappedToken()':package['sourceToken'],'wrappedToken()':package['destinationToken'],
                                    'originalToken()':package['destinationToken'],'guestImageId()':header['imageId'],
                                    'latestBlock()':height-1,'latestHash()':header['anchorHash'],
                                    'isBlockCovered(uint256,uint256,bytes32)':int(scenario=='covered-root-mismatch'),
                                    'getReceiptRoot(uint256,uint256,bytes32)':package['receiptRoot']}
                            if scenario=='wrong-image':values['guestImageId()']='0x'+'de'*32
                            if scenario=='stale-head':values['latestBlock()']=height
                            if scenario=='wrong-anchor':values['latestHash()']='0x'+'de'*32
                            if scenario=='covered-root-mismatch':values['getReceiptRoot(uint256,uint256,bytes32)']='0x'+'de'*32
                            for signature,selected in selectors.items():
                                if selected==selector:return word(values[signature])
                    raise ValueError('unexpected RPC method '+method)

                class Handler(BaseHTTPRequestHandler):
                    def log_message(self,*_args):pass
                    def do_POST(self):
                        request=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
                        response={'jsonrpc':'2.0','id':request['id']}
                        try:response['result']=handle(self.path.removeprefix('/'),request['method'],request.get('params',[]))
                        except Exception as error:response['error']={'code':-32000,'message':str(error)}
                        encoded=json.dumps(response).encode();self.send_response(200);self.send_header('Content-Type','application/json');self.end_headers();self.wfile.write(encoded)

                server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
                thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
                base=f'http://127.0.0.1:{server.server_port}'
                command=[str(binary),'--rpc',base+'/source','--chain-id',str(source_id),'--token',package['sourceToken'],
                         '--destination-token',package['destinationToken'],'--id',package['transferId'],'--action',direction,
                         '--destination-rpc',base+'/destination','--header-source',updater,'--receiver',receiver,'--header-mode',mode]
                if mode=='risc0_batch':command+=['--risc0-host',str(evidence/'risc0-host'),'--header-package',str(evidence/(direction+'-header.json'))]
                try:
                    run=subprocess.run(command,capture_output=True,text=True,timeout=120,env=env)
                finally:
                    server.shutdown();server.server_close();thread.join(timeout=3)
                (output/(name+'.stdout')).write_text(run.stdout);(output/(name+'.stderr')).write_text(run.stderr)
                (output/(name+'-rpc.json')).write_text(json.dumps({'methods':dict(methods),'counts':dict(counts)},indent=2)+'\n')
                if scenario=='valid':
                    if run.returncode:raise AssertionError(name+': '+run.stderr)
                    generated=json.loads(run.stdout)
                    assert not generated['chainAuthenticated'] and generated['claimTransaction']['chainId']==destination_id
                    if mode=='risc0_batch':
                        assert generated['headerProof']['proofVerified'] and generated['headerProof']['receiptKind']=='groth16'
                        assert generated['headerProof']['hashBindingVerified'] and generated['headerProof']['headerBinding']=='canonical-rlp'
                elif run.returncode==0 or run.stdout or expected_error not in run.stderr:
                    raise AssertionError(name+': wrong rejection: '+run.stderr)
                if any('sendTransaction' in method or 'sendRawTransaction' in method for method in methods):raise AssertionError('generator broadcast attempted')
                report['cases'].append({'direction':direction,'mode':mode,'scenario':scenario,'passed':True,'rpcCalls':sum(methods.values())})
                (output/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
        report['localVerdict']='PASS'
        print(f'CLI RPC faults: {len(report["cases"])} cases PASS; broadcasts/proof generation: 0; EVM RPC simulated')
    except Exception as error:
        report['error']=str(error);raise
    finally:(output/'summary.json').write_text(json.dumps(report,indent=2)+'\n')


if __name__=='__main__':main()
