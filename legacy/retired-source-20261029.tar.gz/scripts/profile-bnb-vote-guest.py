#!/usr/bin/env python3
"""Profile measured BNB BLS guest cycles with the unchanged frozen image; no proof."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess

ROOT = Path(__file__).resolve().parent.parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--execution-evidence", type=Path, required=True)
    p.add_argument("--dir", type=Path, required=True)
    args = p.parse_args()
    evidence = args.execution_evidence.resolve()
    summary = json.loads((evidence / "summary.json").read_text())
    metadata = json.loads((evidence / "metadata.json").read_text())
    row = next(r for r in summary["results"] if r["case"] == "parent")
    if (summary.get("status") != "PASS" or row.get("passed") is not True
            or summary.get("headerBinding") != "bnb-vote-native-rlp-supplied-epoch"
            or row.get("execution", {}).get("guestExecuted") is not True):
        raise ValueError("completed actual BNB BLS guest evidence required")
    if sha(evidence / "risc0-host") != metadata["hostSHA256"] or sha(evidence / "parent-input.json") != row["inputSHA256"]:
        raise ValueError("frozen host/input differs")
    server = Path.home() / ".cargo/bin/r0vm"
    if sha(server) != metadata["serverSHA256"]:
        raise ValueError("frozen SDK server differs")
    spec = importlib.util.spec_from_file_location("profile_monitor", ROOT / "scripts/benchmark-header.py")
    monitor = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(monitor)
    out = args.dir.resolve()
    out.mkdir(parents=True, exist_ok=False)
    host = out / "risc0-host"
    shutil.copy2(evidence / "risc0-host", host)
    source_input = out / "input.json"
    shutil.copy2(evidence / "parent-input.json", source_input)
    profile = out / "cycles.pprof"
    env = dict(os.environ, RISC0_DEV_MODE="0", RISC0_PROVER="ipc", RISC0_SERVER_PATH=str(server),
               RAYON_NUM_THREADS="4", BRIDGE_RISC0_SEGMENT_PO2="18", RISC0_PPROF_OUT=str(profile))
    report = {"measuredAt": datetime.now(timezone.utc).isoformat(), "localVerdict": "FAIL",
              "imageId": summary["imageId"], "executionEvidence": str(evidence),
              "hostSHA256": sha(host), "inputSHA256": sha(source_input), "serverSHA256": sha(server),
              "profilingEnabled": True, "guestImageChanged": False, "proofGenerated": False,
              "evmAcceptanceMeasured": False, "chainAuthenticated": False, "realAssetDeploymentAllowed": False,
              "segmentPo2": 18, "threads": 4, "timeoutSeconds": 600,
              "memoryLimitKiB": metadata["memoryLimitKB"]}
    try:
        result, resources = monitor.run_with_memory_limit([str(host), "--execute-input", str(source_input)],
                                                          env, report["memoryLimitKiB"], 600)
        (out / "execute.stdout.json").write_text(result.stdout)
        (out / "execute.stderr.txt").write_text(result.stderr)
        report.update(resources=resources, exitCode=result.returncode)
        if result.returncode:
            raise RuntimeError("bounded actual guest profiler failed")
        actual = json.loads(result.stdout)
        if (actual.get("imageId") != summary["imageId"] or actual.get("journal") != row["execution"]["journal"]
                or actual.get("executionCycles") != row["execution"]["executionCycles"]
                or actual.get("guestExecuted") is not True or actual.get("proofGenerated") is not False):
            raise ValueError("profiling changed image/statement/guest cycles")
        if not profile.is_file() or not 0 < profile.stat().st_size <= 128 * 1024 * 1024:
            raise ValueError("missing/bounded128MiB pprof artifact")
        for suffix, extra in (("flat", []), ("cumulative", ["-cum"])):
            text = subprocess.check_output(["go", "tool", "pprof", "-top", "-nodecount=30", "-symbolize=none",
                                            *extra, str(profile)], text=True, stderr=subprocess.PIPE, timeout=60)
            (out / f"top-{suffix}.txt").write_text(text)
        report.update(localVerdict="PASS", execution=actual, profileSHA256=sha(profile),
                      profileBytes=profile.stat().st_size,
                      limitation="instrumented guest execution cycles, not proving/accepted throughput; wall includes profiler overhead")
    except BaseException as error:
        report["error"] = str(error)
        raise
    finally:
        (out / "summary.json").write_text(json.dumps(report, indent=2) + "\n")
    print(out / "summary.json", flush=True)


if __name__ == "__main__":
    def interrupted(signum, frame):
        raise KeyboardInterrupt("owned BLS cycle profiling interrupted")
    signal.signal(signal.SIGTERM, interrupted)
    main()
