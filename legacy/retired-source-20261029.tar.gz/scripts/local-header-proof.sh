#!/usr/bin/env bash
set -euo pipefail

# Local composite proof/cache check; this submits no transactions and authenticates no chain.
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
RPC=http://127.0.0.1:8557
HOST="$ROOT_DIR/risc0/target/release/bridge-header-benchmark"
if cast chain-id --rpc-url "$RPC" >/dev/null 2>&1; then
    echo "Port 8557 is already in use" >&2; exit 1
fi
[[ -x "$HOST" ]] || { echo "Build the RISC0 host first" >&2; exit 1; }
WORK="$(mktemp -d)"
ANVIL_PID=""
FIRST_PID=""
SECOND_PID=""
cleanup() {
    for pid in "$FIRST_PID" "$SECOND_PID" "$ANVIL_PID"; do
        [[ -z "$pid" ]] || kill "$pid" 2>/dev/null || true
    done
    rm -rf "$WORK"
}
trap cleanup EXIT
anvil --silent --host 127.0.0.1 --port 8557 --chain-id 31337 >"$WORK/anvil.log" 2>&1 &
ANVIL_PID=$!
for _ in $(seq 1 50); do
    if [[ "$(cast chain-id --rpc-url "$RPC" 2>/dev/null || true)" == "31337" ]]; then break; fi
    sleep 0.2
done
[[ "$(cast chain-id --rpc-url "$RPC")" == "31337" ]]
cast rpc anvil_mine 2 --rpc-url "$RPC" >/dev/null
mkdir -p "$ROOT_DIR/.bin"
go -C "$ROOT_DIR/proof-generator" build -o "$ROOT_DIR/.bin/bridge-header-data" ./cmd/bridge-header-data
export RISC0_SERVER_PATH="${RISC0_SERVER_PATH:-$HOME/.cargo/bin/r0vm}"
generate() {
    "$ROOT_DIR/.bin/bridge-header-data" --rpc "$RPC" --chain-id 31337 --start 1 --count 1 \
        --risc0-host "$HOST" --proof-cache "$WORK/cache" --proof-timeout 5m
}
# Concurrent requests must share one generation and independently verify the receipt.
generate >"$WORK/first.json" 2>"$WORK/first.err" &
FIRST_PID=$!
generate >"$WORK/second.json" 2>"$WORK/second.err" &
SECOND_PID=$!
if ! wait "$FIRST_PID"; then cat "$WORK/first.err" >&2; exit 1; fi
FIRST_PID=""
if ! wait "$SECOND_PID"; then cat "$WORK/second.err" >&2; exit 1; fi
SECOND_PID=""
python3 - "$WORK" <<'PY'
import base64, json, sys
from pathlib import Path
work = Path(sys.argv[1])
first, second = [json.loads((work / name).read_text()) for name in ('first.json', 'second.json')]
assert sorted([first['cacheHit'], second['cacheHit']]) == [False, True]
for package in (first, second):
    assert package['kind'] == 'local-composite-header-proof'
    assert package['proofVerified'] and package['receiptKind'] == 'composite'
    assert not package['sealAvailable'] and not package['evmCompatible'] and not package['chainAuthenticated']
assert first['proofReceipt'] == second['proofReceipt']
assert first['journal'] == second['journal'] and first['imageId'] == second['imageId']
(work / 'valid-receipt.json').write_text(json.dumps(first['proofReceipt']))
cache_files = list((work / 'cache').rglob('*.json'))
assert len(cache_files) == 1
cache = json.loads(cache_files[0].read_text())
receipt = json.loads(base64.b64decode(cache['proofData']))
# Tamper with the actual RISC0 journal inside the receipt, not just cache metadata.
receipt['journal']['bytes'][0] ^= 1
cache['proofData'] = base64.b64encode(json.dumps(receipt).encode()).decode()
cache_files[0].write_text(json.dumps(cache))
PY
if generate >"$WORK/tampered.json" 2>"$WORK/tampered.err"; then
    echo "Tampered cached RISC0 receipt was accepted" >&2; exit 1
fi
[[ ! -s "$WORK/tampered.json" ]]
[[ "$(cat "$WORK/tampered.err")" == *"cached proof rejected"* ]]
if RISC0_DEV_MODE=1 "$HOST" --prove-receipt --input "$ROOT_DIR/risc0/fixtures/local-three-headers.json" \
    --receipt-output "$WORK/fake.json" >"$WORK/fake.out" 2>"$WORK/fake.err"; then
    echo "Development-mode proof export was accepted" >&2; exit 1
fi
[[ "$(cat "$WORK/fake.err")" == *"RISC0_DEV_MODE is forbidden"* ]]
[[ ! -e "$WORK/fake.json" ]]
if RISC0_DEV_MODE=1 "$HOST" --verify-receipt "$WORK/valid-receipt.json" \
    >"$WORK/dev-verify.out" 2>"$WORK/dev-verify.err"; then
    echo "Development-mode receipt verification was accepted" >&2; exit 1
fi
[[ "$(cat "$WORK/dev-verify.err")" == *"RISC0_DEV_MODE is forbidden"* ]]
[[ ! -s "$WORK/dev-verify.out" ]]
mkdir -p "$ROOT_DIR/results/local-header-proof"
python3 - "$WORK" "$ROOT_DIR/results/local-header-proof/summary.json" <<'PY'
import datetime, hashlib, json, sys
from pathlib import Path
packages = [json.loads((Path(sys.argv[1]) / name).read_text()) for name in ('first.json','second.json')]
receipt = json.dumps(packages[0]['proofReceipt'], sort_keys=True, separators=(',', ':')).encode()
summary = {
    'measured_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source_chain_id': 31337, 'header_count': 1, 'image_id': packages[0]['imageId'],
    'batch_root': packages[0]['batchRoot'], 'receipt_kind': 'composite',
    'receipt_sha256': hashlib.sha256(receipt).hexdigest(),
    'concurrent_requests': 2, 'cache_misses': 1, 'cache_hits': 1,
    'proof_verified': True, 'tampered_cached_receipt_rejected': True,
    'development_mode_export_rejected': True,
    'development_mode_verification_rejected': True,
    'evm_compatible': False, 'chain_authenticated': False, 'transactions_submitted': 0,
}
Path(sys.argv[2]).write_text(json.dumps(summary, indent=2) + '\n')
print('real local RISC0 composite receipt: verified')
print('two concurrent requests: one generation, one verified cache reuse')
print('tampered receipt and development-mode export: rejected')
print('EVM compatible: false; chain authenticated: false; transactions submitted: 0')
PY
