// Browser integration uses a controlled EIP-1193 provider backed by real local Anvil.
// No external extension/private-key signing is claimed.
import {chromium,launchOptions} from './browser-runtime.mjs';
import fs from 'node:fs';
import {fileURLToPath} from 'node:url';
const [directory,phase]=process.argv.slice(2),base=new URL('../'+directory+'/',import.meta.url);
if(!directory || !['lock','burn','mint','unlock','header-lock','header-burn'].includes(phase)) throw new Error('directory and phase required');
const manifest=JSON.parse(fs.readFileSync(new URL('wallet-manifest.json',base))),owner=manifest.users[0];
let chain=['lock','unlock','header-burn'].includes(phase)?'wl':'bnb';
const methods={},sent=[];
async function rpc(method,params=[]) {
  const response=await fetch(manifest.chains[chain].rpc,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({jsonrpc:'2.0',id:1,method,params}),signal:AbortSignal.timeout(15000)});
  const body=await response.json();if(body.error) throw Object.assign(new Error(body.error.message),body.error);return body.result;
}
const browser=await chromium.launch(launchOptions);
const report={phase,testWallet:'controlled EIP-1193 provider with unlocked local Anvil account',externalExtensionTested:false,chainAuthenticated:false,realAssetDeploymentAllowed:false,passed:false};
try {
  const context=await browser.newContext(),page=await context.newPage(),errors=[];
  page.on('pageerror',error=>errors.push(error.message));
  await page.exposeFunction('__walletRpc',async({method,params=[]})=>{
    methods[method]=(methods[method]||0)+1;
    if(method==='eth_requestAccounts'||method==='eth_accounts') return [owner];
    if(method==='wallet_switchEthereumChain') {chain=Object.keys(manifest.chains).find(k=>BigInt(manifest.chains[k].id)===BigInt(params[0].chainId));if(!chain)throw new Error('not a local chain');return null;}
    try {
      const result=await rpc(method,params);
      if(method==='eth_sendTransaction') sent.push({hash:result,transaction:params[0]});
      return {result};
    } catch(error) {return {error:{message:error.message,code:error.code,data:error.data}};}
  });
  await page.addInitScript(()=>{
    const events={};window.ethereum={on:(name,fn)=>{(events[name]??=[]).push(fn);},request:async args=>{
      const value=await window.__walletRpc(args);
      if(args.method==='wallet_switchEthereumChain') {(events.chainChanged??[]).forEach(fn=>fn(args.params[0].chainId));return null;}
      if(Array.isArray(value)) return value;
      if(value.error) throw Object.assign(new Error(value.error.message),value.error);
      return value.result;
    }};
  });
  const load=async()=>{
    await page.locator('#manifest').setInputFiles(fileURLToPath(new URL('wallet-manifest.json',base)));
    await page.locator('#connect').waitFor({state:'visible'});await page.waitForFunction(()=>!document.getElementById('connect').disabled);
    await page.locator('#connect').click();await page.waitForFunction(()=>document.getElementById('account').textContent.startsWith('0x'));
  };
  await page.goto('http://127.0.0.1:8580');await load();
  if(['lock','burn'].includes(phase)) {
    await page.locator('#action').selectOption(phase);await page.locator('#amount').fill('25000000000000000000');await page.locator('#prepare-action').click();
  } else {
    const file=['mint','header-lock'].includes(phase)?'lock-package.json':'burn-package.json';
    await page.locator('#package').setInputFiles(fileURLToPath(new URL(file,base)));
    const button=phase.startsWith('header-')?'prepare-header':'prepare-claim';
    await page.waitForFunction(id=>!document.getElementById(id).disabled,button);await page.locator('#'+button).click();
  }
  await page.waitForFunction(()=>!document.getElementById('submit').disabled,{timeout:20000});
  const review=await page.locator('#review').innerText();
  if(!review.toLowerCase().includes(owner.toLowerCase())||!review.includes('25000000000000000000')) throw new Error('missing amount/recipient review');
  await page.locator('#submit').click();
  await page.waitForFunction(()=>document.getElementById('status').textContent.includes('지갑이 전송한 거래:'),{timeout:20000});
  if(sent.length!==1) throw new Error('expected one explicit wallet send');
  const pending=await page.evaluate(()=>JSON.parse(localStorage.getItem('worldland-bnb-local-pending-v1')));
  if(pending.transactionHash!==sent[0].hash) throw new Error('pending hash mismatch');
  await page.reload();await load();
  if(!await page.locator('#submit').isDisabled()) throw new Error('unresolved transaction allowed resubmit');
  await page.locator('#recover').click();await page.waitForFunction(()=>document.getElementById('status').textContent==='거래가 수락됐습니다.');
  if(await page.evaluate(()=>localStorage.getItem('worldland-bnb-local-pending-v1'))!==null) throw new Error('confirmed transaction not resolved');
  if(errors.length) throw new Error('browser error: '+errors.join('; '));
  const receipt=await rpc('eth_getTransactionReceipt',[sent[0].hash]);
  if(BigInt(receipt.status)!==1n) throw new Error('EVM transaction failed');
  fs.writeFileSync(new URL(phase+'-receipt.json',base),JSON.stringify(receipt,null,2)+'\n');
  await page.screenshot({path:fileURLToPath(new URL(phase+'-screen.png',base)),fullPage:true});
  Object.assign(report,{passed:true,review,methods,transactions:sent,reloadRecovered:true});
} catch(error) {report.error=error.message;throw error;}
finally {Object.assign(report,{methods,transactions:sent});fs.writeFileSync(new URL(phase+'-browser.json',base),JSON.stringify(report,null,2)+'\n');await browser.close();}
