#!/usr/bin/env python3
"""Explicit local development operator tool, separate from unsigned proof API."""
import argparse
import importlib.util
from pathlib import Path
import threading
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('dev_header_tool',ROOT/'scripts/proof-service.py')
api=importlib.util.module_from_spec(spec);spec.loader.exec_module(api)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--session',type=Path,required=True)
    choice=parser.add_mutually_exclusive_group(required=True)
    choice.add_argument('--job')
    choice.add_argument('--latest',action='store_true',help='use most recently requested ready local job')
    args=parser.parse_args()
    # Read without starting another worker in the server-owned durable directory.
    service=api.Service.__new__(api.Service)
    service.session=api.local.Session(args.session)
    service.manifest=api.manifest(service.session)
    service.confirmations=2
    service.directory=service.session.root/'proof-jobs'
    service.lock=threading.Lock()
    if service.manifest['mode']!='dev':
        raise ValueError('only explicit dev mode operator registration supported')
    if args.latest:
        jobs=[service.read(path) for path in service.directory.glob('*.json')]
        if not jobs:raise ValueError('no local proof requests')
        args.job=max(jobs,key=lambda j:j['createdAt'])['id']
    package=service.get(args.job,True)
    source,destination,_,_,updater,_=service.session.route(package['action'])
    covered=service.session.view(destination,updater,'isBlockCovered(uint256,uint256,bytes32)(bool)',
                                 str(package['sourceChainId']),str(package['blockNumber']),package['blockHash'])
    if covered=='true':
        print('header already registered; no transaction repeated');return
    tx=package.get('headerTransaction')
    if (not tx or tx['role']!='development-operator' or tx['action']!='registerHeader'
        or tx['chainId']!=service.manifest['chains'][destination]['id'] or tx['to'].lower()!=updater.lower()):
        raise ValueError('invalid development header transaction')
    block=service.session.rpc(source,'eth_getBlockByNumber',[hex(package['blockNumber']),False])
    if block['hash'].lower()!=package['blockHash'].lower() or block['receiptsRoot'].lower()!=package['receiptRoot'].lower():
        raise ValueError('source changed; request proof again')
    receipt=service.session.send(destination,service.session.data['operator'],updater,'registerHeader(uint256,bytes32,bytes32)',
                                 str(package['blockNumber']),package['blockHash'],package['receiptRoot'])
    api.local.write_json(service.session.root/(args.job+'-dev-header-receipt.json'),receipt)
    print('explicit local dev header accepted; request proof again to refresh destination coverage')
if __name__=='__main__':main()
