// Offline independent geth RLP/Keccak oracle for local Solidity diagnostics.
package main

import (
	"encoding/json"
	"fmt"
	"math"
	"math/big"
	"os"

	"example.com/worldland-bnb-bridge/proof-generator/internal/chain"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/core/types"
	"github.com/ethereum/go-ethereum/crypto"
	"github.com/ethereum/go-ethereum/rlp"
)

func header(number uint64, parent common.Hash) ([]byte, common.Hash, error) {
	h := &types.Header{ParentHash: parent, UncleHash: types.EmptyUncleHash,
		Root: common.HexToHash("0x01"), TxHash: types.EmptyTxsHash,
		ReceiptHash: types.EmptyReceiptsHash, Difficulty: big.NewInt(1),
		Number: new(big.Int).SetUint64(number), GasLimit: 30000000, Time: 1}
	raw, err := rlp.EncodeToBytes(h)
	return raw, crypto.Keccak256Hash(raw), err
}

func run() error {
	if len(os.Args) != 1 {
		return fmt.Errorf("this offline fixture generator takes no arguments")
	}
	rows := []map[string]any{}
	for _, number := range []uint64{0, 1, 126, 127, 128, 255, 256, 65535, 1<<32 - 1, 1<<63 - 1, math.MaxUint64 - 1} {
		source, sourceHash, err := header(number, common.Hash{})
		if err != nil {
			return err
		}
		target, targetHash, err := header(number+1, sourceHash)
		if err != nil {
			return err
		}
		vote := chain.BNBVoteData{SourceNumber: number, SourceHash: sourceHash, TargetNumber: number + 1, TargetHash: targetHash}
		rawVote, err := rlp.EncodeToBytes(vote)
		if err != nil {
			return err
		}
		rows = append(rows, map[string]any{"sourceNumber": fmt.Sprint(number), "targetNumber": fmt.Sprint(number + 1),
			"sourceRaw": "0x" + common.Bytes2Hex(source), "targetRaw": "0x" + common.Bytes2Hex(target),
			"sourceHash": sourceHash.Hex(), "targetHash": targetHash.Hex(), "voteDataHash": crypto.Keccak256Hash(rawVote).Hex()})
	}
	return json.NewEncoder(os.Stdout).Encode(map[string]any{"synthetic": true, "chainAuthenticated": false, "vectors": rows})
}

func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
