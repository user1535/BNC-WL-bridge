// Read-only source/proof/actual accepted head monitor for local RISC0 updaters.
package main

import (
	"context"
	"encoding/binary"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"os"
	"time"

	"example.com/worldland-bnb-bridge/proof-generator/internal/chain"
	"example.com/worldland-bnb-bridge/proof-generator/internal/header"
	"example.com/worldland-bnb-bridge/proof-generator/internal/risc0"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/common/hexutil"
)

type proofPackage struct {
	Source      uint64          `json:"sourceChainId"`
	End         uint64          `json:"endBlock"`
	EndHash     common.Hash     `json:"endHash"`
	Image       common.Hash     `json:"imageId"`
	Journal     string          `json:"journal"`
	ReceiptKind string          `json:"receiptKind"`
	Receipt     json.RawMessage `json:"proofReceipt"`
}

func main() {
	sourceURL := flag.String("source-rpc", "", "source local RPC")
	destinationURL := flag.String("destination-rpc", "", "destination local RPC")
	id := flag.Uint64("source-chain-id", 0, "31337 or 31338")
	contract := flag.String("header-source", "", "actual RISC0 updater address")
	proofFile := flag.String("proof-package", "", "optional receipt-bearing header package")
	host := flag.String("risc0-host", "", "matching compiled host, required with proof package")
	flag.Parse()
	if err := run(*sourceURL, *destinationURL, *id, *contract, *proofFile, *host); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}

func run(sourceURL, destinationURL string, id uint64, contract, proofFile, host string) error {
	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer cancel()
	var adapter chain.SourceChainAdapter
	var err error
	if id == 31337 {
		adapter, err = chain.NewLocalWorldLand(ctx, sourceURL, 0)
	} else if id == 31338 {
		adapter, err = chain.NewLocalBNB(ctx, sourceURL, 0)
	} else {
		return errors.New("monitor supports local chains only")
	}
	if err != nil {
		return err
	}
	defer adapter.Close()
	if !common.IsHexAddress(contract) || common.HexToAddress(contract) == (common.Address{}) {
		return errors.New("updater address required")
	}
	reader, err := header.NewEVMHeaderCoverageReader(ctx, destinationURL, common.HexToAddress(contract))
	if err != nil {
		return err
	}
	defer reader.Close()
	destinationID, err := reader.ChainID(ctx)
	if err != nil {
		return err
	}
	if !((id == 31337 && destinationID == 31338) || (id == 31338 && destinationID == 31337)) {
		return errors.New("wrong destination chain")
	}
	updaterID, err := reader.ViewUint(ctx, common.HexToAddress(contract), "sourceChainId()")
	if err != nil || !updaterID.IsUint64() || updaterID.Uint64() != id {
		return errors.New("updater source chain mismatch")
	}
	source, err := adapter.LatestHeader(ctx)
	if err != nil {
		return err
	}
	latest, err := reader.ViewUint(ctx, common.HexToAddress(contract), "latestBlock()")
	if err != nil || !latest.IsUint64() {
		return errors.New("updater head unavailable")
	}
	if latest.Uint64() > source.Number {
		return errors.New("updater head is ahead of observed source")
	}
	canonical, err := adapter.HeaderByNumber(ctx, latest.Uint64())
	if err != nil {
		return err
	}
	acceptedHash, err := reader.ViewHash(ctx, common.HexToAddress(contract), "latestHash()")
	if err != nil || canonical.BlockHash != acceptedHash {
		return errors.New("updater/source head conflict or reorganization")
	}
	covered, err := reader.IsBlockCovered(ctx, id, latest.Uint64(), acceptedHash)
	if err != nil {
		return err
	}
	result := map[string]any{"measuredAt": time.Now().UTC().Format(time.RFC3339Nano), "sourceChainId": id, "destinationChainId": destinationID,
		"sourceHead": source.Number, "updaterAnchorOrHead": latest.Uint64(), "acceptedHead": nil, "acceptedLag": nil, "proofHead": nil, "proofLag": nil,
		"chainAuthenticated": false, "performanceVerdict": "INCONCLUSIVE", "reason": "single observation does not establish sustained bounded lag"}
	if covered {
		root, err := reader.ReceiptRoot(ctx, id, latest.Uint64(), acceptedHash)
		if err != nil || root != canonical.ReceiptRoot {
			return errors.New("accepted receipt root mismatch")
		}
		result["acceptedHead"], result["acceptedLag"] = latest.Uint64(), source.Number-latest.Uint64()
	}
	if proofFile != "" {
		if host == "" {
			return errors.New("proof head requires cryptographic --risc0-host verification")
		}
		raw, err := os.ReadFile(proofFile)
		if err != nil {
			return err
		}
		var p proofPackage
		if err := json.Unmarshal(raw, &p); err != nil {
			return err
		}
		journal, err := hexutil.Decode(p.Journal)
		if err != nil || len(journal) != 224 {
			return errors.New("invalid proof head journal")
		}
		image, err := reader.ViewHash(ctx, common.HexToAddress(contract), "guestImageId()")
		if err != nil || image != p.Image {
			return errors.New("proof/updater image mismatch")
		}
		if p.Source != id || p.End > source.Number || binary.BigEndian.Uint64(journal[24:32]) != id || binary.BigEndian.Uint64(journal[88:96]) != p.End {
			return errors.New("proof head metadata mismatch")
		}
		if _, err := (risc0.LocalProver{HostPath: host, ReceiptKind: p.ReceiptKind}).VerifyReceipt(ctx, p.Receipt, journal, p.Image); err != nil {
			return err
		}
		canonical, err := adapter.HeaderByNumber(ctx, p.End)
		if err != nil || canonical.BlockHash != p.EndHash || common.BytesToHash(journal[128:160]) != p.EndHash {
			return errors.New("proof head conflicts with source")
		}
		result["proofHead"], result["proofLag"] = p.End, source.Number-p.End
	}
	return json.NewEncoder(os.Stdout).Encode(result)
}
