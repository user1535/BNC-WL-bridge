package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"strconv"
	"strings"
	"sync/atomic"
	"testing"
	"time"
)

func TestChangedIntermediateReceiptRootRejectsBatch(t *testing.T) {
	var middleReads atomic.Int32
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		var request struct {
			ID     json.RawMessage   `json:"id"`
			Method string            `json:"method"`
			Params []json.RawMessage `json:"params"`
		}
		if err := json.NewDecoder(r.Body).Decode(&request); err != nil {
			t.Error(err)
			return
		}
		var result any
		switch request.Method {
		case "eth_chainId":
			result = "0x7a69"
		case "eth_blockNumber":
			result = "0x3"
		case "eth_getBlockByNumber":
			var number string
			if err := json.Unmarshal(request.Params[0], &number); err != nil {
				t.Error(err)
				return
			}
			height, err := strconv.ParseUint(strings.TrimPrefix(number, "0x"), 16, 64)
			if err != nil || height > 3 {
				t.Errorf("unexpected height: %s", number)
				return
			}
			root := height + 10
			if height == 2 && middleReads.Add(1) > 1 {
				root = 999 // Same end hash, changed intermediate receipt root.
			}
			result = map[string]any{"number": number, "hash": fmt.Sprintf("0x%064x", height+1),
				"parentHash": fmt.Sprintf("0x%064x", height), "receiptsRoot": fmt.Sprintf("0x%064x", root)}
		default:
			t.Errorf("unexpected RPC: %s", request.Method)
			return
		}
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]any{"jsonrpc": "2.0", "id": request.ID, "result": result})
	}))
	defer server.Close()
	if err := run(server.URL, 31337, 1, 3, 0, "", "", time.Minute); err == nil || !strings.Contains(err.Error(), "source batch changed") {
		t.Fatalf("changed intermediate receipt root was not rejected: %v", err)
	}
}
