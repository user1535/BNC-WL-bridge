package main

import (
	"context"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"math"
	"os"
	"time"

	"example.com/worldland-bnb-bridge/proof-generator/internal/chain"
	"example.com/worldland-bnb-bridge/proof-generator/internal/header"
	"example.com/worldland-bnb-bridge/proof-generator/internal/risc0"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/common/hexutil"
)

type guestHeader struct {
	Number       uint64   `json:"number"`
	BlockHash    [32]byte `json:"block_hash"`
	ParentHash   [32]byte `json:"parent_hash"`
	ReceiptRoot  [32]byte `json:"receipt_root"`
	CanonicalRLP []uint16 `json:"canonical_rlp,omitempty"`
}

type guestInput struct {
	ChainID    uint64        `json:"chain_id"`
	AnchorHash [32]byte      `json:"anchor_hash"`
	Headers    []guestHeader `json:"headers"`
}

type output struct {
	Version             uint32          `json:"version"`
	Kind                string          `json:"kind"`
	SourceChainID       uint64          `json:"sourceChainId"`
	StartBlock          uint64          `json:"startBlock"`
	EndBlock            uint64          `json:"endBlock"`
	HeaderCount         int             `json:"headerCount"`
	AnchorHash          common.Hash     `json:"anchorHash"`
	EndHash             common.Hash     `json:"endHash"`
	BatchRoot           common.Hash     `json:"batchRoot"`
	Journal             string          `json:"journal"`
	BatchData           string          `json:"batchData"`
	GuestInput          guestInput      `json:"guestInput"`
	SealAvailable       bool            `json:"sealAvailable"`
	ChainAuthenticated  bool            `json:"chainAuthenticated"`
	ReceiptKind         string          `json:"receiptKind,omitempty"`
	ImageID             common.Hash     `json:"imageId"`
	ProofReceipt        json.RawMessage `json:"proofReceipt,omitempty"`
	ProofVerified       bool            `json:"proofVerified"`
	CacheHit            bool            `json:"cacheHit"`
	EVMCompatible       bool            `json:"evmCompatible"`
	Seal                string          `json:"seal,omitempty"`
	VerifierParameters  common.Hash     `json:"verifierParameters"`
	HeaderBinding       string          `json:"headerBinding"`
	HashBindingVerified bool            `json:"hashBindingVerified"`
}

var receiptKind = "composite"
var repairCache bool
var headerBinding = "minimal-link"

func main() {
	var rpcURL string
	var chainID, start, confirmations uint64
	var count int
	var hostPath, cacheDirectory string
	var proofTimeout time.Duration
	flag.StringVar(&rpcURL, "rpc", "", "source JSON-RPC URL")
	flag.Uint64Var(&chainID, "chain-id", 0, "required local source chain ID (31337 or 31338)")
	flag.Uint64Var(&start, "start", 0, "first source block (at least 1)")
	flag.IntVar(&count, "count", 0, "contiguous header count (1..128)")
	flag.Uint64Var(&confirmations, "confirmations", 0, "source confirmations")
	flag.StringVar(&hostPath, "risc0-host", "", "optional local Rust host for composite proof generation")
	flag.StringVar(&cacheDirectory, "proof-cache", "", "shared cache directory; required with --risc0-host")
	flag.DurationVar(&proofTimeout, "proof-timeout", 15*time.Minute, "timeout for proof generation, verification and batch-lock wait")
	flag.StringVar(&receiptKind, "receipt-kind", "composite", "composite (off-chain) or groth16 (EVM seal)")
	flag.BoolVar(&repairCache, "repair-cache", false, "explicitly quarantine rejected cached receipt before generating a replacement")
	flag.StringVar(&headerBinding, "header-binding", "minimal-link", "minimal-link or canonical-rlp (separate strict guest image)")
	flag.Parse()
	if err := run(rpcURL, chainID, start, count, confirmations, hostPath, cacheDirectory, proofTimeout); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}

func run(rpcURL string, chainID, start uint64, count int, confirmations uint64, hostPath, cacheDirectory string, proofTimeout time.Duration) error {
	if headerBinding != "minimal-link" && headerBinding != "canonical-rlp" {
		return errors.New("unsupported header binding")
	}
	if headerBinding == "canonical-rlp" && hostPath != "" && count > 1 {
		return errors.New("strict canonical RLP proving is limited to one header until memory measurement")
	}
	if rpcURL == "" || start == 0 || count < 1 || count > 128 || start > math.MaxUint64-uint64(count-1) {
		return errors.New("required: --rpc, --chain-id, --start >= 1, --count 1..128; range must fit uint64")
	}
	if (hostPath == "") != (cacheDirectory == "") || proofTimeout <= 0 {
		return errors.New("--risc0-host and --proof-cache must be provided together; --proof-timeout must be positive")
	}
	if receiptKind != "composite" && receiptKind != "groth16" {
		return errors.New("unsupported receipt kind")
	}
	if receiptKind == "groth16" && hostPath == "" {
		return errors.New("groth16 requires --risc0-host and --proof-cache")
	}
	if repairCache && hostPath == "" {
		return errors.New("--repair-cache requires a cryptographic prover")
	}
	if hostPath != "" && count > 4 {
		return errors.New("local composite proving is limited to 4 headers by the measured host memory budget")
	}
	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer cancel()
	var adapter chain.SourceChainAdapter
	var err error
	switch chainID {
	case 31337:
		adapter, err = chain.NewLocalWorldLand(ctx, rpcURL, confirmations)
	case 31338:
		adapter, err = chain.NewLocalBNB(ctx, rpcURL, confirmations)
	default:
		return errors.New("only local chain IDs 31337 and 31338 are supported")
	}
	if err != nil {
		return err
	}
	defer adapter.Close()
	end := start + uint64(count-1)
	safe, err := adapter.SafeHeader(ctx)
	if err != nil {
		return err
	}
	if safe.Number < end {
		return fmt.Errorf("requested end block %d exceeds safe source height %d", end, safe.Number)
	}
	anchor, err := adapter.HeaderByNumber(ctx, start-1)
	if err != nil {
		return err
	}
	headers := make([]header.GuestHeader, count)
	guestHeaders := make([]guestHeader, count)
	for i := 0; i < count; i++ {
		ref, err := adapter.HeaderByNumber(ctx, start+uint64(i))
		if err != nil {
			return err
		}
		headers[i] = header.GuestHeader{Number: ref.Number, BlockHash: ref.BlockHash,
			ParentHash: ref.ParentHash, ReceiptRoot: ref.ReceiptRoot}
		guestHeaders[i] = guestHeader{Number: ref.Number, BlockHash: [32]byte(ref.BlockHash),
			ParentHash: [32]byte(ref.ParentHash), ReceiptRoot: [32]byte(ref.ReceiptRoot)}
		if headerBinding == "canonical-rlp" {
			inspection, err := chain.InspectLocalHeader(ctx, rpcURL, chainID, ref.Number)
			if err != nil {
				return err
			}
			if !inspection.HashMatchesRPC || inspection.SuppliedHash != ref.BlockHash || inspection.ReceiptRoot != ref.ReceiptRoot {
				return errors.New("canonical header does not match source commitment")
			}
			raw, err := hexutil.Decode(inspection.HeaderRLP)
			if err != nil {
				return err
			}
			for _, value := range raw {
				guestHeaders[i].CanonicalRLP = append(guestHeaders[i].CanonicalRLP, uint16(value))
			}
		}
	}
	artifacts, err := header.BuildBatchArtifacts(chainID, anchor.BlockHash, headers)
	if err != nil {
		return err
	}
	result := output{Version: 1, Kind: "unsigned-header-data", SourceChainID: chainID,
		HeaderBinding: headerBinding,
		StartBlock:    start, EndBlock: end, HeaderCount: count, AnchorHash: anchor.BlockHash,
		EndHash: artifacts.EndHash, BatchRoot: artifacts.BatchRoot,
		Journal: hexutil.Encode(artifacts.Journal), BatchData: hexutil.Encode(artifacts.BatchData),
		GuestInput: guestInput{ChainID: chainID, AnchorHash: [32]byte(anchor.BlockHash), Headers: guestHeaders}}
	if hostPath != "" {
		input, err := json.Marshal(result.GuestInput)
		if err != nil {
			return err
		}
		proofCtx, proofCancel := context.WithTimeout(context.Background(), proofTimeout)
		defer proofCancel()
		binding := ""
		if headerBinding == "canonical-rlp" {
			binding = headerBinding
		}
		proof, err := (risc0.LocalProver{HostPath: hostPath, CacheDirectory: cacheDirectory, ReceiptKind: receiptKind, RepairCache: repairCache, HeaderBinding: binding}).GetOrGenerate(proofCtx, artifacts, input)
		if err != nil {
			return err
		}
		result.Kind, result.ReceiptKind = "local-"+receiptKind+"-header-proof", receiptKind
		result.ImageID, result.ProofReceipt = proof.ImageID, proof.Receipt
		result.ProofVerified, result.CacheHit = true, proof.CacheHit
		result.Seal, result.VerifierParameters = proof.Verified.Seal, proof.Verified.VerifierParameters
		result.EVMCompatible, result.SealAvailable = proof.Verified.EVMCompatible, proof.Verified.EVMCompatible
		result.HeaderBinding = proof.Verified.HeaderBinding
		result.HashBindingVerified = proof.Verified.HeaderBinding == "canonical-rlp"
	}
	// Recheck the entire batch after proving or cache verification with a fresh RPC deadline.
	// The guest does not recompute block hashes, so checking only endHash would miss
	// a changed intermediate receipt root. Later reorgs and dishonest RPCs remain possible.
	checkCtx, checkCancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer checkCancel()
	anchorAgain, err := adapter.HeaderByNumber(checkCtx, start-1)
	if err != nil {
		return err
	}
	for _, expected := range headers {
		again, err := adapter.HeaderByNumber(checkCtx, expected.Number)
		if err != nil {
			return err
		}
		if again.BlockHash != expected.BlockHash || again.ParentHash != expected.ParentHash || again.ReceiptRoot != expected.ReceiptRoot {
			return errors.New("source batch changed during data or proof generation")
		}
	}
	safeAgain, err := adapter.SafeHeader(checkCtx)
	if err != nil {
		return err
	}
	if anchorAgain.BlockHash != anchor.BlockHash || safeAgain.Number < end {
		return errors.New("source batch changed during data generation")
	}
	return json.NewEncoder(os.Stdout).Encode(result)
}
