// Offline recovery of an observed public Parlia ECDSA seal. No private key,
// network, signing, transaction generation or consensus state is used.
package main

import (
	"encoding/json"
	"example.com/worldland-bnb-bridge/proof-generator/internal/bnbseal"
	"flag"
	"fmt"
	"io"
	"os"
)

func run() error {
	input := flag.String("input", "", "saved native BNB header JSON")
	source := flag.Uint64("source-chain-id", 0, "explicit source chain56; not the local diagnostic EVM")
	flag.Parse()
	if *input == "" || flag.NArg() != 0 {
		return fmt.Errorf("offline input and explicit source chain required")
	}
	f, err := os.Open(*input)
	if err != nil {
		return err
	}
	defer f.Close()
	raw, err := io.ReadAll(io.LimitReader(f, 64*1024+1))
	if err != nil || len(raw) > 64*1024 {
		return fmt.Errorf("header read/size limit")
	}
	result, err := bnbseal.Inspect(raw, *source)
	if err != nil {
		return err
	}
	return json.NewEncoder(os.Stdout).Encode(result)
}
func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
