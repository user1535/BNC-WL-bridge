// Offline pinned config predicate oracle. Classifies supplied height/time, not
// an authenticated source fork, snapshot, validator set or finality state.
package main

import (
	"bytes"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"math"
	"math/big"
	"os"
	"path/filepath"
	"sort"

	"example.com/worldland-bnb-bridge/proof-generator/internal/chain"
	oracle "example.com/worldland-bnb-bridge/proof-generator/internal/protocoloracle/bnb"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/common/hexutil"
	"github.com/ethereum/go-ethereum/rlp"
)

const genesis = "0x0d21840abff46b96c84b2ac9e10e4f5cdaeb5693cb665db62a2f3b02d2d57b5b"

func flags(c *oracle.ChainConfig, number, time uint64) uint16 {
	n := new(big.Int).SetUint64(number)
	values := []bool{c.IsLondon(n), c.IsLuban(n), c.IsBohr(n, time), c.IsLorentz(n, time), c.IsMaxwell(n, time),
		c.IsFermi(n, time), c.IsOsaka(n, time), c.IsMendel(n, time), c.IsPasteur(n, time)}
	var result uint16
	for i, v := range values {
		if v {
			result |= 1 << i
		}
	}
	return result
}
func read(path string) ([]byte, error) {
	file, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer file.Close()
	raw, err := io.ReadAll(io.LimitReader(file, 64*1024+1))
	if err != nil || len(raw) > 64*1024 {
		return nil, fmt.Errorf("fixture limit")
	}
	return raw, nil
}
func run() error {
	directory := flag.String("fixture-dir", "", "offline native BNB captures")
	flag.Parse()
	if *directory == "" || flag.NArg() != 0 {
		return fmt.Errorf("offline captures required")
	}
	config := oracle.PinnedBSCForkConfig()
	actual := []map[string]any{}
	var parentRaw []byte
	var number, time uint64
	for _, label := range []string{"epoch", "source728", "target729", "parent", "latest"} {
		raw, err := read(filepath.Join(*directory, "bnb-"+label+".json"))
		if err != nil {
			return err
		}
		inspected, err := chain.InspectNativeHeaderJSON(raw, chain.BNBEncoding)
		if err != nil || !inspected.HashMatchesRPC {
			return fmt.Errorf("actual native hash fixture: %v", err)
		}
		var h struct {
			Timestamp hexutil.Uint64 `json:"timestamp"`
		}
		if err = json.Unmarshal(raw, &h); err != nil {
			return err
		}
		actual = append(actual, map[string]any{"name": label, "rawHeader": inspected.HeaderRLP,
			"headerHash": inspected.RecomputedHash, "number": inspected.BlockNumber, "timestamp": uint64(h.Timestamp),
			"expectedFlags": flags(config, inspected.BlockNumber, uint64(h.Timestamp))})
		if label == "parent" {
			parentRaw = common.FromHex(inspected.HeaderRLP)
			number = inspected.BlockNumber
			time = uint64(h.Timestamp)
		}
	}
	scalar := []map[string]any{}
	add := func(name string, n, t, id uint64, g string) {
		row := map[string]any{"name": name, "number": n, "timestamp": t, "sourceChainId": id, "genesis": g,
			"accepted": id == 56 && g == genesis, "synthetic": true}
		if row["accepted"].(bool) {
			row["expectedFlags"] = flags(config, n, t)
		}
		scalar = append(scalar, row)
	}
	luban, london := config.LubanBlock.Uint64(), config.LondonBlock.Uint64()
	for _, n := range []uint64{0, luban - 1, luban, luban + 1, london - 1, london, london + 1, math.MaxUint64} {
		for _, t := range []uint64{0, time, math.MaxUint64} {
			add(fmt.Sprintf("block-%d-time-%d", n, t), n, t, 56, genesis)
		}
	}
	times := map[uint64]bool{}
	for _, t := range []*uint64{config.BohrTime, config.LorentzTime, config.MaxwellTime, config.FermiTime, config.OsakaTime, config.MendelTime, config.PasteurTime} {
		times[*t-1] = true
		times[*t] = true
		times[*t+1] = true
	}
	for t := range times {
		add(fmt.Sprintf("timestamp-%d", t), number, t, 56, genesis)
	}
	for _, id := range []uint64{0, 57, 97, 31337} {
		add(fmt.Sprintf("unsupported-domain-%d", id), number, time, id, genesis)
	}
	add("zero-genesis", number, time, 56, (common.Hash{}).Hex())
	modified := common.HexToHash(genesis)
	modified[31] ^= 1
	add("wrong-genesis", number, time, 56, modified.Hex())
	sort.Slice(scalar, func(i, j int) bool { return scalar[i]["name"].(string) < scalar[j]["name"].(string) })
	var fields []rlp.RawValue
	if err := rlp.DecodeBytes(parentRaw, &fields); err != nil {
		return err
	}
	negatives := []map[string]any{}
	mutations := []struct {
		name  string
		value []byte
	}{
		{"timestamp-uint64-overflow", append([]byte{0x89, 1}, make([]byte, 8)...)},
		{"timestamp-leading-zero", []byte{0x82, 0, 1}},
		{"timestamp-zero-byte", []byte{0}},
		{"timestamp-nested", []byte{0xc1, 1}}}
	for _, m := range mutations {
		copyFields := append([]rlp.RawValue(nil), fields...)
		copyFields[11] = m.value
		encoded, err := rlp.EncodeToBytes(copyFields)
		if err != nil {
			return err
		}
		negatives = append(negatives, map[string]any{"name": m.name, "rawHeader": hexutil.Encode(encoded)})
	}
	negatives = append(negatives, map[string]any{"name": "trailing-raw", "rawHeader": hexutil.Encode(append(bytes.Clone(parentRaw), 0))},
		map[string]any{"name": "truncated-raw", "rawHeader": hexutil.Encode(parentRaw[:len(parentRaw)-1])})
	return json.NewEncoder(os.Stdout).Encode(map[string]any{"scalarVectors": scalar, "actualRawVectors": actual, "rawNegativeVectors": negatives,
		"sourceChainId": 56, "pinnedGenesis": genesis, "configSourceSHA256": "2b8a681c79dd05555ec7186bd1a69da47add698f6782da2e514c805cefb4be4d",
		"flagOrder":              []string{"London", "Luban", "Bohr", "Lorentz", "Maxwell", "Fermi", "Osaka", "Mendel", "Pasteur"},
		"forkPredicatesCompared": true, "forkPolicyAuthenticated": false, "snapshotAuthenticated": false,
		"nativeForkPolicyValidated": false, "chainAuthenticated": false, "realAssetDeploymentAllowed": false})
}
func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
