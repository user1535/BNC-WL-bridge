// Offline only: this command does not authenticate validator keys or finality.
package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"os"

	"example.com/worldland-bnb-bridge/proof-generator/internal/chain"
)

func run() error {
	input := flag.String("input", "", "saved public native BNB header JSON")
	layout := flag.String("layout", "", "required assumption: post-luban-non-epoch")
	flag.Parse()
	if *input == "" || flag.NArg() != 0 {
		return fmt.Errorf("--input and explicit --layout required")
	}
	f, err := os.Open(*input)
	if err != nil {
		return err
	}
	defer f.Close()
	raw, err := io.ReadAll(io.LimitReader(f, 64*1024+1))
	if err != nil || len(raw) > 64*1024 {
		return fmt.Errorf("header input read/size limit")
	}
	result, err := chain.InspectBNBNonEpochAttestation(raw, *layout)
	if err != nil {
		return err
	}
	return json.NewEncoder(os.Stdout).Encode(result)
}
func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
