package main

import (
	"encoding/json"
	"example.com/worldland-bnb-bridge/proof-generator/internal/benchmark"
	"fmt"
	"os"
)

func main() {
	var input struct {
		Samples []benchmark.AcceptedObservation `json:"samples"`
		MaxLag  uint64                          `json:"maxLag"`
	}
	if err := json.NewDecoder(os.Stdin).Decode(&input); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	v, err := benchmark.EvaluateAcceptedSeries(input.Samples, input.MaxLag)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	if err := json.NewEncoder(os.Stdout).Encode(v); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
