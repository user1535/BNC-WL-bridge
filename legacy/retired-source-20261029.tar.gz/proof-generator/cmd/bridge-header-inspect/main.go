// Read-only local header serialization diagnostic; no proof/signing/deployment.
package main

import (
	"context"
	"encoding/json"
	"flag"
	"fmt"
	"os"
	"time"

	"example.com/worldland-bnb-bridge/proof-generator/internal/chain"
)

func main() {
	url := flag.String("rpc", "", "local RPC URL")
	id := flag.Uint64("chain-id", 0, "31337 or 31338")
	number := flag.Uint64("block", 0, "header number to inspect")
	input := flag.String("input", "", "offline native header JSON file; never calls RPC")
	profile := flag.String("encoding-profile", "", "offline: worldland-v1.1.3 or bnb-v1.7.8")
	flag.Parse()
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()
	var result *chain.HeaderInspection
	var err error
	if *input != "" {
		if *url != "" || *id != 0 || *number != 0 {
			fmt.Fprintln(os.Stderr, "offline input cannot be combined with RPC/chain/block")
			os.Exit(1)
		}
		var raw []byte
		raw, err = os.ReadFile(*input)
		if err == nil {
			result, err = chain.InspectNativeHeaderJSON(raw, *profile)
		}
	} else if *profile != "" {
		fmt.Fprintln(os.Stderr, "native encoding profiles require an offline input file")
		os.Exit(1)
	} else {
		result, err = chain.InspectLocalHeader(ctx, *url, *id, *number)
	}
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	if !result.HashMatchesRPC {
		fmt.Fprintln(os.Stderr, "canonical header encoding does not match RPC hash")
		os.Exit(1)
	}
	if err := json.NewEncoder(os.Stdout).Encode(result); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
