package main

import (
	"encoding/json"
	"testing"

	"example.com/worldland-bnb-bridge/proof-generator/internal/chain"
	"example.com/worldland-bnb-bridge/proof-generator/internal/header"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/common/hexutil"
)

func TestModeSelectionDoesNotSilentlyFallback(t *testing.T) {
	for _, options := range []modeOptions{{Mode: "checkpoint"}, {Mode: "risc0_batch"}, {Mode: "dev", Host: "fake-host"}, {Mode: "risc0_composite", Host: "host", Receiver: "0x0000000000000000000000000000000000000000"}} {
		if options.validate() == nil {
			t.Fatalf("invalid configuration accepted: %+v", options)
		}
	}
	if err := (modeOptions{Mode: "dev"}).validate(); err != nil {
		t.Fatal(err)
	}
	if err := (modeOptions{Mode: "risc0_batch", Host: "host", Receiver: "0x0000000000000000000000000000000000000001"}).validate(); err != nil {
		t.Fatal(err)
	}
}

func TestHeaderPackageBindsActualEventAndBatchData(t *testing.T) {
	anchor := common.HexToHash("0x01")
	h := header.GuestHeader{Number: 10, BlockHash: common.HexToHash("0x02"), ParentHash: anchor, ReceiptRoot: common.HexToHash("0x03")}
	artifacts, err := header.BuildBatchArtifacts(31337, anchor, []header.GuestHeader{h})
	if err != nil {
		t.Fatal(err)
	}
	raw, err := json.Marshal(map[string]any{"sourceChainId": 31337, "startBlock": 10, "endBlock": 10,
		"anchorHash": anchor, "endHash": h.BlockHash, "batchRoot": artifacts.BatchRoot,
		"journal": hexutil.Encode(artifacts.Journal), "batchData": hexutil.Encode(artifacts.BatchData),
		"guestInput": map[string]any{"chain_id": 31337, "anchor_hash": [32]byte(anchor), "headers": []map[string]any{
			{"number": 10, "block_hash": [32]byte(h.BlockHash), "parent_hash": [32]byte(anchor), "receipt_root": [32]byte(h.ReceiptRoot)}}}})
	if err != nil {
		t.Fatal(err)
	}
	var pkg headerPackage
	if err := json.Unmarshal(raw, &pkg); err != nil {
		t.Fatal(err)
	}
	target := &chain.Header{Number: 10, BlockHash: h.BlockHash, ParentHash: anchor, ReceiptRoot: h.ReceiptRoot}
	if _, _, err := validateHeaderPackage(&pkg, 31337, target); err != nil {
		t.Fatal(err)
	}
	other := *target
	other.ReceiptRoot = common.HexToHash("0x04")
	if _, _, err := validateHeaderPackage(&pkg, 31337, &other); err == nil {
		t.Fatal("another root accepted")
	}
	if _, _, err := validateHeaderPackage(&pkg, 31338, target); err == nil {
		t.Fatal("another chain accepted")
	}
	pkg.BatchData = hexutil.Encode(append(artifacts.BatchData, 0))
	if _, _, err := validateHeaderPackage(&pkg, 31337, target); err == nil {
		t.Fatal("non-matching ABI data accepted")
	}
}
