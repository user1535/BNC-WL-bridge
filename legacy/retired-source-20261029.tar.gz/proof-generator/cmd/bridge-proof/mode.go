package main

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"math"
	"math/big"
	"os"
	"strings"
	"time"

	"example.com/worldland-bnb-bridge/proof-generator/internal/chain"
	"example.com/worldland-bnb-bridge/proof-generator/internal/header"
	"example.com/worldland-bnb-bridge/proof-generator/internal/risc0"
	"github.com/ethereum/go-ethereum/accounts/abi"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/common/hexutil"
	"github.com/ethereum/go-ethereum/crypto"
)

type modeOptions struct {
	Mode, Host, HeaderPackagePath, Receiver string
}

func (o modeOptions) validate() error {
	if o.Mode != "dev" && o.Mode != "risc0_composite" && o.Mode != "risc0_batch" {
		return errors.New("--header-mode must be dev, risc0_composite or risc0_batch; checkpoint is not implemented")
	}
	if o.Mode == "dev" && (o.Host != "" || o.HeaderPackagePath != "") {
		return errors.New("dev mode does not accept RISC0 host or proof package")
	}
	if o.Mode != "dev" && (o.Host == "" || !common.IsHexAddress(o.Receiver) || common.HexToAddress(o.Receiver) == (common.Address{})) {
		return errors.New("RISC0 modes require --risc0-host and --receiver")
	}
	if o.Receiver != "" && (!common.IsHexAddress(o.Receiver) || common.HexToAddress(o.Receiver) == (common.Address{})) {
		return errors.New("invalid receiver address")
	}
	return nil
}

type userTransaction struct {
	Role    string         `json:"role"`
	Action  string         `json:"action"`
	ChainID uint64         `json:"chainId"`
	To      common.Address `json:"to"`
	Data    string         `json:"data"`
	Value   string         `json:"value"`
}

// This mirrors the standalone header-data CLI. Treat every public flag as untrusted.
type headerPackage struct {
	SourceChainID       uint64          `json:"sourceChainId"`
	StartBlock          uint64          `json:"startBlock"`
	EndBlock            uint64          `json:"endBlock"`
	AnchorHash          common.Hash     `json:"anchorHash"`
	EndHash             common.Hash     `json:"endHash"`
	BatchRoot           common.Hash     `json:"batchRoot"`
	Journal             string          `json:"journal"`
	BatchData           string          `json:"batchData"`
	ImageID             common.Hash     `json:"imageId"`
	ReceiptKind         string          `json:"receiptKind"`
	ProofReceipt        json.RawMessage `json:"proofReceipt"`
	ProofVerified       bool            `json:"proofVerified"`
	SealAvailable       bool            `json:"sealAvailable"`
	EVMCompatible       bool            `json:"evmCompatible"`
	ChainAuthenticated  bool            `json:"chainAuthenticated"`
	Seal                string          `json:"seal,omitempty"`
	VerifierParameters  common.Hash     `json:"verifierParameters"`
	HeaderBinding       string          `json:"headerBinding,omitempty"`
	HashBindingVerified bool            `json:"hashBindingVerified"`
	GuestInput          struct {
		ChainID    uint64   `json:"chain_id"`
		AnchorHash [32]byte `json:"anchor_hash"`
		Headers    []struct {
			Number       uint64   `json:"number"`
			BlockHash    [32]byte `json:"block_hash"`
			ParentHash   [32]byte `json:"parent_hash"`
			ReceiptRoot  [32]byte `json:"receipt_root"`
			CanonicalRLP []uint16 `json:"canonical_rlp,omitempty"`
		} `json:"headers"`
	} `json:"guestInput"`
}

func validateHeaderPackage(p *headerPackage, source uint64, target *chain.Header) (*header.BatchArtifacts, []header.GuestHeader, error) {
	headers := make([]header.GuestHeader, len(p.GuestInput.Headers))
	found := false
	for i, h := range p.GuestInput.Headers {
		headers[i] = header.GuestHeader{Number: h.Number, BlockHash: common.Hash(h.BlockHash), ParentHash: common.Hash(h.ParentHash), ReceiptRoot: common.Hash(h.ReceiptRoot)}
		if h.Number == target.Number && headers[i].BlockHash == target.BlockHash && headers[i].ReceiptRoot == target.ReceiptRoot {
			found = true
		}
	}
	artifacts, err := header.BuildBatchArtifacts(source, common.Hash(p.GuestInput.AnchorHash), headers)
	if err != nil {
		return nil, nil, err
	}
	journal, err := hexutil.Decode(p.Journal)
	if err != nil {
		return nil, nil, err
	}
	batchData, err := hexutil.Decode(p.BatchData)
	if err != nil {
		return nil, nil, err
	}
	if artifacts.Start == 0 || !found || p.GuestInput.ChainID != source || p.SourceChainID != source || p.StartBlock != artifacts.Start ||
		p.EndBlock != artifacts.End || p.AnchorHash != artifacts.AnchorHash || p.EndHash != artifacts.EndHash || p.BatchRoot != artifacts.BatchRoot ||
		!bytes.Equal(journal, artifacts.Journal) || !bytes.Equal(batchData, artifacts.BatchData) {
		return nil, nil, errors.New("header package does not match the event block, source chain or batch")
	}
	return artifacts, headers, nil
}

func prepareHeaderStep(o modeOptions, adapter chain.SourceChainAdapter, reader *header.EVMHeaderCoverageReader,
	source, destination uint64, action string, sourceToken, destinationToken common.Address, target *chain.Header, covered bool, headerAddress common.Address) (*headerPackage, *userTransaction, error) {
	if reader == nil {
		return nil, nil, nil
	}
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Minute)
	defer cancel()
	if o.Receiver != "" {
		bound, err := reader.ViewAddress(ctx, common.HexToAddress(o.Receiver), "headerSource()")
		if err != nil || bound != headerAddress {
			return nil, nil, fmt.Errorf("receiver header source binding mismatch: %v", err)
		}
		id, err := reader.ViewUint(ctx, common.HexToAddress(o.Receiver), "sourceChainId()")
		if err != nil || !id.IsUint64() || id.Uint64() != source {
			return nil, nil, errors.New("receiver source chain binding mismatch")
		}
		sourceView, destinationView := "sourceToken()", "wrappedToken()"
		if action == "burn" {
			sourceView, destinationView = "sourceWrappedToken()", "originalToken()"
		}
		for signature, expected := range map[string]common.Address{sourceView: sourceToken, destinationView: destinationToken} {
			bound, err := reader.ViewAddress(ctx, common.HexToAddress(o.Receiver), signature)
			if err != nil || bound != expected {
				return nil, nil, fmt.Errorf("receiver token binding mismatch for %s", signature)
			}
		}
	}
	var expectedImage common.Hash
	if o.Mode == "risc0_batch" {
		id, err := reader.ViewUint(ctx, headerAddress, "sourceChainId()")
		if err != nil || !id.IsUint64() || id.Uint64() != source {
			return nil, nil, errors.New("RISC0 updater source chain mismatch")
		}
		expectedImage, err = reader.ViewHash(ctx, headerAddress, "guestImageId()")
		if err != nil || expectedImage == (common.Hash{}) {
			return nil, nil, errors.New("RISC0 updater guest image unavailable")
		}
	}
	if covered {
		return nil, nil, nil
	}
	if o.Mode == "dev" {
		data, err := packHeaderCall("registerHeader", new(big.Int).SetUint64(target.Number), target.BlockHash, target.ReceiptRoot)
		if err != nil {
			return nil, nil, err
		}
		return nil, &userTransaction{Role: "development-operator", Action: "registerHeader", ChainID: destination, To: headerAddress, Data: hexutil.Encode(data), Value: "0"}, nil
	}
	if o.HeaderPackagePath == "" {
		return nil, nil, errors.New("uncovered RISC0 event requires --header-package generated by bridge-header-data")
	}
	raw, err := os.ReadFile(o.HeaderPackagePath)
	if err != nil {
		return nil, nil, err
	}
	var pkg headerPackage
	if err := json.Unmarshal(raw, &pkg); err != nil {
		return nil, nil, err
	}
	artifacts, headers, err := validateHeaderPackage(&pkg, source, target)
	if err != nil {
		return nil, nil, err
	}
	kind := "composite"
	if o.Mode == "risc0_batch" {
		kind = "groth16"
	}
	if kind == "groth16" && pkg.ImageID != expectedImage {
		return nil, nil, errors.New("header proof image ID differs from destination updater")
	}
	prover := risc0.LocalProver{HostPath: o.Host, ReceiptKind: kind, HeaderBinding: pkg.HeaderBinding}
	verified, err := prover.VerifyReceipt(ctx, pkg.ProofReceipt, artifacts.Journal, pkg.ImageID)
	if err != nil {
		return nil, nil, err
	}
	pkg.HeaderBinding = verified.HeaderBinding
	pkg.HashBindingVerified = verified.HeaderBinding == "canonical-rlp"
	if pkg.HashBindingVerified {
		for _, h := range pkg.GuestInput.Headers {
			raw := make([]byte, len(h.CanonicalRLP))
			for i, n := range h.CanonicalRLP {
				if n > 255 {
					return nil, nil, errors.New("invalid canonical witness byte")
				}
				raw[i] = byte(n)
			}
			if len(raw) == 0 || crypto.Keccak256Hash(raw) != common.Hash(h.BlockHash) {
				return nil, nil, errors.New("canonical witness does not match proved block hash")
			}
		}
	}
	// Check every supplied header again after cryptographic verification.
	anchorHeader, err := adapter.HeaderByNumber(ctx, artifacts.Start-1)
	if err != nil || anchorHeader.BlockHash != artifacts.AnchorHash {
		return nil, nil, errors.New("source header package anchor changed after proof generation")
	}
	for _, expected := range headers {
		again, err := adapter.HeaderByNumber(ctx, expected.Number)
		if err != nil {
			return nil, nil, err
		}
		if again.BlockHash != expected.BlockHash || again.ParentHash != expected.ParentHash || again.ReceiptRoot != expected.ReceiptRoot {
			return nil, nil, errors.New("source header package changed after proof generation")
		}
	}
	safe, err := adapter.SafeHeader(ctx)
	if err != nil || safe.Number < artifacts.End {
		return nil, nil, errors.New("header proof batch extends beyond source safe height")
	}
	pkg.ReceiptKind, pkg.Seal = verified.ReceiptKind, verified.Seal
	pkg.VerifierParameters = verified.VerifierParameters
	pkg.ProofVerified, pkg.EVMCompatible, pkg.SealAvailable, pkg.ChainAuthenticated = true, verified.EVMCompatible, verified.EVMCompatible, false
	if kind == "composite" {
		data, err := packHeaderCall("registerHeader", new(big.Int).SetUint64(target.Number), target.BlockHash, target.ReceiptRoot)
		if err != nil {
			return nil, nil, err
		}
		return &pkg, &userTransaction{Role: "development-operator", Action: "registerHeader", ChainID: destination, To: headerAddress, Data: hexutil.Encode(data), Value: "0"}, nil
	}
	latest, err := reader.ViewUint(ctx, headerAddress, "latestBlock()")
	if err != nil || !latest.IsUint64() || latest.Uint64() == math.MaxUint64 || latest.Uint64()+1 != artifacts.Start {
		return nil, nil, errors.New("RISC0 batch does not extend destination updater head")
	}
	anchor, err := reader.ViewHash(ctx, headerAddress, "latestHash()")
	if err != nil || anchor != artifacts.AnchorHash {
		return nil, nil, errors.New("RISC0 batch anchor differs from destination updater")
	}
	seal, _ := hexutil.Decode(verified.Seal)
	data, err := packHeaderCall("submitHeaderProof", seal, artifacts.Journal, artifacts.BatchData)
	if err != nil {
		return nil, nil, err
	}
	return &pkg, &userTransaction{Role: "user", Action: "submitHeaderProof", ChainID: destination, To: headerAddress, Data: hexutil.Encode(data), Value: "0"}, nil
}

func packHeaderCall(method string, args ...interface{}) ([]byte, error) {
	const spec = `[{"type":"function","name":"registerHeader","inputs":[{"type":"uint256"},{"type":"bytes32"},{"type":"bytes32"}]},{"type":"function","name":"submitHeaderProof","inputs":[{"type":"bytes"},{"type":"bytes"},{"type":"bytes"}]}]`
	parsed, err := abi.JSON(strings.NewReader(spec))
	if err != nil {
		return nil, err
	}
	return parsed.Pack(method, args...)
}
