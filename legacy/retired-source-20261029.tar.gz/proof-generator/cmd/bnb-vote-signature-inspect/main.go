// Offline mathematical pairing diagnostic; never authenticates a validator set.
package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"os"

	"example.com/worldland-bnb-bridge/proof-generator/internal/bnbvote"
)

func readHeader(path string) ([]byte, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	bytes, err := io.ReadAll(io.LimitReader(f, 64*1024+1))
	if err != nil || len(bytes) > 64*1024 {
		return nil, fmt.Errorf("header read/size limit")
	}
	return bytes, nil
}
func run() error {
	input := flag.String("input", "", "saved native non-epoch header JSON")
	epoch := flag.String("epoch-input", "", "saved native epoch header JSON; unauthenticated")
	layout := flag.String("layout", "", "explicit post-luban-non-epoch assumption")
	epochLayout := flag.String("epoch-layout", "", "explicit post-bohr-epoch assumption")
	length := flag.Uint64("epoch-length", 0, "explicit epoch length assumption 200/500/1000")
	source := flag.String("source-input", "", "optional signed source full header; requires target-input")
	target := flag.String("target-input", "", "optional signed target full header; requires source-input")
	evm := flag.Bool("evm-witness", false, "export supplied-key EIP-2537 diagnostic witness; not chain authentication")
	flag.Parse()
	if *input == "" || *epoch == "" || flag.NArg() != 0 {
		return fmt.Errorf("header, epoch and explicit layout/length assumptions required")
	}
	if (*source == "") != (*target == "") {
		return fmt.Errorf("source-input and target-input required together")
	}
	h, err := readHeader(*input)
	if err != nil {
		return err
	}
	e, err := readHeader(*epoch)
	if err != nil {
		return err
	}
	var result *bnbvote.BNBVoteSignatureInspection
	if *source != "" {
		s, readErr := readHeader(*source)
		if readErr != nil {
			return readErr
		}
		t, readErr := readHeader(*target)
		if readErr != nil {
			return readErr
		}
		result, err = bnbvote.InspectBNBSignedHeaderWitness(h, e, s, t, *layout, *epochLayout, *length)
	} else {
		result, err = bnbvote.InspectBNBVoteSignature(h, e, *layout, *epochLayout, *length)
	}
	if err != nil {
		return err
	}
	if *evm {
		witness, err := bnbvote.BuildBNBEVMVoteWitness(result)
		if err != nil {
			return err
		}
		return json.NewEncoder(os.Stdout).Encode(struct {
			Inspection *bnbvote.BNBVoteSignatureInspection `json:"inspection"`
			EVMWitness *bnbvote.BNBEVMVoteWitness          `json:"evmWitness"`
		}{result, witness})
	}
	return json.NewEncoder(os.Stdout).Encode(result)
}
func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
