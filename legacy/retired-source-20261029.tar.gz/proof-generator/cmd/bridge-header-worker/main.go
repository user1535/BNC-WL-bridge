// Keyless local pipeline: source -> age/size planner -> real proof/cache -> unsigned proposal.
package main

import (
	"context"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"os"
	"os/signal"
	"path/filepath"
	"strings"
	"syscall"
	"time"

	"example.com/worldland-bnb-bridge/proof-generator/internal/batch"
	"example.com/worldland-bnb-bridge/proof-generator/internal/chain"
	"example.com/worldland-bnb-bridge/proof-generator/internal/header"
	"example.com/worldland-bnb-bridge/proof-generator/internal/risc0"
	"github.com/ethereum/go-ethereum/accounts/abi"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/common/hexutil"
)

type options struct {
	source, destination, contract, host, cache, output string
	id                                                 uint64
	size                                               int
	age, timeout                                       time.Duration
	watch                                              bool
	binding                                            string
}
type transaction struct {
	Role  string         `json:"role"`
	Chain uint64         `json:"chainId"`
	To    common.Address `json:"to"`
	Data  string         `json:"data"`
	Value string         `json:"value"`
}
type guestHeader struct {
	Number       uint64   `json:"number"`
	Hash         [32]byte `json:"block_hash"`
	Parent       [32]byte `json:"parent_hash"`
	Root         [32]byte `json:"receipt_root"`
	CanonicalRLP []uint16 `json:"canonical_rlp,omitempty"`
}
type guestInput struct {
	Chain   uint64        `json:"chain_id"`
	Anchor  [32]byte      `json:"anchor_hash"`
	Headers []guestHeader `json:"headers"`
}

func main() {
	o := options{}
	flag.StringVar(&o.source, "source-rpc", "", "local source RPC")
	flag.StringVar(&o.destination, "destination-rpc", "", "local destination RPC")
	flag.StringVar(&o.contract, "header-source", "", "RISC0 updater address")
	flag.StringVar(&o.host, "risc0-host", "", "compiled real receipt host")
	flag.StringVar(&o.cache, "proof-cache", "", "shared proof cache")
	flag.StringVar(&o.output, "output-dir", "", "public unsigned proposal directory")
	flag.Uint64Var(&o.id, "source-chain-id", 0, "31337 or 31338")
	flag.IntVar(&o.size, "max-batch", 4, "measured CPU limit 1..4")
	flag.DurationVar(&o.age, "max-age", 10*time.Second, "age trigger for a partially full batch")
	flag.DurationVar(&o.timeout, "proof-timeout", 45*time.Minute, "proof/cache wait timeout")
	flag.BoolVar(&o.watch, "watch", false, "continue sampling; default flushes one oldest batch")
	flag.StringVar(&o.binding, "header-binding", "minimal-link", "minimal-link or separate canonical-rlp image")
	flag.Parse()
	ctx, cancel := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer cancel()
	if err := run(ctx, o); err != nil && !errors.Is(err, context.Canceled) {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}

func run(ctx context.Context, o options) error {
	if o.binding != "minimal-link" && o.binding != "canonical-rlp" {
		return errors.New("unsupported header binding")
	}
	if o.binding == "canonical-rlp" && o.size > 1 {
		return errors.New("canonical-rlp worker requires --max-batch 1 until larger memory budget is measured")
	}
	if o.size < 1 || o.size > 4 || o.age <= 0 || o.timeout <= 0 || o.host == "" || o.cache == "" || o.output == "" || !common.IsHexAddress(o.contract) {
		return errors.New("local worker requires host/cache/output/updater; batch1..4 and positive timeouts")
	}
	var adapter chain.SourceChainAdapter
	var err error
	if o.id == 31337 {
		adapter, err = chain.NewLocalWorldLand(ctx, o.source, 0)
	} else if o.id == 31338 {
		adapter, err = chain.NewLocalBNB(ctx, o.source, 0)
	} else {
		return errors.New("worker accepts local chain IDs only")
	}
	if err != nil {
		return err
	}
	defer adapter.Close()
	address := common.HexToAddress(o.contract)
	reader, err := header.NewEVMHeaderCoverageReader(ctx, o.destination, address)
	if err != nil {
		return err
	}
	defer reader.Close()
	dest, err := reader.ChainID(ctx)
	if err != nil {
		return err
	}
	if !((o.id == 31337 && dest == 31338) || (o.id == 31338 && dest == 31337)) {
		return errors.New("destination chain mismatch")
	}
	id, err := reader.ViewUint(ctx, address, "sourceChainId()")
	if err != nil || !id.IsUint64() || id.Uint64() != o.id {
		return errors.New("updater source chain mismatch")
	}
	image, err := reader.ViewHash(ctx, address, "guestImageId()")
	if err != nil || image == (common.Hash{}) {
		return errors.New("updater image unavailable")
	}
	store, err := header.NewStore(reader)
	if err != nil {
		return err
	}
	var firstSeen time.Time
	var seenHead uint64
	var seenHash common.Hash
	var lastProposedRoot common.Hash
	for iteration := 0; ; iteration++ {
		if o.watch && iteration > 0 {
			select {
			case <-ctx.Done():
				return ctx.Err()
			case <-time.After(time.Second):
			}
		}
		if ctx.Err() != nil {
			return ctx.Err()
		}
		head, err := reader.ViewUint(ctx, address, "latestBlock()")
		if err != nil || !head.IsUint64() {
			return errors.New("updater head unavailable")
		}
		anchor, err := reader.ViewHash(ctx, address, "latestHash()")
		if err != nil {
			return err
		}
		sourceAnchor, err := adapter.HeaderByNumber(ctx, head.Uint64())
		if err != nil || sourceAnchor.BlockHash != anchor {
			return errors.New("updater anchor conflicts with source")
		}
		safe, err := adapter.SafeHeader(ctx)
		if err != nil {
			return err
		}
		if head.Uint64() > safe.Number {
			return errors.New("updater head is ahead of safe source")
		}
		if safe.Number == head.Uint64() {
			firstSeen = time.Time{}
		}
		if safe.Number > head.Uint64() && (firstSeen.IsZero() || seenHead != head.Uint64() || seenHash != anchor) {
			firstSeen = time.Now()
			seenHead = head.Uint64()
			seenHash = anchor
		}
		if safe.Number > head.Uint64() {
			count := safe.Number - head.Uint64()
			if count > uint64(o.size) {
				count = uint64(o.size)
			}
			pending := make([]batch.Header, count)
			refs := make([]header.GuestHeader, count)
			rust := guestInput{Chain: o.id, Anchor: [32]byte(anchor)}
			for i := range pending {
				h, err := adapter.HeaderByNumber(ctx, head.Uint64()+uint64(i)+1)
				if err != nil {
					return err
				}
				observed := firstSeen
				if !o.watch {
					observed = time.Now().Add(-o.age)
				}
				pending[i] = batch.Header{Number: h.Number, BlockHash: [32]byte(h.BlockHash), ParentHash: [32]byte(h.ParentHash), FirstSeen: observed}
				refs[i] = header.GuestHeader{Number: h.Number, BlockHash: h.BlockHash, ParentHash: h.ParentHash, ReceiptRoot: h.ReceiptRoot}
				inputHeader := guestHeader{Number: h.Number, Hash: [32]byte(h.BlockHash), Parent: [32]byte(h.ParentHash), Root: [32]byte(h.ReceiptRoot)}
				if o.binding == "canonical-rlp" {
					inspected, err := chain.InspectLocalHeader(ctx, o.source, o.id, h.Number)
					if err != nil {
						return err
					}
					if !inspected.HashMatchesRPC || inspected.SuppliedHash != h.BlockHash || inspected.ReceiptRoot != h.ReceiptRoot {
						return errors.New("canonical source commitment mismatch")
					}
					raw, err := hexutil.Decode(inspected.HeaderRLP)
					if err != nil {
						return err
					}
					for _, value := range raw {
						inputHeader.CanonicalRLP = append(inputHeader.CanonicalRLP, uint16(value))
					}
				}
				rust.Headers = append(rust.Headers, inputHeader)
			}
			planned, err := batch.PlanBatch(pending, batch.ChainBatchConfig{MaxBatchSize: o.size, MaxBatchAge: o.age}, time.Now())
			if err != nil {
				return err
			}
			if len(planned) > 0 {
				artifacts, err := header.BuildBatchArtifacts(o.id, anchor, refs)
				if err != nil {
					return err
				}
				if o.watch && artifacts.BatchRoot == lastProposedRoot {
					continue
				}
				input, err := json.Marshal(rust)
				if err != nil {
					return err
				}
				proofCtx, cancel := context.WithTimeout(ctx, o.timeout)
				requiredBinding := ""
				if o.binding == "canonical-rlp" {
					requiredBinding = o.binding
				}
				proof, err := (risc0.LocalProver{HostPath: o.host, CacheDirectory: o.cache, ReceiptKind: "groth16", HeaderBinding: requiredBinding}).GetOrGenerate(proofCtx, artifacts, input)
				cancel()
				if err != nil {
					return err
				}
				if proof.ImageID != image {
					return errors.New("compiled guest differs from updater")
				}
				for _, ref := range refs {
					again, err := adapter.HeaderByNumber(ctx, ref.Number)
					if err != nil || again.BlockHash != ref.BlockHash || again.ParentHash != ref.ParentHash || again.ReceiptRoot != ref.ReceiptRoot {
						return errors.New("source batch changed after proof")
					}
				}
				anchorAgain, err := adapter.HeaderByNumber(ctx, head.Uint64())
				if err != nil || anchorAgain.BlockHash != anchor {
					return errors.New("source anchor changed after proof")
				}
				safeAgain, err := adapter.SafeHeader(ctx)
				if err != nil || safeAgain.Number < artifacts.End {
					return errors.New("source safe height regressed after proof")
				}
				candidate := header.Batch{SourceChainID: o.id, Start: artifacts.Start, End: artifacts.End, AnchorHash: anchor, EndHash: artifacts.EndHash}
				for _, ref := range refs {
					candidate.Headers = append(candidate.Headers, header.HeaderRef{Number: ref.Number, BlockHash: ref.BlockHash, ReceiptRoot: ref.ReceiptRoot})
				}
				if err := store.AddCandidate(candidate); err != nil {
					return err
				}
				covered, err := store.IsBlockCovered(ctx, o.id, artifacts.End, artifacts.EndHash)
				if err != nil {
					return err
				}
				latest, err := reader.ViewUint(ctx, address, "latestBlock()")
				if err != nil {
					return err
				}
				status := "pending_acceptance"
				var tx *transaction
				if covered {
					root, err := reader.ReceiptRoot(ctx, o.id, artifacts.End, artifacts.EndHash)
					if err != nil || root != refs[len(refs)-1].ReceiptRoot {
						return errors.New("accepted candidate receipt root differs")
					}
					status = "accepted"
				} else if latest.Cmp(head) != 0 {
					status = "stale_head"
				} else {
					const spec = `[{"type":"function","name":"submitHeaderProof","inputs":[{"type":"bytes"},{"type":"bytes"},{"type":"bytes"}]}]`
					parsed, err := abi.JSON(strings.NewReader(spec))
					if err != nil {
						return err
					}
					seal, err := hexutil.Decode(proof.Verified.Seal)
					if err != nil {
						return err
					}
					data, err := parsed.Pack("submitHeaderProof", seal, artifacts.Journal, artifacts.BatchData)
					if err != nil {
						return err
					}
					tx = &transaction{Role: "user", Chain: dest, To: address, Data: hexutil.Encode(data), Value: "0"}
				}
				p := map[string]any{"version": 1, "kind": "local-groth16-header-proof", "sourceChainId": o.id, "startBlock": artifacts.Start, "endBlock": artifacts.End,
					"anchorHash": anchor, "endHash": artifacts.EndHash, "batchRoot": artifacts.BatchRoot, "journal": hexutil.Encode(artifacts.Journal), "batchData": hexutil.Encode(artifacts.BatchData),
					"imageId": image, "guestInput": rust, "proofReceipt": proof.Receipt, "receiptKind": "groth16", "proofVerified": true, "cacheHit": proof.CacheHit,
					"seal": proof.Verified.Seal, "verifierParameters": proof.Verified.VerifierParameters, "sealAvailable": true, "evmCompatible": true, "chainAuthenticated": false}
				p["headerBinding"], p["hashBindingVerified"] = proof.Verified.HeaderBinding, proof.Verified.HeaderBinding == "canonical-rlp"
				proposal := map[string]any{"version": 1, "status": status, "candidateIsAccepted": covered, "headerPackage": p, "headerTransaction": tx, "chainAuthenticated": false}
				raw, err := json.MarshalIndent(proposal, "", "  ")
				if err != nil {
					return err
				}
				if err := os.MkdirAll(o.output, 0700); err != nil {
					return err
				}
				name := fmt.Sprintf("%d-%d-%d-%s.json", o.id, artifacts.Start, artifacts.End, artifacts.BatchRoot.Hex()[2:])
				file, err := os.CreateTemp(o.output, ".proposal-*")
				if err != nil {
					return err
				}
				if _, err := file.Write(append(raw, '\n')); err != nil {
					file.Close()
					os.Remove(file.Name())
					return err
				}
				file.Close()
				if err := os.Rename(file.Name(), filepath.Join(o.output, name)); err != nil {
					return err
				}
				lastProposedRoot = artifacts.BatchRoot
				fmt.Printf("%s: %s (cacheHit=%t; no signing/broadcast)\n", filepath.Join(o.output, name), status, proof.CacheHit)
			}
		}
		if !o.watch {
			return nil
		}
	}
}
