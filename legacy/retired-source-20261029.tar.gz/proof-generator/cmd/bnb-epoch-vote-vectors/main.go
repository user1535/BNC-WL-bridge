// Offline geth RLP + pinned Go VoteAttestation decoder oracle. No signing,
// networking, snapshot selection or source authentication is performed.
package main

import (
	"bytes"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"math"
	"math/big"
	"os"
	"sort"

	"example.com/worldland-bnb-bridge/proof-generator/internal/chain"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/crypto"
	"github.com/ethereum/go-ethereum/rlp"
)

func encode(value any) []byte {
	result, err := rlp.EncodeToBytes(value)
	if err != nil {
		panic(err)
	}
	return result
}

func read(path string) ([]byte, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	b, err := io.ReadAll(io.LimitReader(f, 64*1024+1))
	if err != nil || len(b) > 64*1024 {
		return nil, fmt.Errorf("fixture read/size limit")
	}
	return b, nil
}

func run() error {
	input := flag.String("input", "", "saved actual post-Bohr epoch JSON")
	voteInput := flag.String("vote-input", "", "saved non-epoch vote JSON, fallback for an empty epoch suffix")
	flag.Parse()
	if *input == "" || *voteInput == "" || flag.NArg() != 0 {
		return fmt.Errorf("two offline fixture paths required")
	}
	raw, err := read(*input)
	if err != nil {
		return err
	}
	encoded, _, err := chain.CanonicalBNBHeader(raw)
	if err != nil {
		return err
	}
	var fields []rlp.RawValue
	if err := rlp.DecodeBytes(encoded, &fields); err != nil {
		return err
	}
	var extra []byte
	if err := rlp.DecodeBytes(fields[12], &extra); err != nil {
		return err
	}
	if len(extra) < 167 || extra[32] == 0 || extra[32] > 64 {
		return fmt.Errorf("epoch layout")
	}
	end := 33 + int(extra[32])*68
	if end+1+65 > len(extra) || extra[end] == 0 {
		return fmt.Errorf("epoch layout/turn")
	}
	originalVote := extra[end+1 : len(extra)-65]
	baseRaw := originalVote
	if len(baseRaw) == 0 {
		voteRaw, err := read(*voteInput)
		if err != nil {
			return err
		}
		inspection, err := chain.InspectBNBNonEpochAttestation(voteRaw, "post-luban-non-epoch")
		if err != nil || !inspection.Present {
			return fmt.Errorf("actual fallback vote required: %v", err)
		}
		baseRaw = encode(chain.BNBVoteAttestation{VoteAddressSet: inspection.VoteBitmap,
			Data: inspection.Data, Extra: nil})
		// Preserve the observed public signature; no secret or signing is used.
		var wire chain.BNBVoteAttestation
		if err := rlp.DecodeBytes(baseRaw, &wire); err != nil {
			return err
		}
		copy(wire.AggSignature[:], inspection.AggregateSignature)
		baseRaw = encode(wire)
	}
	base, _, err := chain.DecodeBNBVoteAttestation(baseRaw)
	if err != nil {
		return err
	}
	data := func() []any {
		return []any{base.Data.SourceNumber, base.Data.SourceHash, base.Data.TargetNumber, base.Data.TargetHash}
	}
	wire := func(bitmap any, signature any, voteData any, reserved any) []byte {
		// An untyped nil interface is an RLP list; Extra is a byte string.
		if reserved == nil {
			reserved = []byte{}
		}
		return encode([]any{bitmap, signature, voteData, reserved})
	}
	normal := wire(base.VoteAddressSet, base.AggSignature[:], data(), base.Extra)
	type candidate struct {
		name      string
		raw       []byte
		accepted  bool
		synthetic bool
	}
	cases := []candidate{{"actual-epoch", originalVote, true, false}, {"absent", nil, true, true},
		{"supplied-actual-vote", normal, true, true},
		{"max-bitmap", wire(uint64(math.MaxUint64), base.AggSignature[:], data(), nil), true, true},
		{"reserved-extra-256", wire(base.VoteAddressSet, base.AggSignature[:], data(), bytes.Repeat([]byte{0x42}, 256)), true, true},
		{"uint64-range", wire(base.VoteAddressSet, base.AggSignature[:], []any{uint64(math.MaxUint64 - 1), base.Data.SourceHash, uint64(math.MaxUint64), base.Data.TargetHash}, nil), true, true},
		{"source-zero-gap", wire(base.VoteAddressSet, base.AggSignature[:], []any{uint64(0), base.Data.SourceHash, uint64(256), base.Data.TargetHash}, nil), true, true}}
	invalid := func(name string, raw []byte) { cases = append(cases, candidate{name, raw, false, true}) }
	overflow := new(big.Int).Lsh(big.NewInt(1), 64)
	for name, bitmap := range map[string]any{"bitmap-zero": uint64(0), "bitmap-overflow": overflow,
		"bitmap-leading-zero": rlp.RawValue{0x82, 0, 1}, "bitmap-nested": []uint64{1}, "bitmap-noncanonical-scalar": rlp.RawValue{0x81, 1}} {
		invalid(name, wire(bitmap, base.AggSignature[:], data(), nil))
	}
	for name, signature := range map[string]any{"signature-short": make([]byte, 95), "signature-long": make([]byte, 97),
		"signature-zero": make([]byte, 96), "signature-nested": []uint64{1}} {
		invalid(name, wire(base.VoteAddressSet, signature, data(), nil))
	}
	for name, value := range map[string]any{"data-scalar": []byte{1}, "data-missing": data()[:3],
		"data-extra": append(data(), uint64(1)), "source-equals-target": []any{base.Data.TargetNumber, base.Data.SourceHash, base.Data.TargetNumber, base.Data.TargetHash},
		"source-reversed":     []any{base.Data.TargetNumber + 1, base.Data.SourceHash, base.Data.TargetNumber, base.Data.TargetHash},
		"source-overflow":     []any{overflow, base.Data.SourceHash, base.Data.TargetNumber, base.Data.TargetHash},
		"target-overflow":     []any{base.Data.SourceNumber, base.Data.SourceHash, overflow, base.Data.TargetHash},
		"source-leading-zero": []any{rlp.RawValue{0x82, 0, 1}, base.Data.SourceHash, base.Data.TargetNumber, base.Data.TargetHash},
		"source-zero-hash":    []any{base.Data.SourceNumber, common.Hash{}, base.Data.TargetNumber, base.Data.TargetHash},
		"target-zero-hash":    []any{base.Data.SourceNumber, base.Data.SourceHash, base.Data.TargetNumber, common.Hash{}},
		"source-short-hash":   []any{base.Data.SourceNumber, bytes.Repeat([]byte{1}, 31), base.Data.TargetNumber, base.Data.TargetHash},
		"target-long-hash":    []any{base.Data.SourceNumber, base.Data.SourceHash, base.Data.TargetNumber, bytes.Repeat([]byte{1}, 33)}} {
		invalid(name, wire(base.VoteAddressSet, base.AggSignature[:], value, nil))
	}
	invalid("reserved-extra-long", wire(base.VoteAddressSet, base.AggSignature[:], data(), make([]byte, 257)))
	invalid("reserved-extra-nested", wire(base.VoteAddressSet, base.AggSignature[:], data(), []uint64{1}))
	invalid("outer-missing", encode([]any{base.VoteAddressSet, base.AggSignature[:], data()}))
	invalid("outer-extra", encode([]any{base.VoteAddressSet, base.AggSignature[:], data(), []byte{}, uint64(1)}))
	invalid("outer-scalar", encode([]byte{1, 2, 3}))
	invalid("trailing", append(bytes.Clone(normal), 0))
	invalid("truncated", normal[:len(normal)-1])
	if normal[0] != 0xf8 {
		return fmt.Errorf("noncanonical fixture expected single-byte list length")
	}
	invalid("noncanonical-list-length", append([]byte{0xf9, 0, normal[1]}, normal[2:]...))
	invalid("resource-513", make([]byte, 513))
	sort.Slice(cases, func(i, j int) bool { return cases[i].name < cases[j].name })
	rows := []map[string]any{}
	for _, c := range cases {
		row := map[string]any{"name": c.name, "synthetic": c.synthetic, "present": len(c.raw) != 0}
		accepted := true
		if len(c.raw) != 0 {
			vote, hash, err := chain.DecodeBNBVoteAttestation(c.raw)
			accepted = err == nil
			if err != nil {
				row["goError"] = err.Error()
			} else {
				row["voteDataHash"] = hash.Hex()
				row["voteBitmap"] = vote.VoteAddressSet
				row["signatureHash"] = crypto.Keccak256Hash(vote.AggSignature[:]).Hex()
				row["reservedExtraLength"] = len(vote.Extra)
			}
		}
		if accepted != c.accepted {
			return fmt.Errorf("oracle case %s had unexpected acceptance", c.name)
		}
		row["goAccepted"] = accepted
		newExtra := append(bytes.Clone(extra[:end+1]), c.raw...)
		newExtra = append(newExtra, extra[len(extra)-65:]...)
		copyFields := append([]rlp.RawValue(nil), fields...)
		copyFields[12] = encode(newExtra)
		header := encode(copyFields)
		row["epochRaw"] = "0x" + common.Bytes2Hex(header)
		row["epochHash"] = crypto.Keccak256Hash(header).Hex()
		if !c.synthetic && !bytes.Equal(header, encoded) {
			return fmt.Errorf("actual fixture changed")
		}
		rows = append(rows, row)
	}
	return json.NewEncoder(os.Stdout).Encode(map[string]any{"vectors": rows, "chainAuthenticated": false,
		"epochOptionalVoteSignatureVerified": false, "syntheticVariantsUseObservedKeySlots": true})
}

func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
