// Read-only cache audit; no proof generation, wallet, broadcast or deletion.
package main

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"time"

	"example.com/worldland-bnb-bridge/proof-generator/internal/header"
	"example.com/worldland-bnb-bridge/proof-generator/internal/risc0"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/common/hexutil"
)

func main() {
	cachePath := flag.String("proof-cache", "", "shared cache root (contains composite/groth16)")
	host := flag.String("risc0-host", "", "immutable local receipt verifier")
	kind := flag.String("receipt-kind", "groth16", "composite or groth16")
	output := flag.String("output", "", "save to a new JSON file, otherwise stdout")
	timeout := flag.Duration("timeout", 5*time.Minute, "total verification budget")
	flag.Parse()
	if err := run(*cachePath, *host, *kind, *output, *timeout); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}

func run(directory, host, kind, output string, budget time.Duration) error {
	if directory == "" || host == "" || (kind != "composite" && kind != "groth16") || budget <= 0 {
		return errors.New("required cache/host, supported receipt kind and positive timeout")
	}
	ctx, cancel := context.WithTimeout(context.Background(), budget)
	defer cancel()
	command := exec.CommandContext(ctx, host, "--image-id")
	command.Env = append(os.Environ(), "RISC0_DEV_MODE=0", "RISC0_PROVER=ipc")
	raw, err := command.Output()
	if err != nil {
		return err
	}
	imageBytes, err := hexutil.Decode(strings.TrimSpace(string(raw)))
	if err != nil || len(imageBytes) != 32 {
		return errors.New("invalid compiled host image")
	}
	imageID := common.BytesToHash(imageBytes)
	prover := risc0.LocalProver{HostPath: host, ReceiptKind: kind}
	cache := header.ProofCache{Directory: filepath.Join(directory, kind), Verify: func(proof, journal []byte) error {
		_, err := prover.VerifyReceipt(ctx, proof, journal, imageID)
		return err
	}}
	report, err := cache.Audit(ctx, imageID)
	if err != nil {
		return err
	}
	binary, err := os.ReadFile(host)
	if err != nil {
		return err
	}
	digest := sha256.Sum256(binary)
	result := struct {
		Audit                      *header.CacheAudit `json:"cache"`
		HostSHA256                 string             `json:"hostSHA256"`
		ReceiptKind                string             `json:"receiptKind"`
		ChainAuthenticated         bool               `json:"chainAuthenticated"`
		RealAssetDeploymentAllowed bool               `json:"realAssetDeploymentAllowed"`
	}{report, hex.EncodeToString(digest[:]), kind, false, false}
	data, err := json.MarshalIndent(result, "", "  ")
	if err != nil {
		return err
	}
	data = append(data, '\n')
	if output == "" {
		_, err = os.Stdout.Write(data)
	} else {
		var file *os.File
		file, err = os.OpenFile(output, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
		if err == nil {
			_, err = file.Write(data)
			closeErr := file.Close()
			if err == nil {
				err = closeErr
			}
		}
	}
	if err != nil {
		return err
	}
	if report.Verdict == "FAIL" {
		return errors.New("cache audit found rejected/unsupported/unsafe artifacts; original files preserved")
	}
	return nil
}
