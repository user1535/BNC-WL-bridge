// Offline observed native receipt-root/MPT diagnostic; no RPC/proving/assets.
package main

import (
	"encoding/json"
	"errors"
	"example.com/worldland-bnb-bridge/proof-generator/internal/chain"
	receiptproof "example.com/worldland-bnb-bridge/proof-generator/internal/receipt"
	"flag"
	"fmt"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/common/hexutil"
	"github.com/ethereum/go-ethereum/core/types"
	"github.com/ethereum/go-ethereum/trie"
	"io"
	"os"
)

func resultFile(path string, limit int) ([]byte, error) {
	file, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer file.Close()
	info, err := file.Stat()
	if err != nil {
		return nil, err
	}
	if !info.Mode().IsRegular() || info.Size() > int64(limit) {
		return nil, errors.New("invalid diagnostic file or size")
	}
	raw, err := io.ReadAll(io.LimitReader(file, int64(limit)+1))
	if err != nil {
		return nil, err
	}
	if len(raw) > limit {
		return nil, errors.New("diagnostic file exceeds limit")
	}
	var response struct {
		Result json.RawMessage `json:"result"`
		Error  json.RawMessage `json:"error"`
	}
	if err := json.Unmarshal(raw, &response); err != nil {
		return nil, err
	}
	if len(response.Error) > 0 && string(response.Error) != "null" {
		return nil, errors.New("RPC capture has an error")
	}
	if len(response.Result) == 0 || string(response.Result) == "null" {
		return nil, errors.New("capture has no result")
	}
	return response.Result, nil
}
func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
func run() error {
	headerPath := flag.String("header", "", "captured eth_getBlock response")
	receiptsPath := flag.String("receipts", "", "captured block receipts response")
	profile := flag.String("encoding-profile", "", "pinned native encoding profile")
	index := flag.Uint64("tx-index", 0, "receipt index for a first-log proof")
	flag.Parse()
	headerRaw, err := resultFile(*headerPath, 2*1024*1024)
	if err != nil {
		return err
	}
	inspection, err := chain.InspectNativeHeaderJSON(headerRaw, *profile)
	if err != nil {
		return err
	}
	if !inspection.HashMatchesRPC {
		return errors.New("native header hash mismatch")
	}
	var header struct {
		Transactions []common.Hash `json:"transactions"`
	}
	if err := json.Unmarshal(headerRaw, &header); err != nil {
		return err
	}
	raw, err := resultFile(*receiptsPath, 8*1024*1024)
	if err != nil {
		return err
	}
	var receipts types.Receipts
	if err := json.Unmarshal(raw, &receipts); err != nil {
		return err
	}
	if len(receipts) == 0 || len(receipts) != len(header.Transactions) || *index >= uint64(len(receipts)) {
		return errors.New("empty/incomplete receipts or invalid target index")
	}
	encoded := make(receiptproof.EncodedReceipts, len(receipts))
	counts := map[uint8]int{}
	for i, item := range receipts {
		if item == nil || item.BlockHash != inspection.SuppliedHash || item.BlockNumber == nil || !item.BlockNumber.IsUint64() || item.BlockNumber.Uint64() != inspection.BlockNumber || item.TransactionIndex != uint(i) || item.TxHash != header.Transactions[i] {
			return errors.New("receipt block/order/hash metadata mismatch")
		}
		encoded[i], err = receiptproof.EncodeReceipt(item)
		if err != nil {
			return err
		}
		counts[item.Type]++
	}
	root := types.DeriveSha(encoded, trie.NewStackTrie(nil))
	if root != inspection.ReceiptRoot {
		return fmt.Errorf("native receipt root mismatch: built %s expected %s", root, inspection.ReceiptRoot)
	}
	target := receipts[*index]
	if len(target.Logs) == 0 {
		return errors.New("target has no log for inclusion diagnostic")
	}
	sourceHeader := chain.Header{Number: inspection.BlockNumber, BlockHash: inspection.SuppliedHash, ReceiptRoot: inspection.ReceiptRoot}
	proof, err := receiptproof.BuildReceiptProof(sourceHeader, header.Transactions, receipts, *target.Logs[0])
	if err != nil {
		return err
	}
	nodes := make([]string, len(proof.Nodes))
	for i, node := range proof.Nodes {
		nodes[i] = hexutil.Encode(node)
	}
	result := map[string]any{"offline": true, "chainAuthenticated": false, "realAssetDeploymentAllowed": false, "assetClaimTested": false, "nativeHeaderHashChecked": true, "mptRootRecomputed": true, "receiptCount": len(receipts), "receiptTypes": counts, "root": root, "blockHash": inspection.SuppliedHash, "blockNumber": inspection.BlockNumber, "txIndex": proof.TxIndex, "logIndex": proof.LogIndex, "receiptType": target.Type, "receiptBytes": hexutil.Encode(proof.ReceiptBytes), "proofNodes": nodes, "emitter": target.Logs[0].Address, "topics": target.Logs[0].Topics, "data": hexutil.Encode(target.Logs[0].Data)}
	return json.NewEncoder(os.Stdout).Encode(result)
}
