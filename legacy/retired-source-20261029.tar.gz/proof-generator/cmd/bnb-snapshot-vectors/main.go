// Offline supplied-state diagnostic vectors. Only delay arithmetic is checked
// against a verbatim upstream method; snapshot replay/finality are not run.
package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"math"
	"os"
	"path/filepath"
	"sort"

	"example.com/worldland-bnb-bridge/proof-generator/internal/chain"
	oracle "example.com/worldland-bnb-bridge/proof-generator/internal/protocoloracle/bnb"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/rlp"
)

func inspect(directory, label string) (*chain.HeaderInspection, common.Hash, error) {
	file, err := os.Open(filepath.Join(directory, "bnb-"+label+".json"))
	if err != nil {
		return nil, common.Hash{}, err
	}
	defer file.Close()
	raw, err := io.ReadAll(io.LimitReader(file, 64*1024+1))
	if err != nil || len(raw) > 64*1024 {
		return nil, common.Hash{}, fmt.Errorf("fixture limit")
	}
	h, err := chain.InspectNativeHeaderJSON(raw, chain.BNBEncoding)
	if err != nil || !h.HashMatchesRPC {
		return nil, common.Hash{}, fmt.Errorf("native fixture/hash: %v", err)
	}
	var parent struct {
		ParentHash common.Hash `json:"parentHash"`
	}
	if err = json.Unmarshal(raw, &parent); err != nil {
		return nil, common.Hash{}, err
	}
	return h, parent.ParentHash, nil
}

func run() error {
	directory := flag.String("fixture-dir", "", "offline actual BNB captures")
	flag.Parse()
	if *directory == "" || flag.NArg() != 0 {
		return fmt.Errorf("offline fixtures required")
	}
	epoch, _, err := inspect(*directory, "epoch")
	if err != nil {
		return err
	}
	encoded := common.FromHex(epoch.HeaderRLP)
	var fields []rlp.RawValue
	if err = rlp.DecodeBytes(encoded, &fields); err != nil {
		return err
	}
	var extra []byte
	if err = rlp.DecodeBytes(fields[12], &extra); err != nil {
		return err
	}
	if len(extra) < 167 || extra[32] == 0 || extra[32] > 64 {
		return fmt.Errorf("post-Bohr epoch layout")
	}
	count := extra[32]
	end := 33 + int(count)*68
	if end+1+65 > len(extra) || extra[end] == 0 {
		return fmt.Errorf("post-Bohr epoch layout")
	}
	turn := extra[end]
	schedules := []map[string]any{}
	add := func(name string, e uint64, oldCount, oldTurn, newCount, newTurn uint8, number uint64) {
		row := map[string]any{"name": name, "epochNumber": e, "oldCount": oldCount, "oldTurn": oldTurn,
			"newCount": newCount, "newTurn": newTurn, "snapshotNumber": number, "syntheticSuppliedState": true}
		accepted := e != 0 && e%1000 == 0 && e <= math.MaxUint64-1000 && number >= e && number-e < 1000 &&
			oldCount > 0 && oldCount <= 64 && oldTurn > 0 && newCount > 0 && newCount <= 64 && newTurn > 0
		if accepted {
			delay := oracle.SuppliedMinerHistory(oldCount, oldTurn)
			next := oracle.SuppliedMinerHistory(newCount, newTurn)
			accepted = delay < 1000 && next < 1000
			if accepted {
				row["expected"] = []any{delay, e + delay, e + delay + 1, number >= e+delay, next, next > delay}
			}
		}
		row["accepted"] = accepted
		schedules = append(schedules, row)
	}
	e := epoch.BlockNumber
	for _, config := range [][4]uint8{{1, 1, count, turn}, {2, 1, count, turn}, {21, 1, count, turn},
		{21, 4, count, turn}, {21, 8, count, turn}, {21, 16, count, turn}, {64, 16, count, turn},
		{31, 16, count, turn}, {21, 8, 31, 16}, {1, 255, count, turn}} {
		delay := oracle.SuppliedMinerHistory(config[0], config[1])
		label := fmt.Sprintf("%d-%d-to-%d-%d", config[0], config[1], config[2], config[3])
		for suffix, number := range map[string]uint64{"epoch": e, "switch": e + delay, "first-new-header": e + delay + 1, "last": e + 999} {
			add(label+"-"+suffix, e, config[0], config[1], config[2], config[3], number)
		}
		if delay > 0 {
			add(label+"-before-switch", e, config[0], config[1], config[2], config[3], e+delay-1)
		}
		next := oracle.SuppliedMinerHistory(config[2], config[3])
		if next > delay {
			add(label+"-second-trigger-needs-sentinel", e, config[0], config[1], config[2], config[3], e+next)
		}
	}
	for _, config := range [][4]uint8{{0, 8, count, turn}, {65, 8, count, turn}, {21, 0, count, turn},
		{21, 8, 0, turn}, {21, 8, 65, turn}, {21, 8, count, 0}, {64, 255, count, turn}, {21, 8, 64, 255}} {
		add(fmt.Sprintf("unsupported-state-%d-%d-%d-%d", config[0], config[1], config[2], config[3]),
			e, config[0], config[1], config[2], config[3], e+500)
	}
	add("epoch-zero", 0, 21, 8, count, turn, 500)
	add("epoch-not-boundary", e+1, 21, 8, count, turn, e+500)
	add("epoch-overflow", math.MaxUint64/1000*1000, 21, 8, count, turn, math.MaxUint64)
	add("before-epoch", e, 21, 8, count, turn, e-1)
	add("next-epoch-unprocessed", e, 21, 8, count, turn, e+1000)
	// Deterministic artifact despite map iteration when assembling scenarios.
	sortSchedules(schedules)
	roles := []map[string]any{}
	for _, labels := range [][3]string{{"source728", "target729", "parent"}, {"target729", "parent", "latest"}} {
		hs := make([]*chain.HeaderInspection, 3)
		ps := make([]common.Hash, 3)
		for i, label := range labels {
			hs[i], ps[i], err = inspect(*directory, label)
			if err != nil {
				return err
			}
		}
		if hs[0].BlockNumber == 0 || hs[1].BlockNumber != hs[0].BlockNumber+1 || hs[2].BlockNumber != hs[1].BlockNumber+1 ||
			ps[1] != hs[0].RecomputedHash || ps[2] != hs[1].RecomputedHash {
			return fmt.Errorf("adjacent actual role witness required")
		}
		roles = append(roles, map[string]any{"name": labels[2], "sourceRaw": hs[0].HeaderRLP, "targetRaw": hs[1].HeaderRLP,
			"attestingRaw": hs[2].HeaderRLP, "numbers": []uint64{hs[1].BlockNumber - 1, hs[0].BlockNumber - 1, hs[1].BlockNumber - 1, hs[2].BlockNumber - 1},
			"hashes": []common.Hash{ps[1], ps[0], ps[1], ps[2]}})
	}
	return json.NewEncoder(os.Stdout).Encode(map[string]any{"scheduleVectors": schedules, "roleVectors": roles,
		"epochNumber": e, "epochHash": epoch.RecomputedHash, "observedNewCount": count, "observedNewTurn": turn,
		"profileAssumption": "supplied-post-bohr-fixed-epoch1000", "oldConfigurationsAuthenticated": false,
		"delayOracle":                  "verbatim pinned Snapshot.minerHistoryCheckLen only; not Snapshot.apply",
		"actualSnapshotReplayMeasured": false, "forkPolicyAuthenticated": false,
		"snapshotAuthenticated": false, "finalityVerified": false, "chainAuthenticated": false, "realAssetDeploymentAllowed": false})
}

func sortSchedules(rows []map[string]any) { // avoid a helper implementation of Parlia state transitions
	sort.Slice(rows, func(i, j int) bool { return rows[i]["name"].(string) < rows[j]["name"].(string) })
}
func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
