// Generate synthetic offline fixtures using pinned upstream EncodeRLP functions.
package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"os"
	"path/filepath"

	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/common/hexutil"
	"github.com/ethereum/go-ethereum/core/types"
	"github.com/ethereum/go-ethereum/crypto"
	"github.com/ethereum/go-ethereum/rlp"

	"example.com/worldland-bnb-bridge/proof-generator/internal/chain"
	bnb "example.com/worldland-bnb-bridge/proof-generator/internal/protocoloracle/bnb"
	wl "example.com/worldland-bnb-bridge/proof-generator/internal/protocoloracle/worldland"
)

type fixture struct {
	Name    string          `json:"name"`
	Profile string          `json:"profile"`
	RPC     json.RawMessage `json:"rpc"`
	RLP     string          `json:"rlp"`
	Hash    common.Hash     `json:"hash"`
}

func main() {
	output := flag.String("output", "internal/chain/testdata/native-header-fixtures.json", "new output file")
	flag.Parse()
	base, err := os.ReadFile("internal/chain/testdata/anvil-prague-header.json")
	must(err)
	var original map[string]json.RawMessage
	must(json.Unmarshal(base, &original))
	rows := []fixture{}
	newFields := func() map[string]json.RawMessage {
		result := make(map[string]json.RawMessage)
		for _, key := range []string{"parentHash", "sha3Uncles", "miner", "stateRoot", "transactionsRoot", "receiptsRoot", "logsBloom", "difficulty", "number", "gasLimit", "gasUsed", "timestamp", "extraData", "mixHash", "nonce"} {
			result[key] = original[key]
		}
		return result
	}
	add := func(name, profile string, fields map[string]json.RawMessage, encoded []byte) {
		hash := crypto.Keccak256Hash(encoded)
		fields["hash"], err = json.Marshal(hash)
		must(err)
		raw, err := json.Marshal(fields)
		must(err)
		rows = append(rows, fixture{name, profile, raw, hexutil.Encode(encoded), hash})
	}
	for fee := 0; fee < 2; fee++ {
		for word := 0; word < 3; word++ {
			for length := 0; length < 2; length++ {
				fields := newFields()
				if fee != 0 {
					fields["baseFeePerGas"] = json.RawMessage(`"0x0"`)
				}
				if word != 0 {
					fields["codeword"], _ = json.Marshal([]string{"", "0x", "0x010203ff"}[word])
				}
				if length != 0 {
					fields["codelength"] = json.RawMessage(`"0x20"`)
				}
				raw, _ := json.Marshal(fields)
				var h types.Header
				must(json.Unmarshal(raw, &h))
				oracle := wl.Header{Header: h}
				if word == 1 {
					oracle.Codeword = make([]byte, 0)
				}
				if word == 2 {
					oracle.Codeword = []byte{1, 2, 3, 255}
				}
				if length != 0 {
					oracle.CodeLength = 32
				}
				encoded, err := rlp.EncodeToBytes(&oracle)
				must(err)
				add(fmt.Sprintf("worldland-fee%d-word%d-length%d", fee, word, length), chain.WorldLandEncoding, fields, encoded)
			}
		}
	}
	names := []string{"baseFeePerGas", "withdrawalsRoot", "blobGasUsed", "excessBlobGas", "parentBeaconBlockRoot", "requestsHash"}
	hash := common.HexToHash("0x123456789abc")
	hashJSON, _ := json.Marshal(hash)
	for mask := 0; mask < 64; mask++ {
		fields := newFields()
		// Opaque Parlia-shaped vanity/seal bytes; this is no signature/finality fixture.
		extra := make([]byte, 97)
		for index := range extra {
			extra[index] = byte(index)
		}
		fields["extraData"], _ = json.Marshal(hexutil.Encode(extra))
		for index, name := range names {
			if mask&(1<<index) != 0 {
				if index == 0 || index == 2 || index == 3 {
					fields[name] = json.RawMessage(`"0x0"`)
				} else {
					fields[name] = hashJSON
				}
			}
		}
		raw, _ := json.Marshal(fields)
		var h types.Header
		must(json.Unmarshal(raw, &h))
		oracle := bnb.Header{Header: h}
		if mask&32 != 0 {
			oracle.RequestsHash = &hash
		}
		encoded, err := rlp.EncodeToBytes(&oracle)
		must(err)
		add(fmt.Sprintf("bnb-optional-mask-%02x", mask), chain.BNBEncoding, fields, encoded)
	}
	data, err := json.MarshalIndent(struct {
		Synthetic          bool      `json:"synthetic"`
		ChainAuthenticated bool      `json:"chainAuthenticated"`
		Oracle             string    `json:"oracle"`
		Fixtures           []fixture `json:"fixtures"`
	}{true, false, "docs/protocol-sources/oracle-manifest.json", rows}, "", "  ")
	must(err)
	must(os.MkdirAll(filepath.Dir(*output), 0755))
	file, err := os.OpenFile(*output, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0644)
	must(err)
	defer file.Close()
	_, err = file.Write(append(data, '\n'))
	must(err)
	fmt.Printf("%d synthetic upstream-encoder fixtures saved\n", len(rows))
}

func must(err error) {
	if err != nil {
		panic(err)
	}
}
