// Offline pinned EncodeSigHeader + public ECDSA recovery oracle. Modified
// headers are synthetic and carry no newly signed consensus authority.
package main

import (
	"bytes"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"math/big"
	"os"
	"path/filepath"

	"example.com/worldland-bnb-bridge/proof-generator/internal/bnbseal"
	"example.com/worldland-bnb-bridge/proof-generator/internal/chain"
	oracle "example.com/worldland-bnb-bridge/proof-generator/internal/protocoloracle/bnb"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/common/hexutil"
	"github.com/ethereum/go-ethereum/core/types"
	"github.com/ethereum/go-ethereum/crypto"
)

func read(path string) ([]byte, error) {
	file, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer file.Close()
	raw, err := io.ReadAll(io.LimitReader(file, 64*1024+1))
	if err != nil || len(raw) > 64*1024 {
		return nil, fmt.Errorf("fixture read/size limit")
	}
	return raw, nil
}

func run() error {
	directory := flag.String("fixture-dir", "", "saved actual BNB fixtures; no RPC")
	flag.Parse()
	if *directory == "" || flag.NArg() != 0 {
		return fmt.Errorf("offline fixture directory required")
	}
	rows := []map[string]any{}
	parent, err := read(filepath.Join(*directory, "bnb-parent.json"))
	if err != nil {
		return err
	}
	add := func(name string, raw []byte, synthetic bool, recovery bool, codec bool) error {
		encoded, hash, err := chain.CanonicalBNBHeader(raw)
		if err != nil {
			return err
		}
		var fields map[string]any
		if err := json.Unmarshal(raw, &fields); err != nil {
			return err
		}
		// Full-header hash is a serializer oracle, not evidence that a
		// modified header was signed or appeared on the source chain.
		fields["hash"] = hash.Hex()
		raw, err = json.Marshal(fields)
		if err != nil {
			return err
		}
		row := map[string]any{"name": name, "synthetic": synthetic, "headerRaw": hexutil.Encode(encoded),
			"codecAccepted": codec, "recoveryAccepted": recovery, "headerHash": hash.Hex()}
		if codec {
			var header types.Header
			if err := json.Unmarshal(raw, &header); err != nil {
				return err
			}
			var extension struct {
				RequestsHash *common.Hash `json:"requestsHash"`
			}
			if err := json.Unmarshal(raw, &extension); err != nil {
				return err
			}
			if len(header.Extra) < 65 {
				return fmt.Errorf("seal codec precondition")
			}
			var sealed bytes.Buffer
			oracle.EncodeSigHeader(&sealed, &oracle.Header{Header: header, RequestsHash: extension.RequestsHash}, big.NewInt(56))
			row["sealHash"] = crypto.Keccak256Hash(sealed.Bytes()).Hex()
			row["sealRlp"] = hexutil.Encode(sealed.Bytes())
		}
		inspected, err := bnbseal.Inspect(raw, 56)
		if (err == nil) != recovery {
			return fmt.Errorf("unexpected recovery for %s: %v", name, err)
		}
		if err != nil {
			row["goRecoveryError"] = err.Error()
		} else {
			row["signer"] = inspected.Signer.Hex()
			row["coinbase"] = inspected.Coinbase.Hex()
			if inspected.SealHash.Hex() != row["sealHash"] {
				return fmt.Errorf("digest mismatch")
			}
		}
		rows = append(rows, row)
		return nil
	}
	for _, label := range []string{"epoch", "source728", "target729", "parent", "latest"} {
		raw, err := read(filepath.Join(*directory, "bnb-"+label+".json"))
		if err != nil {
			return err
		}
		if err = add("actual-"+label, raw, false, true, true); err != nil {
			return err
		}
	}
	var base map[string]any
	if err = json.Unmarshal(parent, &base); err != nil {
		return err
	}
	modify := func(name string, edit func(map[string]any), recovery bool, codec bool) error {
		fields := make(map[string]any, len(base))
		for key, value := range base {
			fields[key] = value
		}
		edit(fields)
		raw, err := json.Marshal(fields)
		if err != nil {
			return err
		}
		return add(name, raw, true, recovery, codec)
	}
	optional := []string{"baseFeePerGas", "withdrawalsRoot", "blobGasUsed", "excessBlobGas", "parentBeaconBlockRoot", "requestsHash"}
	for count := 15; count < 21; count++ {
		count := count
		if err = modify(fmt.Sprintf("optional-prefix-%d", count), func(f map[string]any) {
			for _, key := range optional[count-15:] {
				delete(f, key)
			}
		}, false, true); err != nil {
			return err
		}
	}
	for _, name := range []string{"nil-parent-with-requests", "nil-parent-changed-ignored-basefee", "parent-present-nil-basefee", "parent-present-nil-blobgas"} {
		if err = modify(name, func(f map[string]any) {
			switch name {
			case "nil-parent-with-requests":
				delete(f, "parentBeaconBlockRoot")
			case "nil-parent-changed-ignored-basefee":
				delete(f, "parentBeaconBlockRoot")
				f["baseFeePerGas"] = "0x1234"
			case "parent-present-nil-basefee":
				delete(f, "baseFeePerGas")
			case "parent-present-nil-blobgas":
				delete(f, "blobGasUsed")
			}
		}, name == "parent-present-nil-basefee", true); err != nil {
			return err
		}
	}
	observed, err := hexutil.Decode(base["extraData"].(string))
	if err != nil {
		return err
	}
	signature := bytes.Clone(observed[len(observed)-65:])
	for _, length := range []int{64, 65, 96, 128} {
		length := length
		if err = modify(fmt.Sprintf("extra-length-%d", length), func(f map[string]any) {
			extra := bytes.Repeat([]byte{0x42}, length)
			if length >= 65 {
				copy(extra[length-65:], signature)
			}
			f["extraData"] = hexutil.Encode(extra)
		}, false, length >= 65); err != nil {
			return err
		}
	}
	for _, name := range []string{"high-s-public-malleation", "invalid-recovery-id", "zero-r", "zero-s", "r-equals-order", "s-equals-order", "altered-r", "altered-s"} {
		if err = modify(name, func(f map[string]any) {
			extra := bytes.Clone(observed)
			seal := extra[len(extra)-65:]
			switch name {
			case "high-s-public-malleation":
				s := new(big.Int).SetBytes(seal[32:64])
				new(big.Int).Sub(crypto.S256().Params().N, s).FillBytes(seal[32:64])
				seal[64] ^= 1
			case "invalid-recovery-id":
				seal[64] = 27
			case "zero-r":
				clear(seal[:32])
			case "zero-s":
				clear(seal[32:64])
			case "r-equals-order":
				crypto.S256().Params().N.FillBytes(seal[:32])
			case "s-equals-order":
				crypto.S256().Params().N.FillBytes(seal[32:64])
			case "altered-r":
				seal[0] ^= 1
			case "altered-s":
				seal[32] ^= 1
			}
			f["extraData"] = hexutil.Encode(extra)
		}, name == "high-s-public-malleation", true); err != nil {
			return err
		}
	}
	for _, key := range []string{"miner", "receiptsRoot"} {
		key := key
		if err = modify("altered-"+key, func(f map[string]any) {
			value, _ := hexutil.Decode(f[key].(string))
			value[len(value)-1] ^= 1
			f[key] = hexutil.Encode(value)
		}, false, true); err != nil {
			return err
		}
	}
	for _, id := range []uint64{0, 57, 31337} {
		if _, err := bnbseal.Inspect(parent, id); err == nil {
			return fmt.Errorf("unsupported domain accepted")
		}
	}
	return json.NewEncoder(os.Stdout).Encode(map[string]any{"vectors": rows, "sourceChainId": 56,
		"unsupportedSourceDomainsRejected": []uint64{0, 57, 31337}, "newSignaturesGenerated": 0,
		"codecOracle": "pinned BNBv1.7.8 types.EncodeSigHeader", "snapshotAuthenticated": false,
		"chainAuthenticated": false, "realAssetDeploymentAllowed": false})
}
func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
