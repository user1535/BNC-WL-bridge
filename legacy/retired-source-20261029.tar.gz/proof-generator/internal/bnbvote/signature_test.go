package bnbvote

import (
	"bytes"
	"encoding/json"
	"os"
	"testing"

	"example.com/worldland-bnb-bridge/proof-generator/internal/chain"

	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/common/hexutil"
)

func capturedEpoch(t *testing.T) []byte {
	t.Helper()
	raw, err := os.ReadFile("../chain/testdata/native-live-captured/bnb-epoch.json")
	if err != nil {
		t.Fatal(err)
	}
	return raw
}

func TestBNBObservedVotePairingDoesNotAuthenticateFinality(t *testing.T) {
	for _, name := range []string{"parent", "latest"} {
		r, err := InspectBNBVoteSignature(capturedAttestation(t, name), capturedEpoch(t), "post-luban-non-epoch", "post-bohr-epoch", 1000)
		if err != nil {
			t.Fatal(err)
		}
		if !r.PairingVerifiedAgainstSuppliedKeys || !r.QuorumSatisfiedForSuppliedSet || r.RequiredSuppliedVotes != 14 || len(r.Epoch.Validators) != 21 || r.Vote.BitmapSetBits != 20 {
			t.Fatalf("unexpected actual vote diagnostic: %+v", r)
		}
		if r.ProofOfPossessionAuthenticated || r.ValidatorSetAuthenticated || r.ValidatorTransitionVerified || r.FinalityVerified || r.ChainAuthenticated || r.RealAssetDeploymentAllowed || r.Vote.SignatureVerified {
			t.Fatal("mathematical pairing enabled authentication")
		}
	}
}

func TestBNBObservedPairingRejectsAlteredMessageKeysAndQuorum(t *testing.T) {
	k, err := InspectBNBEpochKeys(capturedEpoch(t), "post-bohr-epoch", 1000)
	if err != nil {
		t.Fatal(err)
	}
	r, err := chain.InspectBNBNonEpochAttestation(capturedAttestation(t, "parent"), "post-luban-non-epoch")
	if err != nil {
		t.Fatal(err)
	}
	base := chain.BNBVoteAttestation{VoteAddressSet: r.VoteBitmap, Data: r.Data}
	copy(base.AggSignature[:], r.AggregateSignature)
	for variant := 0; variant < 11; variant++ {
		vote := base
		data := *vote.Data
		vote.Data = &data
		keys := append([]BNBVoteKey(nil), k.Validators...)
		switch variant {
		case 0:
			vote.Data.SourceHash[0] ^= 1
		case 1:
			vote.AggSignature[2] ^= 1
		case 2:
			vote.VoteAddressSet |= uint64(1) << len(keys)
		case 3:
			vote.VoteAddressSet = 1
		case 4:
			keys[1].PublicKey = keys[0].PublicKey
		case 5:
			in, out := -1, -1
			for i := range keys {
				if vote.VoteAddressSet&(uint64(1)<<i) != 0 {
					in = i
				} else {
					out = i
				}
			}
			if in < 0 || out < 0 {
				t.Fatal("fixture must contain signed and unsigned keys")
			}
			keys[in].PublicKey, keys[out].PublicKey = keys[out].PublicKey, keys[in].PublicKey
		case 6:
			vote.AggSignature = [96]byte{0xc0}
		case 7:
			keys[0].PublicKey = make([]byte, 48)
			keys[0].PublicKey[0] = 0xc0
		case 8:
			keys[0].PublicKey = keys[0].PublicKey[:47]
		case 9:
			vote.Data.SourceHash = common.Hash{}
		case 10:
			vote.Data.TargetNumber = vote.Data.SourceNumber
		}
		if _, err := verifySuppliedBNBVote(&vote, keys); err == nil {
			t.Fatalf("variant%d accepted", variant)
		}
	}
	if _, err := verifySuppliedBNBVote(&base, nil); err == nil {
		t.Fatal("empty set accepted")
	}
}

// Recompute only the supplied raw header hash so format tests reach epoch
// decoding. These are deliberately invented headers, never authenticated ones.
func reboundEpochExtra(t *testing.T, extra []byte) []byte {
	t.Helper()
	var obj map[string]any
	json.Unmarshal(capturedEpoch(t), &obj)
	obj["extraData"] = hexutil.Encode(extra)
	raw, _ := json.Marshal(obj)
	h, err := chain.InspectNativeHeaderJSON(raw, chain.BNBEncoding)
	if err != nil {
		t.Fatal(err)
	}
	obj["hash"] = h.RecomputedHash.Hex()
	raw, _ = json.Marshal(obj)
	return raw
}

func TestBNBEpochMalformedKeysAndExplicitLayoutReject(t *testing.T) {
	raw := capturedEpoch(t)
	var h struct {
		Extra hexutil.Bytes `json:"extraData"`
	}
	json.Unmarshal(raw, &h)
	for variant := 0; variant < 8; variant++ {
		x := bytes.Clone(h.Extra)
		end := 33 + int(x[32])*68
		switch variant {
		case 0:
			x[32] = 0
		case 1:
			x[32] = 65
		case 2:
			copy(x[33+68:33+68+20], x[33:33+20])
		case 3:
			copy(x[33:33+20], bytes.Repeat([]byte{0xff}, 20))
		case 4:
			copy(x[33+68+20:33+2*68], x[33+20:33+68])
		case 5:
			clear(x[33+20 : 33+68])
		case 6:
			x[end] = 0
		case 7:
			x[end+1] = 0xff
		}
		if _, err := InspectBNBEpochKeys(reboundEpochExtra(t, x), "post-bohr-epoch", 1000); err == nil {
			t.Fatalf("epoch variant%d accepted", variant)
		}
	}
	if _, err := InspectBNBEpochKeys(raw, "", 1000); err == nil {
		t.Fatal("implicit layout accepted")
	}
	if _, err := InspectBNBEpochKeys(raw, "post-bohr-epoch", 1001); err == nil {
		t.Fatal("unknown epoch length accepted")
	}
	if _, err := InspectBNBEpochKeys(capturedAttestation(t, "parent"), "post-bohr-epoch", 1000); err == nil {
		t.Fatal("non epoch accepted")
	}
	if _, err := InspectBNBVoteSignature(capturedAttestation(t, "parent"), raw, "post-luban-non-epoch", "post-bohr-epoch", 200); err == nil {
		t.Fatal("target outside supplied window accepted")
	}
	var obj map[string]any
	json.Unmarshal(raw, &obj)
	obj["receiptsRoot"] = common.Hash{}.Hex()
	bad, _ := json.Marshal(obj)
	if _, err := InspectBNBEpochKeys(bad, "post-bohr-epoch", 1000); err == nil {
		t.Fatal("changed raw header accepted")
	}
}

func capturedAttestation(t *testing.T, which string) []byte {
	t.Helper()
	raw, err := os.ReadFile("../chain/testdata/native-live-captured/bnb-" + which + ".json")
	if err != nil {
		t.Fatal(err)
	}
	return raw
}

func capturedSignedHeader(t *testing.T, name string) []byte {
	t.Helper()
	raw, err := os.ReadFile("../chain/testdata/native-live-captured/bnb-" + name + ".json")
	if err != nil {
		t.Fatal(err)
	}
	return raw
}

func TestActualSignedVoteBindsFullSourceAndTargetWitness(t *testing.T) {
	for _, c := range []struct{ header, source, target string }{{"parent", "source728", "target729"}, {"latest", "target729", "parent"}} {
		header, source, target := capturedSignedHeader(t, c.header), capturedSignedHeader(t, c.source), capturedSignedHeader(t, c.target)
		r, err := InspectBNBSignedHeaderWitness(header, capturedEpoch(t), source, target, "post-luban-non-epoch", "post-bohr-epoch", 1000)
		if err != nil {
			t.Fatal(err)
		}
		if !r.SignedSourceTargetHeadersBound || !r.DirectSourceTargetParentLink || r.HighestJustifiedSourceVerified || r.FinalityVerified || r.ChainAuthenticated {
			t.Fatal("invalid signed witness scope")
		}
		if _, err := InspectBNBSignedHeaderWitness(header, capturedEpoch(t), target, source, "post-luban-non-epoch", "post-bohr-epoch", 1000); err == nil {
			t.Fatal("reversed signed witness accepted")
		}
		for variant := 0; variant < 2; variant++ {
			s, tar := source, target
			var obj map[string]any
			if variant == 0 {
				json.Unmarshal(source, &obj)
			} else {
				json.Unmarshal(target, &obj)
			}
			obj["receiptsRoot"] = common.Hash{}.Hex()
			bad, _ := json.Marshal(obj)
			if variant == 0 {
				s = bad
			} else {
				tar = bad
			}
			if _, err := InspectBNBSignedHeaderWitness(header, capturedEpoch(t), s, tar, "post-luban-non-epoch", "post-bohr-epoch", 1000); err == nil {
				t.Fatal("altered signed raw header accepted")
			}
		}
	}
}
