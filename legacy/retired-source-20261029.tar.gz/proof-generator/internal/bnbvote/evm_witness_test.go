package bnbvote

import (
	"bytes"
	"testing"

	blst "github.com/supranational/blst/bindings/go"
)

func TestActualEIP2537WitnessCoordinatesRoundTripAndRemainUntrusted(t *testing.T) {
	r, err := InspectBNBVoteSignature(capturedAttestation(t, "parent"), capturedEpoch(t), "post-luban-non-epoch", "post-bohr-epoch", 1000)
	if err != nil {
		t.Fatal(err)
	}
	w, err := BuildBNBEVMVoteWitness(r)
	if err != nil {
		t.Fatal(err)
	}
	if len(w.SuppliedKeys) != 21*128 || len(w.Signature) != 256 || len(w.HashPoint) != 256 || w.VoteDataHash != r.Vote.VoteDataHash || w.VoteBitmap != r.Vote.VoteBitmap {
		t.Fatal("witness dimensions/message/bitmap")
	}
	if w.ChainAuthenticated || w.RealAssetDeploymentAllowed || w.ValidatorSetAuthenticated || w.FinalityVerified || w.ProofOfPossessionAuthenticated {
		t.Fatal("witness enabled authentication")
	}
	for i, key := range r.Epoch.Validators {
		point := w.SuppliedKeys[i*128 : (i+1)*128]
		if !bytes.Equal(point[:16], make([]byte, 16)) || !bytes.Equal(point[64:80], make([]byte, 16)) {
			t.Fatal("Fp padding")
		}
		raw := append(bytes.Clone(point[16:64]), point[80:128]...)
		decoded := new(blst.P1Affine).Deserialize(raw)
		if decoded == nil || !decoded.KeyValidate() || !bytes.Equal(decoded.Compress(), key.PublicKey) {
			t.Fatal("G1 coordinate round trip")
		}
	}
	for i, point := range [][]byte{w.Signature, w.HashPoint} {
		raw := make([]byte, 192)
		for j, offset := range []int{48, 0, 144, 96} {
			copy(raw[offset:offset+48], point[j*64+16:(j+1)*64])
		}
		decoded := new(blst.P2Affine).Deserialize(raw)
		if decoded == nil || !decoded.SigValidate(true) {
			t.Fatal("G2 coordinate round trip")
		}
		if i == 0 && !bytes.Equal(decoded.Compress(), r.Vote.AggregateSignature) {
			t.Fatal("signature mismatch")
		}
	}
}

func TestEIP2537WitnessRejectsUnverifiedOrMalformedInspection(t *testing.T) {
	if _, err := BuildBNBEVMVoteWitness(nil); err == nil {
		t.Fatal("nil accepted")
	}
	if _, err := BuildBNBEVMVoteWitness(&BNBVoteSignatureInspection{}); err == nil {
		t.Fatal("unverified accepted")
	}
	r, err := InspectBNBVoteSignature(capturedAttestation(t, "parent"), capturedEpoch(t), "post-luban-non-epoch", "post-bohr-epoch", 1000)
	if err != nil {
		t.Fatal(err)
	}
	r.Epoch.Validators[0].PublicKey = make([]byte, 48)
	if _, err := BuildBNBEVMVoteWitness(r); err == nil {
		t.Fatal("malformed coordinate accepted")
	}
}
