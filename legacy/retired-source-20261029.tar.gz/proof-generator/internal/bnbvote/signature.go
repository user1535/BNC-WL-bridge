package bnbvote

import (
	"bytes"
	"encoding/json"
	"errors"
	"math/bits"

	"example.com/worldland-bnb-bridge/proof-generator/internal/chain"

	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/common/hexutil"
	"github.com/ethereum/go-ethereum/rlp"
	blst "github.com/supranational/blst/bindings/go"
)

// Same min-pk POP domain as the Prysm v5.3.2 used by pinned BNB v1.7.8.
// FastAggregateVerify assumes registered keys have proved possession. This
// diagnostic never authenticates that registration or the supplied epoch.
const bnbVoteDomain = "BLS_SIG_BLS12381G2_XMD:SHA-256_SSWU_RO_POP_"

type BNBVoteKey struct {
	Address   common.Address `json:"address"`
	PublicKey hexutil.Bytes  `json:"publicKey"`
}

type BNBEpochKeys struct {
	HeaderHash            common.Hash  `json:"headerHash"`
	HeaderNumber          uint64       `json:"headerNumber"`
	LayoutAssumption      string       `json:"layoutAssumption"`
	EpochLengthAssumption uint64       `json:"epochLengthAssumption"`
	TurnLength            uint8        `json:"turnLength"`
	Validators            []BNBVoteKey `json:"validators"`
}

// InspectBNBEpochKeys only decodes a supplied post-Bohr epoch layout. It does
// not implement fork activation, delayed validator transitions or PoP checks.
func InspectBNBEpochKeys(raw []byte, layout string, epochLength uint64) (*BNBEpochKeys, error) {
	if layout != "post-bohr-epoch" || (epochLength != 200 && epochLength != 500 && epochLength != 1000) {
		return nil, errors.New("explicit supported epoch layout/length assumptions required")
	}
	h, err := chain.InspectNativeHeaderJSON(raw, chain.BNBEncoding)
	if err != nil {
		return nil, err
	}
	if !h.HashMatchesRPC || h.BlockNumber%epochLength != 0 {
		return nil, errors.New("epoch hash/number mismatch")
	}
	var wire struct {
		Extra hexutil.Bytes `json:"extraData"`
	}
	if err := json.Unmarshal(raw, &wire); err != nil {
		return nil, err
	}
	if len(wire.Extra) < 32+1+68+1+65 || len(wire.Extra) > 4096 {
		return nil, errors.New("epoch extraData size")
	}
	n := int(wire.Extra[32])
	end := 33 + n*68
	if n == 0 || n > 64 || end+1+65 > len(wire.Extra) || wire.Extra[end] == 0 {
		return nil, errors.New("epoch validator/turn length")
	}
	result := &BNBEpochKeys{HeaderHash: h.RecomputedHash, HeaderNumber: h.BlockNumber, LayoutAssumption: layout,
		EpochLengthAssumption: epochLength, TurnLength: wire.Extra[end]}
	seen := map[string]bool{}
	for i := 0; i < n; i++ {
		entry := wire.Extra[33+i*68 : 33+(i+1)*68]
		address := common.BytesToAddress(entry[:20])
		key := bytes.Clone(entry[20:])
		if address == (common.Address{}) || (i > 0 && bytes.Compare(result.Validators[i-1].Address[:], address[:]) >= 0) || seen[string(key)] {
			return nil, errors.New("zero/duplicate/unsorted epoch validator")
		}
		pk := new(blst.P1Affine).Uncompress(key)
		if pk == nil || !pk.KeyValidate() {
			return nil, errors.New("invalid BLS public key")
		}
		seen[string(key)] = true
		result.Validators = append(result.Validators, BNBVoteKey{address, key})
	}
	if vote := wire.Extra[end+1 : len(wire.Extra)-65]; len(vote) > 0 {
		if _, _, err := chain.DecodeBNBVoteAttestation(vote); err != nil {
			return nil, err
		}
	}
	return result, nil
}

func verifySuppliedBNBVote(vote *chain.BNBVoteAttestation, keys []BNBVoteKey) (int, error) {
	if vote == nil || vote.Data == nil || len(keys) == 0 || len(keys) > 64 || (len(keys) < 64 && vote.VoteAddressSet>>len(keys) != 0) {
		return 0, errors.New("vote bitmap exceeds supplied validators")
	}
	count := bits.OnesCount64(vote.VoteAddressSet)
	required := (len(keys)*2 + 2) / 3
	if count < required {
		return 0, errors.New("quorum below two thirds of supplied set")
	}
	seen := map[string]bool{}
	selected := make([]*blst.P1Affine, 0, count)
	for i, key := range keys {
		if len(key.PublicKey) != 48 || seen[string(key.PublicKey)] {
			return 0, errors.New("duplicate/invalid key width")
		}
		pk := new(blst.P1Affine).Uncompress(key.PublicKey)
		if pk == nil || !pk.KeyValidate() {
			return 0, errors.New("invalid BLS public key")
		}
		seen[string(key.PublicKey)] = true
		if vote.VoteAddressSet&(uint64(1)<<i) != 0 {
			selected = append(selected, pk)
		}
	}
	sig := new(blst.P2Affine).Uncompress(vote.AggSignature[:])
	if sig == nil || !sig.SigValidate(true) {
		return 0, errors.New("invalid BLS aggregate signature")
	}
	// Reuse the canonical wire/data checks and official Keccak(RLP(VoteData)).
	encoded, err := rlp.EncodeToBytes(vote)
	if err != nil {
		return 0, err
	}
	_, hash, err := chain.DecodeBNBVoteAttestation(encoded)
	if err != nil {
		return 0, err
	}
	if !sig.FastAggregateVerify(true, selected, hash[:], []byte(bnbVoteDomain)) {
		return 0, errors.New("BLS vote pairing verification failed")
	}
	return required, nil
}

type BNBVoteSignatureInspection struct {
	HeaderHash                         common.Hash                     `json:"headerHash"`
	HeaderNumber                       uint64                          `json:"headerNumber"`
	Epoch                              *BNBEpochKeys                   `json:"suppliedEpoch"`
	Vote                               *chain.BNBAttestationInspection `json:"vote"`
	Domain                             string                          `json:"blsDomain"`
	RequiredSuppliedVotes              int                             `json:"requiredSuppliedVotes"`
	PairingVerifiedAgainstSuppliedKeys bool                            `json:"pairingVerifiedAgainstSuppliedKeys"`
	QuorumSatisfiedForSuppliedSet      bool                            `json:"quorumSatisfiedForSuppliedSet"`
	ProofOfPossessionAuthenticated     bool                            `json:"proofOfPossessionAuthenticated"`
	ValidatorSetAuthenticated          bool                            `json:"validatorSetAuthenticated"`
	ValidatorTransitionVerified        bool                            `json:"validatorTransitionVerified"`
	FinalityVerified                   bool                            `json:"finalityVerified"`
	ChainAuthenticated                 bool                            `json:"chainAuthenticated"`
	RealAssetDeploymentAllowed         bool                            `json:"realAssetDeploymentAllowed"`
	SignedSourceHeaderHash             common.Hash                     `json:"signedSourceHeaderHash"`
	SignedTargetHeaderHash             common.Hash                     `json:"signedTargetHeaderHash"`
	SignedSourceTargetHeadersBound     bool                            `json:"signedSourceTargetHeadersBound"`
	DirectSourceTargetParentLink       bool                            `json:"directSourceTargetParentLink"`
	HighestJustifiedSourceVerified     bool                            `json:"highestJustifiedSourceVerified"`
}

// Bind the signed vote data to two full raw headers. Only a direct parent link
// is supported. Supplied ancestry never authenticates highest-justified or
// finalized status; those require an authenticated anchor and fork policy.
func InspectBNBSignedHeaderWitness(header, epoch, source, target []byte, headerLayout, epochLayout string, epochLength uint64) (*BNBVoteSignatureInspection, error) {
	result, err := InspectBNBVoteSignature(header, epoch, headerLayout, epochLayout, epochLength)
	if err != nil {
		return nil, err
	}
	s, err := chain.InspectNativeHeaderJSON(source, chain.BNBEncoding)
	if err != nil {
		return nil, err
	}
	t, err := chain.InspectNativeHeaderJSON(target, chain.BNBEncoding)
	if err != nil {
		return nil, err
	}
	data := result.Vote.Data
	if !s.HashMatchesRPC || !t.HashMatchesRPC || s.BlockNumber != data.SourceNumber || s.RecomputedHash != data.SourceHash || t.BlockNumber != data.TargetNumber || t.RecomputedHash != data.TargetHash {
		return nil, errors.New("signed source/target full header mismatch")
	}
	var parent struct {
		Hash common.Hash `json:"parentHash"`
	}
	if err := json.Unmarshal(target, &parent); err != nil {
		return nil, err
	}
	if data.TargetNumber-data.SourceNumber != 1 || parent.Hash != s.RecomputedHash {
		return nil, errors.New("direct source-target header witness required")
	}
	result.SignedSourceHeaderHash = s.RecomputedHash
	result.SignedTargetHeaderHash = t.RecomputedHash
	result.SignedSourceTargetHeadersBound = true
	result.DirectSourceTargetParentLink = true
	return result, nil
}

func InspectBNBVoteSignature(header, epoch []byte, headerLayout, epochLayout string, epochLength uint64) (*BNBVoteSignatureInspection, error) {
	vote, err := chain.InspectBNBNonEpochAttestation(header, headerLayout)
	if err != nil {
		return nil, err
	}
	if !vote.Present || !vote.TargetMatchesSuppliedParent {
		return nil, errors.New("parent-target attestation required for diagnostic")
	}
	keys, err := InspectBNBEpochKeys(epoch, epochLayout, epochLength)
	if err != nil {
		return nil, err
	}
	if vote.Data.TargetNumber < keys.HeaderNumber || vote.Data.TargetNumber-keys.HeaderNumber >= epochLength {
		return nil, errors.New("vote target outside supplied epoch diagnostic window")
	}
	attestation := &chain.BNBVoteAttestation{VoteAddressSet: vote.VoteBitmap, Data: vote.Data}
	copy(attestation.AggSignature[:], vote.AggregateSignature)
	required, err := verifySuppliedBNBVote(attestation, keys.Validators)
	if err != nil {
		return nil, err
	}
	return &BNBVoteSignatureInspection{HeaderHash: vote.HeaderHash, HeaderNumber: vote.HeaderNumber, Epoch: keys, Vote: vote,
		Domain: bnbVoteDomain, RequiredSuppliedVotes: required, PairingVerifiedAgainstSuppliedKeys: true, QuorumSatisfiedForSuppliedSet: true}, nil
}
