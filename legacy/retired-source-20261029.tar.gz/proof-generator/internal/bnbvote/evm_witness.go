package bnbvote

import (
	"errors"
	"math/big"

	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/common/hexutil"
	blst "github.com/supranational/blst/bindings/go"
)

// This is an untrusted diagnostic witness, not an authenticated validator set.
// EVM computes its own hash-to-curve; HashPoint is only a comparison oracle.
type BNBEVMVoteWitness struct {
	VoteDataHash                   common.Hash           `json:"voteDataHash"`
	VoteBitmap                     uint64                `json:"voteBitmap"`
	ValidatorCount                 int                   `json:"validatorCount"`
	SuppliedKeys                   hexutil.Bytes         `json:"suppliedKeysEIP2537"`
	Signature                      hexutil.Bytes         `json:"signatureEIP2537"`
	HashPoint                      hexutil.Bytes         `json:"referenceHashPointEIP2537"`
	CompressionOracle              []G2CompressionOracle `json:"referenceCompressionOracle"`
	Encoding                       string                `json:"encoding"`
	ProofOfPossessionAuthenticated bool                  `json:"proofOfPossessionAuthenticated"`
	ValidatorSetAuthenticated      bool                  `json:"validatorSetAuthenticated"`
	FinalityVerified               bool                  `json:"finalityVerified"`
	ChainAuthenticated             bool                  `json:"chainAuthenticated"`
	RealAssetDeploymentAllowed     bool                  `json:"realAssetDeploymentAllowed"`
}

// Public point encoding oracle only. A negated signature is not a valid vote
// for this message; SigValidate checks curve/subgroup, not mathematical pairing.
type G2CompressionOracle struct {
	Point      hexutil.Bytes `json:"pointEIP2537"`
	Compressed hexutil.Bytes `json:"compressed"`
}

func eipG1(p *blst.P1Affine) []byte {
	s := p.Serialize()
	result := make([]byte, 128)
	copy(result[16:64], s[:48])
	copy(result[80:128], s[48:])
	return result
}

func eipG2(p *blst.P2Affine) []byte {
	// blst serializes x.c1,x.c0,y.c1,y.c0; EIP-2537 uses c0,c1.
	s := p.Serialize()
	result := make([]byte, 256)
	for i, offset := range []int{48, 0, 144, 96} {
		copy(result[i*64+16:(i+1)*64], s[offset:offset+48])
	}
	return result
}

func BuildBNBEVMVoteWitness(result *BNBVoteSignatureInspection) (*BNBEVMVoteWitness, error) {
	if result == nil || !result.PairingVerifiedAgainstSuppliedKeys || !result.QuorumSatisfiedForSuppliedSet || result.Epoch == nil || result.Vote == nil {
		return nil, errors.New("verified supplied-key diagnostic required")
	}
	w := &BNBEVMVoteWitness{VoteDataHash: result.Vote.VoteDataHash, VoteBitmap: result.Vote.VoteBitmap,
		ValidatorCount: len(result.Epoch.Validators), Encoding: "EIP-2537 Fp64 big-endian, Fp2 c0 then c1"}
	if w.ValidatorCount == 0 || w.ValidatorCount > 64 {
		return nil, errors.New("validator witness cap")
	}
	for _, key := range result.Epoch.Validators {
		pk := new(blst.P1Affine).Uncompress(key.PublicKey)
		if pk == nil || !pk.KeyValidate() {
			return nil, errors.New("invalid witness key")
		}
		w.SuppliedKeys = append(w.SuppliedKeys, eipG1(pk)...)
	}
	sig := new(blst.P2Affine).Uncompress(result.Vote.AggregateSignature)
	if sig == nil || !sig.SigValidate(true) {
		return nil, errors.New("invalid witness signature")
	}
	w.Signature = eipG2(sig)
	w.CompressionOracle = append(w.CompressionOracle, G2CompressionOracle{eipG2(sig), sig.Compress()})
	serialized := sig.Serialize()
	prime, _ := new(big.Int).SetString("1a0111ea397fe69a4b1ba7b6434bacd764774b84f38512bf6730d2a0f6b0f6241eabfffeb153ffffb9feffffffffaaab", 16)
	for _, offset := range []int{96, 144} {
		coordinate := new(big.Int).SetBytes(serialized[offset : offset+48])
		coordinate.Neg(coordinate).Mod(coordinate, prime).FillBytes(serialized[offset : offset+48])
	}
	negated := new(blst.P2Affine).Deserialize(serialized)
	if negated == nil || !negated.SigValidate(true) {
		return nil, errors.New("negated public point encoding oracle failed")
	}
	w.CompressionOracle = append(w.CompressionOracle, G2CompressionOracle{eipG2(negated), negated.Compress()})
	w.HashPoint = eipG2(blst.HashToG2(w.VoteDataHash[:], []byte(bnbVoteDomain)).ToAffine())
	return w, nil
}
