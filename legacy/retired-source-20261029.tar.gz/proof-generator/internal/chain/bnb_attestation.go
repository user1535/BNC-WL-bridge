package chain

import (
	"bytes"
	"encoding/json"
	"errors"
	"math/bits"

	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/common/hexutil"
	"github.com/ethereum/go-ethereum/crypto"
	"github.com/ethereum/go-ethereum/rlp"
)

// These are the pinned v1.7.8 wire fields, not a validator snapshot or BLS
// verifier. Never infer chain authentication from successful decoding.
type BNBVoteData struct {
	SourceNumber uint64      `json:"sourceNumber"`
	SourceHash   common.Hash `json:"sourceHash"`
	TargetNumber uint64      `json:"targetNumber"`
	TargetHash   common.Hash `json:"targetHash"`
}

type BNBVoteAttestation struct {
	VoteAddressSet uint64
	AggSignature   [96]byte
	Data           *BNBVoteData
	Extra          []byte
}

func DecodeBNBVoteAttestation(raw []byte) (*BNBVoteAttestation, common.Hash, error) {
	if len(raw) == 0 || len(raw) > 512 {
		return nil, common.Hash{}, errors.New("attestation diagnostic resource cap")
	}
	var attestation BNBVoteAttestation
	if err := rlp.DecodeBytes(raw, &attestation); err != nil {
		return nil, common.Hash{}, err
	}
	if attestation.Data == nil || attestation.Data.SourceNumber >= attestation.Data.TargetNumber || len(attestation.Extra) > 256 {
		return nil, common.Hash{}, errors.New("invalid vote range/data/extra")
	}
	if attestation.VoteAddressSet == 0 || attestation.Data.SourceHash == (common.Hash{}) || attestation.Data.TargetHash == (common.Hash{}) || attestation.AggSignature == ([96]byte{}) {
		return nil, common.Hash{}, errors.New("empty vote bitmap/hash/signature")
	}
	encoded, err := rlp.EncodeToBytes(attestation.Data)
	if err != nil {
		return nil, common.Hash{}, err
	}
	return &attestation, crypto.Keccak256Hash(encoded), nil
}

type BNBAttestationInspection struct {
	HeaderHash                    common.Hash   `json:"headerHash"`
	HeaderNumber                  uint64        `json:"headerNumber"`
	LayoutAssumption              string        `json:"layoutAssumption"`
	Present                       bool          `json:"attestationPresent"`
	VoteBitmap                    uint64        `json:"voteBitmap"`
	BitmapSetBits                 int           `json:"bitmapSetBits"`
	AggregateSignature            hexutil.Bytes `json:"aggregateSignature"`
	Data                          *BNBVoteData  `json:"data"`
	VoteDataHash                  common.Hash   `json:"voteDataHash"`
	TargetMatchesSuppliedParent   bool          `json:"targetMatchesSuppliedParent"`
	FullHeaderHashBindingVerified bool          `json:"fullHeaderHashBindingVerified"`
	SignatureVerified             bool          `json:"signatureVerified"`
	ValidatorSetAuthenticated     bool          `json:"validatorSetAuthenticated"`
	QuorumVerified                bool          `json:"quorumVerified"`
	FinalityVerified              bool          `json:"finalityVerified"`
	ChainAuthenticated            bool          `json:"chainAuthenticated"`
	RealAssetDeploymentAllowed    bool          `json:"realAssetDeploymentAllowed"`
}

// InspectBNBNonEpochAttestation implements only the explicitly supplied
// post-Luban non-epoch byte layout. Fork/epoch selection is not authenticated;
// callers must not use this diagnostic as a production header policy.
func InspectBNBNonEpochAttestation(raw []byte, layout string) (*BNBAttestationInspection, error) {
	if layout != "post-luban-non-epoch" {
		return nil, errors.New("explicit post-luban-non-epoch diagnostic layout required")
	}
	inspection, err := InspectNativeHeaderJSON(raw, BNBEncoding)
	if err != nil {
		return nil, err
	}
	if !inspection.HashMatchesRPC {
		return nil, errors.New("native header hash does not match supplied RPC hash")
	}
	var header struct {
		Extra  hexutil.Bytes `json:"extraData"`
		Parent common.Hash   `json:"parentHash"`
	}
	if err := json.Unmarshal(raw, &header); err != nil {
		return nil, err
	}
	if len(header.Extra) < 32+65 || len(header.Extra) > 4096 {
		return nil, errors.New("Parlia extraData diagnostic width")
	}
	result := &BNBAttestationInspection{HeaderHash: inspection.RecomputedHash, HeaderNumber: inspection.BlockNumber,
		LayoutAssumption: layout, FullHeaderHashBindingVerified: true}
	middle := header.Extra[32 : len(header.Extra)-65]
	if len(middle) == 0 {
		return result, nil
	}
	attestation, dataHash, err := DecodeBNBVoteAttestation(middle)
	if err != nil {
		return nil, err
	}
	result.Present = true
	result.VoteBitmap = attestation.VoteAddressSet
	result.BitmapSetBits = bits.OnesCount64(attestation.VoteAddressSet)
	result.AggregateSignature = bytes.Clone(attestation.AggSignature[:])
	result.Data, result.VoteDataHash = attestation.Data, dataHash
	result.TargetMatchesSuppliedParent = inspection.BlockNumber > 0 && attestation.Data.TargetNumber == inspection.BlockNumber-1 && attestation.Data.TargetHash == header.Parent
	return result, nil
}
