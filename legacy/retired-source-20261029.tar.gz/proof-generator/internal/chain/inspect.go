package chain

import (
	"context"
	"encoding/json"
	"errors"

	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/common/hexutil"
)

type HeaderInspection struct {
	ChainID            uint64      `json:"chainId"`
	BlockNumber        uint64      `json:"blockNumber"`
	SuppliedHash       common.Hash `json:"suppliedHash"`
	RecomputedHash     common.Hash `json:"recomputedHash"`
	ReceiptRoot        common.Hash `json:"receiptRoot"`
	HeaderRLP          string      `json:"headerRlp"`
	HashMatchesRPC     bool        `json:"hashMatchesRpc"`
	ChainAuthenticated bool        `json:"chainAuthenticated"`
	EncodingProfile    string      `json:"encodingProfile"`
	Offline            bool        `json:"offline"`
	ReferenceCommit    string      `json:"referenceCommit,omitempty"`
}

func InspectLocalHeader(ctx context.Context, url string, chainID, number uint64) (*HeaderInspection, error) {
	if chainID != 31337 && chainID != 31338 {
		return nil, errors.New("header inspector accepts local IDs only; live encoding/finality policy is not implemented")
	}
	adapter, err := dialLocal(ctx, url, chainID, 0)
	if err != nil {
		return nil, err
	}
	defer adapter.Close()
	a := adapter.(*rpcAdapter)
	var raw json.RawMessage
	_, err = retryRead(ctx, func() (bool, error) {
		return true, a.client.Client().CallContext(ctx, &raw, "eth_getBlockByNumber", hexutil.EncodeUint64(number), false)
	})
	if err != nil {
		return nil, err
	}
	encoded, computed, err := CanonicalEthereumHeader(raw)
	if err != nil {
		return nil, err
	}
	var fields struct {
		Hash        common.Hash    `json:"hash"`
		ReceiptRoot common.Hash    `json:"receiptsRoot"`
		Number      hexutil.Uint64 `json:"number"`
	}
	if err := json.Unmarshal(raw, &fields); err != nil {
		return nil, err
	}
	if fields.Hash == (common.Hash{}) || uint64(fields.Number) != number {
		return nil, errors.New("RPC returned another or missing header")
	}
	return &HeaderInspection{ChainID: chainID, BlockNumber: number, SuppliedHash: fields.Hash, RecomputedHash: computed,
		ReceiptRoot: fields.ReceiptRoot, HeaderRLP: hexutil.Encode(encoded), HashMatchesRPC: computed == fields.Hash,
		ChainAuthenticated: false, EncodingProfile: "ethereum-shaped-local-with-prague-requestsHash"}, nil
}
