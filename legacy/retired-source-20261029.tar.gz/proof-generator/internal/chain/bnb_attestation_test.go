package chain

import (
	"bytes"
	"encoding/json"
	"os"
	"testing"

	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/common/hexutil"
	"github.com/ethereum/go-ethereum/rlp"
)

func capturedAttestation(t *testing.T, which string) []byte {
	t.Helper()
	raw, err := os.ReadFile("testdata/native-live-captured/bnb-" + which + ".json")
	if err != nil {
		t.Fatal(err)
	}
	return raw
}

func TestCapturedBNBVoteWireOnlyNeverAuthenticatesFinality(t *testing.T) {
	for _, name := range []string{"parent", "latest"} {
		raw := capturedAttestation(t, name)
		result, err := InspectBNBNonEpochAttestation(raw, "post-luban-non-epoch")
		if err != nil {
			t.Fatal(err)
		}
		if !result.Present || !result.FullHeaderHashBindingVerified || !result.TargetMatchesSuppliedParent || result.BitmapSetBits == 0 || len(result.AggregateSignature) != 96 || result.VoteDataHash == (common.Hash{}) {
			t.Fatalf("unexpected observed vote wire: %+v", result)
		}
		if result.SignatureVerified || result.ValidatorSetAuthenticated || result.QuorumVerified || result.FinalityVerified || result.ChainAuthenticated || result.RealAssetDeploymentAllowed {
			t.Fatal("wire decoding enabled authentication")
		}
		if _, err := InspectBNBNonEpochAttestation(raw, ""); err == nil {
			t.Fatal("implicit fork/layout accepted")
		}
		var changed map[string]any
		json.Unmarshal(raw, &changed)
		changed["receiptsRoot"] = "0x" + string(bytes.Repeat([]byte{'0'}, 64))
		mutated, _ := json.Marshal(changed)
		if _, err := InspectBNBNonEpochAttestation(mutated, "post-luban-non-epoch"); err == nil {
			t.Fatal("changed header hash accepted")
		}
	}
}

func TestMalformedVoteWireRejected(t *testing.T) {
	raw := capturedAttestation(t, "parent")
	var h struct {
		Extra hexutil.Bytes `json:"extraData"`
	}
	json.Unmarshal(raw, &h)
	attestation, _, err := DecodeBNBVoteAttestation(h.Extra[32 : len(h.Extra)-65])
	if err != nil {
		t.Fatal(err)
	}
	for variant := 0; variant < 7; variant++ {
		bad := *attestation
		data := *bad.Data
		bad.Data = &data
		switch variant {
		case 0:
			bad.VoteAddressSet = 0
		case 1:
			bad.AggSignature = [96]byte{}
		case 2:
			bad.Data.SourceNumber = bad.Data.TargetNumber
		case 3:
			bad.Data.SourceHash = common.Hash{}
		case 4:
			bad.Data.TargetHash = common.Hash{}
		case 5:
			bad.Extra = make([]byte, 257)
		case 6:
			bad.Data = nil
		}
		encoded, err := rlp.EncodeToBytes(&bad)
		if err != nil {
			t.Fatal(err)
		}
		if _, _, err := DecodeBNBVoteAttestation(encoded); err == nil {
			t.Fatalf("variant%d accepted", variant)
		}
	}
	encoded, _ := rlp.EncodeToBytes(attestation)
	if _, _, err := DecodeBNBVoteAttestation(append(encoded, 0x80)); err == nil {
		t.Fatal("trailing RLP accepted")
	}
	for end := 0; end < len(encoded); end++ {
		if _, _, err := DecodeBNBVoteAttestation(encoded[:end]); err == nil {
			t.Fatal("truncated wire accepted")
		}
	}
}
