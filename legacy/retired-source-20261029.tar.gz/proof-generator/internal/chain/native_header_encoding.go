package chain

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"math"
	"math/big"

	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/common/hexutil"
	"github.com/ethereum/go-ethereum/core/types"
	"github.com/ethereum/go-ethereum/crypto"
	"github.com/ethereum/go-ethereum/rlp"
)

const (
	WorldLandEncoding = "worldland-v1.1.3"
	BNBEncoding       = "bnb-v1.7.8"
)

var baseHeaderFields = []string{"parentHash", "sha3Uncles", "miner", "stateRoot", "transactionsRoot", "receiptsRoot", "logsBloom", "difficulty", "number", "gasLimit", "gasUsed", "timestamp", "extraData", "mixHash", "nonce"}

// Native codecs are offline serialization diagnostics pinned to node releases.
// They do not enable live RPC, proving, fork validity, consensus or finality.
func decodeNativeHeader(raw []byte, extra []string) (map[string]json.RawMessage, *types.Header, error) {
	if len(raw) > 64*1024 {
		return nil, nil, errors.New("header JSON exceeds diagnostic resource limit")
	}
	allowed := make(map[string]bool)
	for _, name := range append(append([]string{}, baseHeaderFields...), extra...) {
		allowed[name] = true
	}
	for _, name := range []string{"hash", "size", "totalDifficulty", "transactions", "uncles", "withdrawals"} {
		allowed[name] = true // RPC metadata: never serialized as header fields.
	}
	decoder := json.NewDecoder(bytes.NewReader(raw))
	start, err := decoder.Token()
	if err != nil || start != json.Delim('{') {
		return nil, nil, errors.New("header must be a JSON object")
	}
	fields := make(map[string]json.RawMessage)
	for decoder.More() {
		nameToken, err := decoder.Token()
		if err != nil {
			return nil, nil, err
		}
		name, ok := nameToken.(string)
		if !ok || !allowed[name] {
			return nil, nil, fmt.Errorf("unsupported header field %q for pinned encoding", name)
		}
		if _, exists := fields[name]; exists {
			return nil, nil, fmt.Errorf("duplicate header field %q", name)
		}
		var value json.RawMessage
		if err := decoder.Decode(&value); err != nil {
			return nil, nil, err
		}
		fields[name] = value
	}
	if _, err := decoder.Token(); err != nil {
		return nil, nil, err
	}
	if _, err := decoder.Token(); err != io.EOF {
		return nil, nil, errors.New("trailing JSON after header")
	}
	for _, name := range baseHeaderFields {
		value, ok := fields[name]
		if !ok || bytes.Equal(bytes.TrimSpace(value), []byte("null")) {
			return nil, nil, fmt.Errorf("missing required header field %q", name)
		}
	}
	var header types.Header
	if err := json.Unmarshal(raw, &header); err != nil {
		return nil, nil, err
	}
	if header.Number == nil || !header.Number.IsUint64() || header.Difficulty == nil {
		return nil, nil, errors.New("invalid header number or difficulty")
	}
	return fields, &header, nil
}

func baseHeaderValues(h *types.Header) []any {
	return []any{h.ParentHash, h.UncleHash, h.Coinbase, h.Root, h.TxHash, h.ReceiptHash, h.Bloom,
		h.Difficulty, h.Number, h.GasLimit, h.GasUsed, h.Time, h.Extra, h.MixDigest, h.Nonce}
}

func encodeHeaderValues(values []any) ([]byte, common.Hash, error) {
	encoded, err := rlp.EncodeToBytes(values)
	if err != nil {
		return nil, common.Hash{}, err
	}
	return encoded, crypto.Keccak256Hash(encoded), nil
}

// CanonicalWorldLandHeader matches v1.1.3's generated EncodeRLP: optional
// fields are independently omitted, rather than padded to Ethereum positions.
func CanonicalWorldLandHeader(raw []byte) ([]byte, common.Hash, error) {
	fields, h, err := decodeNativeHeader(raw, []string{"baseFeePerGas", "codeword", "codelength"})
	if err != nil {
		return nil, common.Hash{}, err
	}
	values := baseHeaderValues(h)
	if value, ok := fields["baseFeePerGas"]; ok {
		if bytes.Equal(bytes.TrimSpace(value), []byte("null")) {
			return nil, common.Hash{}, errors.New("WorldLand RPC omits absent baseFee; null is unsupported")
		}
		values = append(values, h.BaseFee)
	}
	if value, ok := fields["codeword"]; ok {
		var codeword hexutil.Bytes
		if bytes.Equal(bytes.TrimSpace(value), []byte("null")) {
			return nil, common.Hash{}, errors.New("WorldLand RPC omits nil codeword; null is unsupported")
		}
		if err := json.Unmarshal(value, &codeword); err != nil {
			return nil, common.Hash{}, err
		}
		values = append(values, []byte(codeword)) // Present empty bytes must encode 0x80.
	}
	if value, ok := fields["codelength"]; ok {
		var length hexutil.Uint64
		if bytes.Equal(bytes.TrimSpace(value), []byte("null")) {
			return nil, common.Hash{}, errors.New("null WorldLand codelength is unsupported")
		}
		if err := json.Unmarshal(value, &length); err != nil {
			return nil, common.Hash{}, err
		}
		if length != 0 {
			values = append(values, uint64(length))
		}
	}
	return encodeHeaderValues(values)
}

// CanonicalBNBHeader follows the pinned generated encoder, including empty RLP
// placeholders for omitted optional fields before a later present field.
// Parlia extraData bytes are preserved; signatures/votes are not validated.
func CanonicalBNBHeader(raw []byte) ([]byte, common.Hash, error) {
	fields, h, err := decodeNativeHeader(raw, []string{"baseFeePerGas", "withdrawalsRoot", "blobGasUsed", "excessBlobGas", "parentBeaconBlockRoot", "requestsHash", "milliTimestamp"})
	if err != nil {
		return nil, common.Hash{}, err
	}
	// Pinned ethapi publishes a derived RPC field, not another RLP element.
	// Validate consistency without rewriting Time or MixDigest. Reject overflow
	// and out-of-range subsecond diagnostics instead of truncating/wrapping.
	if value, present := fields["milliTimestamp"]; present {
		var milliseconds hexutil.Uint64
		if err := json.Unmarshal(value, &milliseconds); err != nil {
			return nil, common.Hash{}, err
		}
		fraction := new(big.Int).SetBytes(h.MixDigest[:])
		if !fraction.IsUint64() || fraction.Uint64() >= 1000 || h.Time > (math.MaxUint64-fraction.Uint64())/1000 {
			return nil, common.Hash{}, errors.New("BNB millisecond diagnostic is out of range")
		}
		if uint64(milliseconds) != h.Time*1000+fraction.Uint64() {
			return nil, common.Hash{}, errors.New("BNB milliTimestamp differs from timestamp/mixHash")
		}
	}
	names := []string{"baseFeePerGas", "withdrawalsRoot", "blobGasUsed", "excessBlobGas", "parentBeaconBlockRoot", "requestsHash"}
	optional := make([]any, len(names))
	last := -1
	for index, name := range names {
		optional[index] = []byte(nil)
		value, ok := fields[name]
		if !ok || bytes.Equal(bytes.TrimSpace(value), []byte("null")) {
			continue
		}
		last = index
		switch name {
		case "baseFeePerGas":
			optional[index] = h.BaseFee
		case "withdrawalsRoot":
			optional[index] = *h.WithdrawalsHash
		case "blobGasUsed":
			optional[index] = *h.BlobGasUsed
		case "excessBlobGas":
			optional[index] = *h.ExcessBlobGas
		case "parentBeaconBlockRoot":
			optional[index] = *h.ParentBeaconRoot
		case "requestsHash":
			var hash common.Hash
			if err := json.Unmarshal(value, &hash); err != nil {
				return nil, common.Hash{}, err
			}
			optional[index] = hash
		}
	}
	return encodeHeaderValues(append(baseHeaderValues(h), optional[:last+1]...))
}

func InspectNativeHeaderJSON(raw []byte, profile string) (*HeaderInspection, error) {
	var encoded []byte
	var computed common.Hash
	var err error
	var commit string
	switch profile {
	case WorldLandEncoding:
		encoded, computed, err = CanonicalWorldLandHeader(raw)
		commit = "5de8aad8131d2495c98b95558697e5a04f518630"
	case BNBEncoding:
		encoded, computed, err = CanonicalBNBHeader(raw)
		commit = "cdb7548b5baacfdae92f9f63437d6456411665f3"
	default:
		return nil, errors.New("unsupported offline native encoding profile")
	}
	if err != nil {
		return nil, err
	}
	var fields struct {
		Hash        common.Hash    `json:"hash"`
		ReceiptRoot common.Hash    `json:"receiptsRoot"`
		Number      hexutil.Uint64 `json:"number"`
	}
	if err := json.Unmarshal(raw, &fields); err != nil {
		return nil, err
	}
	if fields.Hash == (common.Hash{}) {
		return nil, errors.New("offline header must include a nonzero supplied hash")
	}
	return &HeaderInspection{BlockNumber: uint64(fields.Number), SuppliedHash: fields.Hash, RecomputedHash: computed,
		ReceiptRoot: fields.ReceiptRoot, HeaderRLP: hexutil.Encode(encoded), HashMatchesRPC: computed == fields.Hash,
		EncodingProfile: profile, Offline: true, ReferenceCommit: commit, ChainAuthenticated: false}, nil
}
