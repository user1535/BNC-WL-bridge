package chain

import (
	"encoding/json"
	"os"
	"testing"

	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/core/types"
)

func TestPragueHeaderRecomputesRPCBlockHash(t *testing.T) {
	raw, err := os.ReadFile("testdata/anvil-prague-header.json")
	if err != nil {
		t.Fatal(err)
	}
	var fields map[string]json.RawMessage
	json.Unmarshal(raw, &fields)
	var expected common.Hash
	json.Unmarshal(fields["hash"], &expected)
	encoded, actual, err := CanonicalEthereumHeader(raw)
	if err != nil || actual != expected || len(encoded) == 0 {
		t.Fatalf("header hash: %v %s %s", err, actual, expected)
	}
	var legacy types.Header
	json.Unmarshal(raw, &legacy)
	if legacy.Hash() == expected {
		t.Fatal("fixture no longer demonstrates missing Prague requestsHash")
	}
	fields["receiptsRoot"] = json.RawMessage(`"0x0000000000000000000000000000000000000000000000000000000000000001"`)
	altered, _ := json.Marshal(fields)
	_, wrong, err := CanonicalEthereumHeader(altered)
	if err != nil || wrong == expected {
		t.Fatal("receipt root change did not change hash")
	}
	delete(fields, "withdrawalsRoot")
	altered, _ = json.Marshal(fields)
	if _, _, err := CanonicalEthereumHeader(altered); err == nil {
		t.Fatal("unsupported optional field gap accepted")
	}
}
