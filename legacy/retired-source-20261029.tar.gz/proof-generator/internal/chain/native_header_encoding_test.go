package chain

import (
	"bytes"
	"encoding/json"
	"os"
	"strings"
	"testing"

	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/common/hexutil"
	"github.com/ethereum/go-ethereum/rlp"
)

type nativeFixture struct {
	Name    string          `json:"name"`
	Profile string          `json:"profile"`
	RPC     json.RawMessage `json:"rpc"`
	RLP     string          `json:"rlp"`
	Hash    common.Hash     `json:"hash"`
}

func nativeFixtures(t *testing.T) []nativeFixture {
	t.Helper()
	raw, err := os.ReadFile("testdata/native-header-fixtures.json")
	if err != nil {
		t.Fatal(err)
	}
	var file struct {
		Synthetic          bool
		ChainAuthenticated bool
		Fixtures           []nativeFixture
	}
	if err := json.Unmarshal(raw, &file); err != nil {
		t.Fatal(err)
	}
	if !file.Synthetic || file.ChainAuthenticated || len(file.Fixtures) != 76 {
		t.Fatal("wrong oracle provenance")
	}
	return file.Fixtures
}

func TestNativeHeadersAgainstPinnedUpstreamEncoders(t *testing.T) {
	for _, fixture := range nativeFixtures(t) {
		t.Run(fixture.Name, func(t *testing.T) {
			inspection, err := InspectNativeHeaderJSON(fixture.RPC, fixture.Profile)
			if err != nil {
				t.Fatal(err)
			}
			if !inspection.Offline || inspection.ChainAuthenticated || !inspection.HashMatchesRPC || inspection.ReferenceCommit == "" || inspection.RecomputedHash != fixture.Hash || inspection.HeaderRLP != fixture.RLP {
				t.Fatalf("upstream serialization mismatch: %+v", inspection)
			}
		})
	}
}

func TestWorldLandIndependentOmissionAndBNBPadding(t *testing.T) {
	fixtures := nativeFixtures(t)
	wordOnly := fixtures[4] // fee0, nonempty word, length0
	encoded, _, err := CanonicalWorldLandHeader(wordOnly.RPC)
	if err != nil {
		t.Fatal(err)
	}
	var fields []rlp.RawValue
	if err := rlp.DecodeBytes(encoded, &fields); err != nil {
		t.Fatal(err)
	}
	if len(fields) != 16 || !bytes.Equal(fields[15], []byte{0x84, 1, 2, 3, 255}) {
		t.Fatal("WorldLand encoder incorrectly padded absent fee")
	}
	absent, empty := fixtures[0], fixtures[2]
	if absent.Hash == empty.Hash {
		t.Fatal("nil and present empty codeword collapsed")
	}
	requestOnly := fixtures[12+32]
	encoded, _, err = CanonicalBNBHeader(requestOnly.RPC)
	if err != nil {
		t.Fatal(err)
	}
	if err := rlp.DecodeBytes(encoded, &fields); err != nil {
		t.Fatal(err)
	}
	if len(fields) != 21 {
		t.Fatal("BNB requestsHash incorrectly shifted")
	}
	for index := 15; index < 20; index++ {
		if !bytes.Equal(fields[index], []byte{0x80}) {
			t.Fatal("BNB optional gap not empty")
		}
	}
}

func TestNativeHeaderMalformedFieldsAndProfileSeparation(t *testing.T) {
	fixtures := nativeFixtures(t)
	base := fixtures[0]
	for _, tc := range []struct{ name, value string }{
		{"codeword", `null`}, {"codeword", `"0x0"`}, {"codeword", `[1,2]`},
		{"codelength", `"0x01"`}, {"codelength", `"0x10000000000000000"`},
		{"baseFeePerGas", `null`}, {"nonce", `"0x01"`}, {"miner", `null`},
		{"receiptsRoot", `"0x01"`}, {"number", `"0x10000000000000000"`},
		{"withdrawalsRoot", `"0x00"`}, {"futureConsensusField", `"0x0"`},
	} {
		t.Run(tc.name+tc.value, func(t *testing.T) {
			var fields map[string]json.RawMessage
			json.Unmarshal(base.RPC, &fields)
			fields[tc.name] = json.RawMessage(tc.value)
			raw, _ := json.Marshal(fields)
			if _, _, err := CanonicalWorldLandHeader(raw); err == nil {
				t.Fatal("malformed/foreign field accepted")
			}
		})
	}
	for _, name := range []string{"miner", "mixHash", "nonce", "number"} {
		var fields map[string]json.RawMessage
		json.Unmarshal(base.RPC, &fields)
		delete(fields, name)
		raw, _ := json.Marshal(fields)
		if _, _, err := CanonicalWorldLandHeader(raw); err == nil {
			t.Fatal("required field defaulted to zero")
		}
	}
	duplicate := append(append([]byte{}, base.RPC[:len(base.RPC)-1]...), []byte(`,"number":"0x1"}`)...)
	for _, raw := range [][]byte{duplicate, append(append([]byte{}, base.RPC...), []byte(` {}`)...)} {
		if _, _, err := CanonicalWorldLandHeader(raw); err == nil {
			t.Fatal("duplicate/trailing JSON accepted")
		}
	}
	wordOnly := fixtures[4]
	if _, _, err := CanonicalBNBHeader(wordOnly.RPC); err == nil {
		t.Fatal("WorldLand extension used with BNB profile")
	}
	requestOnly := fixtures[12+32]
	if _, _, err := CanonicalWorldLandHeader(requestOnly.RPC); err == nil {
		t.Fatal("BNB extension used with WorldLand profile")
	}
	if _, err := InspectNativeHeaderJSON(base.RPC, "automatic"); err == nil {
		t.Fatal("unknown profile accepted")
	}
}

func TestNativeHeaderMutationChangesHashWithoutAuthenticatingChain(t *testing.T) {
	for _, fixture := range []nativeFixture{nativeFixtures(t)[4], nativeFixtures(t)[12+63]} {
		var fields map[string]json.RawMessage
		json.Unmarshal(fixture.RPC, &fields)
		fields["receiptsRoot"], _ = json.Marshal(common.HexToHash("0xdeadbeef"))
		raw, _ := json.Marshal(fields)
		inspection, err := InspectNativeHeaderJSON(raw, fixture.Profile)
		if err != nil || inspection.HashMatchesRPC || inspection.ChainAuthenticated {
			t.Fatal("root mutation not detected")
		}
		fields["hash"], _ = json.Marshal(inspection.RecomputedHash)
		raw, _ = json.Marshal(fields)
		inspection, err = InspectNativeHeaderJSON(raw, fixture.Profile)
		if err != nil || !inspection.HashMatchesRPC || inspection.ChainAuthenticated {
			t.Fatal("hash equality must not claim consensus")
		}
		if _, err := hexutil.Decode(inspection.HeaderRLP); err != nil {
			t.Fatal(err)
		}
	}
}

// Actual RPC-captured empty blocks complement the synthetic oracle. Hash equality
// is serialization evidence only; it does not establish fork validity/finality.
func TestWorldLandCapturedRPCHeadersAndRootMutation(t *testing.T) {
	for _, name := range []string{"worldland-parent.json", "worldland-latest.json"} {
		raw, err := os.ReadFile("testdata/native-live-captured/" + name)
		if err != nil {
			t.Fatal(err)
		}
		inspection, err := InspectNativeHeaderJSON(raw, WorldLandEncoding)
		if err != nil || !inspection.HashMatchesRPC || inspection.ChainAuthenticated || !inspection.Offline {
			t.Fatalf("captured header: %+v %v", inspection, err)
		}
		var fields map[string]interface{}
		if err := json.Unmarshal(raw, &fields); err != nil {
			t.Fatal(err)
		}
		fields["receiptsRoot"] = "0x" + strings.Repeat("44", 32)
		changed, _ := json.Marshal(fields)
		bad, err := InspectNativeHeaderJSON(changed, WorldLandEncoding)
		if err != nil {
			t.Fatal(err)
		}
		if bad.HashMatchesRPC || bad.ChainAuthenticated {
			t.Fatal("changed header was authenticated")
		}
	}
}

func TestBNBCapturedHeadersAndDerivedMillisecondMetadata(t *testing.T) {
	for _, name := range []string{"bnb-parent.json", "bnb-latest.json"} {
		raw, err := os.ReadFile("testdata/native-live-captured/" + name)
		if err != nil {
			t.Fatal(err)
		}
		inspection, err := InspectNativeHeaderJSON(raw, BNBEncoding)
		if err != nil || !inspection.HashMatchesRPC || inspection.ChainAuthenticated {
			t.Fatalf("captured BNB: %+v %v", inspection, err)
		}
		var fields map[string]interface{}
		if err := json.Unmarshal(raw, &fields); err != nil {
			t.Fatal(err)
		}
		fields["milliTimestamp"] = "0x1"
		changed, _ := json.Marshal(fields)
		if _, _, err := CanonicalBNBHeader(changed); err == nil {
			t.Fatal("inconsistent milliTimestamp accepted")
		}
		delete(fields, "milliTimestamp")
		without, _ := json.Marshal(fields)
		other, err := InspectNativeHeaderJSON(without, BNBEncoding)
		if err != nil || !other.HashMatchesRPC || !bytes.Equal(common.FromHex(other.HeaderRLP), common.FromHex(inspection.HeaderRLP)) {
			t.Fatal("derived metadata affected header RLP", err)
		}
		fields["milliTimestamp"] = "0x00"
		changed, _ = json.Marshal(fields)
		if _, _, err := CanonicalBNBHeader(changed); err == nil {
			t.Fatal("noncanonical milliseconds accepted")
		}
	}
}
