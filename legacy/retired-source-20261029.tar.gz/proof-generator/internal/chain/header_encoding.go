package chain

import (
	"encoding/json"
	"errors"

	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/core/types"
	"github.com/ethereum/go-ethereum/crypto"
	"github.com/ethereum/go-ethereum/rlp"
)

// CanonicalEthereumHeader diagnoses hash/receiptRoot binding for Ethereum-shaped
// local headers, including Prague requestsHash missing from geth v1.14.12.
// It does not authenticate consensus/finality or implement a live chain adapter.
func CanonicalEthereumHeader(raw []byte) ([]byte, common.Hash, error) {
	var fields map[string]json.RawMessage
	if err := json.Unmarshal(raw, &fields); err != nil {
		return nil, common.Hash{}, err
	}
	var h types.Header
	if err := json.Unmarshal(raw, &h); err != nil {
		return nil, common.Hash{}, err
	}
	if h.Number == nil || h.Difficulty == nil {
		return nil, common.Hash{}, errors.New("missing canonical header fields")
	}
	values := []any{h.ParentHash, h.UncleHash, h.Coinbase, h.Root, h.TxHash, h.ReceiptHash, h.Bloom, h.Difficulty, h.Number, h.GasLimit, h.GasUsed, h.Time, h.Extra, h.MixDigest, h.Nonce}
	var requestsHash common.Hash
	if present, ok := fields["requestsHash"]; ok && string(present) != "null" {
		if err := json.Unmarshal(present, &requestsHash); err != nil {
			return nil, common.Hash{}, err
		}
	}
	optional := []struct {
		name  string
		value any
	}{
		{"baseFeePerGas", h.BaseFee}, {"withdrawalsRoot", h.WithdrawalsHash},
		{"blobGasUsed", h.BlobGasUsed}, {"excessBlobGas", h.ExcessBlobGas},
		{"parentBeaconBlockRoot", h.ParentBeaconRoot}, {"requestsHash", requestsHash},
	}
	gap := false
	for _, field := range optional {
		encoded, ok := fields[field.name]
		if !ok || string(encoded) == "null" {
			gap = true
			continue
		}
		if gap {
			return nil, common.Hash{}, errors.New("unsupported gap in optional Ethereum header fields")
		}
		values = append(values, field.value)
	}
	encoded, err := rlp.EncodeToBytes(values)
	if err != nil {
		return nil, common.Hash{}, err
	}
	return encoded, crypto.Keccak256Hash(encoded), nil
}
