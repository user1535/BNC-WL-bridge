package header

import (
	"bytes"
	"crypto/sha256"
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/common/hexutil"
)

type guestFixture struct {
	ChainID    uint64   `json:"chain_id"`
	AnchorHash [32]byte `json:"anchor_hash"`
	Headers    []struct {
		Number      uint64   `json:"number"`
		BlockHash   [32]byte `json:"block_hash"`
		ParentHash  [32]byte `json:"parent_hash"`
		ReceiptRoot [32]byte `json:"receipt_root"`
	} `json:"headers"`
}

func TestBatchArtifactsMatchExecutedGuestJournal(t *testing.T) {
	path := filepath.Join("..", "..", "..", "risc0", "fixtures")
	raw, err := os.ReadFile(filepath.Join(path, "local-three-headers.json"))
	if err != nil {
		t.Fatal(err)
	}
	var fixture guestFixture
	if err := json.Unmarshal(raw, &fixture); err != nil {
		t.Fatal(err)
	}
	headers := make([]GuestHeader, len(fixture.Headers))
	for i, header := range fixture.Headers {
		headers[i] = GuestHeader{Number: header.Number, BlockHash: common.Hash(header.BlockHash),
			ParentHash: common.Hash(header.ParentHash), ReceiptRoot: common.Hash(header.ReceiptRoot)}
	}
	artifacts, err := BuildBatchArtifacts(fixture.ChainID, common.Hash(fixture.AnchorHash), headers)
	if err != nil {
		t.Fatal(err)
	}
	saved, err := os.ReadFile(filepath.Join(path, "local-three-headers.journal.hex"))
	if err != nil {
		t.Fatal(err)
	}
	guestJournal, err := hexutil.Decode(strings.TrimSpace(string(saved)))
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(artifacts.Journal, guestJournal) {
		t.Fatal("Go journal differs from executed RISC0 guest")
	}
	if len(artifacts.BatchData) != 64+128*len(headers) {
		t.Fatal("invalid ABI batch length")
	}
	digest := sha256.Sum256(artifacts.BatchData)
	if common.Hash(digest) != common.HexToHash("0x45b86503b5e63c01cd2bb4b18715380fcf216cab666a5ae379dc947197891aa7") {
		t.Fatal("Go ABI batch differs from Solidity fixture")
	}
	altered := append([]GuestHeader(nil), headers...)
	altered[1].ParentHash = common.HexToHash("0xff")
	if _, err := BuildBatchArtifacts(fixture.ChainID, common.Hash(fixture.AnchorHash), altered); err == nil {
		t.Fatal("broken parent link accepted")
	}
}
