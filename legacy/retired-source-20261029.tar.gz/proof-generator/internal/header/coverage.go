package header

import (
	"context"
	"errors"
	"fmt"
	"sync"

	"github.com/ethereum/go-ethereum/common"
)

type HeaderRef struct {
	Number      uint64
	BlockHash   common.Hash
	ReceiptRoot common.Hash
}

type Batch struct {
	SourceChainID uint64
	Start         uint64
	End           uint64
	AnchorHash    common.Hash
	EndHash       common.Hash
	Headers       []HeaderRef
}

// CoverageReader must inspect an accepted destination-chain header source.
// A local cached batch alone is never evidence of authentication.
type CoverageReader interface {
	IsBlockCovered(ctx context.Context, chainID, number uint64, hash common.Hash) (bool, error)
}

type Store struct {
	mu      sync.RWMutex
	byChain map[uint64][]Batch
	reader  CoverageReader
}

func NewStore(reader CoverageReader) (*Store, error) {
	if reader == nil {
		return nil, errors.New("on-chain coverage reader required")
	}
	return &Store{byChain: make(map[uint64][]Batch), reader: reader}, nil
}

func (s *Store) AddCandidate(batch Batch) error {
	if batch.SourceChainID == 0 || batch.End < batch.Start || len(batch.Headers) != int(batch.End-batch.Start+1) ||
		len(batch.Headers) == 0 || batch.AnchorHash == (common.Hash{}) || batch.EndHash != batch.Headers[len(batch.Headers)-1].BlockHash {
		return errors.New("invalid batch range or hash")
	}
	for i, ref := range batch.Headers {
		if ref.Number != batch.Start+uint64(i) || ref.BlockHash == (common.Hash{}) || ref.ReceiptRoot == (common.Hash{}) {
			return fmt.Errorf("invalid header at %d", i)
		}
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	// Replace stale candidates covering the same range after a source reorganization.
	existing := s.byChain[batch.SourceChainID]
	kept := existing[:0]
	for _, old := range existing {
		if old.End < batch.Start || old.Start > batch.End {
			kept = append(kept, old)
		}
	}
	s.byChain[batch.SourceChainID] = append(kept, batch)
	return nil
}

func (s *Store) FindCandidate(chainID, number uint64, hash common.Hash) (*Batch, bool) {
	s.mu.RLock()
	defer s.mu.RUnlock()
	for _, batch := range s.byChain[chainID] {
		if number >= batch.Start && number <= batch.End && batch.Headers[number-batch.Start].BlockHash == hash {
			copyBatch := batch
			return &copyBatch, true
		}
	}
	return nil, false
}

func (s *Store) IsBlockCovered(ctx context.Context, chainID, number uint64, hash common.Hash) (bool, error) {
	if _, ok := s.FindCandidate(chainID, number, hash); !ok {
		return false, nil
	}
	// A candidate is a lookup hint. Trust comes from the accepted destination state.
	return s.reader.IsBlockCovered(ctx, chainID, number, hash)
}
