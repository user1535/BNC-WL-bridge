package header

import (
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"time"

	"github.com/ethereum/go-ethereum/common"
	"golang.org/x/sys/unix"
)

type ProofCacheKey struct {
	SourceChainID   uint64      `json:"sourceChainId"`
	StartBlock      uint64      `json:"startBlock"`
	EndBlock        uint64      `json:"endBlock"`
	StartAnchorHash common.Hash `json:"startAnchorHash"`
	EndBlockHash    common.Hash `json:"endBlockHash"`
	BatchRoot       common.Hash `json:"batchRoot"`
	ImageID         common.Hash `json:"imageId"`
}

type CachedProof struct {
	Version   uint32        `json:"version,omitempty"`
	Key       ProofCacheKey `json:"key"`
	ProofData []byte        `json:"proofData"` // Serialized receipt; not an EVM seal.
	Journal   []byte        `json:"journal"`
}

type ProofVerifier func(proofData, journal []byte) error

type ProofCache struct {
	Directory string
	Verify    ProofVerifier
}

func (k ProofCacheKey) validate() error {
	if k.SourceChainID == 0 || k.EndBlock < k.StartBlock || k.EndBlock-k.StartBlock >= 4096 ||
		k.StartAnchorHash == (common.Hash{}) || k.EndBlockHash == (common.Hash{}) || k.BatchRoot == (common.Hash{}) || k.ImageID == (common.Hash{}) {
		return errors.New("invalid proof cache key")
	}
	return nil
}

func (k ProofCacheKey) filename() (string, error) {
	if err := k.validate(); err != nil {
		return "", err
	}
	var data [8*3 + 32*4]byte
	binary.BigEndian.PutUint64(data[:8], k.SourceChainID)
	binary.BigEndian.PutUint64(data[8:16], k.StartBlock)
	binary.BigEndian.PutUint64(data[16:24], k.EndBlock)
	copy(data[24:56], k.StartAnchorHash[:])
	copy(data[56:88], k.EndBlockHash[:])
	copy(data[88:120], k.BatchRoot[:])
	copy(data[120:], k.ImageID[:])
	digest := sha256.Sum256(data[:])
	return hex.EncodeToString(digest[:]) + ".json", nil
}

// The 224-byte guest journal binds the proof to all fields used for cache lookup.
func (k ProofCacheKey) validateJournal(journal []byte) error {
	if err := k.validate(); err != nil {
		return err
	}
	if len(journal) != 224 {
		return errors.New("invalid header journal length")
	}
	word := func(offset int) (uint64, bool) {
		var zero [24]byte
		return binary.BigEndian.Uint64(journal[offset+24 : offset+32]), bytes.Equal(journal[offset:offset+24], zero[:])
	}
	chainID, chainOK := word(0)
	start, startOK := word(32)
	end, endOK := word(64)
	count, countOK := word(192)
	if !chainOK || !startOK || !endOK || !countOK ||
		chainID != k.SourceChainID || start != k.StartBlock || end != k.EndBlock ||
		count != k.EndBlock-k.StartBlock+1 ||
		!bytes.Equal(journal[96:128], k.StartAnchorHash[:]) ||
		!bytes.Equal(journal[128:160], k.EndBlockHash[:]) ||
		!bytes.Equal(journal[160:192], k.BatchRoot[:]) {
		return errors.New("header journal does not match cache key")
	}
	return nil
}

func (c ProofCache) Put(value CachedProof) error {
	if value.Version > 1 {
		return errors.New("unsupported proof cache version")
	}
	value.Version = 1
	if c.Verify == nil {
		return errors.New("proof verifier required")
	}
	if err := c.Verify(value.ProofData, value.Journal); err != nil {
		return fmt.Errorf("unverified proof: %w", err)
	}
	if err := value.Key.validateJournal(value.Journal); err != nil {
		return err
	}
	name, err := value.Key.filename()
	if err != nil {
		return err
	}
	if err := os.MkdirAll(c.Directory, 0700); err != nil {
		return err
	}
	raw, err := json.Marshal(value)
	if err != nil {
		return err
	}
	if len(raw) > maxCacheArtifactBytes {
		return errors.New("proof cache artifact exceeds 64MiB write limit")
	}
	temp, err := os.CreateTemp(c.Directory, ".proof-*")
	if err != nil {
		return err
	}
	defer os.Remove(temp.Name())
	if _, err := temp.Write(raw); err != nil {
		temp.Close()
		return err
	}
	if err := temp.Close(); err != nil {
		return err
	}
	return os.Rename(temp.Name(), filepath.Join(c.Directory, name))
}

func (c ProofCache) Get(key ProofCacheKey) (*CachedProof, error) {
	if c.Verify == nil {
		return nil, errors.New("proof verifier required")
	}
	name, err := key.filename()
	if err != nil {
		return nil, err
	}
	raw, err := readRegularCacheFile(filepath.Join(c.Directory, name))
	if err != nil {
		return nil, err
	}
	return c.verifyRaw(key, raw)
}

// Verify the exact immutable byte snapshot read by Get or the read-only audit.
func (c ProofCache) verifyRaw(key ProofCacheKey, raw []byte) (*CachedProof, error) {
	var value CachedProof
	if err := json.Unmarshal(raw, &value); err != nil {
		return nil, err
	}
	if value.Key != key {
		return nil, errors.New("cache key mismatch")
	}
	// Version 0 is the previous schema; it still requires full cryptographic/key verification.
	if value.Version > 1 {
		return nil, errors.New("unsupported proof cache version")
	}
	if err := c.Verify(value.ProofData, value.Journal); err != nil {
		return nil, fmt.Errorf("cached proof rejected: %w", err)
	}
	if err := key.validateJournal(value.Journal); err != nil {
		return nil, err
	}
	return &value, nil
}

const maxCacheArtifactBytes = 64 << 20

func openRegularCacheFile(path string, flags int, mode uint32) (*os.File, error) {
	fd, err := unix.Open(path, flags|unix.O_NOFOLLOW|unix.O_NONBLOCK|unix.O_CLOEXEC, mode)
	if err != nil {
		return nil, err
	}
	file := os.NewFile(uintptr(fd), path)
	info, err := file.Stat()
	if err != nil || !info.Mode().IsRegular() {
		file.Close()
		if err != nil {
			return nil, err
		}
		return nil, errors.New("proof cache path is not a regular file")
	}
	return file, nil
}

func readRegularCacheFile(path string) ([]byte, error) {
	file, err := openRegularCacheFile(path, unix.O_RDONLY, 0)
	if err != nil {
		return nil, err
	}
	defer file.Close()
	info, err := file.Stat()
	if err != nil {
		return nil, err
	}
	if info.Size() > maxCacheArtifactBytes {
		return nil, errors.New("proof cache artifact exceeds 64MiB read limit")
	}
	raw, err := io.ReadAll(io.LimitReader(file, maxCacheArtifactBytes+1))
	if err != nil {
		return nil, err
	}
	if len(raw) > maxCacheArtifactBytes {
		return nil, errors.New("proof cache artifact exceeds 64MiB read limit")
	}
	return raw, nil
}

// Quarantine preserves a rejected artifact. Call only under WithKeyLock and an
// explicit repair request; invalid data must never become an automatic cache hit.
func (c ProofCache) Quarantine(key ProofCacheKey) (string, error) {
	name, err := key.filename()
	if err != nil {
		return "", err
	}
	source := filepath.Join(c.Directory, name)
	target := source + fmt.Sprintf(".%d.rejected", time.Now().UnixNano())
	if err := os.Rename(source, target); err != nil {
		return "", err
	}
	return target, nil
}

// WithKeyLock serializes generation for a shared batch across local processes.
// The persistent lock file is not deleted: unlinking it permits a second lock inode.
// flock is released on process exit, including an interrupted prover.
func (c ProofCache) WithKeyLock(ctx context.Context, key ProofCacheKey, fn func() error) error {
	name, err := key.filename()
	if err != nil {
		return err
	}
	if err := os.MkdirAll(c.Directory, 0700); err != nil {
		return err
	}
	file, err := openRegularCacheFile(filepath.Join(c.Directory, name+".lock"), unix.O_CREAT|unix.O_RDWR, 0600)
	if err != nil {
		return err
	}
	defer file.Close()
	for {
		if err := ctx.Err(); err != nil {
			return err
		}
		err = unix.Flock(int(file.Fd()), unix.LOCK_EX|unix.LOCK_NB)
		if err == nil {
			defer unix.Flock(int(file.Fd()), unix.LOCK_UN)
			return fn()
		}
		if !errors.Is(err, unix.EWOULDBLOCK) && !errors.Is(err, unix.EAGAIN) {
			return err
		}
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-time.After(100 * time.Millisecond):
		}
	}
}
