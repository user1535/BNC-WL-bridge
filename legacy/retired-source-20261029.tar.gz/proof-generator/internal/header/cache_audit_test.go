package header

import (
	"context"
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"testing"

	"github.com/ethereum/go-ethereum/common"
	"golang.org/x/sys/unix"
)

func auditKey() ProofCacheKey {
	return ProofCacheKey{SourceChainID: 31337, StartBlock: 1, EndBlock: 1, StartAnchorHash: common.HexToHash("0x1"), EndBlockHash: common.HexToHash("0x2"), BatchRoot: common.HexToHash("0x3"), ImageID: common.HexToHash("0x4")}
}

func TestCacheAuditExactSnapshotSchemasImagesAndNoMutation(t *testing.T) {
	dir := t.TempDir()
	key := auditKey()
	calls := 0
	cache := ProofCache{Directory: dir, Verify: func(proof, journal []byte) error {
		calls++
		if string(proof) != "unit-fixture" {
			return errors.New("unit verifier rejection")
		}
		return nil
	}}
	snapshots := map[string]string{}
	for index := 0; index < 3; index++ {
		k := key
		k.EndBlockHash[31] += byte(index)
		if index == 1 {
			k.ImageID[31]++
		}
		value := CachedProof{Key: k, Journal: journalForKey(k), ProofData: []byte("unit-fixture")}
		if index == 2 {
			value.Version = 2
		}
		raw, _ := json.Marshal(value)
		name, _ := k.filename()
		snapshots[name] = string(raw)
		if err := os.WriteFile(filepath.Join(dir, name), raw, 0600); err != nil {
			t.Fatal(err)
		}
	}
	for name, value := range map[string]string{"artifact.json.lock": "", "artifact.json.1.rejected": "forensic original", ".proof-active": "in-progress"} {
		snapshots[name] = value
		os.WriteFile(filepath.Join(dir, name), []byte(value), 0600)
	}
	report, err := cache.Audit(context.Background(), key.ImageID)
	if err != nil || report.Verdict != "FAIL" || report.Counts["verified"] != 1 || report.Counts["incompatible_image"] != 1 || report.Counts["unsupported_schema"] != 1 || calls != 1 || report.MutationCount != 0 {
		t.Fatalf("wrong audit: %+v %v %d", report, err, calls)
	}
	for name, expected := range snapshots {
		raw, err := os.ReadFile(filepath.Join(dir, name))
		if err != nil || string(raw) != expected {
			t.Fatal("audit mutated proof/lock/quarantine/temp")
		}
	}
}

func TestCacheRejectsSymlinksFIFOsAndOversizedFilesBeforeVerification(t *testing.T) {
	key := auditKey()
	name, _ := key.filename()
	calls := 0
	cache := ProofCache{Directory: t.TempDir(), Verify: func([]byte, []byte) error { calls++; return nil }}
	target := filepath.Join(t.TempDir(), "outside-sentinel")
	os.WriteFile(target, []byte("unchanged"), 0600)
	for _, kind := range []string{"symlink", "fifo", "large"} {
		path := filepath.Join(cache.Directory, name)
		switch kind {
		case "symlink":
			if err := os.Symlink(target, path); err != nil {
				t.Fatal(err)
			}
		case "fifo":
			if err := unix.Mkfifo(path, 0600); err != nil {
				t.Fatal(err)
			}
		case "large":
			file, err := os.Create(path)
			if err != nil {
				t.Fatal(err)
			}
			file.Truncate(maxCacheArtifactBytes + 1)
			file.Close()
		}
		if _, err := cache.Get(key); err == nil {
			t.Fatal("unsafe cache file accepted")
		}
		os.Remove(path)
	}
	lockPath := filepath.Join(cache.Directory, name+".lock")
	os.Symlink(target, lockPath)
	if err := cache.WithKeyLock(context.Background(), key, func() error { t.Fatal("unsafe lock admitted"); return nil }); err == nil {
		t.Fatal("symlink lock accepted")
	}
	if calls != 0 {
		t.Fatal("unsafe cache reached verifier")
	}
	unchanged, _ := os.ReadFile(target)
	if string(unchanged) != "unchanged" {
		t.Fatal("outside sentinel changed")
	}
}

func TestCacheAuditValidSnapshotAndUnknownFiles(t *testing.T) {
	key := auditKey()
	cache := ProofCache{Directory: t.TempDir(), Verify: func([]byte, []byte) error { return nil }}
	if err := cache.Put(CachedProof{Key: key, ProofData: []byte("unit-fixture"), Journal: journalForKey(key)}); err != nil {
		t.Fatal(err)
	}
	report, err := cache.Audit(context.Background(), key.ImageID)
	if err != nil || report.Verdict != "PASS" || report.Entries[0].SHA256 == "" {
		t.Fatal("valid audit failed")
	}
	os.WriteFile(filepath.Join(cache.Directory, "unknown.txt"), []byte("preserve"), 0600)
	report, err = cache.Audit(context.Background(), key.ImageID)
	if err != nil || report.Verdict != "INCONCLUSIVE" {
		t.Fatal("unknown file silently ignored")
	}
	alias := filepath.Join(t.TempDir(), "cache-alias")
	os.Symlink(cache.Directory, alias)
	unsafe := cache
	unsafe.Directory = alias
	if _, err := unsafe.Audit(context.Background(), key.ImageID); err == nil {
		t.Fatal("symlink cache directory accepted")
	}
	os.Chmod(cache.Directory, 0777)
	if _, err := cache.Audit(context.Background(), key.ImageID); err == nil {
		t.Fatal("shared writable directory accepted")
	}
}
