package header

import (
	"context"
	"testing"

	"github.com/ethereum/go-ethereum/common"
)

type reader struct {
	accepted bool
	calls    int
}

func (r *reader) IsBlockCovered(_ context.Context, _, _ uint64, _ common.Hash) (bool, error) {
	r.calls++
	return r.accepted, nil
}

func TestSharedCoverageRequiresOnchainAcceptance(t *testing.T) {
	r := &reader{}
	store, err := NewStore(r)
	if err != nil {
		t.Fatal(err)
	}
	batch := Batch{SourceChainID: 31337, Start: 100, End: 102, AnchorHash: common.HexToHash("0x01"),
		EndHash: common.HexToHash("0x04"), Headers: []HeaderRef{
			{100, common.HexToHash("0x02"), common.HexToHash("0xa1")},
			{101, common.HexToHash("0x03"), common.HexToHash("0xa2")},
			{102, common.HexToHash("0x04"), common.HexToHash("0xa3")},
		}}
	if err := store.AddCandidate(batch); err != nil {
		t.Fatal(err)
	}
	for _, h := range batch.Headers {
		covered, err := store.IsBlockCovered(context.Background(), 31337, h.Number, h.BlockHash)
		if err != nil || covered {
			t.Fatalf("candidate trusted before acceptance: %v %v", covered, err)
		}
	}
	r.accepted = true
	for _, h := range batch.Headers {
		covered, err := store.IsBlockCovered(context.Background(), 31337, h.Number, h.BlockHash)
		if err != nil || !covered {
			t.Fatalf("accepted header not covered: %v %v", covered, err)
		}
	}
	wrong := common.HexToHash("0xff")
	covered, err := store.IsBlockCovered(context.Background(), 31337, 101, wrong)
	if err != nil || covered || r.calls != 6 {
		t.Fatalf("reorg hash accepted or unnecessary onchain call: %v %v %d", covered, err, r.calls)
	}
}
