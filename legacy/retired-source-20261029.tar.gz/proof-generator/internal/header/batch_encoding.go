package header

import (
	"encoding/binary"
	"errors"
	"fmt"
	"math"

	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/crypto"
)

// GuestHeader mirrors the minimal RISC0 guest input and Solidity updater tuple.
type GuestHeader struct {
	Number      uint64
	BlockHash   common.Hash
	ParentHash  common.Hash
	ReceiptRoot common.Hash
}

type BatchArtifacts struct {
	ChainID    uint64
	Start      uint64
	End        uint64
	AnchorHash common.Hash
	EndHash    common.Hash
	BatchRoot  common.Hash
	Journal    []byte // 224-byte guest journal expected from this input; not a proof.
	BatchData  []byte // abi.encode(GuestHeader[]) for Risc0HeaderUpdater.
}

// BuildBatchArtifacts prepares public batch data. It never signs, proves or broadcasts.
func BuildBatchArtifacts(chainID uint64, anchor common.Hash, headers []GuestHeader) (*BatchArtifacts, error) {
	if chainID == 0 || anchor == (common.Hash{}) || len(headers) == 0 || len(headers) > 128 {
		return nil, errors.New("invalid chain, anchor or batch size")
	}
	if headers[0].Number > math.MaxUint64-uint64(len(headers)-1) {
		return nil, errors.New("batch block numbers exceed uint64")
	}
	leaves := make([]common.Hash, len(headers))
	prior := anchor
	for i, header := range headers {
		if header.Number != headers[0].Number+uint64(i) || header.ParentHash != prior ||
			header.BlockHash == (common.Hash{}) || header.ReceiptRoot == (common.Hash{}) {
			return nil, fmt.Errorf("invalid linked header at index %d", i)
		}
		var leafInput [160]byte
		binary.BigEndian.PutUint64(leafInput[24:32], chainID)
		binary.BigEndian.PutUint64(leafInput[56:64], header.Number)
		copy(leafInput[64:96], header.BlockHash[:])
		copy(leafInput[96:128], header.ParentHash[:])
		copy(leafInput[128:160], header.ReceiptRoot[:])
		leaves[i] = crypto.Keccak256Hash(leafInput[:])
		prior = header.BlockHash
	}
	for len(leaves) > 1 {
		next := make([]common.Hash, 0, (len(leaves)+1)/2)
		for i := 0; i < len(leaves); i += 2 {
			right := leaves[i]
			if i+1 < len(leaves) {
				right = leaves[i+1]
			}
			var pair [64]byte
			copy(pair[:32], leaves[i][:])
			copy(pair[32:], right[:])
			next = append(next, crypto.Keccak256Hash(pair[:]))
		}
		leaves = next
	}
	end := headers[len(headers)-1].Number
	journal := make([]byte, 224)
	binary.BigEndian.PutUint64(journal[24:32], chainID)
	binary.BigEndian.PutUint64(journal[56:64], headers[0].Number)
	binary.BigEndian.PutUint64(journal[88:96], end)
	copy(journal[96:128], anchor[:])
	copy(journal[128:160], prior[:])
	copy(journal[160:192], leaves[0][:])
	binary.BigEndian.PutUint64(journal[216:224], uint64(len(headers)))

	// ABI encoding of one dynamic argument: a static tuple array of four 32-byte words.
	batchData := make([]byte, 64+128*len(headers))
	batchData[31] = 32 // offset to the array
	binary.BigEndian.PutUint64(batchData[56:64], uint64(len(headers)))
	for i, header := range headers {
		offset := 64 + 128*i
		binary.BigEndian.PutUint64(batchData[offset+24:offset+32], header.Number)
		copy(batchData[offset+32:offset+64], header.BlockHash[:])
		copy(batchData[offset+64:offset+96], header.ParentHash[:])
		copy(batchData[offset+96:offset+128], header.ReceiptRoot[:])
	}
	return &BatchArtifacts{ChainID: chainID, Start: headers[0].Number, End: end,
		AnchorHash: anchor, EndHash: prior, BatchRoot: leaves[0], Journal: journal, BatchData: batchData}, nil
}
