package header

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"strings"

	"github.com/ethereum/go-ethereum/common"
)

type CacheAuditEntry struct {
	Name    string      `json:"name"`
	Status  string      `json:"status"`
	Bytes   int64       `json:"bytes"`
	SHA256  string      `json:"sha256,omitempty"`
	ImageID common.Hash `json:"imageId"`
	Schema  uint32      `json:"schema"`
	Error   string      `json:"error,omitempty"`
}

type CacheAudit struct {
	Directory       string            `json:"directory"`
	ExpectedImageID common.Hash       `json:"expectedImageId"`
	Verdict         string            `json:"verdict"`
	Counts          map[string]int    `json:"counts"`
	Entries         []CacheAuditEntry `json:"entries"`
	TotalBytes      int64             `json:"totalBytes"`
	MutationCount   int               `json:"mutationCount"`
}

// Audit never generates a proof, edits schema, deletes locks, repairs or evicts.
// An incompatible compiled image needs its own host; it is not a forged proof.
func (c ProofCache) Audit(ctx context.Context, imageID common.Hash) (*CacheAudit, error) {
	if c.Verify == nil || imageID == (common.Hash{}) {
		return nil, errors.New("audit requires verifier and expected compiled image")
	}
	info, err := os.Lstat(c.Directory)
	if err != nil {
		return nil, err
	}
	if !info.IsDir() || info.Mode()&os.ModeSymlink != 0 || info.Mode().Perm()&0022 != 0 {
		return nil, errors.New("audit requires a real cache directory without group/world write permission")
	}
	files, err := os.ReadDir(c.Directory)
	if err != nil {
		return nil, err
	}
	report := &CacheAudit{Directory: c.Directory, ExpectedImageID: imageID, Verdict: "INCONCLUSIVE", Counts: map[string]int{}, Entries: []CacheAuditEntry{}}
	for _, file := range files {
		if err := ctx.Err(); err != nil {
			return nil, err
		}
		path := filepath.Join(c.Directory, file.Name())
		entry := CacheAuditEntry{Name: file.Name()}
		stat, err := os.Lstat(path)
		if err != nil {
			entry.Status = "invalid"
			entry.Error = err.Error()
		} else {
			entry.Bytes = stat.Size()
			report.TotalBytes += stat.Size()
			if !stat.Mode().IsRegular() {
				entry.Status = "unsafe_path"
			} else if strings.HasSuffix(file.Name(), ".lock") {
				entry.Status = "lock_preserved"
			} else if strings.HasSuffix(file.Name(), ".rejected") {
				entry.Status = "quarantine_preserved"
			} else if strings.HasPrefix(file.Name(), ".proof-") {
				entry.Status = "temporary_preserved"
			} else if !strings.HasSuffix(file.Name(), ".json") {
				entry.Status = "unknown_file"
			} else {
				entry.Status = "invalid"
				raw, readErr := readRegularCacheFile(path)
				if readErr != nil {
					entry.Error = readErr.Error()
				} else {
					digest := sha256.Sum256(raw)
					entry.SHA256 = hex.EncodeToString(digest[:])
					var value CachedProof
					if err := json.Unmarshal(raw, &value); err != nil {
						entry.Error = err.Error()
					} else {
						entry.ImageID = value.Key.ImageID
						entry.Schema = value.Version
						name, keyErr := value.Key.filename()
						if keyErr != nil {
							entry.Error = keyErr.Error()
						} else if name != file.Name() {
							entry.Error = "cache filename/key mismatch"
						} else if value.Version > 1 {
							entry.Status = "unsupported_schema"
						} else if value.Key.ImageID != imageID {
							entry.Status = "incompatible_image"
						} else if _, err := c.verifyRaw(value.Key, raw); err != nil {
							entry.Error = err.Error()
						} else {
							entry.Status = "verified"
						}
					}
				}
			}
		}
		report.Entries = append(report.Entries, entry)
		report.Counts[entry.Status]++
	}
	if report.Counts["invalid"]+report.Counts["unsafe_path"]+report.Counts["unsupported_schema"] > 0 {
		report.Verdict = "FAIL"
	} else if report.Counts["verified"] > 0 && report.Counts["unknown_file"]+report.Counts["incompatible_image"] == 0 {
		report.Verdict = "PASS"
	}
	return report, nil
}
