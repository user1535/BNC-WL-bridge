package header

import (
	"bytes"
	"context"
	"encoding/binary"
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"testing"
	"time"

	"github.com/ethereum/go-ethereum/common"
)

func journalForKey(key ProofCacheKey) []byte {
	journal := make([]byte, 224)
	binary.BigEndian.PutUint64(journal[24:32], key.SourceChainID)
	binary.BigEndian.PutUint64(journal[56:64], key.StartBlock)
	binary.BigEndian.PutUint64(journal[88:96], key.EndBlock)
	copy(journal[96:128], key.StartAnchorHash[:])
	copy(journal[128:160], key.EndBlockHash[:])
	copy(journal[160:192], key.BatchRoot[:])
	binary.BigEndian.PutUint64(journal[216:224], key.EndBlock-key.StartBlock+1)
	return journal
}

func TestProofCacheBindsVerifiedJournalToKey(t *testing.T) {
	key := ProofCacheKey{SourceChainID: 31337, StartBlock: 10, EndBlock: 11,
		StartAnchorHash: common.HexToHash("0x01"), EndBlockHash: common.HexToHash("0x02"),
		BatchRoot: common.HexToHash("0x03"), ImageID: common.HexToHash("0x06")}
	verified := 0
	cache := ProofCache{Directory: t.TempDir(), Verify: func(seal, journal []byte) error {
		verified++
		if !bytes.Equal(seal, []byte("valid")) || len(journal) == 0 {
			return errors.New("invalid")
		}
		return nil
	}}
	valid := CachedProof{Key: key, ProofData: []byte("valid"), Journal: journalForKey(key)}
	if err := cache.Put(valid); err != nil {
		t.Fatal(err)
	}
	if _, err := cache.Get(key); err != nil || verified != 2 {
		t.Fatalf("cache proof not verified: %v %d", err, verified)
	}
	reorgKey := key
	reorgKey.EndBlockHash = common.HexToHash("0x04")
	if _, err := cache.Get(reorgKey); !errors.Is(err, os.ErrNotExist) {
		t.Fatalf("reorg reused old cache: %v", err)
	}
	wrongKey := valid
	wrongKey.Key = reorgKey
	if err := cache.Put(wrongKey); err == nil {
		t.Fatal("valid proof cached under a different block hash")
	}
	wrongRoot := valid
	wrongRoot.Key.BatchRoot = common.HexToHash("0x05")
	if err := cache.Put(wrongRoot); err == nil {
		t.Fatal("valid proof cached under a different batch root")
	}
	if err := cache.Put(CachedProof{Key: key, ProofData: []byte("forged"), Journal: journalForKey(key)}); err == nil {
		t.Fatal("forged proof cached")
	}
	name, err := key.filename()
	if err != nil {
		t.Fatal(err)
	}
	path := filepath.Join(cache.Directory, name)
	raw, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	var altered CachedProof
	if err := json.Unmarshal(raw, &altered); err != nil {
		t.Fatal(err)
	}
	altered.Journal[160] ^= 1
	raw, err = json.Marshal(altered)
	if err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(path, raw, 0600); err != nil {
		t.Fatal(err)
	}
	if _, err := cache.Get(key); err == nil {
		t.Fatal("cache accepted altered journal")
	}
	otherImage := key
	otherImage.ImageID = common.HexToHash("0x07")
	if _, err := cache.Get(otherImage); !errors.Is(err, os.ErrNotExist) {
		t.Fatalf("different guest image reused cached receipt: %v", err)
	}
}

func TestSharedBatchLockWaitsAndCancels(t *testing.T) {
	cache := ProofCache{Directory: t.TempDir()}
	key := ProofCacheKey{SourceChainID: 31337, StartBlock: 10, EndBlock: 11,
		StartAnchorHash: common.HexToHash("0x01"), EndBlockHash: common.HexToHash("0x02"),
		BatchRoot: common.HexToHash("0x03"), ImageID: common.HexToHash("0x06")}
	entered, release, done := make(chan struct{}), make(chan struct{}), make(chan error, 1)
	go func() {
		done <- cache.WithKeyLock(context.Background(), key, func() error {
			close(entered)
			<-release
			return nil
		})
	}()
	<-entered
	ctx, cancel := context.WithTimeout(context.Background(), 100*time.Millisecond)
	defer cancel()
	err := cache.WithKeyLock(ctx, key, func() error {
		t.Error("same batch lock admitted a second generator")
		return nil
	})
	close(release)
	if firstErr := <-done; firstErr != nil {
		t.Fatal(firstErr)
	}
	if !errors.Is(err, context.DeadlineExceeded) {
		t.Fatalf("waiting generator did not honor timeout: %v", err)
	}
	if err := cache.WithKeyLock(context.Background(), key, func() error { return nil }); err != nil {
		t.Fatalf("released batch lock could not be reacquired: %v", err)
	}
}

func TestQuarantinePreservesRejectedProofAndAllowsFreshVerifiedPut(t *testing.T) {
	key := ProofCacheKey{SourceChainID: 31337, StartBlock: 1, EndBlock: 1,
		StartAnchorHash: common.HexToHash("0x01"), EndBlockHash: common.HexToHash("0x02"),
		BatchRoot: common.HexToHash("0x03"), ImageID: common.HexToHash("0x04")}
	cache := ProofCache{Directory: t.TempDir(), Verify: func(proof, journal []byte) error {
		if string(proof) != "valid" {
			return errors.New("forged")
		}
		return nil
	}}
	name, _ := key.filename()
	path := filepath.Join(cache.Directory, name)
	if err := os.WriteFile(path, []byte("corrupt artifact"), 0600); err != nil {
		t.Fatal(err)
	}
	if _, err := cache.Get(key); err == nil {
		t.Fatal("corrupt cache accepted")
	}
	err := cache.WithKeyLock(context.Background(), key, func() error {
		quarantined, err := cache.Quarantine(key)
		if err != nil {
			return err
		}
		preserved, err := os.ReadFile(quarantined)
		if err != nil || string(preserved) != "corrupt artifact" {
			t.Fatal("rejected evidence lost")
		}
		if _, err := cache.Get(key); !errors.Is(err, os.ErrNotExist) {
			t.Fatal("quarantine was still reused")
		}
		return cache.Put(CachedProof{Key: key, ProofData: []byte("valid"), Journal: journalForKey(key)})
	})
	if err != nil {
		t.Fatal(err)
	}
	if _, err := cache.Get(key); err != nil {
		t.Fatal(err)
	}
}
