// Copyright 2017 The go-ethereum Authors
// This file is part of the go-ethereum library.
//
// The go-ethereum library is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// The go-ethereum library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with the go-ethereum library. If not, see <http://www.gnu.org/licenses/>.

// Supplied-count harness for one verbatim upstream arithmetic method only.
package types

import "github.com/ethereum/go-ethereum/common"

type Snapshot struct {
	Validators map[common.Address]struct{}
	TurnLength uint8
}

func (s *Snapshot) minerHistoryCheckLen() uint64 {
	return (uint64(len(s.Validators))/2+1)*uint64(s.TurnLength) - 1
}

// SuppliedMinerHistory does not authenticate the count, turn or snapshot.
func SuppliedMinerHistory(count uint8, turn uint8) uint64 {
	validators := make(map[common.Address]struct{}, int(count))
	for i := uint16(1); i <= uint16(count); i++ {
		var address common.Address
		address[18] = byte(i >> 8)
		address[19] = byte(i)
		validators[address] = struct{}{}
	}
	return (&Snapshot{Validators: validators, TurnLength: turn}).minerHistoryCheckLen()
}
