// Copyright 2016 The go-ethereum Authors
// This file is part of the go-ethereum library.
//
// The go-ethereum library is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// The go-ethereum library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with the go-ethereum library. If not, see <http://www.gnu.org/licenses/>.

// Pinned BSC fork predicate harness only; not chain/snapshot authentication.
package types

import "math/big"

type ChainConfig struct {
	LubanBlock, LondonBlock                                                           *big.Int
	BohrTime, LorentzTime, MaxwellTime, FermiTime, OsakaTime, MendelTime, PasteurTime *uint64
}

func newUint64(val uint64) *uint64 { return &val }

func (c *ChainConfig) IsLuban(num *big.Int) bool {
	return isBlockForked(c.LubanBlock, num)
}

func (c *ChainConfig) IsLondon(num *big.Int) bool {
	return isBlockForked(c.LondonBlock, num)
}

func (c *ChainConfig) IsBohr(num *big.Int, time uint64) bool {
	return c.IsLondon(num) && isTimestampForked(c.BohrTime, time)
}

func (c *ChainConfig) IsLorentz(num *big.Int, time uint64) bool {
	return c.IsLondon(num) && isTimestampForked(c.LorentzTime, time)
}

func (c *ChainConfig) IsMaxwell(num *big.Int, time uint64) bool {
	return c.IsLondon(num) && isTimestampForked(c.MaxwellTime, time)
}

func (c *ChainConfig) IsFermi(num *big.Int, time uint64) bool {
	return c.IsLondon(num) && isTimestampForked(c.FermiTime, time)
}

func (c *ChainConfig) IsOsaka(num *big.Int, time uint64) bool {
	return c.IsLondon(num) && isTimestampForked(c.OsakaTime, time)
}

func (c *ChainConfig) IsMendel(num *big.Int, time uint64) bool {
	return c.IsLondon(num) && isTimestampForked(c.MendelTime, time)
}

func (c *ChainConfig) IsPasteur(num *big.Int, time uint64) bool {
	return c.IsLondon(num) && isTimestampForked(c.PasteurTime, time)
}

func isBlockForked(s, head *big.Int) bool {
	if s == nil || head == nil {
		return false
	}
	return s.Cmp(head) <= 0
}

func isTimestampForked(s *uint64, head uint64) bool {
	if s == nil {
		return false
	}
	return *s <= head
}

func PinnedBSCForkConfig() *ChainConfig {
	return &ChainConfig{
		LubanBlock:  big.NewInt(29020050),
		LondonBlock: big.NewInt(31302048),
		BohrTime:    newUint64(1727317200),
		LorentzTime: newUint64(1745903100),
		MaxwellTime: newUint64(1751250600),
		FermiTime:   newUint64(1768357800),
		OsakaTime:   newUint64(1777343400),
		MendelTime:  newUint64(1777343400),
		PasteurTime: newUint64(1787625000),
	}
}
