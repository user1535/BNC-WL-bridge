// Reference encoder harness: synthetic offline fixtures only, not consensus.
package types

import (
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/core/types"
)

type Header struct {
	types.Header
	RequestsHash *common.Hash
}
