// Copyright 2014 The go-ethereum Authors
// This file is part of the go-ethereum library.
//
// The go-ethereum library is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// The go-ethereum library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with the go-ethereum library. If not, see <http://www.gnu.org/licenses/>.

// Package types contains data types related to Ethereum consensus.
// Reference EncodeSigHeader harness only; not consensus.
package types

import (
	"github.com/ethereum/go-ethereum/rlp"
	"io"
	"math/big"
)

const extraSeal = 65 // Pinned block.go seal suffix width.

func EncodeSigHeader(w io.Writer, header *Header, chainId *big.Int) {
	toEncode := []interface{}{
		chainId,
		header.ParentHash,
		header.UncleHash,
		header.Coinbase,
		header.Root,
		header.TxHash,
		header.ReceiptHash,
		header.Bloom,
		header.Difficulty,
		header.Number,
		header.GasLimit,
		header.GasUsed,
		header.Time,
		header.Extra[:len(header.Extra)-extraSeal], // this will panic if extra is too short, should check before calling encodeSigHeader
		header.MixDigest,
		header.Nonce,
	}
	if header.ParentBeaconRoot != nil {
		toEncode = append(toEncode, header.BaseFee,
			header.WithdrawalsHash,
			header.BlobGasUsed,
			header.ExcessBlobGas,
			header.ParentBeaconRoot)

		if header.RequestsHash != nil {
			toEncode = append(toEncode, header.RequestsHash)
		}
	}
	err := rlp.Encode(w, toEncode)
	if err != nil {
		panic("can't encode: " + err.Error())
	}
}
