package benchmark

import "testing"

func TestActualAcceptedVerdict(t *testing.T) {
	p := func(n uint64) *uint64 { return &n }
	fail := []AcceptedObservation{{0, 15, p(15)}, {150, 165, p(19)}, {300, 315, p(23)}}
	v, err := EvaluateAcceptedSeries(fail, 8)
	if err != nil || v.Verdict != "FAIL" || v.MaximumLag != 292 {
		t.Fatalf("%+v %v", v, err)
	}
	static := []AcceptedObservation{{0, 15, p(15)}, {150, 15, p(15)}, {300, 15, p(15)}}
	v, _ = EvaluateAcceptedSeries(static, 8)
	if v.Verdict != "INCONCLUSIVE" {
		t.Fatal("static lag0 cannot prove throughput")
	}
	fail[0].Accepted = nil
	v, _ = EvaluateAcceptedSeries(fail, 8)
	if v.Verdict != "INCONCLUSIVE" {
		t.Fatal("manual anchor cannot become accepted0")
	}
	bounded := []AcceptedObservation{{0, 10, p(10)}, {150, 160, p(160)}, {300, 310, p(310)}}
	v, _ = EvaluateAcceptedSeries(bounded, 8)
	if v.Verdict != "MARGINAL" {
		t.Fatal("matched rate has no measured headroom")
	}
	bounded[2].Source = 9
	if _, err = EvaluateAcceptedSeries(bounded, 8); err == nil {
		t.Fatal("regression accepted")
	}
}
