package benchmark

import "errors"

type Sample struct {
	SourceHead   uint64
	ProofHead    uint64
	AcceptedHead uint64
}

func (s Sample) HeaderLag() uint64 {
	if s.SourceHead <= s.ProofHead {
		return 0
	}
	return s.SourceHead - s.ProofHead
}

func (s Sample) AcceptedLag() uint64 {
	if s.SourceHead <= s.AcceptedHead {
		return 0
	}
	return s.SourceHead - s.AcceptedHead
}

// MeasureLagGrowth requires at least three successive observations with rising lag.
func MeasureLagGrowth(samples []Sample) (bool, error) {
	if len(samples) < 3 {
		return false, errors.New("at least three samples required")
	}
	for i := 1; i < len(samples); i++ {
		if samples[i].SourceHead < samples[i-1].SourceHead {
			return false, errors.New("source head regressed; reorg must be handled separately")
		}
		if samples[i].HeaderLag() <= samples[i-1].HeaderLag() {
			return false, nil
		}
	}
	return true, nil
}

func CalculateHeaderThroughput(count int, durationSeconds float64) (float64, error) {
	if count <= 0 || durationSeconds <= 0 {
		return 0, errors.New("count and duration must be positive")
	}
	return float64(count) / durationSeconds, nil
}

func CalculateRequiredThroughput(blockIntervalSeconds float64) (float64, error) {
	if blockIntervalSeconds <= 0 {
		return 0, errors.New("block interval must be positive")
	}
	return 1 / blockIntervalSeconds, nil
}

type BacklogRisk string

const (
	Pass     BacklogRisk = "PASS"
	Marginal BacklogRisk = "MARGINAL"
	Fail     BacklogRisk = "FAIL"
)

// EvaluateBacklogRisk keeps a 10% margin for measurement noise and block variability.
func EvaluateBacklogRisk(proofThroughput, blockThroughput float64) BacklogRisk {
	if proofThroughput < blockThroughput {
		return Fail
	}
	if proofThroughput < blockThroughput*1.1 {
		return Marginal
	}
	return Pass
}
