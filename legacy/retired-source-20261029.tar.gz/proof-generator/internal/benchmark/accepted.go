package benchmark

import "errors"

type AcceptedObservation struct {
	Elapsed  float64 `json:"elapsedSeconds"`
	Source   uint64  `json:"sourceHead"`
	Accepted *uint64 `json:"acceptedHead"`
}

type AcceptedVerdict struct {
	Verdict      string  `json:"verdict"`
	Reason       string  `json:"reason"`
	Duration     float64 `json:"durationSeconds"`
	SourceRate   float64 `json:"sourceHeadersPerSecond"`
	AcceptedRate float64 `json:"acceptedHeadersPerSecond"`
	MaximumLag   uint64  `json:"maximumAcceptedLag"`
}

// EvaluateAcceptedSeries uses real destination coverage, never a zero placeholder.
func EvaluateAcceptedSeries(samples []AcceptedObservation, maxLag uint64) (AcceptedVerdict, error) {
	v := AcceptedVerdict{Verdict: "INCONCLUSIVE", Reason: "requires at least three observations and 300 seconds of actual coverage under production"}
	if len(samples) < 3 {
		return v, nil
	}
	for i, s := range samples {
		if s.Elapsed < 0 {
			return v, errors.New("negative observation time")
		}
		if s.Accepted == nil {
			return v, nil
		}
		if *s.Accepted > s.Source {
			return v, errors.New("accepted head is ahead of source")
		}
		if i > 0 && (s.Elapsed <= samples[i-1].Elapsed || s.Source < samples[i-1].Source || *s.Accepted < *samples[i-1].Accepted) {
			return v, errors.New("time or head regression; reorganization is not a throughput result")
		}
		lag := s.Source - *s.Accepted
		if lag > v.MaximumLag {
			v.MaximumLag = lag
		}
	}
	a, b := samples[0], samples[len(samples)-1]
	v.Duration = b.Elapsed - a.Elapsed
	if v.Duration < 300 || b.Source == a.Source {
		return v, nil
	}
	v.SourceRate = float64(b.Source-a.Source) / v.Duration
	v.AcceptedRate = float64(*b.Accepted-*a.Accepted) / v.Duration
	if v.MaximumLag > maxLag || v.AcceptedRate < v.SourceRate {
		v.Verdict, v.Reason = "FAIL", "accepted throughput is below source production or observed lag exceeds configured bound"
	} else if EvaluateBacklogRisk(v.AcceptedRate, v.SourceRate) == Marginal {
		v.Verdict, v.Reason = "MARGINAL", "bounded observed lag with less than 10 percent throughput headroom"
	} else {
		v.Verdict, v.Reason = "PASS", "bounded observed lag and at least 10 percent throughput headroom"
	}
	return v, nil
}
