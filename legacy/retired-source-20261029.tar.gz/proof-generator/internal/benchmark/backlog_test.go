package benchmark

import "testing"

func TestLagGrowthAndThroughputGate(t *testing.T) {
	increasing := []Sample{{100, 99, 99}, {110, 107, 107}, {120, 115, 115}}
	growing, err := MeasureLagGrowth(increasing)
	if err != nil || !growing {
		t.Fatalf("missed sustained lag growth: %v %v", growing, err)
	}
	bounded := []Sample{{100, 99, 99}, {110, 108, 108}, {120, 119, 119}}
	growing, err = MeasureLagGrowth(bounded)
	if err != nil || growing {
		t.Fatalf("bounded lag misclassified: %v %v", growing, err)
	}
	throughput, err := CalculateHeaderThroughput(4, 122.917)
	if err != nil || throughput >= 0.04 || throughput <= 0.03 {
		t.Fatalf("bad measured throughput: %f %v", throughput, err)
	}
	required, err := CalculateRequiredThroughput(1)
	if err != nil || EvaluateBacklogRisk(throughput, required) != Fail {
		t.Fatal("1-second source should fail")
	}
}
