// Package bnbseal performs offline Parlia ECDSA mathematics under explicit
// pinned BNB56 serialization assumptions. It never authenticates snapshots.
package bnbseal

import (
	"bytes"
	"encoding/json"
	"errors"
	"math/big"

	"example.com/worldland-bnb-bridge/proof-generator/internal/chain"
	oracle "example.com/worldland-bnb-bridge/proof-generator/internal/protocoloracle/bnb"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/common/hexutil"
	"github.com/ethereum/go-ethereum/core/types"
	"github.com/ethereum/go-ethereum/crypto"
)

type Inspection struct {
	SourceChainID              uint64         `json:"sourceChainId"`
	HeaderHash                 common.Hash    `json:"headerHash"`
	HeaderNumber               uint64         `json:"headerNumber"`
	HeaderRLP                  string         `json:"headerRlp"`
	SealHash                   common.Hash    `json:"sealHash"`
	SealRLP                    hexutil.Bytes  `json:"sealRlp"`
	Signature                  hexutil.Bytes  `json:"signature"`
	Signer                     common.Address `json:"signer"`
	Coinbase                   common.Address `json:"coinbase"`
	SignerMatchesCoinbase      bool           `json:"signerMatchesCoinbase"`
	SnapshotAuthenticated      bool           `json:"snapshotAuthenticated"`
	ConsensusVerified          bool           `json:"consensusVerified"`
	FinalityVerified           bool           `json:"finalityVerified"`
	ChainAuthenticated         bool           `json:"chainAuthenticated"`
	RealAssetDeploymentAllowed bool           `json:"realAssetDeploymentAllowed"`
}

func Inspect(raw []byte, sourceChainID uint64) (*Inspection, error) {
	if sourceChainID != 56 {
		return nil, errors.New("explicit pinned BNB56 seal diagnostic only")
	}
	inspected, err := chain.InspectNativeHeaderJSON(raw, chain.BNBEncoding)
	if err != nil {
		return nil, err
	}
	if !inspected.HashMatchesRPC {
		return nil, errors.New("full header hash differs from supplied RPC hash")
	}
	var header types.Header
	if err = json.Unmarshal(raw, &header); err != nil {
		return nil, err
	}
	var extension struct {
		RequestsHash *common.Hash `json:"requestsHash"`
	}
	if err = json.Unmarshal(raw, &extension); err != nil {
		return nil, err
	}
	if len(header.Extra) < 65 {
		return nil, errors.New("missing Parlia seal")
	}
	signature := bytes.Clone(header.Extra[len(header.Extra)-65:])
	// Deliberate local diagnostic support bound; not a claim about all native
	// ECDSA recoverable IDs or fork policy.
	if signature[64] > 1 {
		return nil, errors.New("diagnostic supports recovery IDs0/1 only")
	}
	var encoded bytes.Buffer
	oracle.EncodeSigHeader(&encoded, &oracle.Header{Header: header, RequestsHash: extension.RequestsHash}, new(big.Int).SetUint64(sourceChainID))
	digest := crypto.Keccak256Hash(encoded.Bytes())
	public, err := crypto.Ecrecover(digest[:], signature)
	if err != nil {
		return nil, err
	}
	signer := common.BytesToAddress(crypto.Keccak256(public[1:])[12:])
	if signer == (common.Address{}) || signer != header.Coinbase {
		return nil, errors.New("seal signer differs from header coinbase")
	}
	return &Inspection{SourceChainID: sourceChainID, HeaderHash: inspected.RecomputedHash, HeaderNumber: inspected.BlockNumber,
		HeaderRLP: inspected.HeaderRLP, SealHash: digest, SealRLP: encoded.Bytes(), Signature: signature,
		Signer: signer, Coinbase: header.Coinbase, SignerMatchesCoinbase: true}, nil
}
