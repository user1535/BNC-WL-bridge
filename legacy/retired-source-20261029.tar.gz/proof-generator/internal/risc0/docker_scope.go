package risc0

import (
	"context"
	"encoding/hex"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"time"
)

// The SDK starts Docker independently of the host process group. A scoped wrapper
// records and labels its container so cancellation cannot leave our prover running.
func scopedDocker() (directory string, cleanup func(), err error) {
	docker, err := exec.LookPath("docker")
	if err != nil {
		return "", nil, err
	}
	docker, err = filepath.Abs(docker)
	if err != nil {
		return "", nil, err
	}
	directory, err = os.MkdirTemp("", "bridge-groth16-*")
	if err != nil {
		return "", nil, err
	}
	label := filepath.Base(directory)
	cidPath := filepath.Join(directory, "container.cid")
	quote := func(s string) string { return "'" + strings.ReplaceAll(s, "'", "'\"'\"'") + "'" }
	wrapper := "#!/bin/sh\nif [ \"$1\" = run ]; then\nshift\nexec " + quote(docker) + " run --cidfile " + quote(cidPath) + " --label " + quote("worldland-bnb.prover="+label) + " \"$@\"\nfi\nexec " + quote(docker) + " \"$@\"\n"
	if err := os.WriteFile(filepath.Join(directory, "docker"), []byte(wrapper), 0700); err != nil {
		os.RemoveAll(directory)
		return "", nil, err
	}
	cleanup = func() {
		defer os.RemoveAll(directory)
		raw, err := os.ReadFile(cidPath)
		if err != nil {
			return
		}
		id := strings.TrimSpace(string(raw))
		decoded, err := hex.DecodeString(id)
		if err != nil || len(decoded) != 32 {
			return
		}
		ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
		defer cancel()
		actual, err := exec.CommandContext(ctx, docker, "inspect", "--format", "{{index .Config.Labels \"worldland-bnb.prover\"}}", id).Output()
		if err == nil && strings.TrimSpace(string(actual)) == label {
			// Exact container ID AND this request's label; no unrelated container is stopped.
			exec.CommandContext(ctx, docker, "rm", "-f", id).Run()
		}
	}
	return directory, cleanup, nil
}
