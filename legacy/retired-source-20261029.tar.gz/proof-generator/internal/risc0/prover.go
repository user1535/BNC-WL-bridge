// Package risc0 connects the keyless generator to the local Rust receipt host.
// Composite receipts are off-chain artifacts and cannot be submitted to the EVM updater.
package risc0

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"syscall"
	"time"

	"example.com/worldland-bnb-bridge/proof-generator/internal/header"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/common/hexutil"
)

type VerifiedReceipt struct {
	HeaderBinding      string      `json:"header_binding"`
	ImageID            common.Hash `json:"image_id"`
	Journal            string      `json:"journal"`
	ReceiptKind        string      `json:"receipt_kind"`
	Verified           bool        `json:"verified"`
	EVMCompatible      bool        `json:"evm_compatible"`
	ChainAuthenticated bool        `json:"chain_authenticated"`
	Seal               string      `json:"seal"`
	VerifierParameters common.Hash `json:"verifier_parameters"`
}

type Result struct {
	ImageID  common.Hash
	Receipt  json.RawMessage
	CacheHit bool
	Verified VerifiedReceipt
}

type LocalProver struct {
	HostPath       string
	CacheDirectory string
	ReceiptKind    string
	RepairCache    bool
	HeaderBinding  string
}

func (p LocalProver) kind() string {
	if p.ReceiptKind == "" {
		return "composite"
	}
	return p.ReceiptKind
}

func (p LocalProver) command(ctx context.Context, args ...string) ([]byte, error) {
	var dockerDirectory string
	if len(args) > 0 && args[0] == "--prove-receipt" && p.kind() == "groth16" {
		directory, cleanup, err := scopedDocker()
		if err != nil {
			return nil, err
		}
		dockerDirectory = directory
		defer cleanup()
	}
	cmd := exec.CommandContext(ctx, p.HostPath, args...)
	// Cancel the r0vm child as well as the host when proving is interrupted.
	cmd.SysProcAttr = &syscall.SysProcAttr{Setpgid: true}
	cmd.Cancel = func() error { return syscall.Kill(-cmd.Process.Pid, syscall.SIGKILL) }
	cmd.WaitDelay = time.Second
	// Use the installed local r0vm; inherited Bonsai configuration must not select a remote service.
	for _, value := range os.Environ() {
		if !strings.HasPrefix(value, "RISC0_PROVER=") && !(dockerDirectory != "" && (strings.HasPrefix(value, "PATH=") || strings.HasPrefix(value, "RISC0_WORK_DIR="))) {
			cmd.Env = append(cmd.Env, value)
		}
	}
	cmd.Env = append(cmd.Env, "RISC0_PROVER=ipc")
	if dockerDirectory != "" {
		cmd.Env = append(cmd.Env, "PATH="+dockerDirectory+string(os.PathListSeparator)+os.Getenv("PATH"), "RISC0_WORK_DIR="+dockerDirectory)
	}
	var stderr bytes.Buffer
	cmd.Stderr = &stderr
	output, err := cmd.Output()
	if err != nil {
		if ctx.Err() != nil {
			return nil, ctx.Err()
		}
		return nil, fmt.Errorf("local RISC0 host failed: %w: %s", err, stderr.String())
	}
	return output, nil
}

func (p LocalProver) VerifyReceipt(ctx context.Context, receipt, journal []byte, imageID common.Hash) (*VerifiedReceipt, error) {
	dir, err := os.MkdirTemp("", "bridge-receipt-verify-*")
	if err != nil {
		return nil, err
	}
	defer os.RemoveAll(dir)
	path := filepath.Join(dir, "receipt.json")
	if err := os.WriteFile(path, receipt, 0600); err != nil {
		return nil, err
	}
	raw, err := p.command(ctx, "--verify-receipt", path)
	if err != nil {
		return nil, err
	}
	var summary VerifiedReceipt
	if err := json.Unmarshal(raw, &summary); err != nil {
		return nil, err
	}
	// Historical hosts without this metadata only support the minimal relation.
	if summary.HeaderBinding == "" {
		summary.HeaderBinding = "minimal-link"
	}
	if p.HeaderBinding != "" && summary.HeaderBinding != p.HeaderBinding {
		return nil, errors.New("receipt host does not prove the requested header binding")
	}
	verifiedJournal, err := hexutil.Decode(summary.Journal)
	if err != nil {
		return nil, err
	}
	if !summary.Verified || summary.ImageID != imageID || summary.ReceiptKind != p.kind() ||
		summary.EVMCompatible != (p.kind() == "groth16") || summary.ChainAuthenticated || !bytes.Equal(journal, verifiedJournal) {
		return nil, errors.New("RISC0 receipt summary does not match the requested guest and journal")
	}
	if summary.EVMCompatible {
		seal, err := hexutil.Decode(summary.Seal)
		if err != nil || len(seal) != 260 || !bytes.Equal(seal[:4], summary.VerifierParameters[:4]) {
			return nil, errors.New("invalid Groth16 EVM seal or selector")
		}
	} else if summary.Seal != "" {
		return nil, errors.New("composite receipt must not contain an EVM seal")
	}
	return &summary, nil
}

// GetOrGenerate verifies both newly generated and cached receipts against the
// compiled guest image and the Go journal. Corrupted caches fail closed.
func (p LocalProver) GetOrGenerate(ctx context.Context, batch *header.BatchArtifacts, input []byte) (*Result, error) {
	if p.HostPath == "" || p.CacheDirectory == "" || batch == nil {
		return nil, errors.New("local RISC0 host, cache directory and batch required")
	}
	if p.kind() != "composite" && p.kind() != "groth16" {
		return nil, errors.New("unsupported receipt kind")
	}
	if p.HeaderBinding != "" {
		if p.HeaderBinding != "minimal-link" && p.HeaderBinding != "canonical-rlp" {
			return nil, errors.New("unsupported header binding")
		}
		if p.HeaderBinding == "canonical-rlp" && batch.End != batch.Start {
			return nil, errors.New("strict canonical RLP proving is limited to one measured header")
		}
		raw, err := p.command(ctx, "--header-binding")
		if err != nil || strings.TrimSpace(string(raw)) != p.HeaderBinding {
			return nil, errors.New("compiled host header binding mismatch")
		}
	}
	if value := os.Getenv("RISC0_DEV_MODE"); value != "" && value != "0" {
		return nil, errors.New("RISC0_DEV_MODE is forbidden for cryptographic proving")
	}
	if (batch.ChainID != 31337 && batch.ChainID != 31338) || batch.End < batch.Start || batch.End-batch.Start >= 4 {
		return nil, errors.New("local composite proving supports chain IDs 31337/31338 and at most 4 headers on this host")
	}
	rawID, err := p.command(ctx, "--image-id")
	if err != nil {
		return nil, err
	}
	imageBytes, err := hexutil.Decode(strings.TrimSpace(string(rawID)))
	if err != nil || len(imageBytes) != 32 {
		return nil, errors.New("invalid guest image ID returned by local host")
	}
	imageID := common.BytesToHash(imageBytes)
	key := header.ProofCacheKey{SourceChainID: batch.ChainID, StartBlock: batch.Start, EndBlock: batch.End,
		StartAnchorHash: batch.AnchorHash, EndBlockHash: batch.EndHash, BatchRoot: batch.BatchRoot, ImageID: imageID}
	var verified *VerifiedReceipt
	cache := header.ProofCache{Directory: filepath.Join(p.CacheDirectory, p.kind()), Verify: func(proofData, journal []byte) error {
		var err error
		verified, err = p.VerifyReceipt(ctx, proofData, journal, imageID)
		return err
	}}
	var result *Result
	err = cache.WithKeyLock(ctx, key, func() error {
		cached, err := cache.Get(key)
		if err == nil {
			if !bytes.Equal(cached.Journal, batch.Journal) {
				return errors.New("cached receipt journal differs from requested batch")
			}
			result = &Result{ImageID: imageID, Receipt: json.RawMessage(cached.ProofData), CacheHit: true, Verified: *verified}
			return nil
		}
		if !errors.Is(err, os.ErrNotExist) {
			if !p.RepairCache || ctx.Err() != nil {
				return err
			}
			if _, quarantineErr := cache.Quarantine(key); quarantineErr != nil {
				return quarantineErr
			}
		}
		dir, err := os.MkdirTemp("", "bridge-receipt-prove-*")
		if err != nil {
			return err
		}
		defer os.RemoveAll(dir)
		inputPath, receiptPath := filepath.Join(dir, "input.json"), filepath.Join(dir, "receipt.json")
		if err := os.WriteFile(inputPath, input, 0600); err != nil {
			return err
		}
		args := []string{"--prove-receipt", "--input", inputPath, "--receipt-output", receiptPath}
		if p.kind() == "groth16" {
			args = append(args, "--receipt-kind", "groth16")
		}
		if _, err := p.command(ctx, args...); err != nil {
			return err
		}
		receipt, err := os.ReadFile(receiptPath)
		if err != nil {
			return err
		}
		if err := cache.Put(header.CachedProof{Key: key, ProofData: receipt, Journal: batch.Journal}); err != nil {
			return err
		}
		result = &Result{ImageID: imageID, Receipt: json.RawMessage(receipt), Verified: *verified}
		return nil
	})
	return result, err
}
