package risc0

import (
	"context"
	"errors"
	"example.com/worldland-bnb-bridge/proof-generator/internal/header"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"syscall"
	"testing"
	"time"
)

func TestStrictBindingRejectsMinimalHostBeforeProving(t *testing.T) {
	dir := t.TempDir()
	host := filepath.Join(dir, "host")
	marker := filepath.Join(dir, "unexpected-command")
	script := "#!/bin/sh\nif [ \"$1\" = --header-binding ]; then printf 'minimal-link\\n'; else touch '" + marker + "'; fi\n"
	if err := os.WriteFile(host, []byte(script), 0700); err != nil {
		t.Fatal(err)
	}
	_, err := (LocalProver{HostPath: host, CacheDirectory: dir, HeaderBinding: "canonical-rlp"}).GetOrGenerate(context.Background(), &header.BatchArtifacts{}, []byte(`{}`))
	if err == nil || !strings.Contains(err.Error(), "compiled host header binding mismatch") {
		t.Fatalf("unexpected result: %v", err)
	}
	if _, err = os.Stat(marker); !errors.Is(err, os.ErrNotExist) {
		t.Fatal("mismatched host started subsequent commands")
	}
}

func TestProverTimeoutStopsChildProcess(t *testing.T) {
	pidPath := filepath.Join(t.TempDir(), "child.pid")
	ctx, cancel := context.WithTimeout(context.Background(), 300*time.Millisecond)
	defer cancel()
	_, err := (LocalProver{HostPath: "/bin/sh"}).command(ctx, "-c", `sleep 30 & printf '%s' "$!" > "$1"; wait`, "prover-test", pidPath)
	if !errors.Is(err, context.DeadlineExceeded) {
		t.Fatalf("prover command did not report its timeout: %v", err)
	}
	raw, err := os.ReadFile(pidPath)
	if err != nil {
		t.Fatal(err)
	}
	pid, err := strconv.Atoi(string(raw))
	if err != nil {
		t.Fatal(err)
	}
	defer syscall.Kill(pid, syscall.SIGKILL)
	// A killed descendant may remain as a zombie until init reaps it.
	status, err := os.ReadFile("/proc/" + strconv.Itoa(pid) + "/stat")
	if errors.Is(err, os.ErrNotExist) {
		return
	}
	if err != nil || !strings.Contains(string(status), ") Z ") {
		t.Fatalf("prover child survived command timeout: %s, %v", status, err)
	}
}

func TestGroth16TimeoutRemovesOnlyScopedDockerContainer(t *testing.T) {
	if os.Getenv("BRIDGE_DOCKER_TEST") != "1" {
		t.Skip("opt-in Docker integration; fast mode does not require Docker")
	}
	const image = "risczero/risc0-groth16-prover:v2025-04-03.1"
	sentinel, err := exec.Command("docker", "run", "--detach", "--entrypoint", "/bin/sh", image, "-c", "sleep 60").Output()
	if err != nil {
		t.Fatal(err)
	}
	id := strings.TrimSpace(string(sentinel))
	defer exec.Command("docker", "rm", "-f", id).Run()
	directory := t.TempDir()
	path := filepath.Join(directory, "host")
	marker := filepath.Join(directory, "scope")
	script := "#!/bin/sh\nprintf '%s' \"${PATH%%:*}\" > '" + marker + "'\ndocker run --rm --entrypoint /bin/sh " + image + " -c 'sleep 60'\n"
	if err := os.WriteFile(path, []byte(script), 0700); err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	_, err = (LocalProver{HostPath: path, ReceiptKind: "groth16"}).command(ctx, "--prove-receipt")
	if !errors.Is(err, context.DeadlineExceeded) {
		t.Fatalf("timeout: %v", err)
	}
	scope, err := os.ReadFile(marker)
	if err != nil {
		t.Fatal(err)
	}
	remaining, err := exec.Command("docker", "ps", "--filter", "label=worldland-bnb.prover="+filepath.Base(string(scope)), "--format", "{{.ID}}").Output()
	if err != nil || strings.TrimSpace(string(remaining)) != "" {
		t.Fatalf("scoped container survived: %s, %v", remaining, err)
	}
	running, err := exec.Command("docker", "inspect", "--format", "{{.State.Running}}", id).Output()
	if err != nil || strings.TrimSpace(string(running)) != "true" {
		t.Fatalf("unrelated container stopped: %s, %v", running, err)
	}
}
