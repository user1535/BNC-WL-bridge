package batch

import (
	"testing"
	"time"
)

func TestPlanBatchSizeAgeAndContinuity(t *testing.T) {
	now := time.Now()
	var h1, h2, h3 Header
	h1.Number, h1.BlockHash, h1.FirstSeen = 10, [32]byte{1}, now
	h2.Number, h2.BlockHash, h2.ParentHash, h2.FirstSeen = 11, [32]byte{2}, h1.BlockHash, now
	h3.Number, h3.BlockHash, h3.ParentHash, h3.FirstSeen = 12, [32]byte{3}, h2.BlockHash, now
	config := ChainBatchConfig{MaxBatchSize: 3, MaxBatchAge: time.Minute}
	got, err := PlanBatch([]Header{h1, h2}, config, now)
	if err != nil || len(got) != 0 {
		t.Fatalf("early batch: %v %v", got, err)
	}
	got, err = PlanBatch([]Header{h1, h2, h3}, config, now)
	if err != nil || len(got) != 3 {
		t.Fatalf("size trigger: %v %v", got, err)
	}
	got, err = PlanBatch([]Header{h1, h2}, config, now.Add(time.Minute))
	if err != nil || len(got) != 2 {
		t.Fatalf("age trigger: %v %v", got, err)
	}
	h2.ParentHash = [32]byte{9}
	if _, err := PlanBatch([]Header{h1, h2, h3}, config, now); err == nil {
		t.Fatal("discontinuous batch accepted")
	}
}
