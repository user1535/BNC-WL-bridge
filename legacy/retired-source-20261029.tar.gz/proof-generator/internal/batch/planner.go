package batch

import (
	"errors"
	"time"
)

type Header struct {
	Number     uint64
	BlockHash  [32]byte
	ParentHash [32]byte
	FirstSeen  time.Time
}

type ChainBatchConfig struct {
	MaxBatchSize int
	MaxBatchAge  time.Duration
}

// PlanBatch returns the oldest contiguous prefix when its size or age trigger fires.
// Headers remain shared by all transfers in that range; this planner never proves per user.
func PlanBatch(pending []Header, config ChainBatchConfig, now time.Time) ([]Header, error) {
	if config.MaxBatchSize <= 0 || config.MaxBatchAge <= 0 {
		return nil, errors.New("batch size and age must be positive")
	}
	if len(pending) == 0 {
		return nil, nil
	}
	limit := len(pending)
	if limit > config.MaxBatchSize {
		limit = config.MaxBatchSize
	}
	for i := 1; i < limit; i++ {
		if pending[i].Number != pending[i-1].Number+1 || pending[i].ParentHash != pending[i-1].BlockHash {
			return nil, errors.New("pending headers are not contiguous")
		}
	}
	if len(pending) < config.MaxBatchSize && now.Sub(pending[0].FirstSeen) < config.MaxBatchAge {
		return nil, nil
	}
	return append([]Header(nil), pending[:limit]...), nil
}
